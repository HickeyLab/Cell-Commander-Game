/**
 * recognition.test.js — pins WHO is allowed to kill WHAT.
 *
 * The recognition rules are the scientific heart of the game: they are what make CAR-T,
 * native CD8, and NK cells teach three different lessons instead of being three colours of
 * the same unit. They are also the easiest thing to get subtly wrong, and two real defects
 * already got through:
 *
 *   1. CD8 recognition was gated on the CAR's target antigen, which left tumor cells that
 *      no killer could touch and made a level unwinnable.
 *   2. CD8 cells attacked HEALTHY tissue matching the CAR target, so a player who bought no
 *      CAR-T cells at all still caused on-target off-tumor toxicity — an incoherent lesson,
 *      since that toxicity is by definition a property of the engineered receptor.
 *
 * Neither was caught by the unit suite, because both were *plausible* behaviour that simply
 * did not match the biology. Hence this file.
 */

import { test, describe, before } from 'node:test';
import assert from 'node:assert/strict';

import { KIND, ANTIGEN, OUTCOME, QUALITY, TICK_DT } from '../src/core/contracts.js';

let createRound;
let LEVELS;
let makePlan;
let addPlacement;

before(async () => {
  ({ createRound } = await import('../src/sim/engine.js'));
  ({ LEVELS } = await import('../src/content/levels.js'));
  ({ makePlan, addPlacement } = await import('../src/sim/plan.js'));
});

/**
 * Build a small arena where HEALTHY cells carry `sharedAntigen`, the tumor carries something
 * else, and the player's CAR is pointed at the shared one. That is the exact configuration
 * that should hurt the patient — but only when CAR-T cells are the ones doing the killing.
 */
function toxicityLevel(sharedAntigen) {
  const base = LEVELS[0];
  return {
    ...base,
    id: 'test-toxicity',
    timeLimitSec: 60,
    tumorEscapeCap: 9999,
    budget: 999,
    tumor: {
      ...base.tumor,
      count: 10,
      antigenMix: { [ANTIGEN.BLUE]: 1 },
      mhcMean: 0.9,
      mhcSd: 0.02,
      pdl1Base: 0,
      pdl1Inducible: 0,
      divideTimeScale: 999, // hold the tumor still; this test is about healthy tissue
    },
    healthy: { count: 24, antigen: sharedAntigen },
    tregs: 0,
  };
}

/** Run a round and report how much the patient suffered. */
function playToxicity(level, killerKind, carTarget) {
  const plan = makePlan({ budget: level.budget, carTarget });
  // Ring the killers tightly around the tumor centre so they meet healthy tissue quickly.
  for (let i = 0; i < 10; i++) {
    const a = (i / 10) * Math.PI * 2;
    addPlacement(
      plan,
      killerKind,
      level.tumor.cx + Math.cos(a) * (level.tumor.spreadWu + 40),
      level.tumor.cy + Math.sin(a) * (level.tumor.spreadWu + 40)
    );
  }
  const round = createRound({ level, plan, seed: 4242, quality: QUALITY.HIGH });
  for (let t = 0; t < Math.ceil(55 / TICK_DT); t++) {
    round.tick(TICK_DT);
    if (round.outcome !== OUTCOME.RUNNING) break;
  }
  return {
    healthyKilled: round.stats?.healthyKilled ?? 0,
    patientHealth: round.patientHealth,
  };
}

describe('on-target off-tumor toxicity belongs to the engineered receptor only', () => {
  test('CAR-T cells DO damage healthy tissue that shares their target flag', () => {
    const level = toxicityLevel(ANTIGEN.ORANGE);
    const r = playToxicity(level, KIND.CART, ANTIGEN.ORANGE);
    assert.ok(
      r.healthyKilled > 0 || r.patientHealth < 100,
      'CAR-T aimed at an antigen healthy cells also carry must harm the patient — this is ' +
        'the consequence that teaches target selection, and it must stay real'
    );
  });

  test('native CD8 cells do NOT, even with the same flag chosen', () => {
    const level = toxicityLevel(ANTIGEN.ORANGE);
    const r = playToxicity(level, KIND.CD8, ANTIGEN.ORANGE);
    assert.equal(
      r.healthyKilled,
      0,
      'an unmodified CD8 T cell has no receptor for the CAR target, so it cannot commit ' +
        'on-target off-tumor toxicity. It killed ' + r.healthyKilled + ' healthy cells.'
    );
    assert.equal(r.patientHealth, 100, 'patient health should be untouched by CD8 alone');
  });

  test('NK cells do not attack healthy tissue either', () => {
    const level = toxicityLevel(ANTIGEN.ORANGE);
    const r = playToxicity(level, KIND.NK, ANTIGEN.ORANGE);
    assert.equal(r.healthyKilled, 0, 'NK missing-self should not fire on normal healthy cells');
  });
});

describe('every tumor cell is killable by something', () => {
  test('CD8 and NK recognition partition the MHC-I range with no gap', async () => {
    // If a gap opened between the CD8 floor and the NK ceiling, cells landing in it would be
    // invincible and a level could become unwinnable — which is exactly what happened once.
    const P = await import('../src/sim/params.js');
    assert.equal(
      P.MHC_RECOGNITION_MIN,
      P.NK_MISSING_SELF_MAX,
      'a gap (or overlap) between CD8 and NK recognition leaves tumor cells nothing can kill'
    );
  });

  test('no tumor cell survives when both lineages are present, regardless of flag', () => {
    // Mixed antigens including flag-less cells, and MHC spread across the whole range.
    const base = LEVELS[0];
    const level = {
      ...base,
      id: 'test-coverage',
      timeLimitSec: 260,
      tumorEscapeCap: 9999,
      budget: 999,
      tumor: {
        ...base.tumor,
        count: 24,
        antigenMix: { [ANTIGEN.GREEN]: 0.4, [ANTIGEN.BLUE]: 0.2, [ANTIGEN.NONE]: 0.4 },
        mhcMean: 0.5,
        mhcSd: 0.35, // deliberately wide: cells land on both sides of the recognition line
        pdl1Base: 0,
        pdl1Inducible: 0,
        divideTimeScale: 999,
      },
      healthy: { count: 0, antigen: ANTIGEN.NONE },
      tregs: 0,
    };

    const plan = makePlan({ budget: level.budget, carTarget: ANTIGEN.GREEN });
    const mix = [KIND.CD8, KIND.NK, KIND.CART];
    for (let i = 0; i < 18; i++) {
      const a = i * 2.399963;
      const rad = level.tumor.spreadWu + 40 + (i % 3) * 26;
      addPlacement(
        plan,
        mix[i % mix.length],
        level.tumor.cx + Math.cos(a) * rad,
        level.tumor.cy + Math.sin(a) * rad
      );
    }

    const round = createRound({ level, plan, seed: 11, quality: QUALITY.HIGH });
    // Generous clock: this test is about COVERAGE (is every cell killable by something?),
    // not speed. A lone survivor that the killers simply have not walked into yet would
    // otherwise look identical to a genuine gap in the recognition rules.
    for (let t = 0; t < Math.ceil(255 / TICK_DT); t++) {
      round.tick(TICK_DT);
      if (round.outcome !== OUTCOME.RUNNING) break;
    }
    assert.equal(
      round.tumorCount,
      0,
      `${round.tumorCount} tumor cells survived a combined CD8 + NK + CAR-T assault with no ` +
        `shield and no growth. Something in the recognition rules is leaving cells that ` +
        `nothing can kill.`
    );
  });
});
