/**
 * macrophage.js owns IFN-gamma/suppression-driven polarization, M1
 * phagocytic killing and chemokines, and M2 suppressive cytokine output.
 */

import { FIELD, STATE } from '../../core/contracts.js';
import { P } from '../params.js';

/**
 * Update one macrophage without allocating.
 * @param {object} round
 * @param {number} i
 * @param {number} dt
 * @returns {void}
 */
export function updateMacrophage(round, i, dt) {
  const world = round.world;
  const ifng = round.grid.sample(FIELD.IFNG, world.x[i], world.y[i]);
  const suppress = round.grid.sample(FIELD.SUPPRESS, world.x[i], world.y[i]);
  const ifngDrive = ifng / (P.kHalf.ifng + ifng);
  const suppressDrive = suppress / (P.kHalf.suppress + suppress);
  const previousState = world.state[i];
  world.a0[i] = Math.max(
    -1,
    Math.min(1, world.a0[i] + (ifngDrive - suppressDrive) * P.macro.polarizeRate * dt),
  );

  if (world.a0[i] > P.macro.polarizeThreshold) {
    world.state[i] = STATE.M1;
  } else if (world.a0[i] < -P.macro.polarizeThreshold) {
    world.state[i] = STATE.M2;
  } else {
    world.state[i] = STATE.M0;
  }
  if (world.state[i] !== previousState
    && (world.state[i] === STATE.M1 || world.state[i] === STATE.M2)) {
    round._queueEvent(4, world.x[i], world.y[i], world.state[i], 0);
  }

  let engaged = false;
  if (world.state[i] === STATE.M1) {
    round.grid.deposit(
      FIELD.CHEMOKINE,
      world.x[i],
      world.y[i],
      P.production.chemokineM1 * dt,
    );
    if (world.timer[i] > 0) {
      world.timer[i] = Math.max(0, world.timer[i] - dt);
    } else {
      const target = round._findTarget(i);
      if (target >= 0) {
        engaged = true;
        world.a3[i] = target;
        round._damageTarget(i, target, dt);
      }
    }
  } else if (world.state[i] === STATE.M2) {
    round.grid.deposit(
      FIELD.SUPPRESS,
      world.x[i],
      world.y[i],
      P.production.suppressM2 * dt,
    );
    world.a3[i] = -1;
  }
  round._move(i, FIELD.CHEMOKINE, engaged);
}
