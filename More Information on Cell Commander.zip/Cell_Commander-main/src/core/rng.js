/**
 * rng.js owns deterministic pseudo-random streams, stable string hashing, and
 * local-calendar daily seeds so simulations replay identically across runtimes.
 */

const UINT32_SCALE = 4294967296;
const MULBERRY_INCREMENT = 0x6d2b79f5;
const TWO_PI = Math.PI * 2;

function mix32(value) {
  let mixed = value >>> 0;
  mixed = Math.imul(mixed ^ (mixed >>> 16), 0x21f0aaad);
  mixed = Math.imul(mixed ^ (mixed >>> 15), 0x735a2d97);
  return (mixed ^ (mixed >>> 15)) >>> 0;
}

/**
 * Create a deterministic mulberry32 random stream.
 * @param {number} seed Unsigned 32-bit seed (other numeric values are coerced).
 * @returns {object} Random stream and helper methods.
 */
export function makeRng(seed) {
  const initialSeed = seed >>> 0;
  let currentState = initialSeed;

  function next() {
    currentState = (currentState + MULBERRY_INCREMENT) >>> 0;
    let value = currentState;
    value = Math.imul(value ^ (value >>> 15), value | 1);
    value ^= value + Math.imul(value ^ (value >>> 7), value | 61);
    return ((value ^ (value >>> 14)) >>> 0) / UINT32_SCALE;
  }

  return {
    next,

    int(nExclusive) {
      if (!Number.isInteger(nExclusive) || nExclusive <= 0) {
        throw new RangeError('nExclusive must be a positive integer');
      }
      return Math.floor(next() * nExclusive);
    },

    range(lo, hi) {
      return lo + (hi - lo) * next();
    },

    pick(array) {
      if (array.length === 0) {
        return undefined;
      }
      return array[Math.floor(next() * array.length)];
    },

    bool(p) {
      return next() < p;
    },

    gauss(mean = 0, sd = 1) {
      let uniform = next();
      while (uniform === 0) {
        uniform = next();
      }
      const normal = Math.sqrt(-2 * Math.log(uniform)) * Math.cos(TWO_PI * next());
      return mean + normal * sd;
    },

    angle() {
      return next() * TWO_PI;
    },

    fork(salt) {
      const salted = initialSeed ^ mix32((salt >>> 0) ^ 0x9e3779b9);
      return makeRng(mix32(salted));
    },

    state() {
      return currentState >>> 0;
    },

    restore(snapshot) {
      currentState = snapshot >>> 0;
    },
  };
}

/**
 * Hash a string into a stable unsigned 32-bit FNV-1a seed.
 * @param {string} s String to hash.
 * @returns {number} Unsigned 32-bit hash.
 */
export function seedFromString(s) {
  const text = String(s);
  let hash = 0x811c9dc5;

  for (let i = 0; i < text.length; i += 1) {
    hash = Math.imul(hash ^ text.charCodeAt(i), 0x01000193);
  }

  return hash >>> 0;
}

/**
 * Derive a level seed from the supplied local calendar day.
 * @param {string} levelId Stable level identifier.
 * @param {Date} [date=new Date()] Date whose local calendar fields are used.
 * @returns {number} Unsigned 32-bit seed.
 */
export function dailySeed(levelId, date = new Date()) {
  const year = date.getFullYear();
  const month = date.getMonth() + 1;
  const day = date.getDate();
  return seedFromString(`${levelId}\0${year}-${month}-${day}`);
}
