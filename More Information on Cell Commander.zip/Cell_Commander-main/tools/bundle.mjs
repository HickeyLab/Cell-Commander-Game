#!/usr/bin/env node
/**
 * Zero-dependency offline bundler for Cell Commander.
 *
 * Native browser modules are converted into ordered IIFEs backed by a small
 * export registry. CSS and local image/font references become inline data, so
 * the generated HTML can be opened directly from an iPad's Files app.
 */

import { readFile, mkdir, writeFile } from 'node:fs/promises';
import { gzipSync } from 'node:zlib';
import {
  dirname,
  extname,
  isAbsolute,
  join,
  relative,
  resolve,
  sep,
} from 'node:path';
import { fileURLToPath } from 'node:url';

const ROOT = resolve(fileURLToPath(new URL('..', import.meta.url)));
const INDEX_PATH = join(ROOT, 'index.html');
const args = new Set(process.argv.slice(2));
const artifactMode = args.has('--artifact');
const checkMode = args.has('--check');
const unknownArgs = [...args].filter((arg) => arg !== '--artifact' && arg !== '--check');

const MIME = {
  '.avif': 'image/avif',
  '.gif': 'image/gif',
  '.ico': 'image/x-icon',
  '.jpeg': 'image/jpeg',
  '.jpg': 'image/jpeg',
  '.otf': 'font/otf',
  '.png': 'image/png',
  '.svg': 'image/svg+xml',
  '.ttf': 'font/ttf',
  '.webp': 'image/webp',
  '.woff': 'font/woff',
  '.woff2': 'font/woff2',
};

function displayPath(path) {
  return relative(ROOT, path).split(sep).join('/');
}

function insideRoot(path) {
  const rel = relative(ROOT, path);
  return rel === '' || (!rel.startsWith('..' + sep) && rel !== '..' && !isAbsolute(rel));
}

function htmlAttribute(attributes, name) {
  const match = attributes.match(
    new RegExp(`\\b${name}\\s*=\\s*(?:"([^"]*)"|'([^']*)'|([^\\s"'=<>]+))`, 'i')
  );
  return match ? (match[1] ?? match[2] ?? match[3]) : null;
}

function isRemoteReference(value) {
  return /^(?:[a-z][a-z0-9+.-]*:)?\/\//i.test(value)
    || /^(?:blob|javascript|mailto|tel):/i.test(value);
}

function localReferencePath(reference, baseDir) {
  const clean = decodeURIComponent(reference.split('#')[0].split('?')[0]);
  const path = resolve(baseDir, clean);
  if (!insideRoot(path)) {
    throw new Error(`asset escapes the project root: ${reference}`);
  }
  return path;
}

async function dataUriFor(reference, baseDir) {
  if (!reference || reference.startsWith('data:') || reference.startsWith('#')) {
    return reference;
  }
  if (isRemoteReference(reference)) return reference;

  const path = localReferencePath(reference, baseDir);
  const mime = MIME[extname(path).toLowerCase()];
  if (!mime) return reference;

  let bytes;
  try {
    bytes = await readFile(path);
  } catch {
    throw new Error(`referenced asset not found: ${displayPath(path)}`);
  }
  return `data:${mime};base64,${bytes.toString('base64')}`;
}

async function replaceAsync(input, regex, replacer) {
  const matches = [...input.matchAll(regex)];
  if (matches.length === 0) return input;
  const replacements = await Promise.all(matches.map((match) => replacer(...match)));
  let output = '';
  let cursor = 0;
  for (let i = 0; i < matches.length; i += 1) {
    const match = matches[i];
    output += input.slice(cursor, match.index) + replacements[i];
    cursor = match.index + match[0].length;
  }
  return output + input.slice(cursor);
}

async function inlineCssUrls(css, baseDir) {
  return replaceAsync(
    css,
    /url\(\s*(?:"([^"]*)"|'([^']*)'|([^'")\s][^)]*?))\s*\)/gi,
    async (whole, doubleQuoted, singleQuoted, bare) => {
      const reference = (doubleQuoted ?? singleQuoted ?? bare ?? '').trim();
      const inlined = await dataUriFor(reference, baseDir);
      return `url("${inlined}")`;
    }
  );
}

async function inlineHtmlAssets(html, baseDir) {
  let output = await replaceAsync(
    html,
    /\b(src|href|poster)\s*=\s*(?:"([^"]*)"|'([^']*)'|([^\s"'=<>]+))/gi,
    async (whole, attribute, doubleQuoted, singleQuoted, bare) => {
      const reference = doubleQuoted ?? singleQuoted ?? bare ?? '';
      const inlined = await dataUriFor(reference, baseDir);
      return `${attribute}="${inlined}"`;
    }
  );

  output = await replaceAsync(
    output,
    /\bsrcset\s*=\s*(?:"([^"]*)"|'([^']*)')/gi,
    async (whole, doubleQuoted, singleQuoted) => {
      const value = doubleQuoted ?? singleQuoted ?? '';
      if (value.includes('data:')) return `srcset="${value}"`;
      const candidates = value.split(',');
      const inlined = [];
      for (const candidate of candidates) {
        const [reference, ...descriptor] = candidate.trim().split(/\s+/);
        const uri = await dataUriFor(reference, baseDir);
        inlined.push([uri, ...descriptor].join(' '));
      }
      return `srcset="${inlined.join(', ')}"`;
    }
  );

  return inlineCssUrls(output, baseDir);
}

function resolveModule(importerPath, specifier) {
  if (!specifier.startsWith('./') && !specifier.startsWith('../')) {
    throw new Error(
      `${displayPath(importerPath)} imports non-local module "${specifier}"; `
      + 'standalone builds only support relative modules'
    );
  }
  const resolved = resolve(dirname(importerPath), specifier.split('?')[0].split('#')[0]);
  if (!insideRoot(resolved)) {
    throw new Error(`${displayPath(importerPath)} imports outside the project: ${specifier}`);
  }
  return resolved;
}

function staticDependencies(source) {
  const statements = [];
  const importFromPattern =
    /^[ \t]*import\s+(?!['"])([\s\S]*?)\s+from\s+(['"])([^'"]+)\2\s*(?:with\s*\{[^}]*\})?\s*;?/gm;
  const sideEffectImportPattern =
    /^[ \t]*import\s*(['"])([^'"]+)\1\s*(?:with\s*\{[^}]*\})?\s*;?/gm;
  const reexportPattern =
    /^[ \t]*export\s+(\{[\s\S]*?\}|\*\s*(?:as\s+[A-Za-z_$][\w$]*)?)\s+from\s+(['"])([^'"]+)\2\s*;?/gm;

  for (const match of source.matchAll(importFromPattern)) {
    statements.push({
      start: match.index,
      end: match.index + match[0].length,
      kind: 'import',
      clause: (match[1] || '').trim(),
      specifier: match[3],
    });
  }
  for (const match of source.matchAll(sideEffectImportPattern)) {
    statements.push({
      start: match.index,
      end: match.index + match[0].length,
      kind: 'import',
      clause: '',
      specifier: match[2],
    });
  }
  for (const match of source.matchAll(reexportPattern)) {
    statements.push({
      start: match.index,
      end: match.index + match[0].length,
      kind: 'reexport',
      clause: match[1].trim(),
      specifier: match[3],
    });
  }

  statements.sort((a, b) => a.start - b.start);
  for (let i = 1; i < statements.length; i += 1) {
    if (statements[i].start < statements[i - 1].end) {
      throw new Error('could not unambiguously parse static module statements');
    }
  }
  return statements;
}

function splitCommaList(value) {
  const parts = [];
  let start = 0;
  let depth = 0;
  let quote = '';
  let escaped = false;
  for (let i = 0; i < value.length; i += 1) {
    const char = value[i];
    if (quote) {
      if (escaped) {
        escaped = false;
      } else if (char === '\\') {
        escaped = true;
      } else if (char === quote) {
        quote = '';
      }
      continue;
    }
    if (char === '"' || char === '\'' || char === '`') {
      quote = char;
    } else if (char === '(' || char === '[' || char === '{') {
      depth += 1;
    } else if (char === ')' || char === ']' || char === '}') {
      depth -= 1;
    } else if (char === ',' && depth === 0) {
      parts.push(value.slice(start, i).trim());
      start = i + 1;
    }
  }
  parts.push(value.slice(start).trim());
  return parts.filter(Boolean);
}

function parseNamedBindings(block) {
  return splitCommaList(block.slice(1, -1)).map((part) => {
    const match = part.match(
      /^([A-Za-z_$][\w$]*|['"][^'"]+['"])(?:\s+as\s+([A-Za-z_$][\w$]*))?$/
    );
    if (!match) throw new Error(`unsupported named import/export binding: ${part}`);
    const imported = match[1].replace(/^['"]|['"]$/g, '');
    return { imported, local: match[2] || imported };
  });
}

function importReplacement(clause, moduleId) {
  const registry = `__ccModules[${JSON.stringify(moduleId)}]`;
  if (!clause) return `void ${registry};`;

  const declarations = [];
  let rest = clause.trim();
  if (!rest.startsWith('{') && !rest.startsWith('*')) {
    const comma = rest.indexOf(',');
    const local = (comma < 0 ? rest : rest.slice(0, comma)).trim();
    if (!/^[A-Za-z_$][\w$]*$/.test(local)) {
      throw new Error(`unsupported default import binding: ${local}`);
    }
    declarations.push(`const ${local} = ${registry}.default;`);
    rest = comma < 0 ? '' : rest.slice(comma + 1).trim();
  }

  if (rest.startsWith('{')) {
    const bindings = parseNamedBindings(rest);
    for (const { imported, local } of bindings) {
      declarations.push(`const ${local} = ${registry}[${JSON.stringify(imported)}];`);
    }
  } else if (rest.startsWith('*')) {
    const match = rest.match(/^\*\s+as\s+([A-Za-z_$][\w$]*)$/);
    if (!match) throw new Error(`unsupported namespace import: ${rest}`);
    declarations.push(`const ${match[1]} = ${registry};`);
  } else if (rest) {
    throw new Error(`unsupported import clause: ${clause}`);
  }
  return declarations.join('\n');
}

function reexportReplacement(clause, moduleId) {
  const registry = `__ccModules[${JSON.stringify(moduleId)}]`;
  if (clause === '*') {
    return `{ const __source = ${registry}; for (const __key of Object.keys(__source)) { `
      + `if (__key !== 'default') __exports[__key] = __source[__key]; } }`;
  }
  const namespace = clause.match(/^\*\s+as\s+([A-Za-z_$][\w$]*)$/);
  if (namespace) {
    return `__exports[${JSON.stringify(namespace[1])}] = ${registry};`;
  }
  const bindings = parseNamedBindings(clause);
  return bindings.map(({ imported, local }) => (
    `__exports[${JSON.stringify(local)}] = ${registry}[${JSON.stringify(imported)}];`
  )).join('\n');
}

function rewriteLocalExports(source, moduleId) {
  const exports = [];
  let defaultCounter = 0;

  source = source.replace(
    /^([ \t]*)export\s+default\s+(async\s+)?function(\s*\*)?\s+([A-Za-z_$][\w$]*)/gm,
    (whole, indent, asyncKeyword = '', star = '', name) => {
      exports.push({ exported: 'default', local: name });
      return `${indent}${asyncKeyword || ''}function${star || ''} ${name}`;
    }
  );
  source = source.replace(
    /^([ \t]*)export\s+default\s+class\s+([A-Za-z_$][\w$]*)/gm,
    (whole, indent, name) => {
      exports.push({ exported: 'default', local: name });
      return `${indent}class ${name}`;
    }
  );
  source = source.replace(
    /^([ \t]*)export\s+default\s+/gm,
    (whole, indent) => {
      const local = `__defaultExport${defaultCounter}`;
      defaultCounter += 1;
      exports.push({ exported: 'default', local });
      return `${indent}const ${local} = `;
    }
  );
  source = source.replace(
    /^([ \t]*)export\s+((?:async\s+)?function(?:\s*\*)?|class)\s+([A-Za-z_$][\w$]*)/gm,
    (whole, indent, declaration, name) => {
      exports.push({ exported: name, local: name });
      return `${indent}${declaration} ${name}`;
    }
  );
  source = source.replace(
    /^([ \t]*)export\s+(const|let|var)\s+([\s\S]*?);(?=[ \t]*(?:(?:\/\/[^\r\n]*)?\r?\n|$))/gm,
    (whole, indent, declaration, body) => {
      for (const part of splitCommaList(body)) {
        const match = part.match(/^([A-Za-z_$][\w$]*)\s*(?:=|$)/);
        if (!match) {
          throw new Error(`${moduleId} has an unsupported exported variable declaration`);
        }
        exports.push({ exported: match[1], local: match[1] });
      }
      return `${indent}${declaration} ${body};`;
    }
  );
  source = source.replace(
    /^([ \t]*)export\s*\{([\s\S]*?)\}\s*;?/gm,
    (whole, indent, body) => {
      for (const { imported, local } of parseNamedBindings(`{${body}}`)) {
        exports.push({ exported: local, local: imported });
      }
      return indent;
    }
  );

  if (/^[ \t]*export\b/m.test(source)) {
    throw new Error(`${moduleId} contains an export form the bundler does not support`);
  }

  const seen = new Set();
  const assignments = [];
  for (const item of exports) {
    if (seen.has(item.exported)) {
      throw new Error(`${moduleId} exports "${item.exported}" more than once`);
    }
    seen.add(item.exported);
    assignments.push(
      `__exports[${JSON.stringify(item.exported)}] = ${item.local};`
    );
  }
  return `${source.trim()}\n${assignments.join('\n')}`;
}

function compileModule(module) {
  let source = module.source;
  const replacements = module.statements.map((statement) => {
    const dependencyPath = resolveModule(module.path, statement.specifier);
    const moduleId = displayPath(dependencyPath);
    const text = statement.kind === 'import'
      ? importReplacement(statement.clause, moduleId)
      : reexportReplacement(statement.clause, moduleId);
    return { start: statement.start, end: statement.end, text };
  }).sort((a, b) => b.start - a.start);

  for (const replacement of replacements) {
    source = source.slice(0, replacement.start)
      + replacement.text
      + source.slice(replacement.end);
  }
  source = rewriteLocalExports(source, module.id);

  return `__ccModules[${JSON.stringify(module.id)}] = (() => {\n`
    + 'const __exports = Object.create(null);\n'
    + `${source}\nreturn __exports;\n})();`;
}

async function moduleGraph(entryPaths) {
  const modules = new Map();
  const state = new Map();
  const stack = [];
  const ordered = [];

  async function visit(path) {
    const status = state.get(path) || 0;
    if (status === 2) return;
    if (status === 1) {
      const cycleStart = stack.indexOf(path);
      const cycle = [...stack.slice(cycleStart), path].map(displayPath);
      throw new Error(`module cycle detected: ${cycle.join(' -> ')}`);
    }

    let source;
    try {
      source = await readFile(path, 'utf8');
    } catch {
      throw new Error(`module not found: ${displayPath(path)}`);
    }
    const statements = staticDependencies(source);
    const module = { path, id: displayPath(path), source, statements };
    modules.set(path, module);
    state.set(path, 1);
    stack.push(path);
    for (const statement of statements) {
      await visit(resolveModule(path, statement.specifier));
    }
    stack.pop();
    state.set(path, 2);
    ordered.push(module);
  }

  for (const entryPath of entryPaths) await visit(entryPath);
  return ordered;
}

async function parseHtml(html) {
  const entryPaths = [];
  const styles = [];
  let output = html;

  output = await replaceAsync(
    output,
    /<script\b([^>]*)>[\s\S]*?<\/script\s*>/gi,
    async (whole, attributes) => {
      const type = (htmlAttribute(attributes, 'type') || '').toLowerCase();
      if (type !== 'module') return whole;
      const src = htmlAttribute(attributes, 'src');
      if (!src) {
        throw new Error('inline type="module" scripts are not supported; move the code to a module');
      }
      if (isRemoteReference(src)) {
        throw new Error(`module entry must be local: ${src}`);
      }
      entryPaths.push(localReferencePath(src, ROOT));
      return '';
    }
  );

  output = await replaceAsync(
    output,
    /<link\b[^>]*>/gi,
    async (whole) => {
      const relValue = (htmlAttribute(whole, 'rel') || '').toLowerCase();
      const rels = relValue.split(/\s+/);
      const href = htmlAttribute(whole, 'href');
      if (rels.includes('manifest')) return '';
      if (!rels.includes('stylesheet')) return whole;
      if (!href) throw new Error('stylesheet link is missing href');
      if (isRemoteReference(href)) {
        throw new Error(`stylesheet must be local: ${href}`);
      }
      const cssPath = localReferencePath(href, ROOT);
      let css;
      try {
        css = await readFile(cssPath, 'utf8');
      } catch {
        throw new Error(`stylesheet not found: ${displayPath(cssPath)}`);
      }
      styles.push(await inlineCssUrls(css, dirname(cssPath)));
      return '';
    }
  );

  if (entryPaths.length === 0) {
    throw new Error('index.html has no <script type="module" src="..."> entry');
  }
  output = await inlineHtmlAssets(output, ROOT);
  return { html: output, entryPaths, css: styles.join('\n\n') };
}

function insertBeforeClosing(html, tag, content) {
  const pattern = new RegExp(`</${tag}\\s*>`, 'i');
  // A FUNCTION replacer, never a string one. String replacements expand $&, $`, $', and
  // $1..$9, and `content` here is the entire bundled application. A single `$'` anywhere in
  // the source — for example in a regex literal like '^2x$' — splices the rest of the
  // document into the middle of a string and yields a bundle that will not parse. That
  // happened, and the syntax error pointed at the innocent source line rather than at here.
  if (pattern.test(html)) return html.replace(pattern, () => `${content}\n</${tag}>`);
  return `${html}\n${content}`;
}

/**
 * XML namespace URIs are identifiers, not resources. `document.createElementNS` REQUIRES the
 * literal string 'http://www.w3.org/2000/svg' to build an SVG element, and nothing is ever
 * fetched from it. Treating them as external references made the self-containment guard fail
 * on a bundle that was in fact perfectly offline.
 */
const NAMESPACE_URIS = [
  'http://www.w3.org/2000/svg',
  'http://www.w3.org/1999/xhtml',
  'http://www.w3.org/1999/xlink',
  'http://www.w3.org/XML/1998/namespace',
  'http://www.w3.org/2000/xmlns/',
];

/** Blank out namespace URIs so the scan below only sees genuine network references. */
function withoutNamespaceUris(text) {
  let out = text;
  for (const uri of NAMESPACE_URIS) out = out.split(uri).join('');
  return out;
}

function assertStandalone(rawOutput) {
  const output = withoutNamespaceUris(rawOutput);
  const problems = [];
  if (/https?:\/\//i.test(output)) {
    // Report the offenders rather than just saying one exists — a bare "external reference
    // found" message sends whoever hits this hunting through 300 KB of bundled output.
    const found = [...new Set(output.match(/https?:\/\/[^\s'"`)<>]{0,80}/gi) || [])].slice(0, 8);
    problems.push(`external URL(s): ${found.join(', ')}`);
  }

  const attrPattern = /\b(src|href|poster)\s*=\s*(?:"([^"]*)"|'([^']*)'|([^\s"'=<>]+))/gi;
  for (const match of output.matchAll(attrPattern)) {
    const value = match[2] ?? match[3] ?? match[4] ?? '';
    if (!value.startsWith('data:') && !value.startsWith('#')) {
      problems.push(`${match[1]}="${value}"`);
    }
  }
  const srcsetPattern = /\bsrcset\s*=\s*(?:"([^"]*)"|'([^']*)')/gi;
  for (const match of output.matchAll(srcsetPattern)) {
    const value = match[1] ?? match[2] ?? '';
    if (!value.startsWith('data:')) problems.push(`srcset="${value}"`);
  }
  for (const match of output.matchAll(/url\(\s*(?:"([^"]*)"|'([^']*)'|([^)]*))\s*\)/gi)) {
    const value = (match[1] ?? match[2] ?? match[3] ?? '').trim();
    if (!value.startsWith('data:') && !value.startsWith('#')) {
      problems.push(`url(${value})`);
    }
  }

  if (problems.length > 0) {
    const unique = [...new Set(problems)];
    throw new Error(`standalone scan found external references: ${unique.join(', ')}`);
  }
}

function sizeReport(output, modules) {
  const total = Buffer.byteLength(output);
  const gzip = gzipSync(Buffer.from(output)).length;
  console.log(`Total: ${total.toLocaleString()} bytes`);
  console.log(`Gzip estimate: ${gzip.toLocaleString()} bytes`);
  console.log('Modules:');
  for (const module of [...modules].sort((a, b) => (
    Buffer.byteLength(b.source) - Buffer.byteLength(a.source)
  ))) {
    console.log(`  ${displayPath(module.path)}: ${Buffer.byteLength(module.source).toLocaleString()} bytes`);
  }
}

async function main() {
  if (unknownArgs.length > 0) {
    throw new Error(`unknown option: ${unknownArgs[0]}`);
  }
  if (artifactMode && checkMode) {
    throw new Error('--artifact and --check cannot be used together');
  }

  let html;
  try {
    html = await readFile(INDEX_PATH, 'utf8');
  } catch {
    throw new Error('index.html not found — nothing to bundle yet');
  }

  const parsed = await parseHtml(html);
  const modules = await moduleGraph(parsed.entryPaths);
  const compiled = modules.map(compileModule).join('\n\n');
  const script = `const __ccModules = Object.create(null);\n${compiled}`
    .replace(/<\/script/gi, '<\\/script');
  const styleTag = `<style>\n${parsed.css}\n</style>`;
  const scriptTag = `<script>
window.__CC_STANDALONE__ = true;
\n${script}\n</script>`;

  let output;
  if (artifactMode) {
    const body = parsed.html.match(/<body\b[^>]*>([\s\S]*?)<\/body\s*>/i);
    const markup = (body ? body[1] : parsed.html)
      .replace(/<!doctype[^>]*>/gi, '')
      .replace(/<\/?(?:html|head|body)\b[^>]*>/gi, '')
      .trim();
    output = `${styleTag}\n${markup}\n${scriptTag}\n`;
  } else {
    output = insertBeforeClosing(parsed.html, 'head', styleTag);
    output = insertBeforeClosing(output, 'body', scriptTag);
    if (!/<!doctype\s+html/i.test(output)) output = `<!doctype html>\n${output}`;
  }

  assertStandalone(output);
  sizeReport(output, modules);
  if (checkMode) {
    console.log('Standalone check passed.');
    return;
  }

  const outputName = artifactMode
    ? 'cell-commander.artifact.html'
    : 'cell-commander.html';
  const outputPath = join(ROOT, 'dist', outputName);
  await mkdir(dirname(outputPath), { recursive: true });
  await writeFile(outputPath, output);
  console.log(`Wrote ${displayPath(outputPath)}`);
}

main().catch((error) => {
  console.error(`bundle: ${error.message}`);
  process.exitCode = 1;
});
