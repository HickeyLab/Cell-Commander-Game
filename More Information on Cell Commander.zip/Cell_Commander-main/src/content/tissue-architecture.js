/**
 * tissue-architecture.js — the shape of a real piece of lung, from an H&E slide.
 *
 * This is not a generated texture. It is a crop of the tissue map produced by the lab's own
 * histopathology pipeline: whole-slide H&E imaged, tiled into patches, each patch embedded
 * and clustered, giving a grid where every square is either background or one of four tissue
 * neighbourhoods the clustering found.
 *
 * WHAT THIS LETS THE GAME DO
 *
 * The board stops being an abstract rectangle. Cells live where tissue actually is, the empty
 * regions are genuinely empty in the source slide, and the neighbourhoods give the board
 * internal structure that a child can see and reason about — some places are dense, some are
 * open, and that shapes where immune cells can get to.
 *
 * WHAT IT MUST NOT CLAIM
 *
 * The source config is explicit: "Cluster identities need manual assignment based on
 * representative_patches.png. Map cluster IDs to tissue types: alveolar, bronchiolar,
 * vascular, stromal." That assignment has NOT been done. So these four neighbourhoods are
 * unnamed here, and the UI calls them "tissue neighbourhoods" rather than guessing at
 * alveolar or vascular. Labelling them would be inventing a result the lab has not produced.
 *
 * Source: Influenza_Modeling/out/he_composition/tissue_mask.npy (+ tissue_mask_config.json),
 * produced by lung_model/analysis/he_tissue_composition.py.
 */

/** Grid width in patches. */
export const TISSUE_COLS = 50;

/** Grid height in patches. Cropped from the square source to the board aspect. */
export const TISSUE_ROWS = 33;

/** Patch edge length in microns, from the source config. */
export const PATCH_SIZE_UM = 84.2;

/** Number of tissue neighbourhoods the clustering found. Identities unassigned. */
export const TISSUE_CLUSTERS = 4;

/** Fraction of the cropped field that is tissue rather than empty space. */
export const TISSUE_FRACTION = 0.6309;

/**
 * The map itself, one string per row. '.' is background (no tissue in the slide); the digits
 * are neighbourhood ids as produced by the clustering, deliberately unnamed.
 */
export const TISSUE_MAP = Object.freeze([
  '232.23000000000300000220000002300020000000000011..',
  '...223000000002230000330000003000000000000000000..',
  '...233000300030200000300000000000000003000000000..',
  '..23333000032.3000000000000000000000003000000000..',
  '..1330300000133300000000000300000000032000000001..',
  '..222200000323200000200000003000000022222220000...',
  '.....10000032220000020000.000000000022222222200...',
  '......330000203300000.......0000000003222000......',
  '......00010000330000..2.2....10000002002000.......',
  '......1100000210100..2........000000000000........',
  '.......03001113100...2.....2...00000000000........',
  '2.......131.13..................00030000..........',
  '..................2...............1221............',
  '......................2............2..............',
  '........................22........................',
  '...............2.....2.22.........................',
  '..................................................',
  '.........11.......................................',
  '........1111121111111.............................',
  '.......21111111111111111111.......................',
  '......222111111111111111111.......................',
  '.....1222211111111111113331112..1122111111........',
  '.....1122221112112112111331122111111111111111111..',
  '.....111222111111111111133331111111131111111111111',
  '....1112111311111111111131330333333311111111111111',
  '....2111111313111111111111221111333333112331111111',
  '....1111111111111111111322221111133333333331111111',
  '....1111111131112111111122222111132333333331111221',
  '....1111111222211123222222222211113333333331111211',
  '....1311111111111112222222222221111132213122212111',
  '....111111111111112221111222221111111231112222211.',
  '....111111111111111111112212111111111211112222222.',
  '.....11111112111122111112212111111131131112211122.',
]);

/**
 * Is there tissue at this grid square?
 * @param {number} col
 * @param {number} row
 * @returns {boolean}
 */
export function hasTissue(col, row) {
  const line = TISSUE_MAP[row];
  if (!line) return false;
  const ch = line[col];
  return ch !== undefined && ch !== '.';
}

/**
 * Neighbourhood id at a grid square, or -1 for background.
 * @param {number} col
 * @param {number} row
 * @returns {number}
 */
export function neighbourhoodAt(col, row) {
  const line = TISSUE_MAP[row];
  if (!line) return -1;
  const ch = line[col];
  if (ch === undefined || ch === '.') return -1;
  return Number(ch);
}
