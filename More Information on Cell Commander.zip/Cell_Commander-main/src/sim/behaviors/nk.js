/**
 * nk.js owns missing-self recognition, contact killing, inflammatory output,
 * exhaustion recovery, and chemotactic movement for natural-killer cells.
 */

import { FIELD, STATE } from '../../core/contracts.js';
import { P } from '../params.js';

/**
 * Update one NK cell without allocating.
 * @param {object} round
 * @param {number} i
 * @param {number} dt
 * @returns {void}
 */
export function updateNK(round, i, dt) {
  const world = round.world;
  if (world.timer[i] > 0) {
    world.timer[i] = Math.max(0, world.timer[i] - dt);
    world.state[i] = STATE.ACTIVE;
    round._recoverKiller(i, dt);
    round._move(i, FIELD.CHEMOKINE, false);
    return;
  }

  const target = round._findTarget(i);
  if (target >= 0) {
    if (world.state[i] !== STATE.ENGAGED) {
      round._queueEvent(3, world.x[i], world.y[i], 0, 0);
    }
    world.state[i] = STATE.ENGAGED;
    world.a3[i] = target;
    const ifngRate = world.a1[i] >= 1 - P.exhaustion.killFloor
      ? P.production.ifngExhausted
      : P.production.ifng;
    round.grid.deposit(FIELD.IFNG, world.x[i], world.y[i], ifngRate * dt);
    round.grid.deposit(
      FIELD.CHEMOKINE,
      world.x[i],
      world.y[i],
      P.production.chemokine * dt,
    );
    round._damageTarget(i, target, dt);
    round._move(i, FIELD.CHEMOKINE, true);
    return;
  }

  world.a3[i] = -1;
  world.state[i] = world.a1[i] >= 1 - P.exhaustion.killFloor
    ? STATE.EXHAUSTED
    : STATE.ACTIVE;
  round._recoverKiller(i, dt);
  round._move(i, FIELD.CHEMOKINE, false);
}
