/**
 * spatialhash.js owns an allocation-free uniform-grid index over live agent
 * slots, supporting exact-radius neighbor iteration and predicate-aware nearest search.
 */

/**
 * Create a flat typed-array spatial hash for a fixed world rectangle.
 * @param {{worldW:number,worldH:number,cellSize:number}} opts Hash geometry.
 * @returns {object} Spatial hash API.
 */
export function makeSpatialHash(opts) {
  const worldW = opts.worldW;
  const worldH = opts.worldH;
  const cellSize = opts.cellSize;

  if (!(worldW > 0) || !(worldH > 0) || !(cellSize > 0)) {
    throw new RangeError('world dimensions and cellSize must be positive');
  }

  const columns = Math.ceil(worldW / cellSize);
  const rows = Math.ceil(worldH / cellSize);
  const bucketCount = columns * rows;
  const counts = new Uint32Array(bucketCount);
  const offsets = new Uint32Array(bucketCount + 1);
  const cursors = new Uint32Array(bucketCount);
  let entries = new Int32Array(0);
  let entryCapacity = 0;
  let world = null;

  function bucketFor(x, y) {
    let cx = Math.floor(x / cellSize);
    let cy = Math.floor(y / cellSize);
    if (cx < 0) cx = 0;
    if (cx >= columns) cx = columns - 1;
    if (cy < 0) cy = 0;
    if (cy >= rows) cy = rows - 1;
    return cy * columns + cx;
  }

  function clampColumn(column) {
    if (column < 0) return 0;
    if (column >= columns) return columns - 1;
    return column;
  }

  function clampRow(row) {
    if (row < 0) return 0;
    if (row >= rows) return rows - 1;
    return row;
  }

  return {
    cellSize,

    rebuild(nextWorld) {
      world = nextWorld;
      const declaredCapacity = nextWorld.capacity ?? nextWorld.length ?? nextWorld.alive.length;
      const limit = Math.min(
        declaredCapacity,
        nextWorld.alive.length,
        nextWorld.x.length,
        nextWorld.y.length,
      );

      if (declaredCapacity > entryCapacity) {
        entries = new Int32Array(declaredCapacity);
        entryCapacity = declaredCapacity;
      }

      counts.fill(0);
      for (let i = 0; i < limit; i += 1) {
        if (nextWorld.alive[i] !== 0) {
          counts[bucketFor(nextWorld.x[i], nextWorld.y[i])] += 1;
        }
      }

      offsets[0] = 0;
      for (let bucket = 0; bucket < bucketCount; bucket += 1) {
        offsets[bucket + 1] = offsets[bucket] + counts[bucket];
        cursors[bucket] = offsets[bucket];
      }

      for (let i = 0; i < limit; i += 1) {
        if (nextWorld.alive[i] !== 0) {
          const bucket = bucketFor(nextWorld.x[i], nextWorld.y[i]);
          entries[cursors[bucket]] = i;
          cursors[bucket] += 1;
        }
      }
    },

    forEachNeighbor(x, y, radius, fn) {
      if (world === null || radius < 0) {
        return;
      }

      const minCx = clampColumn(Math.floor((x - radius) / cellSize));
      const maxCx = clampColumn(Math.floor((x + radius) / cellSize));
      const minCy = clampRow(Math.floor((y - radius) / cellSize));
      const maxCy = clampRow(Math.floor((y + radius) / cellSize));
      const radiusSq = radius * radius;

      for (let cy = minCy; cy <= maxCy; cy += 1) {
        for (let cx = minCx; cx <= maxCx; cx += 1) {
          const bucket = cy * columns + cx;
          const end = offsets[bucket + 1];
          for (let cursor = offsets[bucket]; cursor < end; cursor += 1) {
            const slot = entries[cursor];
            const dx = world.x[slot] - x;
            const dy = world.y[slot] - y;
            if (dx * dx + dy * dy <= radiusSq) {
              fn(slot);
            }
          }
        }
      }
    },

    nearest(x, y, radius, predicate) {
      if (world === null || radius < 0) {
        return -1;
      }

      const minCx = clampColumn(Math.floor((x - radius) / cellSize));
      const maxCx = clampColumn(Math.floor((x + radius) / cellSize));
      const minCy = clampRow(Math.floor((y - radius) / cellSize));
      const maxCy = clampRow(Math.floor((y + radius) / cellSize));
      const radiusSq = radius * radius;
      let nearestSlot = -1;
      let nearestDistanceSq = radiusSq;

      for (let cy = minCy; cy <= maxCy; cy += 1) {
        for (let cx = minCx; cx <= maxCx; cx += 1) {
          const bucket = cy * columns + cx;
          const end = offsets[bucket + 1];
          for (let cursor = offsets[bucket]; cursor < end; cursor += 1) {
            const slot = entries[cursor];
            const dx = world.x[slot] - x;
            const dy = world.y[slot] - y;
            const distanceSq = dx * dx + dy * dy;
            if (distanceSq <= radiusSq && predicate(slot)
              && (nearestSlot < 0 || distanceSq < nearestDistanceSq
                || (distanceSq === nearestDistanceSq && slot < nearestSlot))) {
              nearestSlot = slot;
              nearestDistanceSq = distanceSq;
            }
          }
        }
      }

      return nearestSlot;
    },
  };
}
