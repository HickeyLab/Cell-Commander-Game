/**
 * grid.js owns field-major scalar storage and allocation-free diffusion, decay,
 * deposition, interpolation, and gradient operations on a uniform world grid.
 */

const MAX_DIFFUSION_ALPHA = 0.24;

/**
 * Create a shared uniform grid for diffusing scalar fields.
 * @param {{
 *   w:number,
 *   h:number,
 *   worldW:number,
 *   worldH:number,
 *   fieldCount:number,
 *   concentrationUnitArea?:number,
 * }} opts Grid geometry and optional concentration display unit.
 * @returns {object} Field grid API.
 */
export function makeFieldGrid(opts) {
  const worldW = opts.worldW;
  const worldH = opts.worldH;
  const fieldCount = opts.fieldCount;
  const concentrationUnitArea = opts.concentrationUnitArea ?? 1;
  let w = opts.w;
  let h = opts.h;
  let planeSize = w * h;
  let cellW = worldW / w;
  let cellH = worldH / h;
  let inverseCellArea = 1 / (cellW * cellH);
  let data = new Float32Array(fieldCount * planeSize);
  let scratch = new Float32Array(fieldCount * planeSize);

  if (!Number.isInteger(w) || w <= 0 || !Number.isInteger(h) || h <= 0) {
    throw new RangeError('grid dimensions must be positive integers');
  }
  if (!Number.isInteger(fieldCount) || fieldCount <= 0) {
    throw new RangeError('fieldCount must be a positive integer');
  }
  if (!(worldW > 0) || !(worldH > 0)) {
    throw new RangeError('world dimensions must be positive');
  }
  if (!(concentrationUnitArea > 0) || !Number.isFinite(concentrationUnitArea)) {
    throw new RangeError('concentrationUnitArea must be positive and finite');
  }

  function sampleInside(f, worldX, worldY) {
    const gridX = worldX / cellW - 0.5;
    const gridY = worldY / cellH - 0.5;
    let x0 = Math.floor(gridX);
    let y0 = Math.floor(gridY);
    let x1 = x0 + 1;
    let y1 = y0 + 1;
    const tx = gridX - x0;
    const ty = gridY - y0;

    if (x0 < 0) x0 = 0;
    if (x1 < 0) x1 = 0;
    if (x0 >= w) x0 = w - 1;
    if (x1 >= w) x1 = w - 1;
    if (y0 < 0) y0 = 0;
    if (y1 < 0) y1 = 0;
    if (y0 >= h) y0 = h - 1;
    if (y1 >= h) y1 = h - 1;

    const offset = f * planeSize;
    const topLeft = data[offset + y0 * w + x0];
    const topRight = data[offset + y0 * w + x1];
    const bottomLeft = data[offset + y1 * w + x0];
    const bottomRight = data[offset + y1 * w + x1];
    const top = topLeft + (topRight - topLeft) * tx;
    const bottom = bottomLeft + (bottomRight - bottomLeft) * tx;
    return top + (bottom - top) * ty;
  }

  function addSubstance(index, amount) {
    data[index] += amount * inverseCellArea;
  }

  const grid = {
    w,
    h,
    cellW,
    cellH,
    fieldCount,
    concentrationUnitArea,
    data,

    idx(f, cx, cy) {
      return f * planeSize + cy * w + cx;
    },

    clear(f) {
      if (f === undefined) {
        data.fill(0);
        return;
      }
      const start = f * planeSize;
      data.fill(0, start, start + planeSize);
    },

    deposit(f, worldX, worldY, amount) {
      let cx = Math.floor(worldX / cellW);
      let cy = Math.floor(worldY / cellH);
      if (cx < 0) {
        cx = 0;
      } else if (cx >= w) {
        cx = w - 1;
      }
      if (cy < 0) {
        cy = 0;
      } else if (cy >= h) {
        cy = h - 1;
      }
      addSubstance(f * planeSize + cy * w + cx, amount);
    },

    depositRadius(f, worldX, worldY, amount, radiusWu) {
      if (!(radiusWu > 0)) {
        grid.deposit(f, worldX, worldY, amount);
        return;
      }

      let minCx = Math.floor((worldX - radiusWu) / cellW);
      let maxCx = Math.floor((worldX + radiusWu) / cellW);
      let minCy = Math.floor((worldY - radiusWu) / cellH);
      let maxCy = Math.floor((worldY + radiusWu) / cellH);
      if (minCx < 0) minCx = 0;
      if (maxCx >= w) maxCx = w - 1;
      if (minCy < 0) minCy = 0;
      if (maxCy >= h) maxCy = h - 1;

      const radiusSq = radiusWu * radiusWu;
      let totalWeight = 0;
      let lastIndex = -1;

      for (let cy = minCy; cy <= maxCy; cy += 1) {
        const dy = (cy + 0.5) * cellH - worldY;
        for (let cx = minCx; cx <= maxCx; cx += 1) {
          const dx = (cx + 0.5) * cellW - worldX;
          const distanceSq = dx * dx + dy * dy;
          if (distanceSq <= radiusSq) {
            totalWeight += radiusWu - Math.sqrt(distanceSq);
            lastIndex = f * planeSize + cy * w + cx;
          }
        }
      }

      if (!(totalWeight > 0) || lastIndex < 0) {
        grid.deposit(f, worldX, worldY, amount);
        return;
      }

      let assignedFraction = 0;
      for (let cy = minCy; cy <= maxCy; cy += 1) {
        const dy = (cy + 0.5) * cellH - worldY;
        for (let cx = minCx; cx <= maxCx; cx += 1) {
          const dx = (cx + 0.5) * cellW - worldX;
          const distanceSq = dx * dx + dy * dy;
          if (distanceSq <= radiusSq) {
            const index = f * planeSize + cy * w + cx;
            let fraction;
            if (index === lastIndex) {
              fraction = 1 - assignedFraction;
            } else {
              fraction = (radiusWu - Math.sqrt(distanceSq)) / totalWeight;
              assignedFraction += fraction;
            }
            addSubstance(index, amount * fraction);
          }
        }
      }
    },

    sample(f, worldX, worldY) {
      if (worldX < 0 || worldX >= worldW || worldY < 0 || worldY >= worldH) {
        return 0;
      }
      return sampleInside(f, worldX, worldY) * concentrationUnitArea;
    },

    gradient(f, worldX, worldY, out) {
      const xLo = Math.max(0, worldX - cellW);
      const xHi = Math.min(worldW, worldX + cellW);
      const yLo = Math.max(0, worldY - cellH);
      const yHi = Math.min(worldH, worldY + cellH);
      const dx = xHi - xLo;
      const dy = yHi - yLo;
      out.x = dx > 0
        ? (sampleInside(f, xHi, worldY) - sampleInside(f, xLo, worldY))
          * concentrationUnitArea / dx
        : 0;
      out.y = dy > 0
        ? (sampleInside(f, worldX, yHi) - sampleInside(f, worldX, yLo))
          * concentrationUnitArea / dy
        : 0;
    },

    step(dt, params) {
      if (!(dt > 0)) {
        return;
      }

      const inverseCellWSq = 1 / (cellW * cellW);
      const inverseCellHSq = 1 / (cellH * cellH);

      for (let f = 0; f < fieldCount; f += 1) {
        const diffusion = Math.max(0, Number(params.diffusion[f]) || 0);
        const decay = Math.max(0, Number(params.decay[f]) || 0);
        const offset = f * planeSize;

        if (diffusion === 0) {
          if (decay !== 0) {
            const decayFactor = Math.exp(-decay * dt);
            const end = offset + planeSize;
            for (let i = offset; i < end; i += 1) {
              data[i] *= decayFactor;
            }
          }
          continue;
        }

        const alphaX = diffusion * dt * inverseCellWSq;
        const alphaY = diffusion * dt * inverseCellHSq;
        const maxAlpha = Math.max(alphaX, alphaY);
        const substeps = Math.max(1, Math.ceil(maxAlpha / MAX_DIFFUSION_ALPHA));
        const subDt = dt / substeps;
        const stepAlphaX = diffusion * subDt * inverseCellWSq;
        const stepAlphaY = diffusion * subDt * inverseCellHSq;
        const decayFactor = Math.exp(-decay * subDt);
        let source = data;
        let target = scratch;

        for (let substep = 0; substep < substeps; substep += 1) {
          for (let cy = 0; cy < h; cy += 1) {
            const row = offset + cy * w;
            for (let cx = 0; cx < w; cx += 1) {
              const index = row + cx;
              const center = source[index];
              const left = cx === 0 ? center : source[index - 1];
              const right = cx === w - 1 ? center : source[index + 1];
              const up = cy === 0 ? center : source[index - w];
              const down = cy === h - 1 ? center : source[index + w];
              const diffused = center
                + stepAlphaX * (left + right - 2 * center)
                + stepAlphaY * (up + down - 2 * center);
              target[index] = diffused > 0 ? diffused * decayFactor : 0;
            }
          }

          const swap = source;
          source = target;
          target = swap;
        }

        if (source !== data) {
          const end = offset + planeSize;
          for (let i = offset; i < end; i += 1) {
            data[i] = source[i];
          }
        }
      }
    },

    total(f) {
      const start = f * planeSize;
      const end = start + planeSize;
      let sum = 0;
      for (let i = start; i < end; i += 1) {
        sum += data[i];
      }
      return sum;
    },

    max(f) {
      const start = f * planeSize;
      const end = start + planeSize;
      let maximum = -Infinity;
      for (let i = start; i < end; i += 1) {
        if (data[i] > maximum) {
          maximum = data[i];
        }
      }
      return maximum;
    },

    resize(nextW, nextH) {
      if (!Number.isInteger(nextW) || nextW <= 0
        || !Number.isInteger(nextH) || nextH <= 0) {
        throw new RangeError('grid dimensions must be positive integers');
      }

      w = nextW;
      h = nextH;
      planeSize = w * h;
      cellW = worldW / w;
      cellH = worldH / h;
      inverseCellArea = 1 / (cellW * cellH);
      data = new Float32Array(fieldCount * planeSize);
      scratch = new Float32Array(fieldCount * planeSize);
      grid.w = w;
      grid.h = h;
      grid.cellW = cellW;
      grid.cellH = cellH;
      grid.data = data;
    },
  };

  return grid;
}
