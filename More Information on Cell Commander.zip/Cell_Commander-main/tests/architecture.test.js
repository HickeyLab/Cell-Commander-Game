/**
 * architecture.test.js — enforces the layering rules that make this project verifiable.
 *
 * Three properties are load-bearing and easy to lose during ordinary edits, so they are
 * checked mechanically rather than trusted:
 *
 *   1. The simulation is DETERMINISTIC. If `Math.random` appears anywhere in src/sim/ or
 *      src/core/, replays diverge, the leaderboard becomes unfair, and the determinism test
 *      starts failing intermittently in a way that is miserable to debug.
 *   2. The simulation is HEADLESS. If sim/ touches `window` or `document` it can no longer be
 *      unit-tested in Node, benchmarked without a browser, or reasoned about in isolation.
 *   3. The simulation does not depend on presentation. sim/ importing render/ or ui/ would
 *      invert the dependency and make the model impossible to reuse or verify on its own.
 */

import { test, describe } from 'node:test';
import assert from 'node:assert/strict';
import { readdir, readFile } from 'node:fs/promises';
import { join, relative, sep } from 'node:path';
import { fileURLToPath } from 'node:url';

const ROOT = fileURLToPath(new URL('..', import.meta.url));
const SRC = join(ROOT, 'src');

/** Recursively collect .js files under a directory. Returns [] if it does not exist. */
async function collect(dir) {
  let entries;
  try {
    entries = await readdir(dir, { withFileTypes: true });
  } catch {
    return [];
  }
  const out = [];
  for (const e of entries) {
    const full = join(dir, e.name);
    if (e.isDirectory()) out.push(...(await collect(full)));
    else if (e.name.endsWith('.js')) out.push(full);
  }
  return out;
}

/** Strip comments and string literals so we only scan executable code. */
function stripNonCode(src) {
  return src
    .replace(/\/\*[\s\S]*?\*\//g, ' ')
    .replace(/(^|[^:])\/\/[^\n]*/g, '$1 ')
    .replace(/'(?:\\.|[^'\\])*'/g, "''")
    .replace(/"(?:\\.|[^"\\])*"/g, '""')
    .replace(/`(?:\\.|[^`\\])*`/g, '``');
}

const rel = (f) => relative(ROOT, f).split(sep).join('/');

const simFiles = [...(await collect(join(SRC, 'sim'))), ...(await collect(join(SRC, 'core')))];
const allFiles = await collect(SRC);

describe('simulation layer purity', () => {
  test('there are simulation files to check', () => {
    assert.ok(
      simFiles.length >= 3,
      `expected several files under src/sim and src/core, found ${simFiles.length}`
    );
  });

  test('no Math.random anywhere in sim/ or core/', async () => {
    const offenders = [];
    for (const f of simFiles) {
      const code = stripNonCode(await readFile(f, 'utf8'));
      if (/\bMath\s*\.\s*random\b/.test(code)) offenders.push(rel(f));
    }
    assert.deepEqual(
      offenders,
      [],
      `Math.random breaks determinism. Use the injected seeded Rng instead. Offenders:\n  ${offenders.join('\n  ')}`
    );
  });

  test('sim/ and core/ never touch the DOM', async () => {
    const offenders = [];
    for (const f of simFiles) {
      const code = stripNonCode(await readFile(f, 'utf8'));
      // `perf.js` may legitimately read performance.now(); that is not DOM.
      const hits = [];
      if (/\bdocument\s*\./.test(code)) hits.push('document');
      if (/\bwindow\s*\./.test(code)) hits.push('window');
      if (/\blocalStorage\b/.test(code)) hits.push('localStorage');
      if (/\bnavigator\s*\./.test(code)) hits.push('navigator');
      if (hits.length) offenders.push(`${rel(f)} -> ${hits.join(', ')}`);
    }
    assert.deepEqual(
      offenders,
      [],
      `sim/ and core/ must run headless in Node. Offenders:\n  ${offenders.join('\n  ')}`
    );
  });

  test('sim/ does not import from render/ or ui/', async () => {
    const offenders = [];
    for (const f of await collect(join(SRC, 'sim'))) {
      const src = await readFile(f, 'utf8');
      for (const m of src.matchAll(/from\s+['"]([^'"]+)['"]/g)) {
        const spec = m[1];
        if (spec.includes('/render/') || spec.includes('/ui/')) {
          offenders.push(`${rel(f)} imports ${spec}`);
        }
      }
    }
    assert.deepEqual(
      offenders,
      [],
      `The model must not depend on presentation. Offenders:\n  ${offenders.join('\n  ')}`
    );
  });

  test('core/ does not import from sim/, render/, or ui/', async () => {
    const offenders = [];
    for (const f of await collect(join(SRC, 'core'))) {
      const src = await readFile(f, 'utf8');
      for (const m of src.matchAll(/from\s+['"]([^'"]+)['"]/g)) {
        const spec = m[1];
        if (spec.includes('/sim/') || spec.includes('/render/') || spec.includes('/ui/')) {
          offenders.push(`${rel(f)} imports ${spec}`);
        }
      }
    }
    assert.deepEqual(offenders, [], `core/ is the base layer:\n  ${offenders.join('\n  ')}`);
  });

  test('render/ never mutates the simulation', async () => {
    // A renderer that writes into the world creates bugs that only appear at certain frame
    // rates. Catch the obvious forms: assigning into round.* or world state arrays.
    const offenders = [];
    for (const f of await collect(join(SRC, 'render'))) {
      const code = stripNonCode(await readFile(f, 'utf8'));
      const bad = code.match(
        /\b(round|world)\s*\.\s*[A-Za-z_$][\w$]*\s*(?:\[[^\]]*\])?\s*(?:=(?!=)|\+=|-=|\*=|\/=|\+\+|--)/g
      );
      if (bad) offenders.push(`${rel(f)} -> ${[...new Set(bad)].join(' | ')}`);
    }
    assert.deepEqual(
      offenders,
      [],
      `The renderer reads; it must not write. Offenders:\n  ${offenders.join('\n  ')}`
    );
  });
});

describe('offline and dependency constraints', () => {
  test('no bare-specifier imports — the game must run with no build step or node_modules', async () => {
    const offenders = [];
    for (const f of allFiles) {
      const src = await readFile(f, 'utf8');
      for (const m of src.matchAll(/from\s+['"]([^'"]+)['"]/g)) {
        const spec = m[1];
        const isRelative = spec.startsWith('./') || spec.startsWith('../') || spec.startsWith('/');
        const isNode = spec.startsWith('node:');
        if (!isRelative && !isNode) offenders.push(`${rel(f)} imports bare specifier "${spec}"`);
      }
    }
    assert.deepEqual(
      offenders,
      [],
      `Bare specifiers need a bundler or node_modules; this project ships neither.\n  ${offenders.join('\n  ')}`
    );
  });

  test('no source file references an external host', async () => {
    const offenders = [];
    for (const f of allFiles) {
      const src = await readFile(f, 'utf8');
      // Allow http(s) inside comments (citations, docs links); flag it in executable code.
      const code = stripNonCode(src);
      const m = code.match(/https?:\/\/[^\s'"`)]+/g);
      if (m) offenders.push(`${rel(f)} -> ${[...new Set(m)].join(', ')}`);
    }
    assert.deepEqual(
      offenders,
      [],
      `The game must work offline on a tablet with no network.\n  ${offenders.join('\n  ')}`
    );
  });

  test('every module has an explanatory header comment', async () => {
    const offenders = [];
    for (const f of allFiles) {
      const src = (await readFile(f, 'utf8')).trimStart();
      if (!src.startsWith('/*') && !src.startsWith('//')) offenders.push(rel(f));
    }
    assert.deepEqual(
      offenders,
      [],
      `Each module should open by saying what it owns:\n  ${offenders.join('\n  ')}`
    );
  });
});
