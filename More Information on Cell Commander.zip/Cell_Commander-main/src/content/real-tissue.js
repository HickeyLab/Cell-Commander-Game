/**
 * real-tissue.js — what a real piece of human lung actually contains, measured.
 *
 * These are not illustrative numbers. They come from the lab's own CODEX multiplexed imaging
 * run: 255,000 cells across 35 markers, segmented with Mesmer and assigned to lineages by
 * hierarchical marker gating, over a 6.5 x 8.3 mm field of view. Densities are cells per
 * square millimetre and are stable across domain sizes, so they can be scaled to the game's
 * much smaller tissue window.
 *
 * WHY PUT THIS IN A CHILDREN'S GAME
 *
 * The counts are genuinely surprising, and the surprise is the lesson. In a patch of lung the
 * size of the game board there are roughly 180 epithelial cells and 57 macrophages — but only
 * about 8 killer T cells. Macrophages outnumber killer T cells seven to one. NK cells
 * outnumber them three to one. A child who has just spent a minute placing a dozen CAR-T
 * cells has, without realising it, been imagining an immune system far denser than the real
 * one. Showing them the measured composition reframes everything they just did.
 *
 * HONESTY, CARRIED FROM THE SOURCE
 *
 * The research file marks these PRELIMINARY and the caveats travel with the data rather than
 * being quietly dropped on the way into the game:
 *   - 49.7% of cells were confidently classified; 42.6% remain unclassified structural cells
 *   - the specimen is a "serum lung test" sample; species and condition are still TBD
 *   - gating thresholds have not been validated against manual annotation
 * So this is "what our imaging measured", not "what human lung definitively contains", and
 * the UI wording must not overclaim.
 *
 * Source: Influenza_Modeling/lung_model/library/parameters.py CODEX_CELL_DENSITIES,
 * derived from Box/Lung_Flu_U01_SA2/Data/CODEX/analysis_output/seg_region_1_mesmer_result.csv
 * Gating: lung_model/analysis/codex_gating.py. Pixel-to-micron 0.376, verified from the
 * acquisition parameters (7.52 µm sensor, 20x magnification).
 */

import { KIND } from '../core/contracts.js';

/** Measured density, cells per mm², with the marker combination used to call each lineage. */
export const CODEX_DENSITY_PER_MM2 = Object.freeze({
  epithelial: { density: 762.9, markers: 'SFTPC+ or AQP5+ or CK5+p63+, CD45−' },
  fibroblast: { density: 758.3, markers: 'aSMA+ or Vimentin+, CD31−, CD45−' },
  macrophage: { density: 239.0, markers: 'CD68hi, CD45+' },
  endothelial: { density: 215.7, markers: 'CD31+, CD45−' },
  nk_cell: { density: 99.8, markers: 'CD56+CD3−' },
  b_cell: { density: 83.7, markers: 'CD20+' },
  cd4_t_cell: { density: 64.4, markers: 'CD3+CD57−' },
  cd8_t_cell: { density: 32.7, markers: 'CD3+CD57+' },
  dendritic_cell: { density: 15.2, markers: 'HLADR+CD11b+' },
  neutrophil: { density: 11.2, markers: 'CD66+' },
});

/** The caveats, verbatim in spirit from the research file. Show these wherever numbers show. */
export const CODEX_CAVEATS = Object.freeze([
  'About half the cells in the image could be confidently identified.',
  'The sample is one test specimen — we have not confirmed the species or condition.',
  'The marker thresholds have not been checked against a human expert yet.',
]);

export const CODEX_PROVENANCE = Object.freeze({
  cells: 255000,
  markers: 35,
  fovMm: { w: 6.5, h: 8.3 },
  pixelToMicron: 0.376,
  segmentation: 'Mesmer',
  classifiedFraction: 0.497,
});

/**
 * Scale the measured densities to an area of tissue.
 * @param {number} areaMm2 tissue area in square millimetres
 * @returns {Object<string, number>} cell type -> whole-cell count (at least 1)
 */
export function cellCountsForArea(areaMm2) {
  const counts = {};
  for (const [type, entry] of Object.entries(CODEX_DENSITY_PER_MM2)) {
    counts[type] = Math.max(1, Math.round(entry.density * areaMm2));
  }
  return counts;
}

/**
 * The game's tissue window is 600 x 400 µm = 0.24 mm².
 * Defined here rather than imported so this module stays pure data.
 */
export const GAME_TISSUE_AREA_MM2 = (600 / 1000) * (400 / 1000);

/** Counts for the game's own board, at real measured density. */
export const GAME_BOARD_COUNTS = Object.freeze(cellCountsForArea(GAME_TISSUE_AREA_MM2));

/**
 * The immune cells the game lets a child place, at their real measured abundance.
 * CAR-T is deliberately absent: engineered cells do not occur in tissue, they are infused.
 */
export const REAL_IMMUNE_ROSTER = Object.freeze({
  [KIND.MACRO]: GAME_BOARD_COUNTS.macrophage,
  [KIND.NK]: GAME_BOARD_COUNTS.nk_cell,
  [KIND.CD4]: GAME_BOARD_COUNTS.cd4_t_cell,
  [KIND.CD8]: GAME_BOARD_COUNTS.cd8_t_cell,
  [KIND.DC]: GAME_BOARD_COUNTS.dendritic_cell,
  [KIND.CART]: 0,
});

/**
 * The one-line facts worth saying out loud at a booth. Each is computed from the measured
 * numbers rather than written by hand, so they cannot drift away from the data.
 * @returns {string[]}
 */
export function surprisingFacts() {
  const c = GAME_BOARD_COUNTS;
  const macroPerCd8 = Math.round(c.macrophage / c.cd8_t_cell);
  const nkPerCd8 = Math.round(c.nk_cell / c.cd8_t_cell);
  return [
    `A piece of lung this size holds only about ${c.cd8_t_cell} killer T cells.`,
    `Macrophages outnumber killer T cells about ${macroPerCd8} to 1.`,
    `NK cells outnumber killer T cells about ${nkPerCd8} to 1.`,
    `There are roughly ${c.epithelial} lung cells for them to protect.`,
  ];
}
