/**
 * fx.js owns a bounded, allocation-free-during-play particle pool for kill,
 * division, cytokine, and toxicity feedback rendered in world coordinates.
 */

import { COLORS } from '../core/contracts.js';

const TYPE_KILL = 1;
const TYPE_DIVIDE = 2;
const TYPE_PUFF = 3;
const TYPE_TOXIC = 4;
const TAU = Math.PI * 2;

const FX_COLORS = Object.freeze([
  COLORS.ink,
  COLORS.tumor,
  COLORS.tumorQuiescent,
  COLORS.cd8,
  COLORS.cart,
  COLORS.nk,
  COLORS.macro,
  COLORS.dc,
  COLORS.cd4,
  COLORS.treg,
  COLORS.vessel,
  COLORS.healthy,
  COLORS.good,
  COLORS.warn,
  COLORS.bad,
]);

function colorIndexFor(color) {
  for (let index = 0; index < FX_COLORS.length; index += 1) {
    if (FX_COLORS[index] === color) {
      return index;
    }
  }
  return 0;
}

/**
 * Creates a fixed-capacity particle effect pool whose slots are recycled by a
 * typed-array free list.
 * @param {{max:number}} opts
 * @returns {{
 *   emitKill:function(number,number,string):void,
 *   emitDivide:function(number,number):void,
 *   emitPuff:function(number,number,string):void,
 *   emitToxic:function(number,number):void,
 *   update:function(number):void,
 *   draw:function(CanvasRenderingContext2D,object):void,
 *   clear:function():void,
 *   setBudget:function(number):void,
 *   readonly activeCount:number,
 *   readonly freeCount:number,
 *   readonly max:number
 * }}
 */
export function makeFx(opts) {
  const max = Math.max(0, Math.trunc(Number(opts?.max) || 0));
  const active = new Uint8Array(max);
  const type = new Uint8Array(max);
  const colorIndex = new Uint8Array(max);
  const particleX = new Float32Array(max);
  const particleY = new Float32Array(max);
  const vx = new Float32Array(max);
  const vy = new Float32Array(max);
  const age = new Float32Array(max);
  const life = new Float32Array(max);
  const size = new Float32Array(max);
  const free = new Int32Array(max);
  let freeTop = max;
  let activeCount = 0;
  let budget = 1;
  let randomState = 0x9e3779b9;

  for (let slot = 0; slot < max; slot += 1) {
    free[slot] = max - slot - 1;
  }

  function randomUnit() {
    randomState ^= randomState << 13;
    randomState ^= randomState >>> 17;
    randomState ^= randomState << 5;
    return (randomState >>> 0) / 0x100000000;
  }

  function scaledCount(base) {
    return Math.max(0, Math.min(base, Math.round(base * budget)));
  }

  function acquire() {
    if (freeTop === 0) {
      return -1;
    }
    const slot = free[--freeTop];
    active[slot] = 1;
    activeCount += 1;
    return slot;
  }

  function release(slot) {
    active[slot] = 0;
    free[freeTop] = slot;
    freeTop += 1;
    activeCount -= 1;
  }

  function spawn(px, py, speed, angle, particleLife, particleSize, particleType, particleColor) {
    const slot = acquire();
    if (slot < 0) {
      return false;
    }
    active[slot] = 1;
    type[slot] = particleType;
    colorIndex[slot] = particleColor;
    particleX[slot] = px;
    particleY[slot] = py;
    vx[slot] = Math.cos(angle) * speed;
    vy[slot] = Math.sin(angle) * speed;
    age[slot] = 0;
    life[slot] = particleLife;
    size[slot] = particleSize;
    return true;
  }

  function emitKill(x, y, color) {
    const count = scaledCount(6 + Math.floor(randomUnit() * 5));
    const particleColor = colorIndexFor(color);
    for (let particle = 0; particle < count; particle += 1) {
      const angle = randomUnit() * TAU;
      const speed = 34 + randomUnit() * 72;
      if (!spawn(
        x,
        y,
        speed,
        angle,
        0.32 + randomUnit() * 0.28,
        1.5 + randomUnit() * 2.1,
        TYPE_KILL,
        particleColor,
      )) {
        break;
      }
    }
  }

  function emitDivide(x, y) {
    const count = scaledCount(7);
    for (let particle = 0; particle < count; particle += 1) {
      const angle = particle * TAU / Math.max(1, count) + randomUnit() * 0.2;
      if (!spawn(
        x,
        y,
        24 + randomUnit() * 34,
        angle,
        0.38 + randomUnit() * 0.2,
        1.3 + randomUnit() * 1.8,
        TYPE_DIVIDE,
        1,
      )) {
        break;
      }
    }
  }

  function emitPuff(x, y, color) {
    const count = scaledCount(5);
    const particleColor = colorIndexFor(color);
    for (let particle = 0; particle < count; particle += 1) {
      const angle = -Math.PI * 0.5 + (randomUnit() - 0.5) * 1.8;
      if (!spawn(
        x,
        y,
        8 + randomUnit() * 20,
        angle,
        0.7 + randomUnit() * 0.35,
        2 + randomUnit() * 3.2,
        TYPE_PUFF,
        particleColor,
      )) {
        break;
      }
    }
  }

  function emitToxic(x, y) {
    const count = scaledCount(10);
    for (let particle = 0; particle < count; particle += 1) {
      const angle = particle * TAU / Math.max(1, count);
      if (!spawn(
        x,
        y,
        58 + randomUnit() * 44,
        angle,
        0.25 + randomUnit() * 0.18,
        2.2 + randomUnit() * 2.4,
        TYPE_TOXIC,
        14,
      )) {
        break;
      }
    }
  }

  function update(dt) {
    const step = Number.isFinite(dt) ? Math.max(0, dt) : 0;
    if (step === 0 || activeCount === 0) {
      return;
    }
    const drag = Math.exp(-3.2 * step);
    for (let slot = 0; slot < max; slot += 1) {
      if (active[slot] === 0) {
        continue;
      }
      age[slot] += step;
      if (age[slot] >= life[slot]) {
        release(slot);
        continue;
      }
      vx[slot] *= drag;
      vy[slot] *= drag;
      if (type[slot] === TYPE_PUFF) {
        vy[slot] -= 4 * step;
        size[slot] += 3.5 * step;
      }
      particleX[slot] += vx[slot] * step;
      particleY[slot] += vy[slot] * step;
    }
  }

  function draw(ctx, view) {
    if (!ctx || activeCount === 0) {
      return;
    }
    const scale = Number.isFinite(view?.scale) ? view.scale : 1;
    const offsetX = Number.isFinite(view?.offsetX) ? view.offsetX : 0;
    const offsetY = Number.isFinite(view?.offsetY) ? view.offsetY : 0;
    let lastColor = -1;
    ctx.save();
    ctx.globalCompositeOperation = 'lighter';
    for (let slot = 0; slot < max; slot += 1) {
      if (active[slot] === 0) {
        continue;
      }
      const remaining = Math.max(0, 1 - age[slot] / life[slot]);
      const particleSize = Math.max(1, size[slot] * Math.max(0.35, scale));
      const sx = offsetX + particleX[slot] * scale;
      const sy = offsetY + particleY[slot] * scale;
      if (lastColor !== colorIndex[slot]) {
        lastColor = colorIndex[slot];
        ctx.fillStyle = FX_COLORS[lastColor];
      }
      ctx.globalAlpha = remaining * remaining;
      if (type[slot] === TYPE_TOXIC) {
        ctx.fillRect(sx - particleSize * 1.5, sy - particleSize * 0.35, particleSize * 3, particleSize * 0.7);
        ctx.fillRect(sx - particleSize * 0.35, sy - particleSize * 1.5, particleSize * 0.7, particleSize * 3);
      } else {
        ctx.fillRect(
          sx - particleSize * 0.5,
          sy - particleSize * 0.5,
          particleSize,
          particleSize,
        );
      }
    }
    ctx.restore();
  }

  function clear() {
    active.fill(0);
    activeCount = 0;
    freeTop = max;
    for (let slot = 0; slot < max; slot += 1) {
      free[slot] = max - slot - 1;
    }
  }

  function setBudget(fraction) {
    budget = Number.isFinite(fraction)
      ? Math.max(0, Math.min(1, fraction))
      : 1;
  }

  return {
    emitKill,
    emitDivide,
    emitPuff,
    emitToxic,
    update,
    draw,
    clear,
    setBudget,
    get activeCount() {
      return activeCount;
    },
    get freeCount() {
      return freeTop;
    },
    max,
  };
}
