/**
 * app.js — the browser entry point and sole boot owner: it constructs shared
 * context, routes screens, drives animation updates, and enforces booth idle reset.
 */

import {
  OUTCOME,
  PLAN_DEFAULTS,
  QUALITY,
  SCREEN,
} from '../core/contracts.js';
import { makePerfMonitor, makeQualityController } from '../core/perf.js';
import * as Rng from '../core/rng.js';
import * as Engine from '../sim/engine.js';
import * as Plan from '../sim/plan.js';
import * as Levels from '../content/levels.js';
import { button, chip, icon } from './components.js';
import * as SetupScreen from './setup.js';
import * as LiveScreen from './live.js';
import * as ResultsScreen from './results.js';
import * as LeaderboardScreen from './leaderboard.js';
import * as SandboxScreen from './sandbox.js';
import { startDemo, demoRequested } from './demo.js';
import { startTour, tourRequested } from './tour.js';

const IDLE_MS = 90_000;
const IDLE_SCREENS = new Set([
  SCREEN.TITLE,
  SCREEN.LEVEL_SELECT,
  SCREEN.RESULTS,
  SCREEN.LEADERBOARD,
]);
const PROGRESS_KEY = 'cc.progress.v1';

function fallbackSeed(value) {
  let hash = 2166136261;
  const text = String(value);
  for (let index = 0; index < text.length; index += 1) {
    hash ^= text.charCodeAt(index);
    hash = Math.imul(hash, 16777619);
  }
  return hash >>> 0;
}

function safeStorage(win) {
  try {
    return win.localStorage ?? null;
  } catch {
    return null;
  }
}

function readProgress(storage) {
  if (!storage) {
    return { wins: [] };
  }
  try {
    const parsed = JSON.parse(storage.getItem(PROGRESS_KEY) ?? '{"wins":[]}');
    return {
      wins: Array.isArray(parsed?.wins) ? parsed.wins.map(String) : [],
    };
  } catch {
    return { wins: [] };
  }
}

function writeProgress(storage, progress) {
  if (!storage) {
    return;
  }
  try {
    storage.setItem(PROGRESS_KEY, JSON.stringify(progress));
  } catch {
    // Progress gracefully becomes session-only through app.progress.
  }
}

function makeTreatmentPlan(level) {
  const overrides = {
    ...PLAN_DEFAULTS,
    placements: [],
    budget: Number(level?.budget ?? PLAN_DEFAULTS.budget),
  };
  try {
    return typeof Plan.makePlan === 'function'
      ? Plan.makePlan(overrides)
      : overrides;
  } catch {
    return overrides;
  }
}

function makeLevelSeed(levelId) {
  try {
    if (typeof Rng.dailySeed === 'function') {
      return Rng.dailySeed(String(levelId));
    }
    if (typeof Rng.seedFromString === 'function') {
      const date = new Date();
      return Rng.seedFromString(
        `${levelId}:${date.getFullYear()}-${date.getMonth() + 1}-${date.getDate()}`,
      );
    }
  } catch {
    // Deterministic fallback below keeps today's board coherent.
  }
  const date = new Date();
  return fallbackSeed(
    `${levelId}:${date.getFullYear()}-${date.getMonth() + 1}-${date.getDate()}`,
  );
}

function makeLevelRng(seed) {
  try {
    return typeof Rng.makeRng === 'function' ? Rng.makeRng(seed) : null;
  } catch {
    return null;
  }
}

function mountTitle(rootEl, ctx) {
  const screen = document.createElement('main');
  screen.className = 'cc-screen title-screen acquisition';
  const field = document.createElement('section');
  field.className = 'title-field';
  const scan = document.createElement('span');
  scan.className = 'title-scan-line';
  const specimen = document.createElement('div');
  specimen.className = 'title-specimen';
  specimen.setAttribute('aria-hidden', 'true');
  for (let index = 0; index < 18; index += 1) {
    const cell = document.createElement('span');
    cell.className = `title-cell title-cell--${index % 6}`;
    cell.style.setProperty('--x', `${8 + ((index * 37) % 84)}%`);
    cell.style.setProperty('--y', `${10 + ((index * 53) % 78)}%`);
    specimen.append(cell);
  }
  const hero = document.createElement('div');
  hero.className = 'title-hero';
  const eyebrow = document.createElement('p');
  eyebrow.className = 'instrument-label';
  eyebrow.textContent = 'Fluorescence acquisition / Ready';
  const title = document.createElement('h1');
  title.textContent = 'Cell Commander';
  const subtitle = document.createElement('p');
  subtitle.textContent = 'Build an immune team. Find a safe way to clear the tumor.';
  const play = button('▶ Play', {
    className: 'cc-button--primary title-play',
    onClick: () => ctx.app.go(SCREEN.LEVEL_SELECT),
  });
  const secondary = document.createElement('div');
  secondary.className = 'title-secondary-actions';
  secondary.append(
    button('Leaderboard', {
      className: 'cc-button--link',
      onClick: () => ctx.app.go(SCREEN.LEADERBOARD),
    }),
    button('Sandbox', {
      className: 'cc-button--link',
      onClick: () => ctx.app.go(SCREEN.SANDBOX),
    }),
    // For presenting: the game plays itself, narrated, on a loop.
    button('Watch it play', {
      className: 'cc-button--link',
      onClick: () => startDemo(),
    }),
    // Same autopilot idea, cut as a film: chapter cards and held beats, for an audience.
    button('Cinematic tour', {
      className: 'cc-button--link',
      onClick: () => startTour(),
    }),
  );
  hero.append(eyebrow, title, subtitle, play, secondary);

  const readouts = document.createElement('aside');
  readouts.className = 'title-readouts instrument-panel';
  const capture = document.createElement('strong');
  capture.textContent = '000';
  const captureLabel = document.createElement('span');
  captureLabel.className = 'instrument-label';
  captureLabel.textContent = 'Image captured';
  const channels = document.createElement('strong');
  channels.textContent = '0 / 5';
  const channelsLabel = document.createElement('span');
  channelsLabel.className = 'instrument-label';
  channelsLabel.textContent = 'Channels ready';
  readouts.append(captureLabel, capture, channelsLabel, channels);
  field.append(specimen, scan, hero, readouts);
  screen.append(field);
  rootEl.replaceChildren(screen);

  const win = screen.ownerDocument.defaultView;
  const reduced = win?.matchMedia?.('(prefers-reduced-motion: reduce)').matches ?? false;
  let frameId = 0;
  if (reduced) {
    capture.textContent = '100';
    channels.textContent = '5 / 5';
  } else {
    const start = performance.now();
    const update = (now) => {
      const progress = Math.min(1, (now - start) / 1100);
      capture.textContent = String(Math.round(progress * 100)).padStart(3, '0');
      channels.textContent = `${Math.min(5, Math.floor(progress * 6))} / 5`;
      if (progress < 1 && screen.isConnected) {
        frameId = win.requestAnimationFrame(update);
      }
    };
    frameId = win.requestAnimationFrame(update);
  }

  return {
    unmount() {
      if (frameId) {
        win.cancelAnimationFrame(frameId);
      }
      screen.remove();
    },
  };
}

function mountLevelSelect(rootEl, ctx) {
  const screen = document.createElement('main');
  screen.className = 'cc-screen level-select-screen';
  const header = document.createElement('header');
  header.className = 'screen-header';
  const headingWrap = document.createElement('div');
  const eyebrow = document.createElement('p');
  eyebrow.className = 'instrument-label';
  eyebrow.textContent = 'Specimen library';
  const heading = document.createElement('h1');
  heading.textContent = 'Choose a mission';
  const subtitle = document.createElement('p');
  subtitle.textContent = 'Each tumor teaches a new immune-system trick.';
  const subtitleNote = document.createElement('p');
  subtitleNote.textContent = 'These rounds are meant to highlight that certain cancers are really tough to beat. This game simplifies the biology to keep it playable, but underneath it runs on the same kind of biologically-based models our lab publishes.';
  headingWrap.append(eyebrow, heading, subtitle, subtitleNote);
  const back = button('← Title', {
    className: 'cc-button--quiet',
    onClick: () => ctx.app.go(SCREEN.TITLE),
  });
  header.append(headingWrap, back);

  const grid = document.createElement('div');
  grid.className = 'level-grid';
  const levels = ctx.app.levels;
  if (!Array.isArray(levels) || levels.length === 0) {
    const waiting = document.createElement('section');
    waiting.className = 'level-loading instrument-panel';
    waiting.append(
      icon('⌬'),
      Object.assign(document.createElement('h2'), { textContent: 'Specimens are loading' }),
      Object.assign(document.createElement('p'), {
        textContent: 'The title screen is ready while the level library connects.',
      }),
    );
    grid.append(waiting);
  } else {
    const ordered = [...levels].sort((a, b) => Number(a.number) - Number(b.number));
    for (let index = 0; index < ordered.length; index += 1) {
      const level = ordered[index];
      // All levels open, by request -- players can jump to any mission instead of having
      // to win the previous one first. Win tracking and leaderboard scores below are
      // unaffected; this only removes the entry gate.
      const unlocked = true;
      const seed = ctx.app.dailySeedFor(level.id);
      const scores = LeaderboardScreen.loadScores(level.id, seed);
      const card = document.createElement('article');
      card.className = `level-card ${unlocked ? 'is-unlocked' : 'is-locked'}`;
      const cardTop = document.createElement('div');
      cardTop.className = 'level-card__top';
      const number = document.createElement('span');
      number.className = 'level-card__number';
      number.textContent = String(level.number).padStart(2, '0');
      const state = chip(
        Number(level.number) === 6 ? 'Always open' : unlocked ? 'Ready' : 'Locked',
        { tone: unlocked ? 'ok' : 'neutral', icon: unlocked ? '✓' : '⌁' },
      );
      cardTop.append(number, state);
      const name = document.createElement('h2');
      name.textContent = level.name;
      const teaches = document.createElement('p');
      teaches.textContent = level.teaches;
      const best = document.createElement('p');
      best.className = 'level-card__best instrument-label';
      best.textContent = scores.length > 0
        ? `Best today ${scores[0].score.toLocaleString('en-US')}`
        : 'No score today';
      const action = button(
        Number(level.number) === 6 ? 'Open sandbox' : unlocked ? 'Study this tumor' : 'Win the mission before this',
        {
          className: unlocked ? 'cc-button--primary level-card__action' : 'level-card__action',
          disabled: !unlocked,
          onClick: () => ctx.app.go(
            Number(level.number) === 6 ? SCREEN.SANDBOX : SCREEN.SETUP,
            { level },
          ),
        },
      );
      card.append(cardTop, name, teaches, best, action);
      grid.append(card);
    }
  }
  screen.append(header, grid);
  rootEl.replaceChildren(screen);
  return {
    unmount() {
      screen.remove();
    },
  };
}

function mountFailure(rootEl) {
  const surface = document.createElement('main');
  surface.className = 'cc-screen route-failure';
  const label = document.createElement('p');
  label.className = 'instrument-label';
  label.textContent = 'Screen error';
  const title = document.createElement('h1');
  title.textContent = 'Something went wrong loading this screen';
  const body = document.createElement('p');
  body.textContent = 'Reload the game to try again.';
  const win = rootEl.ownerDocument.defaultView;
  const reload = button('Reload', {
    className: 'cc-button--primary',
    onClick: () => win?.location.reload(),
  });
  surface.append(label, title, body, reload);
  rootEl.replaceChildren(surface);
  return {
    unmount() {
      surface.remove();
    },
  };
}

/**
 * Boots Cell Commander into a supplied root and returns its router/lifecycle API.
 * @param {HTMLElement} rootEl
 * @returns {{go:(screen:string,payload?:object)=>void,current:string,destroy:()=>void}}
 */
export function boot(rootEl) {
  if (!rootEl) {
    throw new TypeError('Cell Commander needs a root element.');
  }
  const win = rootEl.ownerDocument.defaultView;
  const storage = safeStorage(win);
  let mounted = null;
  let mountedContext = null;
  let idleTimer = 0;
  let frameId = 0;
  let lastFrame = performance.now();
  let hasLoggedFrameError = false;
  let destroyed = false;
  const perfMonitor = makePerfMonitor();
  const qualityController = makeQualityController(QUALITY.HIGH.id);

  const app = {
    current: '',
    level: null,
    levels: Array.isArray(Levels.LEVELS) ? Levels.LEVELS : [],
    plan: null,
    round: null,
    rng: null,
    seed: null,
    storage,
    quality: qualityController.tier,
    progress: readProgress(storage),
    dailySeedFor: makeLevelSeed,
    markWon(levelId) {
      const id = String(levelId);
      if (!app.progress.wins.includes(id)) {
        app.progress.wins.push(id);
        writeProgress(storage, app.progress);
      }
    },
    go(screen, payload = {}) {
      if (destroyed || !Object.values(SCREEN).includes(screen)) {
        return;
      }
      if (!IDLE_SCREENS.has(screen)) {
        clearTimeout(idleTimer);
        idleTimer = 0;
      }
      mounted?.unmount();
      mounted = null;
      mountedContext = null;

      if (payload.level) {
        app.level = payload.level;
      } else if (payload.levelId && typeof Levels.getLevel === 'function') {
        try {
          app.level = Levels.getLevel(payload.levelId);
        } catch {
          app.level = app.levels[0] ?? null;
        }
      }
      if (!app.level && screen !== SCREEN.TITLE && screen !== SCREEN.LEVEL_SELECT) {
        app.level = screen === SCREEN.SANDBOX
          ? app.levels.find((level) => Number(level.number) === 6) ?? app.levels.at(-1) ?? null
          : app.levels[0] ?? null;
      }
      if (screen === SCREEN.SETUP) {
        app.plan = payload.plan ?? makeTreatmentPlan(app.level);
        app.round = null;
      } else if (payload.plan) {
        app.plan = payload.plan;
      }
      if (screen === SCREEN.SANDBOX && !app.plan) {
        app.plan = makeTreatmentPlan(app.level);
      }
      if (app.level) {
        app.seed = payload.seed ?? makeLevelSeed(app.level.id);
        app.rng = makeLevelRng(app.seed);
      }
      if (screen === SCREEN.PLAYING) {
        app.round = payload.round ?? null;
        if (!app.round && app.level && app.plan) {
          try {
            app.round = typeof Engine.createRound === 'function'
              ? Engine.createRound({
                level: app.level,
                plan: app.plan,
                seed: app.seed,
                quality: app.quality,
              })
              : null;
          } catch {
            app.round = null;
          }
        }
      } else if (payload.round) {
        app.round = payload.round;
      }

      app.current = screen;
      rootEl.dataset.screen = screen;
      const ctx = {
        app,
        level: app.level,
        plan: app.plan,
        round: app.round,
        rng: app.rng,
        storage,
        quality: app.quality,
      };
      mountedContext = ctx;
      try {
        if (screen === SCREEN.TITLE) {
          mounted = mountTitle(rootEl, ctx);
        } else if (screen === SCREEN.LEVEL_SELECT) {
          mounted = mountLevelSelect(rootEl, ctx);
        } else if (screen === SCREEN.SETUP) {
          mounted = SetupScreen.mount(rootEl, ctx);
        } else if (screen === SCREEN.PLAYING) {
          mounted = LiveScreen.mount(rootEl, ctx);
        } else if (screen === SCREEN.RESULTS) {
          mounted = ResultsScreen.mount(rootEl, ctx);
        } else if (screen === SCREEN.LEADERBOARD) {
          mounted = LeaderboardScreen.mount(rootEl, ctx);
        } else if (screen === SCREEN.SANDBOX) {
          mounted = SandboxScreen.mount(rootEl, ctx);
        }
      } catch (error) {
        // Surface the cause. The player still gets the friendly Reload screen, but silently
        // swallowing the exception makes a booth failure impossible to diagnose afterwards —
        // and it hid a real use-before-declaration bug during development.
        rootEl.ownerDocument.defaultView?.console?.error(
          `Cell Commander: the "${screen}" screen failed to mount.`,
          error,
        );
        mounted = mountFailure(rootEl);
      }
      if (mounted) {
        const screenRoot = rootEl.querySelector('.cc-screen');
        const focusTarget = screenRoot?.querySelector('h1') ?? screenRoot;
        if (focusTarget) {
          focusTarget.tabIndex = -1;
          focusTarget.focus({ preventScroll: true });
        }
      }
      resetIdle();
    },
    destroy() {
      if (destroyed) {
        return;
      }
      destroyed = true;
      mounted?.unmount();
      mounted = null;
      mountedContext = null;
      clearTimeout(idleTimer);
      win.cancelAnimationFrame(frameId);
      for (const eventName of ['pointerdown', 'keydown', 'touchstart']) {
        win.removeEventListener(eventName, resetIdle);
      }
      rootEl.replaceChildren();
      delete rootEl.dataset.screen;
    },
  };

  function resetIdle() {
    clearTimeout(idleTimer);
    idleTimer = 0;
    if (!IDLE_SCREENS.has(app.current)) {
      return;
    }
    idleTimer = win.setTimeout(() => {
      if (!destroyed && IDLE_SCREENS.has(app.current)) {
        app.go(SCREEN.TITLE);
      }
    }, IDLE_MS);
  }

  function applyQuality(quality) {
    app.quality = quality;
    if (mountedContext) {
      mountedContext.quality = quality;
    }
    if (app.round) {
      try {
        app.round.quality = quality;
      } catch {
        // The next round still inherits app.quality even if this round is immutable.
      }
    }
    try {
      mounted?.setQuality?.(quality);
    } catch {
      // Quality adaptation must not interrupt the master animation loop.
    }
  }

  function frame(now) {
    if (destroyed) {
      return;
    }
    const frameMs = Number.isFinite(now) ? Math.max(0, now - lastFrame) : 0;
    const dt = Math.min(0.1, frameMs / 1000);
    lastFrame = now;
    perfMonitor.frame(frameMs);
    if (qualityController.update(perfMonitor.median())) {
      applyQuality(qualityController.tier);
    }
    try {
      mounted?.update?.(dt);
    } catch (error) {
      if (!hasLoggedFrameError) {
        hasLoggedFrameError = true;
        win.console?.error('Cell Commander screen update failed:', error);
      }
    }
    frameId = win.requestAnimationFrame(frame);
  }

  for (const eventName of ['pointerdown', 'keydown', 'touchstart']) {
    win.addEventListener(eventName, resetIdle, { passive: true });
  }
  app.go(SCREEN.TITLE);
  frameId = win.requestAnimationFrame(frame);

  // ?demo=1 opens straight into the narrated self-playing walkthrough, so a projector link
  // needs no interaction. Started after the first screen has mounted and the frame loop is
  // running, because the autopilot drives the real UI exactly as a person would.
  if (demoRequested(win)) {
    win.setTimeout(() => {
      try {
        startDemo();
      } catch (error) {
        win.console?.error('Cell Commander: demo mode failed to start.', error);
      }
    }, 900);
  }

  // ?tour=1 is the cinematic cut of the same idea. Kept separate from ?demo=1 so a broken
  // tour can never take the plain playthrough down with it.
  if (tourRequested(win)) {
    win.setTimeout(() => {
      try {
        startTour();
      } catch (error) {
        win.console?.error('Cell Commander: tour mode failed to start.', error);
      }
    }, 900);
  }

  return app;
}

if (typeof document !== 'undefined') {
  const root = document.getElementById('root');
  if (root) {
    boot(root);
  }

  const win = document.defaultView;
  if (win) {
    const { location, navigator } = win;
    const isLocalhost = location.hostname === 'localhost'
      || location.hostname === '127.0.0.1';
    // The standalone bundle IS the offline mechanism — everything is already inlined into
    // one file — so it must not try to register a worker. It is routinely opened from a
    // subdirectory or from Files on an iPad, where './sw.js' does not resolve and the failed
    // fetch logs a 404 that looks like a real fault to whoever is running the booth.
    const isStandaloneBundle = win.__CC_STANDALONE__ === true;

    const canRegister = 'serviceWorker' in navigator
      && !isStandaloneBundle
      && location.protocol !== 'file:'
      && (location.protocol === 'https:' || isLocalhost);

    if (canRegister) {
      const registerServiceWorker = async () => {
        try {
          await navigator.serviceWorker.register('./sw.js');
        } catch (error) {
          win.console?.warn('Cell Commander offline caching is unavailable:', error);
        }
      };
      if (document.readyState === 'complete') {
        void registerServiceWorker();
      } else {
        win.addEventListener('load', registerServiceWorker, { once: true });
      }
    }
  }
}
