/**
 * live.js — owns the thin in-round microscope chrome, fixed-step play controls,
 * channel toggles, rally beacon interaction, and render/HUD integration call sites.
 */

import {
  COLORS,
  FIELD,
  FIELD_LABEL,
  KIND,
  KIND_LABEL,
  MAX_CATCHUP_TICKS,
  OUTCOME,
  PLACEABLE,
  SCREEN,
  TICK_DT,
  WORLD_H,
  WORLD_W,
} from '../core/contracts.js';
import * as CanvasRender from '../render/canvas.js';
import * as HudRender from '../render/hud.js';
import { P } from '../sim/params.js';
import { makeCoachStrip } from './coach-strip.js';
import {
  button,
  channelRail,
  chip,
  icon,
  meter,
  segmentedControl,
} from './components.js';

const CHANNELS = Object.freeze([
  { id: FIELD.CHEMOKINE, label: FIELD_LABEL[FIELD.CHEMOKINE], glyph: '◎', className: 'channel--cart' },
  { id: FIELD.IFNG, label: FIELD_LABEL[FIELD.IFNG], glyph: '⚡', className: 'channel--cd8' },
  { id: FIELD.IL2, label: FIELD_LABEL[FIELD.IL2], glyph: '✦', className: 'channel--cd4' },
  { id: FIELD.SUPPRESS, label: FIELD_LABEL[FIELD.SUPPRESS], glyph: '⌁', className: 'channel--macro' },
  { id: FIELD.DEBRIS, label: FIELD_LABEL[FIELD.DEBRIS], glyph: '·', className: 'channel--tumor' },
]);

const ROSTER_COLOR = Object.freeze({
  [KIND.CART]: COLORS.cart,
  [KIND.CD8]: COLORS.cd8,
  [KIND.NK]: COLORS.nk,
  [KIND.MACRO]: COLORS.macro,
  [KIND.DC]: COLORS.dc,
  [KIND.CD4]: COLORS.cd4,
  [KIND.TUMOR]: COLORS.tumor,
  [KIND.HEALTHY]: COLORS.healthy,
});

const ROSTER_GLYPH = Object.freeze({
  [KIND.CART]: '⬢',
  [KIND.CD8]: '◕',
  [KIND.NK]: '◆',
  [KIND.MACRO]: '✣',
  [KIND.DC]: '✦',
  [KIND.CD4]: '●',
  [KIND.TUMOR]: '⬤',
  [KIND.HEALTHY]: '○',
});

const KIND_FX_COLOR = Object.freeze({
  [KIND.TUMOR]: COLORS.tumor,
  [KIND.CD8]: COLORS.cd8,
  [KIND.CART]: COLORS.cart,
  [KIND.NK]: COLORS.nk,
  [KIND.MACRO]: COLORS.macro,
  [KIND.DC]: COLORS.dc,
  [KIND.CD4]: COLORS.cd4,
  [KIND.TREG]: COLORS.treg,
  [KIND.VESSEL]: COLORS.vessel,
  [KIND.HEALTHY]: COLORS.healthy,
});

function prefersReducedMotion(win) {
  try {
    return win?.matchMedia?.('(prefers-reduced-motion: reduce)').matches ?? false;
  } catch {
    return false;
  }
}

function emitRoundEvents(events, fx) {
  if (!Array.isArray(events) || !fx) {
    return;
  }
  for (const event of events) {
    if (event.type === 'kill') {
      fx.emitKill(event.x, event.y, KIND_FX_COLOR[event.victimKind] ?? COLORS.ink);
    } else if (event.type === 'divide') {
      fx.emitDivide(event.x, event.y);
    } else if (event.type === 'toxicity') {
      fx.emitToxic(event.x, event.y);
    } else if (event.type === 'engage') {
      fx.emitPuff(event.x, event.y, COLORS.ink);
    } else if (event.type === 'polarize') {
      fx.emitPuff(event.x, event.y, COLORS.macro);
    } else if (event.type === 'wave') {
      fx.emitPuff(event.x, event.y, KIND_FX_COLOR[event.kind] ?? COLORS.dc);
    }
  }
}

function formatTime(seconds) {
  const safe = Math.max(0, Math.floor(Number(seconds) || 0));
  return `${Math.floor(safe / 60)}:${String(safe % 60).padStart(2, '0')}`;
}

/** One roster line: the cell's own mark, in its own colour, beside its name. */
function rosterRow(kind, countText) {
  const item = document.createElement('div');
  item.className = 'roster-item';
  const mark = icon(ROSTER_GLYPH[kind]);
  mark.classList.add('roster-item__mark');
  mark.style.color = ROSTER_COLOR[kind] ?? 'currentColor';
  const name = document.createElement('span');
  name.textContent = KIND_LABEL[kind];
  const count = document.createElement('strong');
  count.textContent = countText;
  item.append(mark, name, count);
  return item;
}

function countPlaced(plan, kind) {
  return plan?.placements?.filter((placement) => placement.kind === kind).length ?? 0;
}

/**
 * Mounts the active treatment screen and returns its animation update hook.
 * @param {HTMLElement} rootEl
 * @param {{app:object,level:object,plan:object,round:object,quality:object}} ctx
 * @returns {{unmount:()=>void,update:(dt:number)=>void,setQuality:(quality:object)=>void}}
 */
export function mount(rootEl, ctx) {
  const screen = document.createElement('main');
  screen.className = 'cc-screen game-shell live-screen';
  const canvasRegion = document.createElement('section');
  canvasRegion.className = 'tissue-region';
  const canvas = document.createElement('canvas');
  canvas.className = 'tissue-canvas';
  canvas.setAttribute('aria-label', 'Live tissue field');
  canvas.tabIndex = 0;
  const scanLine = document.createElement('span');
  scanLine.className = 'acquisition-scan';
  canvasRegion.append(canvas, scanLine);

  const reducedMotion = prefersReducedMotion(canvas.ownerDocument.defaultView);
  // Live commentary: tells the child WHY the round is going the way it is, while they
  // can still act on it. See docs/LIVE-FEEDBACK.md.
  // Declared before the coach because the coach closes over it to announce through the
  // HUD's single live region. Relying on the arrow being called later would work, but it
  // is the same use-before-declaration shape that already caused one mount failure here.
  let hud = null;

  const coach = makeCoachStrip({
    reducedMotion,
    announce: (text) => hud?.announce?.(text),
  });
  canvasRegion.append(coach.el);

  let fieldOverlay = null;
  let renderer = null;
  const uiState = {
    paused: false,
    speed: 1,
    beaconActive: false,
    fieldOverlay,
    quality: ctx.quality,
  };

  try {
    renderer = typeof CanvasRender.makeRenderer === 'function'
      ? CanvasRender.makeRenderer(canvas, { quality: ctx.quality })
      : null;
  } catch {
    renderer = null;
  }

  const rail = channelRail(CHANNELS, (fieldId) => {
    fieldOverlay = fieldId;
    uiState.fieldOverlay = fieldId;
    try {
      renderer?.setFieldOverlay(fieldId);
    } catch {
      // The field controls remain useful even while a renderer is integrating.
    }
  });

  const panel = document.createElement('aside');
  panel.className = 'instrument-panel live-panel';
  const panelLabel = document.createElement('p');
  panelLabel.className = 'instrument-label';
  panelLabel.textContent = 'Live specimen';
  const fallbackHud = document.createElement('div');
  fallbackHud.className = 'ui-hud-fallback';
  const tumorReadout = document.createElement('div');
  tumorReadout.className = 'headline-readout';
  const tumorLabel = document.createElement('span');
  tumorLabel.className = 'instrument-label';
  tumorLabel.textContent = 'Cancer cells';
  const tumorValue = document.createElement('strong');
  tumorValue.textContent = String(ctx.round?.tumorCount ?? '—');
  tumorReadout.append(tumorLabel, tumorValue);
  const patientMeter = meter('Patient health', ctx.round?.patientHealth ?? 100, {
    max: 100,
    unit: '%',
    tone: 'health',
  });
  const crsMeter = meter('Fever / CRS', (ctx.round?.crs ?? 0) * 100, {
    max: 100,
    unit: '%',
    tone: 'crs',
  });
  const timeReadout = document.createElement('div');
  timeReadout.className = 'time-readout';
  timeReadout.append(
    Object.assign(document.createElement('span'), {
      className: 'instrument-label',
      textContent: 'Time',
    }),
    Object.assign(document.createElement('strong'), {
      textContent: formatTime(ctx.round?.timeSec ?? 0),
    }),
  );
  const roster = document.createElement('section');
  roster.className = 'roster-panel';
  const rosterTitle = document.createElement('h2');
  rosterTitle.className = 'instrument-label';
  rosterTitle.textContent = 'Your roster';
  roster.append(rosterTitle);
  for (const kind of PLACEABLE) {
    const count = countPlaced(ctx.plan, kind);
    if (count === 0) {
      continue;
    }
    roster.append(rosterRow(kind, String(count)));
  }

  // Name the two most common things on screen. A child could previously tell an NK cell from
  // a killer T cell only by guessing — the shapes are deliberately distinct, but nothing said
  // which was which, and the cancer and healthy cells were never named at all.
  const keyTitle = document.createElement('h2');
  keyTitle.className = 'instrument-label roster-key__title';
  keyTitle.textContent = 'Also on screen';
  roster.append(keyTitle, rosterRow(KIND.TUMOR, ''), rosterRow(KIND.HEALTHY, ''));
  const hudHost = document.createElement('div');
  hudHost.className = 'renderer-hud-host';
  fallbackHud.append(
    tumorReadout,
    patientMeter,
    crsMeter,
    timeReadout,
    roster,
  );
  panel.append(panelLabel, fallbackHud, hudHost);
  try {
    hud = typeof HudRender.makeHud === 'function' ? HudRender.makeHud(hudHost) : null;
    fallbackHud.hidden = Boolean(hud);
  } catch {
    hud = null;
  }

  const bottom = document.createElement('footer');
  bottom.className = 'play-bottom-bar';
  const back = button('← Levels', {
    className: 'cc-button--quiet',
    onClick: () => ctx.app.go(SCREEN.LEVEL_SELECT),
  });
  const pauseButton = button('Ⅱ Pause', {
    className: 'cc-button--quiet',
    onClick: () => {
      uiState.paused = !uiState.paused;
      pauseButton.textContent = uiState.paused ? '▶ Play' : 'Ⅱ Pause';
      pauseButton.setAttribute('aria-pressed', String(uiState.paused));
    },
  });
  pauseButton.setAttribute('aria-pressed', 'false');
  const speedControl = segmentedControl(
    [
      { value: 1, label: '1×' },
      { value: 2, label: '2×' },
      { value: 3, label: '3×' },
    ],
    {
      value: 1,
      label: 'Treatment speed',
      onChange: (value) => {
        // Guard the multiplier. It feeds the fixed-step accumulator, and a NaN there would
        // silently stop the simulation forever with the UI still showing "running" — a
        // failure with no error and no visible cause, which is the worst kind to debug on a
        // projector.
        const next = Number(value);
        uiState.speed = Number.isFinite(next) ? Math.min(3, Math.max(1, next)) : 1;
        try {
          ctx.round?.setSpeed(uiState.speed);
        } catch {
          // The fixed-step caller below still applies the selected multiplier.
        }
      },
    },
  );
  let beaconUses = P.beacon.uses;
  const beaconButton = button('', {
    className: 'cc-button--beacon',
    ariaLabel: 'Place a rally beacon',
    pressed: false,
  });
  const beaconLabel = document.createElement('span');
  beaconLabel.textContent = '◎ Rally beacon';
  const beaconCount = document.createElement('strong');
  beaconCount.textContent = `${beaconUses} left`;
  beaconButton.append(beaconLabel, beaconCount);
  beaconButton.addEventListener('click', () => {
    if (beaconUses <= 0) {
      return;
    }
    uiState.beaconActive = !uiState.beaconActive;
    beaconButton.classList.toggle('is-active', uiState.beaconActive);
    beaconButton.setAttribute('aria-pressed', String(uiState.beaconActive));
  });
  const beaconHint = chip('Tap the tissue to call cells here.', { tone: 'hint', icon: '◎' });
  const stopButton = button('■ Emergency stop', {
    className: 'cc-button--danger',
    onClick: () => {
      try {
        ctx.round?.abort();
      } finally {
        ctx.app.go(SCREEN.RESULTS, { level: ctx.level, plan: ctx.plan, round: ctx.round });
      }
    },
  });
  if (!ctx.round) {
    stopButton.disabled = true;
  }
  bottom.append(back, pauseButton, speedControl, beaconButton, beaconHint, stopButton);
  screen.append(rail, canvasRegion, panel, bottom);
  rootEl.replaceChildren(screen);

  function resizeRenderer() {
    // Measure the CANVAS, not its container. The container is the full tissue region, but
    // .tissue-canvas is constrained by `aspect-ratio: 3/2` and a `max-height`, so the element
    // the browser actually paints is shorter than its host. Sizing the backing store from the
    // host made the bitmap 748px tall while CSS displayed it at 557px, and the browser
    // squashed the whole simulation vertically by 25% — cells drifted off their true
    // positions and the tissue read as a wide letterbox slot.
    // getBoundingClientRect on a not-yet-laid-out canvas can be 0, so fall back to the host.
    const canvasRect = canvas.getBoundingClientRect();
    const hostRect = canvasRegion.getBoundingClientRect();
    const rect = canvasRect.width > 0 && canvasRect.height > 0 ? canvasRect : hostRect;
    if (renderer) {
      try {
        renderer.resize(rect.width, rect.height);
        return;
      } catch {
        renderer = null;
      }
    }
    const dpr = Math.max(1, canvas.ownerDocument.defaultView?.devicePixelRatio ?? 1);
    canvas.width = Math.max(1, Math.round(rect.width * dpr));
    canvas.height = Math.max(1, Math.round(rect.height * dpr));
  }

  function drawFallback() {
    const context = canvas.getContext('2d');
    const dpr = Math.max(1, canvas.ownerDocument.defaultView?.devicePixelRatio ?? 1);
    const cssW = canvas.width / dpr;
    const cssH = canvas.height / dpr;
    context.setTransform(dpr, 0, 0, dpr, 0, 0);
    context.fillStyle = '#0A1018';
    context.fillRect(0, 0, cssW, cssH);
    context.fillStyle = '#7E93A8';
    context.font = '14px ui-monospace, monospace';
    context.textAlign = 'center';
    context.fillText(
      ctx.round ? 'Specimen renderer is connecting…' : 'Treatment model is connecting…',
      cssW / 2,
      cssH / 2,
    );
  }

  function canvasToWorld(event) {
    const rect = canvas.getBoundingClientRect();
    const point = { x: 0, y: 0 };
    if (renderer) {
      try {
        renderer.screenToWorld(event.clientX - rect.left, event.clientY - rect.top, point);
        return point;
      } catch {
        // Fall through to the same centered 3:2 letterbox used by setup.
      }
    }
    const scale = Math.min(rect.width / WORLD_W, rect.height / WORLD_H);
    const offsetX = (rect.width - WORLD_W * scale) / 2;
    const offsetY = (rect.height - WORLD_H * scale) / 2;
    point.x = Math.max(0, Math.min(WORLD_W, (event.clientX - rect.left - offsetX) / scale));
    point.y = Math.max(0, Math.min(WORLD_H, (event.clientY - rect.top - offsetY) / scale));
    return point;
  }

  canvas.addEventListener('pointerup', (event) => {
    if (!uiState.beaconActive || beaconUses <= 0 || !ctx.round?.grid) {
      return;
    }
    const point = canvasToWorld(event);
    try {
      ctx.round.grid.depositRadius(FIELD.BEACON, point.x, point.y, P.beacon.strength, P.beacon.radius);
      beaconUses -= 1;
      beaconCount.textContent = `${beaconUses} left`;
      uiState.beaconActive = false;
      beaconButton.classList.remove('is-active');
      beaconButton.setAttribute('aria-pressed', 'false');
      beaconButton.disabled = beaconUses <= 0;
    } catch {
      // Keep the control alive if a partially integrated round lacks its field grid.
    }
  });

  resizeRenderer();
  const resizeObserver = typeof ResizeObserver === 'function'
    ? new ResizeObserver(resizeRenderer)
    : null;
  resizeObserver?.observe(canvasRegion);

  let accumulator = 0;
  return {
    update(dt) {
      if (ctx.round && !uiState.paused && ctx.round.outcome === OUTCOME.RUNNING) {
        const step = Number.isFinite(dt) ? Math.min(0.1, Math.max(0, dt)) : 0;
        accumulator += step * uiState.speed;
        if (!Number.isFinite(accumulator)) accumulator = 0; // never let the clock die silently
        let ticks = 0;
        while (accumulator >= TICK_DT && ticks < MAX_CATCHUP_TICKS) {
          ctx.round.tick(TICK_DT);
          accumulator -= TICK_DT;
          ticks += 1;
        }
        // On overload, dropping excess simulation time is preferable to a permanent backlog.
        accumulator = Math.min(accumulator, MAX_CATCHUP_TICKS * TICK_DT);
      }
      if (ctx.round && typeof ctx.round.drainEvents === 'function') {
        const events = ctx.round.drainEvents();
        for (const event of events) {
          if (event?.type === 'kill') coach.noteKill();
          else if (event?.type === 'wave') coach.noteWave();
        }
        if (!reducedMotion) {
          emitRoundEvents(events, renderer?.fx);
        }
      }
      coach.update(dt, ctx.round, ctx.plan);
      if (ctx.round?.outcome !== undefined && ctx.round.outcome !== OUTCOME.RUNNING) {
        ctx.app.go(SCREEN.RESULTS, {
          level: ctx.level,
          plan: ctx.plan,
          round: ctx.round,
        });
        return;
      }

      tumorValue.textContent = String(ctx.round?.tumorCount ?? '—');
      patientMeter.setValue(ctx.round?.patientHealth ?? 100, 100);
      crsMeter.setValue((ctx.round?.crs ?? 0) * 100, 100);
      timeReadout.lastElementChild.textContent = formatTime(ctx.round?.timeSec ?? 0);
      try {
        // A11Y-NOTE: hud.js is the sole aria-live owner and already throttles via setTextIfChanged.
        hud?.update(ctx.round, ctx.level);
      } catch {
        hud = null;
      }

      // API-NOTE: This is the frozen renderer integration seam. The fallback only
      // paints a tissue field while src/render/canvas.js is landing.
      if (renderer && ctx.round) {
        try {
          renderer.draw(ctx.round, uiState, dt);
        } catch {
          renderer = null;
          drawFallback();
        }
      } else {
        drawFallback();
      }
    },
    setQuality(quality) {
      ctx.quality = quality;
      uiState.quality = quality;
      if (ctx.round) {
        ctx.round.quality = quality;
      }
      renderer?.fx?.setBudget(reducedMotion ? 0 : quality?.particles);
    },
    unmount() {
      coach.destroy();
      resizeObserver?.disconnect();
      try {
        hud?.setVisible(false);
      } catch {
        // The DOM removal below is the final cleanup path.
      }
      screen.remove();
    },
  };
}
