# Live Feedback Design — the Coach, the Key, and Inspect

A design spec for three additions aimed at one problem.

## The problem

Once a child presses **Start treatment**, the game becomes a thing they watch. The instrument
panel reports *what* is happening — 22 cancer cells, patient 96%, cytokines 31% — but never
*why*. When the tumor count stops falling, a child has no way to tell whether:

- the tumor raised its shield and their cells are being braked,
- their cells are exhausted,
- the survivors are flag-hiders their CAR-T cannot see,
- or their cells simply never found the tumor.

Those are four completely different lessons with four different answers, and they are the whole
point of the game. Right now all four look identical: a number that stopped moving.

The science cards explain them — *after* the round, when the child can no longer act. The most
dramatic beat in the game, the moment PD-L1 rises, passes completely unmarked.

## 1. The Coach — a live event ticker

A narrow strip along the bottom of the tissue field. When something meaningful happens, one
short sentence slides in, stays ~5 s, and fades. At most one message at a time; a new message
of higher priority replaces the current one, otherwise it queues.

**Voice:** the same as everywhere else — direct, active, second person, never blaming. It names
what happened and, where there is one, the lever the child holds.

| Trigger (observed from round state, ~2 Hz) | Message | Priority |
|---|---|---|
| Mean tumor PD-L1 rises past 0.35 for the first time | `The tumor just put up a shield. That's its answer to being attacked.` | high |
| Same, and the player has no checkpoint inhibitor | `The shield is slowing your cells. The checkpoint medicine removes it.` | high |
| Mean killer exhaustion passes 0.5 | `Your T cells are getting tired. Helper cells and IL-2 keep them going.` | med |
| CRS passes the danger threshold | `The patient is running a fever. Too many cells fighting at once.` | high |
| A flag-less cell's mean MHC-I drifts back above 0.3 (level has CD8 unlocked) | `Some no-flag cells raised their badge again — CD8 cells can catch those.` | high |
| 15s into The Escape Artist and IL-2 support hasn't been bought | `This is a long fight. Energy Boost (IL-2) helps your T cells survive and keep dividing.` | med |
| No killer has been engaged for 8 s while tumor cells remain | `Your cells can't find the tumor. Drop a rally beacon to call them over.` | med |
| First kill of the round | `That's a kill. One T cell can do that over and over.` | low |
| Tumor count crosses below 25% of its starting value | `You're winning. Keep the pressure on.` | low |
| A dendritic cell calls a wave | `Your dendritic cell brought in reinforcements.` | low |

Each message fires **once per round** so the strip never nags. All copy lives in
`src/content/coach.js` as data, next to the science cards, so it can be reviewed for accuracy
without reading UI code.

Two rules that used to live in this table, `healthy-death` and `flagless-tumor`, were removed
when CAR-T was removed as a playable option: CAR-T was the only killer type whose recognition
check does not require the target to be a tumor cell (it matches purely on antigen), so it was
the only kind able to hit a healthy cell at all. Without it, a healthy cell can never be killed
and antigen/flag status no longer affects which killer can catch a cell, so neither rule can
fire or has anything actionable left to say. See `src/content/coach.js` for the full note.

The strip is also an `aria-live="polite"` region — it is the natural place for a screen reader to
learn what is happening, and it replaces nothing that already exists.

## 2. The Key — a persistent legend

A child currently cannot tell an NK cell from a killer T cell. The shapes are distinct by
design, but nothing on screen says which is which, and the roster in the instrument panel lists
names without showing the mark.

Put the mark next to the name. The roster already lists every cell type the player owns; render
each row's glyph in that cell's colour and shape, at a size that is legible at arm's length, and
add the cancer cell and healthy cell as two non-purchasable rows so the two most common things
on screen are named. That is the whole fix — no new panel, no extra screen space.

## 3. Inspect — tap any cell

Tap a cell in the tissue field and a small card appears beside it for a few seconds:

```
CAR-T Cell
Hunting: green flag
Getting tired (40%)
```

```
Cancer Cell
Flag: none
Shield: up
```

The card answers, in the child's own vocabulary, the question the whole screen is provoking:
*what is that, and what is it doing?* It costs nothing to ignore, and it rewards the curious —
which is the population this exhibit exists for.

Rules: tapping empty tissue dismisses it; the card never covers the cell it describes; it does
not pause the simulation; it re-reads state each frame so a watched cell's status updates live.

## Why these three and not more agency

The obvious alternative — giving the player more to *do* during a round — would make the game
busier without making it clearer, and would compete with the simulation for attention. The
diagnosis problem is the one actually blocking understanding. A child who can see *why* their
attack stalled will change their plan on the next run, which is the loop this exhibit is for.
