/**
 * canvas.js owns DPR-capped canvas sizing, 3:2 view transforms, the fixed
 * tissue draw pipeline, selected-field haze, acquisition motion, and FX.
 */

import {
  COLORS,
  FIELD,
  FIELD_COUNT,
  FIELD_LABEL,
  KIND,
  QUALITY,
  STATE,
  WORLD_H,
  WORLD_W,
} from '../core/contracts.js';
import {
  TISSUE_COLS,
  TISSUE_ROWS,
  TISSUE_MAP,
} from '../content/tissue-architecture.js';
import { makeFx } from './fx.js';
import {
  buildSpriteCache,
  spriteSizeBucket,
  spriteVariantKey,
} from './sprites.js';

// API-NOTE: Field channels have no canonical colors in the assigned contracts.js
// snapshot; promote these single-hue choices into contracts.js as FIELD_COLOR.
const FIELD_COLORS = Object.freeze([
  '#2BD9C4',
  '#FF6B3D',
  '#C6F24A',
  '#7B6BFF',
  '#C9A66B',
  '#2BD9C4', // FIELD.BEACON: not a user-selectable channel, reuses chemokine's hue
]);

const FIELD_RGB = new Uint8Array(FIELD_COUNT * 3);
for (let field = 0; field < FIELD_COUNT; field += 1) {
  const packed = Number.parseInt(FIELD_COLORS[field].slice(1), 16);
  const target = field * 3;
  FIELD_RGB[target] = packed >> 16;
  FIELD_RGB[target + 1] = (packed >> 8) & 0xff;
  FIELD_RGB[target + 2] = packed & 0xff;
}

const ACQUISITION_SECONDS = 1.1;
const TAU = Math.PI * 2;

function safeDimension(value) {
  return Number.isFinite(value) ? Math.max(0, value) : 0;
}

function safeDpr(forcedDpr) {
  const detected = Number.isFinite(forcedDpr)
    ? forcedDpr
    : Number(globalThis.devicePixelRatio) || 1;
  return Math.max(1, Math.min(2, detected));
}

function prefersReducedMotion() {
  try {
    return typeof globalThis.window !== 'undefined'
      && typeof globalThis.window.matchMedia === 'function'
      && globalThis.window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  } catch {
    return false;
  }
}

function createSurface(width, height, ownerDocument) {
  const safeWidth = Math.max(1, Math.ceil(width));
  const safeHeight = Math.max(1, Math.ceil(height));
  if (typeof globalThis.OffscreenCanvas === 'function') {
    return new globalThis.OffscreenCanvas(safeWidth, safeHeight);
  }
  const doc = ownerDocument
    ?? (typeof globalThis.document !== 'undefined' ? globalThis.document : null);
  if (doc && typeof doc.createElement === 'function') {
    const surface = doc.createElement('canvas');
    surface.width = safeWidth;
    surface.height = safeHeight;
    return surface;
  }
  return null;
}

/**
 * Computes the centered 3:2 tissue rectangle for a CSS-pixel container.
 * @param {number} cssW
 * @param {number} cssH
 * @param {{x:number,y:number,width:number,height:number,scale:number}} [out]
 * @returns {{x:number,y:number,width:number,height:number,scale:number}}
 */
export function computeLetterbox(cssW, cssH, out) {
  const result = out ?? { x: 0, y: 0, width: 0, height: 0, scale: 0 };
  const width = safeDimension(cssW);
  const height = safeDimension(cssH);
  const scale = width > 0 && height > 0
    ? Math.min(width / WORLD_W, height / WORLD_H)
    : 0;
  result.width = WORLD_W * scale;
  result.height = WORLD_H * scale;
  result.x = (width - result.width) * 0.5;
  result.y = (height - result.height) * 0.5;
  result.scale = scale;
  return result;
}

/**
 * Creates the read-only round renderer for one canvas.
 * @param {HTMLCanvasElement|OffscreenCanvas|null} canvas
 * @param {object} opts
 * @returns {{
 *   resize:function(number,number):void,
 *   setView:function(object):void,
 *   draw:function(object,object,number):void,
 *   worldToScreen:function(number,number,object):void,
 *   screenToWorld:function(number,number,object):void,
 *   setFieldOverlay:function(number|null):void,
 *   playAcquisition:function():void,
 *   fx:object
 * }}
 */
export function makeRenderer(canvas, opts) {
  const options = opts ?? {};
  const ctx = canvas && typeof canvas.getContext === 'function'
    ? canvas.getContext('2d', { alpha: false })
    : null;
  const ownerDocument = canvas?.ownerDocument ?? null;
  const camera = { scale: 1, offsetX: 0, offsetY: 0 };
  const tissueRect = { x: 0, y: 0, width: WORLD_W, height: WORLD_H, scale: 1 };
  const reducedMotion = prefersReducedMotion();
  const fx = options.fx ?? makeFx({
    max: Number.isFinite(options.maxParticles) ? options.maxParticles : 320,
  });
  const agentVariants = new Int32Array(QUALITY.HIGH.maxAgents);
  let dpr = safeDpr(options.dpr);
  let cssWidth = 0;
  let cssHeight = 0;
  let spriteCache = ctx ? buildSpriteCache(dpr) : null;
  let backgroundCanvas = null;
  let fieldCanvas = null;
  let fieldCtx = null;
  let fieldImage = null;
  let fieldW = 0;
  let fieldH = 0;
  let selectedField = null;
  let acquisitionActive = false;
  let acquisitionElapsed = ACQUISITION_SECONDS;
  let scanX = tissueRect.x + tissueRect.width;

  const startingParticleBudget = Number.isFinite(options.quality?.particles)
    ? options.quality.particles
    : QUALITY.HIGH.particles;
  fx.setBudget(reducedMotion ? 0 : startingParticleBudget);

  function rebuildBackground() {
    if (!ctx || tissueRect.width <= 0 || tissueRect.height <= 0) {
      backgroundCanvas = null;
      return;
    }
    const pixelWidth = Math.max(1, Math.ceil(tissueRect.width * dpr));
    const pixelHeight = Math.max(1, Math.ceil(tissueRect.height * dpr));
    backgroundCanvas = createSurface(pixelWidth, pixelHeight, ownerDocument);
    const backgroundCtx = backgroundCanvas?.getContext('2d');
    if (!backgroundCtx) {
      backgroundCanvas = null;
      return;
    }
    backgroundCtx.setTransform(dpr, 0, 0, dpr, 0, 0);
    const width = tissueRect.width;
    const height = tissueRect.height;
    backgroundCtx.fillStyle = COLORS.bgTissue;
    backgroundCtx.fillRect(0, 0, width, height);

    const vignette = backgroundCtx.createRadialGradient(
      width * 0.5,
      height * 0.48,
      Math.min(width, height) * 0.12,
      width * 0.5,
      height * 0.5,
      Math.max(width, height) * 0.68,
    );
    vignette.addColorStop(0, '#15213100');
    vignette.addColorStop(0.7, '#07101C22');
    vignette.addColorStop(1, '#020407B8');
    backgroundCtx.fillStyle = vignette;
    backgroundCtx.fillRect(0, 0, width, height);

    // Real tissue architecture, from an H&E slide rather than a procedural speckle.
    //
    // Each square is one imaged patch: either background (no tissue in the slide) or one of
    // four neighbourhoods the lab's clustering found. The neighbourhoods are drawn as very
    // faint differences in density, so the board reads as a real section — sparse in some
    // regions, dense in others — without competing with the cells for attention.
    //
    // They are deliberately NOT colour-coded by type: the source config states the cluster
    // identities have not yet been manually assigned, so naming or colouring them as
    // alveolar / vascular / stromal would invent a result the lab has not produced.
    const patchW = width / TISSUE_COLS;
    const patchH = height / TISSUE_ROWS;
    const NEIGHBOURHOOD_ALPHA = ['06', '0a', '0e', '12'];
    for (let row = 0; row < TISSUE_ROWS; row += 1) {
      const line = TISSUE_MAP[row];
      if (!line) continue;
      for (let column = 0; column < TISSUE_COLS; column += 1) {
        const ch = line[column];
        if (ch === undefined || ch === '.') continue; // genuinely empty in the slide
        const alpha = NEIGHBOURHOOD_ALPHA[Number(ch) % NEIGHBOURHOOD_ALPHA.length];
        backgroundCtx.fillStyle = `${COLORS.inkDim}${alpha}`;
        backgroundCtx.fillRect(
          column * patchW,
          row * patchH,
          patchW + 0.5,
          patchH + 0.5,
        );
      }
    }
  }

  function setView(view) {
    if (!view || !Number.isFinite(view.scale) || view.scale <= 0) {
      return;
    }
    camera.scale = view.scale;
    camera.offsetX = Number.isFinite(view.offsetX) ? view.offsetX : 0;
    camera.offsetY = Number.isFinite(view.offsetY) ? view.offsetY : 0;
    tissueRect.x = camera.offsetX;
    tissueRect.y = camera.offsetY;
    tissueRect.width = WORLD_W * camera.scale;
    tissueRect.height = WORLD_H * camera.scale;
    tissueRect.scale = camera.scale;
    scanX = tissueRect.x + tissueRect.width;
    rebuildBackground();
  }

  function resize(cssW, cssH) {
    cssWidth = safeDimension(cssW);
    cssHeight = safeDimension(cssH);
    const nextDpr = safeDpr(options.dpr);
    if (nextDpr !== dpr) {
      dpr = nextDpr;
      spriteCache = ctx ? buildSpriteCache(dpr) : null;
    }
    if (canvas) {
      canvas.width = Math.max(1, Math.round(cssWidth * dpr));
      canvas.height = Math.max(1, Math.round(cssHeight * dpr));
      if (canvas.style) {
        canvas.style.width = `${cssWidth}px`;
        canvas.style.height = `${cssHeight}px`;
      }
    }
    if (ctx) {
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    }
    computeLetterbox(cssWidth, cssHeight, tissueRect);
    camera.scale = tissueRect.scale > 0 ? tissueRect.scale : 1;
    camera.offsetX = tissueRect.x;
    camera.offsetY = tissueRect.y;
    scanX = tissueRect.x + tissueRect.width;
    rebuildBackground();
  }

  function worldToScreen(wx, wy, out) {
    out.x = camera.offsetX + wx * camera.scale;
    out.y = camera.offsetY + wy * camera.scale;
  }

  function screenToWorld(sx, sy, out) {
    out.x = (sx - camera.offsetX) / camera.scale;
    out.y = (sy - camera.offsetY) / camera.scale;
  }

  function setFieldOverlay(fieldIdOrNull) {
    if (fieldIdOrNull === null || fieldIdOrNull === undefined) {
      selectedField = null;
      return;
    }
    const fieldId = Math.trunc(fieldIdOrNull);
    selectedField = fieldId >= FIELD.CHEMOKINE && fieldId < FIELD_COUNT
      ? fieldId
      : null;
  }

  function ensureFieldSurface(width, height) {
    if (width === fieldW && height === fieldH && fieldImage) {
      return true;
    }
    fieldW = width;
    fieldH = height;
    fieldCanvas = createSurface(width, height, ownerDocument);
    fieldCtx = fieldCanvas?.getContext('2d', { alpha: true }) ?? null;
    fieldImage = fieldCtx?.createImageData(width, height) ?? null;
    return Boolean(fieldImage);
  }

  function drawFieldHaze(round) {
    if (!ctx || selectedField === null || !round?.grid) {
      return;
    }
    const grid = round.grid;
    const width = Math.trunc(grid.w);
    const height = Math.trunc(grid.h);
    const cells = width * height;
    const source = grid.data;
    if (width <= 0 || height <= 0 || !source
      || source.length < (selectedField + 1) * cells
      || !ensureFieldSurface(width, height)) {
      return;
    }
    const sourceOffset = selectedField * cells;
    const rgba = fieldImage.data;
    const rgbOffset = selectedField * 3;
    const red = FIELD_RGB[rgbOffset];
    const green = FIELD_RGB[rgbOffset + 1];
    const blue = FIELD_RGB[rgbOffset + 2];
    for (let cell = 0; cell < cells; cell += 1) {
      const target = cell * 4;
      const concentration = Math.max(0, source[sourceOffset + cell]);
      const strength = concentration > 0.0005
        ? 1 - Math.exp(-concentration * 1.5)
        : 0;
      rgba[target] = red;
      rgba[target + 1] = green;
      rgba[target + 2] = blue;
      rgba[target + 3] = Math.min(148, Math.round(Math.sqrt(strength) * 132));
    }
    fieldCtx.putImageData(fieldImage, 0, 0);
    ctx.save();
    ctx.globalAlpha = 0.72;
    ctx.imageSmoothingEnabled = true;
    ctx.drawImage(
      fieldCanvas,
      tissueRect.x,
      tissueRect.y,
      tissueRect.width,
      tissueRect.height,
    );
    ctx.restore();
  }

  function targetDirection(world, index) {
    const target = Math.trunc(world.a3?.[index] ?? -1);
    if (target < 0 || target >= world.capacity || world.alive?.[target] !== 1) {
      return -1;
    }
    const angle = Math.atan2(
      world.y[target] - world.y[index],
      world.x[target] - world.x[index],
    );
    return (Math.round(angle * 8 / TAU) + 8) & 7;
  }

  function variantFor(round, index, kind, state) {
    const world = round.world;
    const radius = (world.radius?.[index] ?? 10) * camera.scale;
    const sizeBucket = spriteSizeBucket(radius);
    const time = Number.isFinite(round.timeSec) ? round.timeSec : 0;
    let phase = 0;
    let direction = 0;
    let detail = 0;
    let flag = 0;
    if (!reducedMotion && kind === KIND.TUMOR) {
      phase = (Math.floor(time * 1.5) + index) & 3;
    }
    if (kind === KIND.TUMOR) {
      detail = Math.max(0, Math.min(3, Math.round(world.a0?.[index] ?? 0)));
      flag = (world.a2?.[index] ?? 0) >= 0.6 ? 1 : 0;
    } else if (kind === KIND.CART) {
      const target = targetDirection(world, index);
      if (target >= 0) {
        direction = target;
        flag = 1;
      }
    } else if (kind === KIND.NK) {
      const kills = Math.max(0, Math.floor(world.a2?.[index] ?? 0));
      detail = Math.max(0, 3 - Math.min(3, kills));
    } else if (kind === KIND.HEALTHY) {
      flag = (world.hp?.[index] ?? 1) < 0.7 || (world.a3?.[index] ?? 0) > 0 ? 1 : 0;
    }
    return spriteVariantKey(sizeBucket, phase, direction, detail, flag);
  }

  function acquisitionAlpha(screenX) {
    if (!acquisitionActive) {
      return 1;
    }
    const fadeWidth = Math.max(20, tissueRect.width * 0.065);
    return Math.max(0, Math.min(1, (scanX - screenX) / fadeWidth));
  }

  function motionAlpha(round, index, kind, state, layer) {
    let alpha = acquisitionAlpha(camera.offsetX + round.world.x[index] * camera.scale);
    if (reducedMotion) {
      return alpha;
    }
    const time = Number.isFinite(round.timeSec) ? round.timeSec : 0;
    if (state === STATE.ENGAGED) {
      alpha *= 0.9 + Math.sin(time * Math.PI * 4 + index) * 0.1;
    } else if (kind === KIND.CD4 && layer === 2) {
      alpha *= 0.76 + Math.sin(time * Math.PI * 2 + index) * 0.18;
    } else if (kind === KIND.TREG && layer === 2) {
      alpha *= 0.65 + Math.sin(time * Math.PI * 0.75 + index) * 0.18;
    } else if (kind === KIND.VESSEL) {
      alpha *= 0.86 + Math.sin(time * Math.PI + index) * 0.1;
    } else if (kind === KIND.HEALTHY
      && (round.world.hp?.[index] ?? 1) < 0.7) {
      alpha *= 0.6 + Math.sin(time * Math.PI * 7 + index) * 0.3;
    }
    if (layer === 0 && acquisitionActive) {
      alpha *= 1 + Math.sin(Math.min(1, alpha) * Math.PI) * 0.55;
    }
    return Math.max(0, Math.min(1, alpha));
  }

  function prepareAgentVariants(round) {
    const world = round.world;
    const capacity = Math.min(
      agentVariants.length,
      Math.trunc(world.capacity ?? world.alive?.length ?? 0),
    );
    for (let index = 0; index < capacity; index += 1) {
      if (world.alive?.[index] !== 1) {
        continue;
      }
      const kind = world.kind[index];
      const state = world.state?.[index] ?? STATE.ALIVE;
      agentVariants[index] = variantFor(round, index, kind, state);
    }
  }

  function drawAgentLayer(round, layer, vesselOnly) {
    if (!ctx || !spriteCache || !round?.world) {
      return;
    }
    const world = round.world;
    const capacity = Math.min(
      agentVariants.length,
      Math.trunc(world.capacity ?? world.alive?.length ?? 0),
    );
    for (let index = 0; index < capacity; index += 1) {
      if (world.alive?.[index] !== 1) {
        continue;
      }
      const kind = world.kind[index];
      if ((kind === KIND.VESSEL) !== vesselOnly) {
        continue;
      }
      const state = world.state?.[index] ?? STATE.ALIVE;
      const variant = agentVariants[index];
      let sprite;
      if (layer === 0) {
        sprite = spriteCache.getGlow(kind, state, variant);
      } else if (layer === 1) {
        sprite = spriteCache.getBody(kind, state, variant);
      } else {
        sprite = spriteCache.getAccent(kind, state, variant);
      }
      const destinationSize = spriteCache.destinationSize(variant);
      const sx = camera.offsetX + world.x[index] * camera.scale;
      const sy = camera.offsetY + world.y[index] * camera.scale;
      ctx.globalAlpha = motionAlpha(round, index, kind, state, layer);
      ctx.drawImage(
        sprite,
        sx - destinationSize * 0.5,
        sy - destinationSize * 0.5,
        destinationSize,
        destinationSize,
      );
    }
    ctx.globalAlpha = 1;
  }

  function drawVesselUnderlay(round) {
    ctx.globalCompositeOperation = 'lighter';
    drawAgentLayer(round, 0, true);
    ctx.globalCompositeOperation = 'source-over';
    drawAgentLayer(round, 1, true);
    drawAgentLayer(round, 2, true);
  }

  function isKiller(kind) {
    return kind === KIND.CART || kind === KIND.CD8 || kind === KIND.NK;
  }

  function drawSynapses(round) {
    if (!ctx || !round?.world) {
      return;
    }
    const world = round.world;
    const capacity = Math.trunc(world.capacity ?? world.alive?.length ?? 0);
    let hasLine = false;
    ctx.beginPath();
    for (let index = 0; index < capacity; index += 1) {
      if (world.alive?.[index] !== 1
        || world.state?.[index] !== STATE.ENGAGED
        || !isKiller(world.kind[index])) {
        continue;
      }
      const target = Math.trunc(world.a3?.[index] ?? -1);
      if (target < 0 || target >= capacity || target === index
        || world.alive?.[target] !== 1) {
        continue;
      }
      ctx.moveTo(
        camera.offsetX + world.x[index] * camera.scale,
        camera.offsetY + world.y[index] * camera.scale,
      );
      ctx.lineTo(
        camera.offsetX + world.x[target] * camera.scale,
        camera.offsetY + world.y[target] * camera.scale,
      );
      hasLine = true;
    }
    if (hasLine) {
      ctx.globalAlpha = 0.86;
      ctx.strokeStyle = COLORS.ink;
      ctx.lineWidth = 1.5;
      ctx.stroke();
      ctx.globalAlpha = 1;
    }
  }

  function drawPlacementPreview(uiState) {
    if (!ctx || !spriteCache || !uiState) {
      return;
    }
    const preview = uiState.placementGhost ?? uiState.preview ?? null;
    if (!preview || !Number.isFinite(preview.x) || !Number.isFinite(preview.y)
      || !Number.isFinite(preview.kind)) {
      return;
    }
    const state = Number.isFinite(preview.state) ? preview.state : STATE.ALIVE;
    const radius = Number.isFinite(preview.radius) ? preview.radius : 12;
    const variant = spriteVariantKey(spriteSizeBucket(radius * camera.scale));
    const destinationSize = spriteCache.destinationSize(variant);
    const sx = camera.offsetX + preview.x * camera.scale;
    const sy = camera.offsetY + preview.y * camera.scale;
    ctx.save();
    ctx.globalAlpha = preview.valid === false ? 0.28 : 0.62;
    ctx.drawImage(
      spriteCache.getBody(preview.kind, state, variant),
      sx - destinationSize * 0.5,
      sy - destinationSize * 0.5,
      destinationSize,
      destinationSize,
    );
    ctx.drawImage(
      spriteCache.getAccent(preview.kind, state, variant),
      sx - destinationSize * 0.5,
      sy - destinationSize * 0.5,
      destinationSize,
      destinationSize,
    );
    ctx.restore();
  }

  function drawDevOverlay(uiState) {
    if (!ctx || !uiState?.devOverlay) {
      return;
    }
    ctx.save();
    ctx.fillStyle = '#05080CCC';
    ctx.fillRect(tissueRect.x + 8, tissueRect.y + 8, 178, 44);
    ctx.fillStyle = COLORS.ink;
    ctx.font = '11px ui-monospace, monospace';
    ctx.textBaseline = 'top';
    const qualityId = uiState.quality?.id ?? options.quality?.id ?? QUALITY.HIGH.id;
    const fieldName = selectedField === null ? 'none' : FIELD_LABEL[selectedField];
    ctx.fillText(`QUALITY ${qualityId}`, tissueRect.x + 16, tissueRect.y + 15);
    ctx.fillText(`FIELD ${fieldName}`, tissueRect.x + 16, tissueRect.y + 31);
    ctx.restore();
  }

  function drawAcquisitionLine() {
    if (!ctx || !acquisitionActive) {
      return;
    }
    const gradient = ctx.createLinearGradient(scanX - 18, 0, scanX + 4, 0);
    gradient.addColorStop(0, `${COLORS.cart}00`);
    gradient.addColorStop(0.72, `${COLORS.cart}66`);
    gradient.addColorStop(1, COLORS.cart);
    ctx.save();
    ctx.globalCompositeOperation = 'lighter';
    ctx.fillStyle = gradient;
    ctx.fillRect(scanX - 18, tissueRect.y, 22, tissueRect.height);
    ctx.fillStyle = COLORS.ink;
    ctx.globalAlpha = 0.82;
    ctx.fillRect(scanX, tissueRect.y, 1, tissueRect.height);
    ctx.restore();
  }

  function updateAcquisition(dt) {
    if (!acquisitionActive) {
      return;
    }
    acquisitionElapsed += Number.isFinite(dt) ? Math.max(0, dt) : 0;
    const progress = Math.min(1, acquisitionElapsed / ACQUISITION_SECONDS);
    scanX = tissueRect.x + tissueRect.width * progress;
    if (progress >= 1) {
      acquisitionActive = false;
      acquisitionElapsed = ACQUISITION_SECONDS;
      scanX = tissueRect.x + tissueRect.width;
    }
  }

  function draw(round, uiState, dt) {
    updateAcquisition(dt);
    fx.update(dt);
    if (!ctx || !round?.world) {
      return;
    }
    ctx.globalCompositeOperation = 'source-over';
    ctx.globalAlpha = 1;
    ctx.fillStyle = COLORS.bgPanel;
    ctx.fillRect(0, 0, cssWidth, cssHeight);
    ctx.fillStyle = '#000000';
    ctx.fillRect(tissueRect.x, tissueRect.y, tissueRect.width, tissueRect.height);

    ctx.save();
    ctx.beginPath();
    ctx.rect(
      tissueRect.x,
      tissueRect.y,
      acquisitionActive
        ? Math.max(0, scanX - tissueRect.x)
        : tissueRect.width,
      tissueRect.height,
    );
    ctx.clip();

    if (backgroundCanvas) {
      ctx.drawImage(
        backgroundCanvas,
        tissueRect.x,
        tissueRect.y,
        tissueRect.width,
        tissueRect.height,
      );
    } else {
      ctx.fillStyle = COLORS.bgTissue;
      ctx.fillRect(tissueRect.x, tissueRect.y, tissueRect.width, tissueRect.height);
    }

    prepareAgentVariants(round);
    drawVesselUnderlay(round);
    drawFieldHaze(round);
    ctx.globalCompositeOperation = 'lighter';
    drawAgentLayer(round, 0, false);
    ctx.globalCompositeOperation = 'source-over';
    drawAgentLayer(round, 1, false);
    drawSynapses(round);
    drawAgentLayer(round, 2, false);
    if (!reducedMotion) {
      fx.draw(ctx, camera);
    }
    drawPlacementPreview(uiState);
    drawDevOverlay(uiState);

    ctx.restore();
    drawAcquisitionLine();
  }

  function playAcquisition() {
    if (reducedMotion) {
      acquisitionActive = false;
      acquisitionElapsed = ACQUISITION_SECONDS;
      scanX = tissueRect.x + tissueRect.width;
      fx.clear();
      return;
    }
    acquisitionElapsed = 0;
    acquisitionActive = true;
    scanX = tissueRect.x;
  }

  return {
    resize,
    setView,
    draw,
    worldToScreen,
    screenToWorld,
    setFieldOverlay,
    playAcquisition,
    fx,
  };
}
