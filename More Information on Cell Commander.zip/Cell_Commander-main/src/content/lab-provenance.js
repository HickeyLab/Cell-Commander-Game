/**
 * lab-provenance.js — links each mechanic in this game to the verified interaction it comes
 * from in the lab's own agent-based models.
 *
 * WHY THIS FILE EXISTS
 *
 * src/sim/params.js already gives every NUMBER a provenance tag. This does the same job for
 * the MECHANICS: it records, for each thing the game teaches, which interaction in the lab's
 * research code implements it, which automated test exercises it, and whether a mechanism
 * audit has certified that the right code path actually fired.
 *
 * That matters because the interactions are the part a visitor is most likely to doubt. "Do
 * NK cells really kill the cells that hide?" is a fair question, and the answer here is not
 * "we made it up for the game" — it is "that is interaction NK-02 in our influenza model,
 * covered by the nk_epithelial_killing pairwise test, with a mechanism audit confirming the
 * missing-self path fired and not something else."
 *
 * TWO SOURCES, AND AN HONEST DISTINCTION
 *
 *   `flu`   The lab's influenza ABM (Influenza_Modeling). Its interaction inventory lists 103
 *           implemented interactions; 68 are COVERED, meaning a pairwise test matched AND a
 *           mechanism audit exists. The immune interactions cited below are the shared
 *           immunology — missing-self recognition, packet-based cytotoxicity, macrophage
 *           polarization, dendritic-cell priming — verified there in a VIRAL INFECTION
 *           context, not a tumor one. The cell biology is the same; the disease is not, and
 *           this file says so rather than blurring it.
 *
 *   `tumor` The lab's published tumor microenvironment ABM (tumor-tcell; Hickey, Agmon,
 *           Horowitz, Lamore, Sunwoo, Covert & Nolan, Cell Systems). This is where the
 *           tumor-specific mechanics come from — PD-1/PD-L1 braking, IFN-γ-driven tumor state
 *           switching, the cytotoxic packet threshold.
 *
 * `status` is copied from the source inventory, not asserted here:
 *   'covered'       a pairwise test matches AND a mechanism audit certifies it fired
 *   'implemented'   implemented in the research code, no matching automated test found
 *   'game-only'     no counterpart in either research model; invented for teaching
 */

/**
 * @typedef {Object} LabLink
 * @property {'flu'|'tumor'|'none'} source   which research model
 * @property {string} id                     interaction ID in that model's inventory
 * @property {string} description            the inventory's own wording, quoted
 * @property {string} [test]                 the automated test that exercises it
 * @property {'covered'|'implemented'|'game-only'} status
 */

/** Mechanic key -> the research interaction(s) behind it. */
export const LAB_PROVENANCE = Object.freeze({
  'contact-killing': [
    {
      source: 'flu',
      id: 'CD8-03',
      description: 'Infected cell killed; packet-based mechanism',
      test: 'cd8_epithelial_killing',
      status: 'covered',
    },
    {
      source: 'flu',
      id: 'NK-03',
      description: 'Target cell lysis; packet delivery to epithelial',
      test: 'nk_epithelial_killing',
      status: 'covered',
    },
  ],

  'missing-self': [
    {
      source: 'flu',
      id: 'NK-02',
      description: 'NK recognizes and targets MHC-I-low infected cells',
      test: 'nk_epithelial_killing',
      status: 'covered',
    },
  ],

  // The clearest example of the game's central lesson already being a verified result:
  // two killer lineages together clear a target faster than either alone.
  'combination-therapy': [
    {
      source: 'flu',
      id: 'NK-11',
      description: 'Combined NK+CD8 kills faster (~1.25h vs 2-3h alone)',
      test: 'cytotoxic_triad',
      status: 'covered',
    },
    {
      source: 'flu',
      id: 'CD8-06',
      description: 'Synergistic kill time ~1.25h',
      test: 'cytotoxic_triad',
      status: 'covered',
    },
  ],

  chemotaxis: [
    {
      source: 'flu',
      id: 'CD8-02',
      description: 'CD8 cells migrate toward infection site',
      status: 'implemented',
    },
    {
      source: 'flu',
      id: 'MAC-04',
      description: 'Recruits monocytes, NK cells, CD8 T cells',
      test: 'endothelial_mcp1_recruitment',
      status: 'covered',
    },
    {
      source: 'flu',
      id: 'NK-06',
      description: 'Dormant NK cells at tissue edge activate and migrate in',
      test: 'dormant_nk_cxcl10_recruitment',
      status: 'covered',
    },
  ],

  'macrophage-polarization': [
    {
      source: 'flu',
      id: 'MAC-02',
      description: 'M0 → M1 within 10-30 min of virus exposure',
      test: 'nk_macrophage_bcell_coordination',
      status: 'covered',
    },
    {
      source: 'flu',
      id: 'IFN2-03',
      description: 'IFN-γ reinforces M1 macrophage polarization',
      test: 'cd4_th1_effector_function',
      status: 'covered',
    },
  ],

  'immunosuppression': [
    {
      source: 'flu',
      id: 'MAC-10',
      description: 'M1 → M2 after ~8 h or via IL-10 from Treg',
      test: 'macrophage_il10_m2_resolution',
      status: 'covered',
    },
    {
      source: 'flu',
      id: 'MAC-16',
      description: 'Anti-inflammatory; feeds back to suppress M1',
      test: 'macrophage_il10_m2_resolution',
      status: 'covered',
    },
  ],

  'antigen-presentation': [
    {
      source: 'flu',
      id: 'DC-06',
      description: 'CD8 T cell priming for cytotoxic response',
      test: 'cd4_th1_effector_function',
      status: 'covered',
    },
    {
      source: 'flu',
      id: 'DC-03',
      description: 'IL-12 activates NK cells; drives Th1 differentiation',
      test: 'dc_antigen_capture',
      status: 'covered',
    },
  ],

  'ifn-gamma-mhc': [
    {
      source: 'flu',
      id: 'IFN2-02',
      description: 'IFN-γ secreted; enhances MHC-I on epithelials',
      test: 'cd4_th1_effector_function',
      status: 'covered',
    },
  ],

  // Tumor-specific: these have no counterpart in the influenza model, and come instead from
  // the lab's published tumor microenvironment ABM.
  'adaptive-resistance': [
    {
      source: 'tumor',
      id: 'tumor.py:IFNg_threshold',
      description:
        'Tumor switches from proliferative (MHCI/PDL1 low) to quiescent (MHCI/PDL1 high) '
        + 'on IFN-γ exposure',
      status: 'implemented',
    },
  ],

  'checkpoint-brake': [
    {
      source: 'tumor',
      id: 't_cell.py:PD1p_cytotoxic_packets_max',
      description:
        'PD1+ T cells produce 10x fewer cytotoxic packets than PD1- (1000 vs 10000)',
      status: 'implemented',
    },
  ],

  'serial-killing': [
    {
      source: 'tumor',
      id: 't_cell.py:cytotoxic_transfer_rate',
      description: '400 packets/min transferred; 12800 needed per target, then re-engage',
      status: 'implemented',
    },
  ],

  // Honest gaps: mechanics the game teaches that neither research model implements.
  'antigen-escape': [
    {
      source: 'none',
      id: '—',
      description:
        'Neither model has a CAR receptor or antigen-negative escape variants. The game '
        + 'adds them because they are the most common reason CAR-T therapy relapses.',
      status: 'game-only',
    },
  ],

  'cytokine-release-syndrome': [
    {
      source: 'none',
      id: '—',
      description:
        'Neither model has patient-level physiology. The mechanism (more simultaneous '
        + 'killing produces more cytokine, which harms the patient) is real; the numbers are '
        + 'a game-design choice.',
      status: 'game-only',
    },
  ],

  'off-tumor-toxicity': [
    {
      source: 'none',
      id: '—',
      description:
        'Requires a CAR target shared with healthy tissue, which neither model represents.',
      status: 'game-only',
    },
  ],
});

/** Human-readable source names for display. */
export const LAB_SOURCE_LABEL = Object.freeze({
  flu: "the lab's influenza tissue model",
  tumor: "the lab's published tumor model",
  none: 'not in either research model',
});

/**
 * One-line summary of where a mechanic comes from, for a science card footer.
 * @param {string} key mechanic key in LAB_PROVENANCE
 * @returns {string} empty string when the mechanic has no entry
 */
export function provenanceLine(key) {
  const links = LAB_PROVENANCE[key];
  if (!Array.isArray(links) || links.length === 0) return '';

  const first = links[0];
  if (first.source === 'none') {
    return 'Added for this game — not part of the research models.';
  }
  const ids = links.filter((l) => l.source !== 'none').map((l) => l.id).join(', ');
  const verified = links.some((l) => l.status === 'covered');
  const where = LAB_SOURCE_LABEL[first.source];
  return verified
    ? `Verified in ${where} as ${ids}.`
    : `From ${where} (${ids}).`;
}

/** Every mechanic that a research model verifies with an automated test. */
export function verifiedMechanics() {
  return Object.entries(LAB_PROVENANCE)
    .filter(([, links]) => links.some((l) => l.status === 'covered'))
    .map(([key]) => key);
}
