/**
 * results.js — owns discovery-first outcome copy, animated score evidence,
 * the two-line treatment history chart, science card, and initials capture.
 */

import {
  OUTCOME,
  OUTCOME_TITLE,
  SCREEN,
} from '../core/contracts.js';
import * as Scoring from '../sim/scoring.js';
import * as Science from '../content/science.js';
import {
  button,
  chip,
  icon,
} from './components.js';
import {
  SCORE_LIMIT,
  isInitialsAllowed,
  loadScores,
  saveScore,
} from './leaderboard.js';

const OUTCOME_COPY = Object.freeze({
  [OUTCOME.WIN]: {
    discovery: 'You found a treatment that cleared every cancer cell.',
    science: 'Fast matters. A gentle, focused treatment protects the patient too.',
  },
  [OUTCOME.LOSS_TUMOR_ESCAPED]: {
    discovery: 'You discovered that some cancer cells can outrun a treatment.',
    science: 'Try a new mix of cells or target a flag shared by more cancer cells.',
  },
  [OUTCOME.LOSS_PATIENT_DIED]: {
    discovery: 'You cleared many cancer cells, but the treatment was too harsh.',
    science: 'Real doctors balance tumor killing with patient safety every day.',
  },
  [OUTCOME.LOSS_TIMEOUT]: {
    discovery: 'You discovered that the immune cells needed a faster route.',
    science: 'Placement and danger scents help cells reach the tumor in time.',
  },
  [OUTCOME.ABORTED]: {
    discovery: 'You stopped treatment to protect the patient.',
    science: 'Emergency rescue can control a dangerous cytokine storm.',
  },
});

function fallbackScore(stats) {
  const total = 0;
  return {
    total,
    base: 0,
    speed: 0,
    health: 0,
    efficiency: 0,
    penalty: 0,
    breakdown: [
      { label: 'Score model connecting', value: total, good: true },
    ],
  };
}

function computeResult(stats, level) {
  try {
    return typeof Scoring.computeScore === 'function'
      ? Scoring.computeScore(stats, level)
      : fallbackScore(stats);
  } catch {
    return fallbackScore(stats);
  }
}

function makeHistoryChart(history) {
  const figure = document.createElement('figure');
  figure.className = 'history-chart';
  const caption = document.createElement('figcaption');
  caption.textContent = 'What changed during treatment';
  if (!Array.isArray(history) || history.length < 2) {
    figure.append(caption, chip('The treatment ended before a timeline was recorded.', {
      tone: 'neutral',
      icon: '⌁',
    }));
    return figure;
  }

  const svg = document.createElementNS('http://www.w3.org/2000/svg', 'svg');
  svg.setAttribute('viewBox', '0 0 640 220');
  svg.setAttribute('role', 'img');
  svg.setAttribute('aria-label', 'Cancer and immune cell counts over time');
  const left = 18;
  const top = 16;
  const plotWidth = 500;
  const plotHeight = 180;
  const maxT = Math.max(1, ...history.map((point) => Number(point.t) || 0));
  const maxCount = Math.max(
    1,
    ...history.flatMap((point) => [
      Number(point.tumor) || 0,
      Number(point.immune) || 0,
    ]),
  );
  const pointFor = (point, key) => ({
    x: left + ((Number(point.t) || 0) / maxT) * plotWidth,
    y: top + plotHeight - ((Number(point[key]) || 0) / maxCount) * plotHeight,
  });
  const pathFor = (key) => history
    .map((point, index) => {
      const pos = pointFor(point, key);
      return `${index === 0 ? 'M' : 'L'}${pos.x.toFixed(1)},${pos.y.toFixed(1)}`;
    })
    .join(' ');

  const cancerPath = document.createElementNS('http://www.w3.org/2000/svg', 'path');
  cancerPath.setAttribute('d', pathFor('tumor'));
  cancerPath.setAttribute('class', 'history-chart__line history-chart__line--tumor');
  const immunePath = document.createElementNS('http://www.w3.org/2000/svg', 'path');
  immunePath.setAttribute('d', pathFor('immune'));
  immunePath.setAttribute('class', 'history-chart__line history-chart__line--immune');
  svg.append(cancerPath, immunePath);

  for (const [key, label, className] of [
    ['tumor', 'Cancer cells', 'history-chart__label--tumor'],
    ['immune', 'Immune cells', 'history-chart__label--immune'],
  ]) {
    const end = pointFor(history.at(-1), key);
    const text = document.createElementNS('http://www.w3.org/2000/svg', 'text');
    text.setAttribute('x', String(end.x + 10));
    text.setAttribute('y', String(Math.max(14, Math.min(210, end.y + (key === 'tumor' ? -5 : 14)))));
    text.setAttribute('class', `history-chart__label ${className}`);
    text.textContent = label;
    svg.append(text);
  }
  figure.append(caption, svg);
  return figure;
}

function scoreQualifies(scores, score, timeSec) {
  if (scores.length < SCORE_LIMIT) {
    return true;
  }
  const last = scores.at(-1);
  return score > last.score || (score === last.score && timeSec < last.timeSec);
}

/**
 * Mounts the post-treatment results screen.
 * @param {HTMLElement} rootEl
 * @param {{app:object,level:object,plan:object,round:object}} ctx
 * @returns {{unmount:()=>void}}
 */
export function mount(rootEl, ctx) {
  const round = ctx.round ?? {};
  const stats = round.stats ?? {
    outcome: round.outcome,
    timeSec: round.timeSec ?? 0,
    history: [],
  };
  const outcome = round.outcome ?? stats.outcome ?? OUTCOME.ABORTED;
  const copy = OUTCOME_COPY[outcome] ?? OUTCOME_COPY[OUTCOME.ABORTED];
  const score = computeResult(stats, ctx.level);
  const timers = [];

  if (outcome === OUTCOME.WIN) {
    ctx.app.markWon?.(ctx.level.id);
  }

  const screen = document.createElement('main');
  screen.className = `cc-screen results-screen ${outcome === OUTCOME.WIN ? 'is-win' : 'is-loss'}`;
  const header = document.createElement('header');
  header.className = 'results-hero';
  const eyebrow = document.createElement('p');
  eyebrow.className = 'instrument-label';
  eyebrow.textContent = outcome === OUTCOME.WIN ? 'Treatment complete' : 'Experiment complete';
  const title = document.createElement('h1');
  title.textContent = OUTCOME_TITLE[outcome] ?? 'Treatment complete';
  const discovery = document.createElement('p');
  discovery.className = 'results-discovery';
  discovery.textContent = copy.discovery;
  const scienceLine = document.createElement('p');
  scienceLine.className = 'results-science-line';
  scienceLine.textContent = copy.science;
  header.append(eyebrow, title, discovery, scienceLine);

  const content = document.createElement('div');
  content.className = 'results-grid';
  const scorePanel = document.createElement('section');
  scorePanel.className = 'score-panel instrument-panel';
  const scoreTitle = document.createElement('h2');
  scoreTitle.textContent = 'Your score';
  const total = document.createElement('strong');
  total.className = 'score-total';
  total.textContent = '0';
  const tally = document.createElement('ol');
  tally.className = 'score-breakdown';
  scorePanel.append(scoreTitle, total, tally);

  const reducedMotion = screen.ownerDocument.defaultView
    ?.matchMedia?.('(prefers-reduced-motion: reduce)').matches ?? false;
  const breakdown = Array.isArray(score.breakdown) ? score.breakdown : [];
  breakdown.forEach((part, index) => {
    const row = document.createElement('li');
    row.className = part.good ? 'is-good' : 'is-penalty';
    const label = document.createElement('span');
    label.textContent = part.label;
    const value = document.createElement('strong');
    value.textContent = reducedMotion ? `${part.value >= 0 ? '+' : '−'}${Math.abs(part.value)}` : '···';
    row.append(label, value);
    tally.append(row);
    if (!reducedMotion) {
      timers.push(setTimeout(() => {
        value.textContent = `${part.value >= 0 ? '+' : '−'}${Math.abs(part.value)}`;
        row.classList.add('is-revealed');
      }, 180 + index * 190));
    } else {
      row.classList.add('is-revealed');
    }
  });
  if (reducedMotion) {
    total.textContent = String(score.total);
  } else {
    timers.push(setTimeout(() => {
      const duration = 650;
      const start = performance.now();
      const animate = (now) => {
        const progress = Math.min(1, (now - start) / duration);
        total.textContent = String(Math.round(score.total * progress));
        if (progress < 1 && screen.isConnected) {
          requestAnimationFrame(animate);
        }
      };
      requestAnimationFrame(animate);
    }, 180 + breakdown.length * 190));
  }

  const chart = makeHistoryChart(stats.history);
  const scienceCard = document.createElement('article');
  scienceCard.className = 'science-card';
  let card = null;
  try {
    card = typeof Science.getCard === 'function'
      ? Science.getCard(ctx.level.scienceCardId)
      : null;
  } catch {
    card = null;
  }
  const cardTitle = document.createElement('h2');
  cardTitle.textContent = card?.title ?? 'The science in your treatment';
  const kidText = document.createElement('p');
  kidText.textContent = card?.kidText ?? copy.science;
  const realText = document.createElement('p');
  realText.className = 'science-card__real';
  realText.textContent = card?.realText
    ?? 'Scientists test how immune cells recognize, reach, and safely clear cancer.';
  const concept = chip(card?.concept ?? 'immunotherapy', {
    tone: 'science',
    icon: card?.icon ?? '⌬',
  });
  scienceCard.append(cardTitle, kidText, realText, concept);

  const seed = ctx.app.seed ?? 'today';
  const existingScores = loadScores(ctx.level.id, seed);
  if (outcome === OUTCOME.WIN
    && scoreQualifies(existingScores, score.total, stats.timeSec ?? round.timeSec ?? 0)) {
    const entryPanel = document.createElement('form');
    entryPanel.className = 'initials-entry';
    const entryTitle = document.createElement('h2');
    entryTitle.textContent = existingScores.length === 0 || score.total >= (existingScores[0]?.score ?? 0)
      ? 'New high score'
      : 'You made today’s board';
    const label = document.createElement('label');
    label.textContent = 'Enter 3 letters';
    const input = document.createElement('input');
    input.className = 'initials-input';
    input.maxLength = 3;
    input.inputMode = 'text';
    input.autocomplete = 'off';
    input.spellcheck = false;
    const submit = button('Save score', {
      type: 'submit',
      className: 'cc-button--primary',
    });
    const feedback = document.createElement('p');
    feedback.className = 'inline-caution';
    feedback.setAttribute('aria-live', 'polite');
    input.addEventListener('input', () => {
      input.value = input.value.toUpperCase().replace(/[^A-Z0-9]/g, '').slice(0, 3);
    });
    label.append(input);
    entryPanel.append(entryTitle, label, submit, feedback);
    entryPanel.addEventListener('submit', (event) => {
      event.preventDefault();
      if (input.value.length !== 3) {
        feedback.textContent = 'Use exactly 3 letters.';
        input.focus();
        return;
      }
      if (!isInitialsAllowed(input.value)) {
        feedback.textContent = 'Pick a different set of letters.';
        input.select();
        return;
      }
      saveScore(ctx.level.id, seed, {
        initials: input.value,
        score: score.total,
        timeSec: stats.timeSec ?? round.timeSec ?? 0,
        when: Date.now(),
      });
      entryPanel.replaceChildren(chip('Score saved to today’s board.', {
        tone: 'ok',
        icon: '✓',
      }));
    });
    content.append(scorePanel, chart, scienceCard, entryPanel);
  } else {
    content.append(scorePanel, chart, scienceCard);
  }

  const actions = document.createElement('footer');
  actions.className = 'results-actions';
  const tryAgain = button('↻ Try again', {
    className: 'cc-button--primary cc-button--try-again',
    onClick: () => ctx.app.go(SCREEN.SETUP, { level: ctx.level }),
  });
  const levels = button('Choose a level', {
    className: 'cc-button--quiet',
    onClick: () => ctx.app.go(SCREEN.LEVEL_SELECT),
  });
  actions.append(tryAgain, levels);
  screen.append(header, content, actions);
  rootEl.replaceChildren(screen);

  return {
    unmount() {
      for (const timer of timers) {
        clearTimeout(timer);
      }
      screen.remove();
    },
  };
}
