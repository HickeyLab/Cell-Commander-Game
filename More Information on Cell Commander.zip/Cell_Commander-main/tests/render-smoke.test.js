/**
 * render-smoke.test.js verifies DOM-free renderer imports, coordinate and
 * letterbox math, bounded particle recycling, and collision-free sprite keys.
 */

import assert from 'node:assert/strict';
import test from 'node:test';

import { KIND, STATE } from '../src/core/contracts.js';
import { computeLetterbox, makeRenderer } from '../src/render/canvas.js';
import { makeFx } from '../src/render/fx.js';
import { makeHud } from '../src/render/hud.js';
import {
  buildSpriteCache,
  spriteCacheKey,
  spriteVariantKey,
} from '../src/render/sprites.js';

test('world and screen transforms round-trip across views', () => {
  const renderer = makeRenderer(null, {});
  const views = [
    { scale: 0.25, offsetX: 300, offsetY: 75 },
    { scale: 1, offsetX: 0, offsetY: 0 },
    { scale: 2.75, offsetX: -125.5, offsetY: 44.25 },
  ];
  const points = [
    { x: 0, y: 0 },
    { x: 600, y: 400 },
    { x: 1199.75, y: 799.5 },
  ];
  const screen = { x: 0, y: 0 };
  const world = { x: 0, y: 0 };

  for (const view of views) {
    renderer.setView(view);
    for (const point of points) {
      renderer.worldToScreen(point.x, point.y, screen);
      renderer.screenToWorld(screen.x, screen.y, world);
      assert.ok(Math.abs(world.x - point.x) <= 1e-6);
      assert.ok(Math.abs(world.y - point.y) <= 1e-6);
    }
  }
});

test('letterbox math centers a 3:2 world in wide, tall, and exact containers', () => {
  assert.deepEqual(computeLetterbox(1800, 800), {
    x: 300,
    y: 0,
    width: 1200,
    height: 800,
    scale: 1,
  });

  const tall = computeLetterbox(800, 1000);
  assert.ok(Math.abs(tall.x) <= 1e-12);
  assert.ok(Math.abs(tall.y - (700 / 3)) <= 1e-12);
  assert.ok(Math.abs(tall.width - 800) <= 1e-12);
  assert.ok(Math.abs(tall.height - (1600 / 3)) <= 1e-12);
  assert.ok(Math.abs(tall.scale - (2 / 3)) <= 1e-12);

  assert.deepEqual(computeLetterbox(1200, 800), {
    x: 0,
    y: 0,
    width: 1200,
    height: 800,
    scale: 1,
  });
});

test('particle pool enforces its cap and recycles every expired slot', () => {
  const fx = makeFx({ max: 16 });

  for (let event = 0; event < 100; event += 1) {
    fx.emitKill(event, event * 0.5, '#FF3D8B');
    fx.emitDivide(event, event);
    fx.emitPuff(event, event, '#22E0E8');
    fx.emitToxic(event, event);
    assert.ok(fx.activeCount <= 16);
  }

  assert.equal(fx.activeCount, 16);
  assert.equal(fx.freeCount, 0);
  fx.update(100);
  assert.equal(fx.activeCount, 0);
  assert.equal(fx.freeCount, 16);

  fx.emitDivide(10, 20);
  assert.ok(fx.activeCount > 0);
  assert.ok(fx.activeCount <= 16);
  assert.equal(fx.freeCount, 16 - fx.activeCount);
});

test('sprite cache keys are stable and distinct for every kind and state pair', () => {
  const keys = new Set();
  const states = Object.values(STATE);

  for (let kind = KIND.TUMOR; kind <= KIND.HEALTHY; kind += 1) {
    for (const state of states) {
      const first = spriteCacheKey(kind, state, 3);
      const second = spriteCacheKey(kind, state, 3);
      assert.equal(first, second);
      assert.equal(keys.has(first), false, `collision at kind ${kind}, state ${state}`);
      keys.add(first);
    }
  }

  assert.equal(typeof makeHud, 'function');
});

test('sprite cache pre-bakes dynamic accents without excessive surface growth', () => {
  const OriginalOffscreenCanvas = globalThis.OffscreenCanvas;
  let surfaceCount = 0;
  globalThis.OffscreenCanvas = class CountingCanvas {
    constructor(width, height) {
      this.width = width;
      this.height = height;
      surfaceCount += 1;
    }

    getContext() {
      return null;
    }
  };

  try {
    const cache = buildSpriteCache(2);
    const bakedCount = surfaceCount;
    cache.getAccent(
      KIND.TUMOR,
      STATE.QUIESCENT,
      spriteVariantKey(3, 3, 0, 3, 1),
    );
    cache.getAccent(
      KIND.CART,
      STATE.ENGAGED,
      spriteVariantKey(3, 0, 7, 0, 1),
    );
    cache.getAccent(KIND.NK, STATE.ACTIVE, spriteVariantKey(3, 0, 0, 0, 0));
    cache.getAccent(KIND.HEALTHY, STATE.ALIVE, spriteVariantKey(3, 0, 0, 0, 1));

    assert.equal(surfaceCount, bakedCount, 'frame-time cache reads must not bake surfaces');
    assert.ok(bakedCount < 500, `sprite cache created ${bakedCount} surfaces`);
  } finally {
    if (OriginalOffscreenCanvas === undefined) {
      delete globalThis.OffscreenCanvas;
    } else {
      globalThis.OffscreenCanvas = OriginalOffscreenCanvas;
    }
  }
});
