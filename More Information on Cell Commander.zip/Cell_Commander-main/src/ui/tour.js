/**
 * tour.js — a cinematic guided tour, for showing the work to an audience.
 *
 * Separate from demo.js on purpose. The demo is a narrated playthrough: it looks like someone
 * playing. This is a film: chapter cards, held beats, big centred type, and a route that
 * visits the parts worth talking about rather than simply finishing a level.
 *
 * Nothing here touches demo.js or any game module. It drives the same real UI through the
 * same clicks, so if it ever breaks, "Watch it play" is unaffected.
 *
 * Chapters:
 *   I    The specimen        — the board is a real H&E section
 *   II   The diagnosis       — what exactly is this tumor, and its real marker
 *   III  The attack          — contact, synapse, serial killing
 *   IV   The model speaks    — the live commentary explaining itself
 *   V    What is really there— the measured CODEX composition
 */

const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

function waitFor(predicate, timeoutMs = 8000, stepMs = 120) {
  return new Promise((resolve) => {
    const started = Date.now();
    const tick = () => {
      let v = null;
      try { v = predicate(); } catch { v = null; }
      if (v) return resolve(v);
      if (Date.now() - started > timeoutMs) return resolve(null);
      setTimeout(tick, stepMs);
    };
    tick();
  });
}

function control(pattern) {
  const re = new RegExp(pattern, 'i');
  return [...document.querySelectorAll('button, a')].find(
    (el) => re.test(el.textContent || '') && el.offsetParent !== null && !el.disabled,
  ) || null;
}

function tap(canvas, fx, fy) {
  const r = canvas.getBoundingClientRect();
  const x = r.left + r.width * fx;
  const y = r.top + r.height * fy;
  const o = {
    bubbles: true, cancelable: true, clientX: x, clientY: y,
    pointerId: 1, pointerType: 'touch', isPrimary: true, button: 0, buttons: 1,
  };
  canvas.dispatchEvent(new PointerEvent('pointerdown', o));
  canvas.dispatchEvent(new PointerEvent('pointerup', { ...o, buttons: 0 }));
  canvas.dispatchEvent(new MouseEvent('click', { bubbles: true, cancelable: true, clientX: x, clientY: y }));
}

/**
 * Start the cinematic tour.
 * @param {{loop?: boolean}} [options]
 * @returns {{stop: () => void}}
 */
export function startTour(options = {}) {
  const loop = options.loop !== false;
  let stopped = false;

  const root = document.createElement('div');
  root.className = 'tour-root';

  // Letterbox bars give the whole thing a filmic frame and, usefully, hide the fact that the
  // game chrome is still sitting underneath.
  const barTop = document.createElement('div');
  barTop.className = 'tour-bar tour-bar--top';
  const barBottom = document.createElement('div');
  barBottom.className = 'tour-bar tour-bar--bottom';

  // Full-screen chapter card.
  const card = document.createElement('div');
  card.className = 'tour-card';
  const cardNum = document.createElement('p');
  cardNum.className = 'tour-card__numeral';
  const cardTitle = document.createElement('h2');
  cardTitle.className = 'tour-card__title';
  const cardSub = document.createElement('p');
  cardSub.className = 'tour-card__sub';
  card.append(cardNum, cardTitle, cardSub);

  // Lower-third narration.
  const lower = document.createElement('p');
  lower.className = 'tour-lower';
  lower.setAttribute('aria-live', 'polite');

  const exit = document.createElement('button');
  exit.type = 'button';
  exit.className = 'cc-button cc-button--quiet tour-exit';
  exit.textContent = 'Exit tour';
  exit.addEventListener('click', () => stop());

  root.append(barTop, barBottom, card, lower, exit);
  document.body.append(root);
  document.documentElement.classList.add('is-tour');

  function stop() {
    stopped = true;
    root.remove();
    document.documentElement.classList.remove('is-tour');
  }

  /** Hold a full-screen chapter card. */
  async function chapter(numeral, title, sub, ms = 5000) {
    if (stopped) return false;
    lower.classList.remove('is-on');
    cardNum.textContent = numeral;
    cardTitle.textContent = title;
    cardSub.textContent = sub;
    card.classList.add('is-on');
    await sleep(ms);
    if (stopped) return false;
    card.classList.remove('is-on');
    await sleep(600);
    return !stopped;
  }

  /** Show a line over the live game. */
  async function line(text, ms = 4000) {
    if (stopped) return false;
    lower.textContent = text;
    lower.classList.add('is-on');
    await sleep(ms);
    return !stopped;
  }

  async function runOnce() {
    // ---- opening -------------------------------------------------------
    if (!(await chapter('', 'Cell Commander', 'A working model of cancer immunotherapy, made playable.', 5000))) return;

    // Get to a level's setup screen.
    control('^\\s*▶?\\s*Play')?.click();
    if (!(await waitFor(() => control('Study this tumor')))) return;
    control('Study this tumor')?.click();
    if (!(await waitFor(() => document.querySelector('.setup-step--a')))) return;
    await sleep(700);

    // ---- I. the specimen -----------------------------------------------
    if (!(await chapter('I', 'The specimen', 'The board is not a drawing.'))) return;
    if (!(await line('The tissue under the cells is a real H&E section from our own slides.', 5000))) return;
    if (!(await line('Where the board is empty, the slide was empty. 63% is tissue.', 5000))) return;

    // ---- II. the diagnosis -----------------------------------------------
    if (!(await chapter('II', 'The diagnosis', 'What exactly is this tumor?'))) return;
    const tumorName = document.querySelector('.tumor-specs__name')?.textContent?.trim();
    const tumorMarker = document.querySelector('.tumor-specs__marker')?.textContent?.trim();
    const tumorProfile = document.querySelector('.tumor-specs__profile')?.textContent?.trim();
    if (tumorName && tumorMarker) {
      if (!(await line(`${tumorName}. ${tumorMarker}.`, 5000))) return;
    }
    if (tumorProfile && !(await line(tumorProfile, 5000))) return;

    // ---- III. the attack -----------------------------------------------
    if (!(await chapter('III', 'The attack', 'A T cell has to make contact with the cancer cells'))) return;
    const cart = [...document.querySelectorAll('.setup-palette button, .setup-palette .shop-item')]
      .find((b) => /Killer T/i.test(b.textContent || ''));
    cart?.click();
    await sleep(400);
    const board = document.querySelector('.placement-board-wrap canvas');
    if (!board) return;
    if (!(await line("Placing the T-cells, where they start determines whether they'll hit their target", 5000))) return;
    for (let i = 0; i < 9 && !stopped; i += 1) {
      const a = (i / 9) * Math.PI * 2;
      tap(board, 0.62 + Math.cos(a) * 0.17, 0.5 + Math.sin(a) * 0.28);
      await sleep(300);
    }
    if (stopped) return;
    control('Start treatment')?.click();
    if (!(await waitFor(() => document.querySelector('.live-screen')))) return;
    await sleep(1400);
    if (!(await line('Killing is contact-dependent. Watch for the bright line between two cells.', 5200))) return;
    if (!(await line('That line is the immune synapse — granules going into the target.', 5000))) return;
    control('^2×$')?.click();
    if (!(await line('One T cell kills, releases, and finds another. Serial killing.', 5000))) return;

    // ---- IV. the model speaks ------------------------------------------
    if (!(await chapter('IV', 'The model explains itself', 'It says why, while you can still act.'))) return;
    if (!(await line('The strip along the bottom narrates the simulation as it happens.', 5000))) return;
    control('^3×$')?.click();
    if (!(await line('Every rate here comes from our published tumour model, tagged to its source.', 5200))) return;
    await waitFor(() => /Tumor Cleared|Out of Time|Escaped|Too Harsh/i.test(document.body.innerText), 60000, 500);
    if (stopped) return;
    await sleep(1200);
    if (!(await line('Cleared. The score rewards a fast, gentle, cheap cure over a brutal one.', 5000))) return;

    // ---- V. the real numbers -------------------------------------------
    if (!(await chapter('V', 'What is really in there', 'Measured, not imagined.'))) return;
    control('Levels|Try again|Title')?.click();
    await sleep(900);
    control('Title')?.click();
    await sleep(900);
    control('Sandbox')?.click();
    if (!(await waitFor(() => document.querySelector('.sandbox-layout')))) return;
    await sleep(1200);
    if (!(await line('Free play: every cell count, the tumour, the shield, the drugs.', 5000))) return;
    const preset = control('Use real tissue numbers');
    if (preset) {
      if (!(await line('And this sets them to what our CODEX imaging actually measured.', 5000))) return;
      preset.click();
      await sleep(1600);
      if (!(await line('A piece of lung this size holds about eight killer T cells.', 5000))) return;
      if (!(await line('Macrophages outnumber them seven to one. That is why we infuse cells.', 5200))) return;
    }

    if (!(await chapter('', 'Every number has a source.', 'Parameters, interactions, densities and tissue — all from our own work.', 5200))) return;

    control('Levels')?.click();
    await sleep(800);
    control('Title')?.click();
    await sleep(1200);
  }

  (async () => {
    do {
      await runOnce();
      if (stopped) break;
      await sleep(1200);
    } while (loop && !stopped);
    if (!stopped) stop();
  })();

  return { stop };
}

/** True when the page was opened asking for the cinematic tour. */
export function tourRequested(win = window) {
  try {
    return new URLSearchParams(win.location.search).has('tour');
  } catch {
    return false;
  }
}
