/**
 * leaderboard.test.js — verifies score ordering, persistence fallbacks, import/export,
 * and initials safety against the public leaderboard API.
 */

import assert from 'node:assert/strict';
import test, { beforeEach } from 'node:test';

import {
  clearScores,
  exportScores,
  importScores,
  isInitialsAllowed,
  loadScores,
  saveScore,
  setStorageBackend,
} from '../src/ui/leaderboard.js';

function makeStorage() {
  const data = new Map();
  return {
    get length() {
      return data.size;
    },
    clear() {
      data.clear();
    },
    getItem(key) {
      return data.has(key) ? data.get(key) : null;
    },
    key(index) {
      return [...data.keys()][index] ?? null;
    },
    removeItem(key) {
      data.delete(key);
    },
    setItem(key, value) {
      data.set(key, String(value));
    },
  };
}

function makeEntry(initials, score, timeSec, when = 1) {
  return { initials, score, timeSec, when };
}

beforeEach(() => {
  setStorageBackend(makeStorage());
  clearScores();
});

test('sorts scores descending and breaks ties with faster time', () => {
  saveScore('1', 42, makeEntry('SLO', 900, 31));
  saveScore('1', 42, makeEntry('TOP', 1200, 29));
  const scores = saveScore('1', 42, makeEntry('FST', 900, 18));

  assert.deepEqual(
    scores.map(({ initials, score, timeSec }) => ({ initials, score, timeSec })),
    [
      { initials: 'TOP', score: 1200, timeSec: 29 },
      { initials: 'FST', score: 900, timeSec: 18 },
      { initials: 'SLO', score: 900, timeSec: 31 },
    ],
  );
});

test('caps each level and seed list at 25 entries', () => {
  for (let index = 0; index < 30; index += 1) {
    saveScore('2', 7, makeEntry('KID', index, 100 - index, index));
  }

  const scores = loadScores('2', 7);
  assert.equal(scores.length, 25);
  assert.equal(scores[0].score, 29);
  assert.equal(scores.at(-1).score, 5);
});

test('falls back to session memory when every storage operation throws', () => {
  const throwingStorage = new Proxy({}, {
    get() {
      throw new Error('Safari private mode');
    },
  });
  setStorageBackend(throwingStorage);
  clearScores();

  assert.doesNotThrow(() => {
    saveScore('3', 99, makeEntry('CAL', 777, 44));
  });
  assert.deepEqual(loadScores('3', 99), [
    makeEntry('CAL', 777, 44),
  ]);
});

test('export and import round-trip all score groups', () => {
  saveScore('1', 11, makeEntry('ION', 500, 20, 10));
  saveScore('2', 22, makeEntry('LAB', 800, 30, 20));
  const exported = exportScores();

  setStorageBackend(makeStorage());
  clearScores();
  importScores(exported);

  assert.deepEqual(loadScores('1', 11), [makeEntry('ION', 500, 20, 10)]);
  assert.deepEqual(loadScores('2', 22), [makeEntry('LAB', 800, 30, 20)]);
});

test('initials filter rejects blocked words and accepts normal initials', () => {
  assert.equal(isInitialsAllowed('ass'), false);
  assert.equal(isInitialsAllowed('bio'), true);
});
