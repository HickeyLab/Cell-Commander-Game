/**
 * science.js owns the kid-facing science cards, teacher-facing immunology text,
 * and tap-to-define glossary used across guided levels and the sandbox.
 */

function card(definition) {
  return Object.freeze(definition);
}

export const SCIENCE_CARDS = Object.freeze({
  'level-first-contact': card({
    id: 'level-first-contact',
    title: 'Touch Starts the Attack',
    kidText: "Your T cells have to actually touch a cancer cell to kill it. Watch for the bright line between them - that's the attack happening. Give it a second. It works.",
    realText: 'Cytotoxic lymphocytes form an immune synapse with a target and deliver perforin and granzymes, so killing is contact-dependent and requires sustained engagement.',
    concept: 'contact-dependent cytotoxicity (immune synapse and granule exocytosis)',
    icon: '🤝',
  }),
  'level-the-shield': card({
    id: 'level-the-shield',
    title: 'The Tumor Fights Back',
    kidText: "Your attack was working, so the tumor put up a shield. That's its answer to being hit. The shield-blocking medicine takes it down and your cells get back to work.",
    realText: 'IFN-γ released during attack can induce tumor PD-L1, an adaptive-resistance response. PD-1/PD-L1 checkpoint blockade can restore T-cell activity.',
    concept: 'adaptive resistance overcome by PD-1/PD-L1 checkpoint blockade',
    icon: '🛡️',
  }),
  'level-the-escape-artist': card({
    id: 'level-the-escape-artist',
    title: 'Two Ways to Find a Target',
    kidText: "Some cancer cells hid their marker. NK cells check for a low badge. But a long fight can raise that badge back up, so you need killer T cells — they watch for a HIGH badge.",
    realText: "Antigen-negative tumor variants evade antigen-specific recognition, but NK and native CD8 T cells complement this by recognizing low and high MHC-I regardless of antigen. Sustained local IFN-gamma from active killing drives MHC-I upward over time, so a cell can drift out of NK's reach and into CD8's before it is caught.",
    concept: 'combination therapy for antigen escape, MHC-I loss, and IFN-gamma-driven MHC-I recovery',
    icon: '🎭',
  }),
  'level-cold-tumor': card({
    id: 'level-cold-tumor',
    title: 'Wake a Quiet Tumor',
    kidText: "Your cells can't find a tumor that isn't calling for help. Lay down a trail, or send a dendritic cell to spread the word, and they will come running.",
    realText: 'Immune-excluded or cold tumors have weak recruiting chemokine signals and may contain Tregs or M2 macrophages that suppress effector cells. Dendritic-cell antigen presentation can support T-cell priming and recruitment.',
    concept: 'cold tumor immune exclusion and dendritic-cell priming',
    icon: '🧭',
  }),
  'level-deep-core': card({
    id: 'level-deep-core',
    title: 'Work from the Outside In',
    kidText: "You cleared the outside fast, but the middle is packed tight and far from any blood vessel. Your cells have to push in. Keep going - this one takes patience.",
    realText: 'Large solid tumors can have poor central perfusion, necrosis, and physical barriers to lymphocyte infiltration. Clearing accessible peripheral cells does not guarantee that effector cells have penetrated the viable tumor core.',
    concept: 'tumor perfusion and immune-cell infiltration',
    icon: '🧅',
  }),
  'level-sandbox': card({
    id: 'level-sandbox',
    title: 'Change One Thing',
    kidText: "You are the scientist now. Change one thing, run it, and watch what is different. Then change one more. That is how real experiments work.",
    realText: 'Controlled experiments change one variable at a time so differences in outcomes can be linked to that variable. The sandbox is a qualitative systems-immunology model, not a predictor of patient response.',
    concept: 'controlled experimentation in systems immunology',
    icon: '🧪',
  }),
  'serial-killing': card({
    id: 'serial-killing',
    title: 'One Cell, Many Kills',
    kidText: "That same T cell is about to do it again. One of your killer T cells can take out cancer cell after cancer cell, which is why a few good cells beat a big crowd.",
    realText: 'Cytotoxic T lymphocytes and NK cells can disengage after delivering lethal granules and then kill additional targets, a behavior called serial killing.',
    concept: 'serial killing by cytotoxic lymphocytes',
    icon: '🔁',
  }),
  chemotaxis: card({
    id: 'chemotaxis',
    title: 'Follow the Danger Trail',
    kidText: "Your immune cells smell their way to trouble. They follow the scent uphill, toward wherever it is strongest. No scent, and they just wander around lost.",
    realText: 'Chemotaxis directs immune-cell migration up chemokine concentration gradients; CXCL9 and CXCL10 are important examples that recruit activated T cells through CXCR3.',
    concept: 'chemotaxis along a chemokine gradient',
    icon: '👃',
  }),
  'adaptive-resistance': card({
    id: 'adaptive-resistance',
    title: 'An Attack Can Raise a Shield',
    kidText: "Here is the twist: attacking the tumor is what switched its shield on. Your cells shout a chemical alarm when they fight, and the tumor hears it and armors up.",
    realText: 'IFN-γ from activated T cells and NK cells can induce PD-L1 expression on tumor cells. This feedback response is termed adaptive immune resistance.',
    concept: 'adaptive immune resistance (IFN-γ-induced PD-L1)',
    icon: '🚧',
  }),
  'checkpoint-blockade': card({
    id: 'checkpoint-blockade',
    title: 'Block the Stop Signal',
    kidText: "This medicine does not take away the tumor's stop sign. It stops your T cells from reading it. They walk right past it and keep fighting.",
    realText: 'Antibodies against PD-1 or PD-L1 interrupt an inhibitory immune-checkpoint interaction and can restore T-cell effector function. Checkpoint blockade does not restore a lost target antigen.',
    concept: 'PD-1/PD-L1 immune checkpoint blockade',
    icon: '✂️',
  }),
  'antigen-escape': card({
    id: 'antigen-escape',
    title: 'Some Targets Lose the Flag',
    kidText: "Your CAR-T cells were built to hunt one flag. Cancer cells without it survive, and every cell they make is a hider too. That is how a tumor comes back.",
    realText: 'CAR-T cells recognize their engineered target antigen independently of MHC presentation. Selection can therefore favor antigen-negative tumor variants, producing antigen escape and relapse.',
    concept: 'antigen-negative escape from CAR-T therapy',
    icon: '🙈',
  }),
  'missing-self-nk': card({
    id: 'missing-self-nk',
    title: 'NK Cells Check the Self Badge',
    kidText: "NK cells check every cell for an ID badge. No badge, no mercy. That is a completely different test from the flag your CAR-T cells look for, which is why bringing both kinds of killer covers more of the tumor.",
    realText: 'NK-cell inhibitory receptors normally detect self MHC-I; reduced MHC-I removes that inhibitory signal and can trigger missing-self killing. This is distinct from loss of the CAR target antigen.',
    concept: 'NK-cell missing-self recognition of MHC-I loss',
    icon: '🔍',
  }),
  'immunosuppressive-microenvironment': card({
    id: 'immunosuppressive-microenvironment',
    title: 'Calm-Down Signals',
    kidText: "Those are the tumor's bodyguards. They do not fight - they tell your cells to calm down, and your cells listen. Even good cells go quiet near them.",
    realText: 'Regulatory T cells and M2-like macrophages can create an immunosuppressive tumor microenvironment through mediators including TGF-β and IL-10, reducing cytotoxic-cell movement and function.',
    concept: 'immunosuppressive tumor microenvironment',
    icon: '🤫',
  }),
  'dendritic-antigen-presentation': card({
    id: 'dendritic-antigen-presentation',
    title: 'Show the Wanted Poster',
    kidText: "This cell picks up crumbs from dead cancer cells and carries them off like a wanted poster. Show the poster, and fresh fighters come back to help you.",
    realText: 'Dendritic cells take up tumor material, process proteins, and present peptide antigens on MHC molecules to prime T cells. Priming normally occurs in lymphoid tissues and can expand tumor-reactive T-cell responses.',
    concept: 'dendritic-cell antigen presentation and T-cell priming',
    icon: '📣',
  }),
  'cytokine-release-syndrome': card({
    id: 'cytokine-release-syndrome',
    title: 'Watch the Cytokine Storm',
    kidText: "Watch the storm meter. When too many of your cells fight at once, their signals flood the whole body and the patient gets a fever. Winning too hard is its own problem.",
    realText: 'Cytokine release syndrome is a systemic inflammatory toxicity driven by cytokines released during massive immune activation, including activation caused by CAR-T engagement. It is not produced by the tumor alone.',
    concept: 'cytokine release syndrome (CRS)',
    icon: '🌡️',
  }),
  'on-target-off-tumor-toxicity': card({
    id: 'on-target-off-tumor-toxicity',
    title: 'Choose a Safe Target',
    kidText: "Check the flag before you pick it. If healthy cells fly the same one, your CAR-T cells will hit them too. They cannot tell the difference. That is why choosing well matters.",
    realText: 'On-target off-tumor toxicity occurs when the therapeutic target antigen is also expressed by healthy tissue, so correctly functioning CAR-T cells damage nonmalignant cells.',
    concept: 'on-target off-tumor toxicity',
    icon: '🎯',
  }),
  't-cell-exhaustion': card({
    id: 't-cell-exhaustion',
    title: 'Killer Cells Can Wear Down',
    kidText: "Your T cell is worn out. Real ones get tired after a long fight. Helper cells give it a boost, but the real fix is clearing out whatever keeps wearing it down.",
    realText: 'Persistent antigen stimulation and suppressive signaling can produce T-cell exhaustion, with inhibitory receptors such as PD-1 and reduced effector function. Supportive cytokines may improve function but do not erase the exhausted state by themselves.',
    concept: 'T-cell exhaustion during chronic antigen stimulation',
    icon: '🔋',
  }),
});

export const GLOSSARY = Object.freeze({
  'adaptive resistance': 'A tumor change caused by an immune attack that helps the tumor resist the next attack.',
  antigen: 'A molecule that an immune cell can recognize, shown as a target flag in the game.',
  'antigen escape': 'When cancer cells without the chosen target survive while targeted cells are removed.',
  'antigen presentation': 'How a cell displays a small protein clue so a T cell can inspect it.',
  'CAR-T cell': 'A T cell changed in a lab so it can grab one chosen surface target.',
  'checkpoint blockade': 'Medicine that blocks an immune stop signal such as PD-1 meeting PD-L1.',
  'checkpoint inhibitor': 'A medicine that releases a natural brake on immune cells.',
  chemokine: 'A small chemical signal that helps guide immune cells through tissue.',
  chemotaxis: 'Movement toward a stronger chemical signal.',
  cytokine: 'A message protein that cells release to change what nearby or distant cells do.',
  'cytokine release syndrome (CRS)': 'A body-wide illness caused by too many immune signals being released during a very strong activation.',
  'dendritic cell': 'An immune cell that gathers clues and presents them to help train T cells.',
  'IFN-gamma': 'An alarm cytokine made by active T cells and NK cells.',
  'immune synapse': 'The close contact zone where an immune cell talks to or attacks another cell.',
  'immunosuppressive microenvironment': 'The cells and signals around a tumor that weaken an immune attack.',
  'IL-2': 'A cytokine that helps activated T cells grow and stay active.',
  macrophage: 'A large immune cell that eats debris and can either help or slow an immune attack.',
  'M2 macrophage': 'A macrophage state that can help calm inflammation and suppress tumor-fighting cells.',
  'MHC-I': 'A normal self badge on most body cells that displays protein pieces for immune inspection.',
  'missing-self': 'How NK cells notice that a cell has lost enough of its normal MHC-I self badge.',
  'NK cell': 'A natural killer cell that can attack stressed cells, especially cells with low MHC-I.',
  necrosis: 'Cell death caused by severe damage or too little oxygen and nutrients.',
  'on-target off-tumor toxicity': 'Damage caused when healthy cells carry the same target as the tumor.',
  'PD-1': 'A brake receptor on T cells that can receive a stop signal from PD-L1.',
  'PD-L1': 'A surface protein that can press the PD-1 brake on a T cell.',
  perfusion: 'The delivery of blood, oxygen, and nutrients through vessels into tissue.',
  'perforin and granzymes': 'Killing proteins released by T cells and NK cells into a target cell.',
  'serial killing': 'When one immune cell kills several target cells one after another.',
  'T cell exhaustion': 'A worn-down T-cell state caused by long-lasting stimulation and suppressive signals.',
  Treg: 'A regulatory T cell that prevents too much immune activity but can also protect a tumor.',
});

/**
 * Returns the science card with the requested stable id, or undefined when absent.
 *
 * @param {string} id
 * @returns {object|undefined}
 */
export function getCard(id) {
  return SCIENCE_CARDS[id];
}
