/**
 * perf.test.js verifies rolling frame statistics and the quality controller's
 * exact tier identities, consecutive thresholds, hysteresis, and force behavior.
 */

import test from 'node:test';
import assert from 'node:assert/strict';

import { QUALITY } from '../src/core/contracts.js';
import { makePerfMonitor, makeQualityController } from '../src/core/perf.js';

test('median, p95, and fps match a hand-computed rolling window', () => {
  const perf = makePerfMonitor({ sampleSize: 5 });
  for (const value of [10, 30, 20, 40, 50]) {
    perf.frame(value);
  }

  assert.equal(perf.median(), 30);
  assert.equal(perf.p95(), 50);
  assert.equal(perf.fps(), 1000 / 30);

  perf.frame(60);
  assert.equal(perf.median(), 40);
  assert.equal(perf.p95(), 60);

  perf.reset();
  assert.equal(perf.median(), 0);
  assert.equal(perf.p95(), 0);
  assert.equal(perf.fps(), 0);
});

test('quality drops after exactly 90 consecutive slow updates', () => {
  const qc = makeQualityController('high');

  for (let i = 0; i < 89; i += 1) {
    assert.equal(qc.update(25), false);
  }
  assert.equal(qc.tier, QUALITY.HIGH);
  assert.equal(qc.update(25), true);
  assert.equal(qc.tier, QUALITY.MEDIUM);
  assert.equal(qc.update(25), false);
});

test('quality rises after exactly 300 consecutive fast updates', () => {
  const qc = makeQualityController('low');

  for (let i = 0; i < 299; i += 1) {
    assert.equal(qc.update(5), false);
  }
  assert.equal(qc.tier, QUALITY.LOW);
  assert.equal(qc.update(5), true);
  assert.equal(qc.tier, QUALITY.MEDIUM);
  assert.equal(qc.update(5), false);
});

test('alternating good and bad frames never accumulate hysteresis counters', () => {
  const qc = makeQualityController('medium');

  for (let i = 0; i < 2000; i += 1) {
    assert.equal(qc.update(i % 2 === 0 ? 25 : 5), false);
  }

  assert.equal(qc.tier, QUALITY.MEDIUM);
});

test('threshold-equal frames reset streaks and forceTier selects exact tier objects', () => {
  const qc = makeQualityController('high');

  for (let i = 0; i < 89; i += 1) {
    qc.update(25);
  }
  assert.equal(qc.update(20), false);
  assert.equal(qc.update(25), false);
  assert.equal(qc.tier, QUALITY.HIGH);

  qc.forceTier('low');
  assert.equal(qc.tier, QUALITY.LOW);
  for (let i = 0; i < 299; i += 1) {
    qc.update(5);
  }
  assert.equal(qc.update(11), false);
  assert.equal(qc.update(5), false);
  assert.equal(qc.tier, QUALITY.LOW);
});
