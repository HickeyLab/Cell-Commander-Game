/**
 * levels.js owns the six data-only LevelDef records and every number that a later
 * headless-simulation balance pass may need to tune.
 *
 * BALANCE KNOBS
 * - First Contact: make easier with more FIRST_CONTACT_TIME_LIMIT_SEC, budget, or
 *   starting chemokine; make harder with more tumor cells or faster division
 *   (a lower FIRST_CONTACT_DIVIDE_TIME_SCALE).
 * - The Shield: make easier with less SHIELD_PDL1_INDUCIBLE, more time/budget,
 *   or slower division; reverse those changes to make it harder.
 * - The Escape Artist: make easier with less ESCAPE_ANTIGEN_MIX NONE, lower MHC-I,
 *   more time/budget, or slower division; reverse those changes to make it harder.
 * - Cold Tumor: make easier with fewer COLD_TREGS, less starting suppression, more
 *   chemokine, closer vessels, more time, or slower division; reverse those changes
 *   to make it harder.
 * - Deep Core: make easier with fewer tumor cells, closer vessels, more chemokine,
 *   more time, or slower division; reverse those changes to make it harder.
 * - Sandbox: SANDBOX_* constants set only the starting state; its UI exposes the
 *   sliders, while the unlimited timer and effective no-cap value keep play open.
 */

import { ANTIGEN, KIND } from '../core/contracts.js';

// First Contact: 60 credits allow 6-8 CAR-T cells with room to experiment.
export const FIRST_CONTACT_BUDGET = 60;
// First Contact: the maximum guided-round timer makes learning the controls forgiving.
export const FIRST_CONTACT_TIME_LIMIT_SEC = 180;
// First Contact: a high cap prevents growth from causing an early accidental loss.
export const FIRST_CONTACT_TUMOR_ESCAPE_CAP = 120;
// First Contact: DESIGN.md fixes this small, readable tumor at 40 cells.
export const FIRST_CONTACT_TUMOR_COUNT = 40;
// First Contact: a right-of-center target leaves a clear placement lane from vessels.
export const FIRST_CONTACT_TUMOR_CX = 690;
// First Contact: vertical centering keeps the first drag path easy to understand.
export const FIRST_CONTACT_TUMOR_CY = 400;
// First Contact: a compact but not dense cluster gives 6-8 killers easy surface access.
export const FIRST_CONTACT_TUMOR_SPREAD_WU = 85;
// First Contact: one GREEN population removes target-choice ambiguity.
export const FIRST_CONTACT_ANTIGEN_MIX = Object.freeze({ [ANTIGEN.GREEN]: 1 });
// First Contact: high MHC-I also lets native CD8 cells recognize the tumor.
export const FIRST_CONTACT_MHC_MEAN = 0.85;
// First Contact: low MHC-I variation keeps nearly every tumor cell recognizable.
export const FIRST_CONTACT_MHC_SD = 0.05;
// First Contact: zero baseline PD-L1 removes checkpoint braking.
export const FIRST_CONTACT_PDL1_BASE = 0;
// First Contact: zero inducible PD-L1 prevents a surprise shield during the tutorial.
export const FIRST_CONTACT_PDL1_INDUCIBLE = 0;
// First Contact: ~173 s divisions make growth barely visible near the tutorial's 180 s limit.
export const FIRST_CONTACT_DIVIDE_TIME_SCALE = 0.55;
// First Contact: visible healthy cells teach team identity without adding toxicity risk.
export const FIRST_CONTACT_HEALTHY_COUNT = 12;
// First Contact: no healthy-cell target antigen removes off-tumor toxicity from the tutorial.
export const FIRST_CONTACT_HEALTHY_ANTIGEN = ANTIGEN.NONE;
// First Contact: three left-edge vessels make the route toward the tumor obvious.
export const FIRST_CONTACT_VESSELS = Object.freeze([
  Object.freeze({ x: 130, y: 220 }),
  Object.freeze({ x: 130, y: 400 }),
  Object.freeze({ x: 130, y: 580 }),
]);
// First Contact: no Tregs keeps suppression out of the controls tutorial.
export const FIRST_CONTACT_TREGS = 0;
// First Contact: no preloaded suppressive field keeps killer cells fully active.
export const FIRST_CONTACT_STARTING_SUPPRESS = 0;
// First Contact: a strong initial trail helps wandering cells find the tumor.
export const FIRST_CONTACT_STARTING_CHEMOKINE = 0.55;

// The Shield: 90 credits buy checkpoint blockade plus a robust 68-credit roster.
// Raised 90 -> 100 after CAR-T was removed as a playable option (Dr. Hickey's request).
// CAR-T was both the fastest killer in the game (kill rate 3200 vs CD8's 2000) and the most
// cost-efficient per credit (533/cr vs CD8's 500/cr) -- every level's original budget was
// implicitly tuned assuming it was available. Verified: CD8+CD4+checkpoint at the original
// budget of 90 won only 8/20; at 100, 30/30.
export const SHIELD_BUDGET = 100;
// The Shield: 165 seconds rewards using the inhibitor but lets the stall become visible first.
export const SHIELD_TIME_LIMIT_SEC = 165;
// The Shield: this cap allows a stalled tumor to persist without ending the lesson too early.
export const SHIELD_TUMOR_ESCAPE_CAP = 130;
// The Shield: 60 cells make a 50-60% clearance plateau visually obvious.
export const SHIELD_TUMOR_COUNT = 60;
// The Shield: a central target keeps trafficking from competing with the checkpoint lesson.
export const SHIELD_TUMOR_CX = 660;
// The Shield: vertical centering gives all vessels comparable access.
export const SHIELD_TUMOR_CY = 400;
// The Shield: moderate spread keeps many targets accessible during the early burst.
export const SHIELD_TUMOR_SPREAD_WU = 105;
// The Shield: uniform GREEN ensures the stall comes from PD-L1, not antigen escape.
export const SHIELD_ANTIGEN_MIX = Object.freeze({ [ANTIGEN.GREEN]: 1 });
// The Shield: high MHC-I prevents missing-self from becoming the main solution.
export const SHIELD_MHC_MEAN = 0.8;
// The Shield: modest MHC-I variation preserves broad native recognition.
export const SHIELD_MHC_SD = 0.08;
// The Shield: low baseline PD-L1 permits a fast opening wave of kills.
export const SHIELD_PDL1_BASE = 0.05;
// The Shield: near-maximal inducible PD-L1 makes IFN-gamma rapidly impose a visible brake.
export const SHIELD_PDL1_INDUCIBLE = 0.95;
// The Shield: ~141 s divisions add slow pressure without overtaking the checkpoint lesson.
export const SHIELD_DIVIDE_TIME_SCALE = 0.45;
// The Shield: healthy bystanders make the arena legible without sharing the target.
export const SHIELD_HEALTHY_COUNT = 16;
// The Shield: target-free healthy cells keep patient damage from obscuring checkpoint braking.
export const SHIELD_HEALTHY_ANTIGEN = ANTIGEN.NONE;
// The Shield: distributed vessels remove a single correct placement answer.
export const SHIELD_VESSELS = Object.freeze([
  Object.freeze({ x: 110, y: 180 }),
  Object.freeze({ x: 110, y: 620 }),
  Object.freeze({ x: 1090, y: 400 }),
]);
// The Shield: no Tregs isolates adaptive resistance as the only suppressive lesson.
export const SHIELD_TREGS = 0;
// The Shield: no starting suppressive field keeps the PD-1/PD-L1 brake interpretable.
export const SHIELD_STARTING_SUPPRESS = 0;
// The Shield: a moderate trail lets killers arrive promptly and trigger IFN-gamma.
export const SHIELD_STARTING_CHEMOKINE = 0.35;

// The Escape Artist: 125 credits fund a balanced CAR-T + NK + CD8 combination with room
// for checkpoint blockade and IL-2 support. CD8 is a genuine safety net, not just a
// strong CAR-T-plus-NK roster.
//
// Why CD8 is unlocked at all: balance testing surfaced an issue beyond the original budget
// shortfall — MHC-I is correctly, and intentionally, driven upward by local IFN-gamma
// exposure (see the `ifng` field's documented effect in DESIGN.md section 5.2, and the
// tumor quiescence transition in the cited research model, vivarium-collective/tumor-tcell —
// proliferative-state cells have low MHC-I and PD-L1, quiescent-state cells have high MHC-I
// and PD-L1, and sustained local IFN-gamma drives that transition). That is real,
// correctly-modeled biology, not a bug — but it means an antigen-negative cell that starts
// NK-catchable (low MHC-I) can drift into CD8's high-MHC-I window over the course of a round
// as nearby engagements raise local IFN-gamma, exactly as a real tumor cell under sustained
// immune pressure would. Section 5.5 of DESIGN.md treats "every tumor cell is killable by
// something" as a continuous invariant, not a spawn-time-only guarantee — CD8 (MHC-high) and
// NK (MHC-low) only keep partitioning the whole range if CD8 is actually in the roster.
// Without it, a drifted cell became invincible again, recreating the exact failure class the
// original CD8-recognition fix closed, just arriving dynamically mid-round instead of at
// spawn. CD8 is a supplementary catch for cells that drift, not the primary strategy: the
// core lesson (CAR-T clears the flagged majority, NK finishes the flag-less remainder) still
// carries the level.
//
// Budget history: raised 100 -> 115 -> 135 across earlier balance passes as the above issue
// was diagnosed and fixed. Then lowered 135 -> 118 after further testing found real slack:
// a well-balanced three-killer roster (roughly equal parts CAR-T, NK, and CD8) held an
// 80-100% win rate all the way down to 110-120 credits, only degrading noticeably below
// ~105. 135 was also the highest budget of any real level — above both Cold Tumor (110) and
// Deep Core (120) — despite Escape Artist having the smallest tumor of the three (48 cells).
// Raised back up 118 -> 125 after playtesting found 118 felt too difficult in practice —
// automated win-rate testing alone doesn't capture felt difficulty, pacing, or decision
// pressure during actual play. 125 still sits below the original 135 and keeps a comfortable
// margin above the real cliff in winnability that appears around 110 credits.
// Raised 125 -> 160 after CAR-T was removed as a playable option (Dr. Hickey's request).
// This level needed more than the flat efficiency gap other levels did (see SHIELD_BUDGET's
// comment): traced a specific compounding effect where NK's own attacks locally raise
// IFN-gamma, which can drift a target's MHC-I past NK's own recognition threshold *while NK
// is mid-kill* -- confirmed directly, watching one target's MHC climb from 0.185 to 0.201
// during active engagement. This isn't a bug (it's the same drift CD8 was added to catch
// elsewhere), but it means NK's effort routinely converts into partial progress for CD8 to
// finish rather than an independent kill, lowering the roster's effective combined
// throughput below what raw kill-rate numbers alone would suggest. A CD8-heavy mix (CD8
// covers the higher-MHC population and finishes NK's handoffs; NK still needed for the
// initial low-MHC catch) verified at 24/25 wins at this budget.
export const ESCAPE_BUDGET = 160;
// The Escape Artist: the full guided timer gives the slower NK contingent time to finish.
// Balance-tested: a correct combination plan (CAR-T + NK + IL-2 support) clears this in
// roughly 150 s, so 210 leaves a child real room to get the combination wrong once.
export const ESCAPE_TIME_LIMIT_SEC = 210;
// The Escape Artist: a generous cap keeps the antigen-negative plateau on screen.
export const ESCAPE_TUMOR_ESCAPE_CAP = 150;
// The Escape Artist: 70 cells make the 65/35 split easy to see in the remaining count.
// Reduced from 70 after balance testing: 70 cells exceeded the kill budget of the roster
// a 100-credit purse can field before exhaustion sets in, stranding ~6 survivors.
export const ESCAPE_TUMOR_COUNT = 48;
// The Escape Artist: a near-central target keeps recognition, not travel, as the challenge.
export const ESCAPE_TUMOR_CX = 700;
// The Escape Artist: vertical centering supports equal access by CAR-T and NK cells.
export const ESCAPE_TUMOR_CY = 400;
// The Escape Artist: moderate spread allows both killer types to contact mixed targets.
export const ESCAPE_TUMOR_SPREAD_WU = 110;
// The Escape Artist: CAR-T can clear 65% GREEN, while 35% target-negative cells remain.
export const ESCAPE_ANTIGEN_MIX = Object.freeze({
  [ANTIGEN.GREEN]: 0.65,
  [ANTIGEN.NONE]: 0.35,
});
// API-NOTE: LevelDef exposes one tumor-wide MHC distribution. Antigen-negative cells'
// MHC is rejection-sampled below NK_MISSING_SELF_MAX in engine.js's sampleMhc, which is
// what actually guarantees low MHC-I among NONE cells — this mean/sd pair alone does not.
export const ESCAPE_MHC_MEAN = 0.18;
// The Escape Artist: tight variation keeps most cells below the NK recognition threshold.
export const ESCAPE_MHC_SD = 0.06;
// The Escape Artist: low baseline PD-L1 prevents checkpoint effects masking antigen escape.
export const ESCAPE_PDL1_BASE = 0.05;
// The Escape Artist: weak inducible PD-L1 keeps combination recognition as the main puzzle.
export const ESCAPE_PDL1_INDUCIBLE = 0.2;
// The Escape Artist: ~173 s divisions slowly expand inherited antigen-negative escapees.
export const ESCAPE_DIVIDE_TIME_SCALE = 0.55;
// The Escape Artist: healthy bystanders lack the CAR target and do not distract from escape.
export const ESCAPE_HEALTHY_COUNT = 14;
// The Escape Artist: target-free healthy cells keep antigen escape separate from toxicity.
export const ESCAPE_HEALTHY_ANTIGEN = ANTIGEN.NONE;
// The Escape Artist: vessels on both sides give CAR-T and NK cells fair entry routes.
export const ESCAPE_VESSELS = Object.freeze([
  Object.freeze({ x: 90, y: 200 }),
  Object.freeze({ x: 90, y: 600 }),
  Object.freeze({ x: 1110, y: 400 }),
]);
// The Escape Artist: one Treg adds texture without turning this into the suppression level.
export const ESCAPE_TREGS = 1;
// The Escape Artist: light suppression leaves NK finishing power intact.
export const ESCAPE_STARTING_SUPPRESS = 0.1;
// The Escape Artist: moderate chemokine keeps both killer types moving into the mixed mass.
export const ESCAPE_STARTING_CHEMOKINE = 0.35;

// Cold Tumor: 110 credits fund several dendritic cells, helpers, and a killer roster.
export const COLD_BUDGET = 110;
// Cold Tumor: the full guided timer allows priming and reinforcement waves to develop.
export const COLD_TIME_LIMIT_SEC = 180;
// Cold Tumor: this cap leaves time to discover failed trafficking before tumor escape.
export const COLD_TUMOR_ESCAPE_CAP = 145;
// Cold Tumor: 64 cells require reinforcement without becoming a Deep Core-sized mass.
export const COLD_TUMOR_COUNT = 64;
// Cold Tumor: the far-right center maximizes distance from all left-edge vessels.
export const COLD_TUMOR_CX = 1010;
// Cold Tumor: mid-height placement keeps vessel distance, not a corner trap, responsible.
export const COLD_TUMOR_CY = 400;
// Cold Tumor: a compact target makes finding it, rather than penetrating it, the challenge.
export const COLD_TUMOR_SPREAD_WU = 90;
// Cold Tumor: uniform GREEN removes antigen selection as a competing lesson.
export const COLD_ANTIGEN_MIX = Object.freeze({ [ANTIGEN.GREEN]: 1 });
// Cold Tumor: high MHC-I supports CD8 reinforcements primed by dendritic cells.
export const COLD_MHC_MEAN = 0.75;
// Cold Tumor: modest variation preserves broad CD8 recognition.
export const COLD_MHC_SD = 0.1;
// Cold Tumor: a small PD-L1 baseline adds realism without recreating The Shield.
export const COLD_PDL1_BASE = 0.1;
// Cold Tumor: limited inducible PD-L1 keeps trafficking and suppression dominant.
export const COLD_PDL1_INDUCIBLE = 0.25;
// Cold Tumor: ~94 s divisions make a tumor that remains unfound escape late in the round.
export const COLD_DIVIDE_TIME_SCALE = 0.3;
// Cold Tumor: healthy cells show that the remote tumor sits within ordinary tissue.
export const COLD_HEALTHY_COUNT = 12;
// Cold Tumor: target-free healthy cells keep trafficking and suppression as the challenge.
export const COLD_HEALTHY_ANTIGEN = ANTIGEN.NONE;
// Cold Tumor: all vessels stay over 900 wu from the tumor center to enforce poor trafficking.
export const COLD_VESSELS = Object.freeze([
  Object.freeze({ x: 60, y: 100 }),
  Object.freeze({ x: 60, y: 400 }),
  Object.freeze({ x: 60, y: 700 }),
]);
// Cold Tumor: eight Tregs continuously reinforce a suppressive microenvironment.
export const COLD_TREGS = 8;
// API-NOTE: LevelDef has no seeded M2-macrophage count, so high initial suppression
// represents the requested Treg/M2-derived suppressive cytokine environment.
export const COLD_STARTING_SUPPRESS = 0.75;
// Cold Tumor: near-zero chemokine makes untargeted immune cells wander.
export const COLD_STARTING_CHEMOKINE = 0.01;

// Deep Core: 120 credits support a varied, patient infiltration strategy.
export const DEEP_CORE_BUDGET = 120;
// Deep Core: the full guided timer teaches persistence while remaining booth-friendly.
// The largest tumor in the game and the one that most needs patience; balance testing
// finished with a single cell left at 180 s, so the limit is raised to give margin.
export const DEEP_CORE_TIME_LIMIT_SEC = 230;
// Deep Core: a high cap prevents the large starting mass from causing an instant escape.
export const DEEP_CORE_TUMOR_ESCAPE_CAP = 320;
// Deep Core: 150 cells create the largest, densest guided tumor.
// Still by far the biggest mass, but trimmed so the round ends on a clear win rather
// than a photo finish.
export const DEEP_CORE_TUMOR_COUNT = 128;
// Deep Core: horizontal centering puts the core far from every peripheral vessel.
export const DEEP_CORE_TUMOR_CX = 600;
// Deep Core: vertical centering maximizes the low-perfusion central region.
export const DEEP_CORE_TUMOR_CY = 400;
// Deep Core: a 150-wu radius creates multiple layers while keeping the mass dense.
export const DEEP_CORE_TUMOR_SPREAD_WU = 150;
// Deep Core: uniform GREEN ensures penetration, not target choice, controls success.
export const DEEP_CORE_ANTIGEN_MIX = Object.freeze({ [ANTIGEN.GREEN]: 1 });
// Deep Core: high MHC-I permits both CAR-T and native CD8 recognition.
export const DEEP_CORE_MHC_MEAN = 0.75;
// Deep Core: moderate MHC-I variation adds realism without requiring NK cells.
export const DEEP_CORE_MHC_SD = 0.1;
// Deep Core: a small PD-L1 baseline adds resistance without reproducing The Shield.
export const DEEP_CORE_PDL1_BASE = 0.1;
// Deep Core: modest induction keeps infiltration as the main bottleneck.
export const DEEP_CORE_PDL1_INDUCIBLE = 0.25;
// Deep Core: ~110 s divisions reach the escape cap late while leaving a prompt plan time to win.
export const DEEP_CORE_DIVIDE_TIME_SCALE = 0.35;
// Deep Core: extra healthy cells make the broad tissue field feel populated.
export const DEEP_CORE_HEALTHY_COUNT = 24;
// Deep Core: target-free healthy cells prevent toxicity from competing with infiltration.
export const DEEP_CORE_HEALTHY_ANTIGEN = ANTIGEN.NONE;
// Deep Core: corner vessels leave the center far from perfusion sources.
export const DEEP_CORE_VESSELS = Object.freeze([
  Object.freeze({ x: 70, y: 70 }),
  Object.freeze({ x: 1130, y: 70 }),
  Object.freeze({ x: 70, y: 730 }),
  Object.freeze({ x: 1130, y: 730 }),
]);
// Deep Core: no Tregs isolates physical infiltration and perfusion as the lesson.
export const DEEP_CORE_TREGS = 0;
// Deep Core: light baseline suppression avoids a second Cold Tumor puzzle.
export const DEEP_CORE_STARTING_SUPPRESS = 0.12;
// Deep Core: a weak trail guides cells to the rim but does not teleport them into the core.
export const DEEP_CORE_STARTING_CHEMOKINE = 0.2;

// Sandbox: a large budget lets players place every cell type and buy every intervention.
export const SANDBOX_BUDGET = 500;
// Sandbox: the API-defined zero timer means unlimited play.
export const SANDBOX_TIME_LIMIT_SEC = 0;
// Sandbox: LevelDef has no disabled sentinel, so this finite unreachable value is effectively no cap.
export const SANDBOX_TUMOR_ESCAPE_CAP = Number.MAX_SAFE_INTEGER;
// Sandbox: 80 starting cells provide enough activity without crowding out experiments.
export const SANDBOX_TUMOR_COUNT = 80;
// Sandbox: a centered default leaves equal room for placements on every side.
export const SANDBOX_TUMOR_CX = 600;
// Sandbox: vertical centering supports symmetric default vessel placement.
export const SANDBOX_TUMOR_CY = 400;
// Sandbox: medium spread is a neutral starting point for the exposed density slider.
export const SANDBOX_TUMOR_SPREAD_WU = 120;
// Sandbox: all antigen states start represented so every targeting strategy is testable.
export const SANDBOX_ANTIGEN_MIX = Object.freeze({
  [ANTIGEN.NONE]: 0.25,
  [ANTIGEN.GREEN]: 0.25,
  [ANTIGEN.BLUE]: 0.25,
  [ANTIGEN.ORANGE]: 0.25,
});
// Sandbox: midrange MHC-I leaves room to explore both CD8 recognition and NK missing-self.
export const SANDBOX_MHC_MEAN = 0.5;
// Sandbox: broad MHC-I variation supplies targets on both sides of recognition thresholds.
export const SANDBOX_MHC_SD = 0.2;
// Sandbox: a mid-low PD-L1 baseline makes checkpoint effects observable but not immediate.
export const SANDBOX_PDL1_BASE = 0.2;
// Sandbox: a midrange inducible response leaves room to move the exposed slider either way.
export const SANDBOX_PDL1_INDUCIBLE = 0.5;
// Sandbox: baseline division speed makes the growth-rate slider's changes easy to compare.
export const SANDBOX_DIVIDE_TIME_SCALE = 1;
// Sandbox: many bystanders make on-target off-tumor experiments visible.
export const SANDBOX_HEALTHY_COUNT = 30;
// Sandbox: ORANGE on healthy cells enables deliberate on-target off-tumor experiments.
export const SANDBOX_HEALTHY_ANTIGEN = ANTIGEN.ORANGE;
// Sandbox: four edge vessels provide symmetric perfusion before sliders are changed.
export const SANDBOX_VESSELS = Object.freeze([
  Object.freeze({ x: 80, y: 100 }),
  Object.freeze({ x: 80, y: 700 }),
  Object.freeze({ x: 1120, y: 100 }),
  Object.freeze({ x: 1120, y: 700 }),
]);
// Sandbox: six Tregs provide a visible but adjustable suppressive starting population.
export const SANDBOX_TREGS = 6;
// Sandbox: mid-low suppression makes both increases and decreases informative.
export const SANDBOX_STARTING_SUPPRESS = 0.25;
// Sandbox: a modest chemokine field provides a neutral trafficking baseline.
export const SANDBOX_STARTING_CHEMOKINE = 0.2;

export const LEVELS = Object.freeze([
  Object.freeze({
    id: 'first-contact',
    number: 1,
    name: 'First Contact',
    subtitle: 'Meet your cell army',
    teaches: 'You place killer cells, then watch them follow signals and touch cancer cells to attack.',
    budget: FIRST_CONTACT_BUDGET,
    timeLimitSec: FIRST_CONTACT_TIME_LIMIT_SEC,
    tumorEscapeCap: FIRST_CONTACT_TUMOR_ESCAPE_CAP,
    tumor: Object.freeze({
      count: FIRST_CONTACT_TUMOR_COUNT,
      cx: FIRST_CONTACT_TUMOR_CX,
      cy: FIRST_CONTACT_TUMOR_CY,
      spreadWu: FIRST_CONTACT_TUMOR_SPREAD_WU,
      antigenMix: FIRST_CONTACT_ANTIGEN_MIX,
      mhcMean: FIRST_CONTACT_MHC_MEAN,
      mhcSd: FIRST_CONTACT_MHC_SD,
      pdl1Base: FIRST_CONTACT_PDL1_BASE,
      pdl1Inducible: FIRST_CONTACT_PDL1_INDUCIBLE,
      divideTimeScale: FIRST_CONTACT_DIVIDE_TIME_SCALE,
    }),
    healthy: Object.freeze({
      count: FIRST_CONTACT_HEALTHY_COUNT,
      antigen: FIRST_CONTACT_HEALTHY_ANTIGEN,
    }),
    vessels: FIRST_CONTACT_VESSELS,
    tregs: FIRST_CONTACT_TREGS,
    startingSuppress: FIRST_CONTACT_STARTING_SUPPRESS,
    startingChemokine: FIRST_CONTACT_STARTING_CHEMOKINE,
    unlocks: Object.freeze([KIND.CD8, KIND.NK, 'rally']),
    scienceCardId: 'level-first-contact',
    tumorTypeName: 'Neuroblastoma',
    tumorMarkerInfo: 'GD2 — a childhood nerve-cell cancer',
    tumorProfile: 'A straightforward first case — no shield, no disguises.',
    hint: 'Tap a killer T cell, then tap 6-8 spots near the tumor. Press start.',
  }),
  Object.freeze({
    id: 'the-shield',
    number: 2,
    name: 'The Shield',
    subtitle: 'Cut the stop signal',
    teaches: 'You learn why an attack can raise a tumor shield and how checkpoint medicine removes its brake.',
    budget: SHIELD_BUDGET,
    timeLimitSec: SHIELD_TIME_LIMIT_SEC,
    tumorEscapeCap: SHIELD_TUMOR_ESCAPE_CAP,
    tumor: Object.freeze({
      count: SHIELD_TUMOR_COUNT,
      cx: SHIELD_TUMOR_CX,
      cy: SHIELD_TUMOR_CY,
      spreadWu: SHIELD_TUMOR_SPREAD_WU,
      antigenMix: SHIELD_ANTIGEN_MIX,
      mhcMean: SHIELD_MHC_MEAN,
      mhcSd: SHIELD_MHC_SD,
      pdl1Base: SHIELD_PDL1_BASE,
      pdl1Inducible: SHIELD_PDL1_INDUCIBLE,
      divideTimeScale: SHIELD_DIVIDE_TIME_SCALE,
    }),
    healthy: Object.freeze({
      count: SHIELD_HEALTHY_COUNT,
      antigen: SHIELD_HEALTHY_ANTIGEN,
    }),
    vessels: SHIELD_VESSELS,
    tregs: SHIELD_TREGS,
    startingSuppress: SHIELD_STARTING_SUPPRESS,
    startingChemokine: SHIELD_STARTING_CHEMOKINE,
    unlocks: Object.freeze([KIND.CD8, KIND.NK, KIND.CD4, 'checkpoint']),
    scienceCardId: 'level-the-shield',
    tumorTypeName: 'Melanoma',
    tumorMarkerInfo: 'PD-L1 — first proven target of checkpoint-blocking drugs',
    tumorProfile: 'Puts up a defensive shield the moment it is attacked.',
    hint: 'Save 20 credits for the medicine that blocks the tumor shield.',
  }),
  Object.freeze({
    id: 'the-escape-artist',
    number: 3,
    name: 'The Escape Artist',
    subtitle: 'Catch the flag-hiders',
    teaches: 'You combine NK and killer T cells because each one finds tumor cells by a different MHC-I badge level — too low, or too high.',
    budget: ESCAPE_BUDGET,
    timeLimitSec: ESCAPE_TIME_LIMIT_SEC,
    tumorEscapeCap: ESCAPE_TUMOR_ESCAPE_CAP,
    tumor: Object.freeze({
      count: ESCAPE_TUMOR_COUNT,
      cx: ESCAPE_TUMOR_CX,
      cy: ESCAPE_TUMOR_CY,
      spreadWu: ESCAPE_TUMOR_SPREAD_WU,
      antigenMix: ESCAPE_ANTIGEN_MIX,
      mhcMean: ESCAPE_MHC_MEAN,
      mhcSd: ESCAPE_MHC_SD,
      pdl1Base: ESCAPE_PDL1_BASE,
      pdl1Inducible: ESCAPE_PDL1_INDUCIBLE,
      divideTimeScale: ESCAPE_DIVIDE_TIME_SCALE,
    }),
    healthy: Object.freeze({
      count: ESCAPE_HEALTHY_COUNT,
      antigen: ESCAPE_HEALTHY_ANTIGEN,
    }),
    vessels: ESCAPE_VESSELS,
    tregs: ESCAPE_TREGS,
    startingSuppress: ESCAPE_STARTING_SUPPRESS,
    startingChemokine: ESCAPE_STARTING_CHEMOKINE,
    // CD8 is a safety net for cells whose MHC-I drifts upward mid-round (see the
    // ESCAPE_BUDGET comment above) — the hint below teaches the NK+CD8 strategy, since
    // that's what clears most of the tumor now that CAR-T is no longer a playable option.
    unlocks: Object.freeze([KIND.NK, KIND.CD8, KIND.CD4]),
    scienceCardId: 'level-the-escape-artist',
    tumorTypeName: 'B-cell Leukemia',
    tumorMarkerInfo: 'CD19 — leukemia can lose this marker and relapse unseen',
    tumorProfile: 'About a third of these cells have hidden their marker.',
    hint: 'Stack your roster with NK and killer T cells, then pick up a few helper T cells.',
  }),
  Object.freeze({
    id: 'cold-tumor',
    number: 4,
    name: 'Cold Tumor',
    subtitle: 'Guide cells to the fight',
    teaches: 'You build a danger trail and use dendritic cells to bring immune reinforcements into a quiet tumor.',
    budget: COLD_BUDGET,
    timeLimitSec: COLD_TIME_LIMIT_SEC,
    tumorEscapeCap: COLD_TUMOR_ESCAPE_CAP,
    tumor: Object.freeze({
      count: COLD_TUMOR_COUNT,
      cx: COLD_TUMOR_CX,
      cy: COLD_TUMOR_CY,
      spreadWu: COLD_TUMOR_SPREAD_WU,
      antigenMix: COLD_ANTIGEN_MIX,
      mhcMean: COLD_MHC_MEAN,
      mhcSd: COLD_MHC_SD,
      pdl1Base: COLD_PDL1_BASE,
      pdl1Inducible: COLD_PDL1_INDUCIBLE,
      divideTimeScale: COLD_DIVIDE_TIME_SCALE,
    }),
    healthy: Object.freeze({
      count: COLD_HEALTHY_COUNT,
      antigen: COLD_HEALTHY_ANTIGEN,
    }),
    vessels: COLD_VESSELS,
    tregs: COLD_TREGS,
    startingSuppress: COLD_STARTING_SUPPRESS,
    startingChemokine: COLD_STARTING_CHEMOKINE,
    // Checkpoint and IL-2 added after discovering the level was genuinely unwinnable
    // without them, at any tested budget or roster (confirmed 0/15 across five different
    // configurations using only what was previously unlocked here). Cold Tumor's own tumor
    // definition already carries nonzero pdl1Base/pdl1Inducible, so PD-L1 braking was always
    // a real mechanic in this level's math -- checkpoint just wasn't available to counter it.
    // Checkpoint blockade doesn't add more simultaneously-engaged killers (which is what
    // drives CRS risk); it makes existing ones finish faster, which is why it resolves the
    // CRS-versus-budget trap that simply adding more killers cannot: verified 0/30 wins with
    // neither unlocked, 100% (40/40) with both, at the *same*, unchanged budget.
    unlocks: Object.freeze([
      KIND.CD8,
      KIND.NK,
      KIND.DC,
      KIND.CD4,
      'rally',
      'lymphodepletion',
      'checkpoint',
      'il2',
    ]),
    scienceCardId: 'level-cold-tumor',
    tumorTypeName: 'Pancreatic Cancer',
    tumorMarkerInfo: 'Known for resisting immune attack — T cells rarely get in',
    tumorProfile: 'A quiet tumor — nothing here is calling immune cells in.',
    hint: 'Buy the checkpoint medicine first, then use dendritic cells and a danger trail to guide reinforcements.',
  }),
  Object.freeze({
    id: 'deep-core',
    number: 5,
    name: 'Deep Core',
    subtitle: 'Reach every layer',
    teaches: 'You learn that clearing the rim is only the start when cells must push into a dense, poorly supplied center.',
    budget: DEEP_CORE_BUDGET,
    timeLimitSec: DEEP_CORE_TIME_LIMIT_SEC,
    tumorEscapeCap: DEEP_CORE_TUMOR_ESCAPE_CAP,
    tumor: Object.freeze({
      count: DEEP_CORE_TUMOR_COUNT,
      cx: DEEP_CORE_TUMOR_CX,
      cy: DEEP_CORE_TUMOR_CY,
      spreadWu: DEEP_CORE_TUMOR_SPREAD_WU,
      antigenMix: DEEP_CORE_ANTIGEN_MIX,
      mhcMean: DEEP_CORE_MHC_MEAN,
      mhcSd: DEEP_CORE_MHC_SD,
      pdl1Base: DEEP_CORE_PDL1_BASE,
      pdl1Inducible: DEEP_CORE_PDL1_INDUCIBLE,
      divideTimeScale: DEEP_CORE_DIVIDE_TIME_SCALE,
    }),
    healthy: Object.freeze({
      count: DEEP_CORE_HEALTHY_COUNT,
      antigen: DEEP_CORE_HEALTHY_ANTIGEN,
    }),
    vessels: DEEP_CORE_VESSELS,
    tregs: DEEP_CORE_TREGS,
    startingSuppress: DEEP_CORE_STARTING_SUPPRESS,
    startingChemokine: DEEP_CORE_STARTING_CHEMOKINE,
    // Checkpoint added after Deep Core proved effectively unwinnable without it: without
    // IL-2, the tumor's growth (divideTimeScale 0.35, the second-fastest of any level,
    // combined with the largest tumor count in the game) outpaces any tested kill rate --
    // confirmed the tumor actually grows to ~247 cells by round's end. With IL-2 alone, kill
    // rate catches up (down to ~20 remaining) but its 1.6x CRS multiplier, applied across the
    // large roster this tumor size demands, pushes average patient health down to ~32/100.
    // Deep Core's pdl1Base/pdl1Inducible are identical to Cold Tumor's, where checkpoint
    // solved the same shape of problem: it doesn't add killers (what drives CRS), it makes
    // existing ones finish faster. Verified: IL-2 + checkpoint together, same unchanged
    // budget, 38/40 wins, average final patient health back to ~100.
    unlocks: Object.freeze([
      KIND.CD8,
      KIND.NK,
      KIND.MACRO,
      KIND.DC,
      KIND.CD4,
      'rally',
      'il2',
      'checkpoint',
    ]),
    scienceCardId: 'level-deep-core',
    tumorTypeName: 'Glioblastoma',
    tumorMarkerInfo: 'A dense tumor with an oxygen-starved, hard-to-reach core',
    tumorProfile: 'The largest mass here, packed dense with a poorly-supplied core.',
    hint: 'Buy checkpoint and IL-2 support first, then guide a mixed team to the rim and work inward.',
  }),
  Object.freeze({
    id: 'sandbox',
    number: 6,
    name: 'Sandbox',
    subtitle: 'Try your own experiment',
    teaches: 'You change the cells, tumor, and medicines, then compare what happens with no clock.',
    budget: SANDBOX_BUDGET,
    timeLimitSec: SANDBOX_TIME_LIMIT_SEC,
    tumorEscapeCap: SANDBOX_TUMOR_ESCAPE_CAP,
    tumor: Object.freeze({
      count: SANDBOX_TUMOR_COUNT,
      cx: SANDBOX_TUMOR_CX,
      cy: SANDBOX_TUMOR_CY,
      spreadWu: SANDBOX_TUMOR_SPREAD_WU,
      antigenMix: SANDBOX_ANTIGEN_MIX,
      mhcMean: SANDBOX_MHC_MEAN,
      mhcSd: SANDBOX_MHC_SD,
      pdl1Base: SANDBOX_PDL1_BASE,
      pdl1Inducible: SANDBOX_PDL1_INDUCIBLE,
      divideTimeScale: SANDBOX_DIVIDE_TIME_SCALE,
    }),
    healthy: Object.freeze({
      count: SANDBOX_HEALTHY_COUNT,
      antigen: SANDBOX_HEALTHY_ANTIGEN,
    }),
    vessels: SANDBOX_VESSELS,
    tregs: SANDBOX_TREGS,
    startingSuppress: SANDBOX_STARTING_SUPPRESS,
    startingChemokine: SANDBOX_STARTING_CHEMOKINE,
    unlocks: Object.freeze([
      KIND.CD8,
      KIND.NK,
      KIND.MACRO,
      KIND.DC,
      KIND.CD4,
      'checkpoint',
      'il2',
      'lymphodepletion',
      'rally',
    ]),
    scienceCardId: 'level-sandbox',
    tumorTypeName: null,
    tumorMarkerInfo: null,
    tumorProfile: 'Fully configurable — set every tumor property yourself.',
    hint: 'Move one slider at a time so you can see what each change does.',
  }),
]);

/**
 * Returns the level with the requested stable id, or undefined when no level matches.
 *
 * @param {string} id
 * @returns {object|undefined}
 */
export function getLevel(id) {
  return LEVELS.find((level) => level.id === id);
}
