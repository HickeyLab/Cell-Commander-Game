/**
 * booth-hardening.test.js — pins the fixes from the adversarial review round.
 *
 * These are the defects that make the difference between a demo that works when you're
 * standing next to it and an exhibit that survives an unattended day with two hundred
 * children. Every one of them was found by review, not by the unit suite, because they live
 * in wiring and lifecycle rather than in logic — which is exactly the category that silently
 * regresses.
 *
 * Several assertions are necessarily STRUCTURAL (they read source text) rather than
 * behavioural, because the behaviour lives in a DOM this project deliberately has no test
 * harness for. They are written to check for the presence of a *concept* — a guard, a
 * confirmation step — rather than an exact spelling, so ordinary refactoring should not
 * break them. If one does start failing spuriously, fix the assertion; do not delete it
 * without re-verifying the underlying behaviour in a browser.
 */

import { test, describe } from 'node:test';
import assert from 'node:assert/strict';
import { readFile, readdir, access } from 'node:fs/promises';
import { join, dirname } from 'node:path';
import { fileURLToPath } from 'node:url';

const ROOT = fileURLToPath(new URL('..', import.meta.url));
const read = (rel) => readFile(join(ROOT, rel), 'utf8');
const exists = async (rel) => {
  try { await access(join(ROOT, rel)); return true; } catch { return false; }
};

/** Strip comments so an assertion can't be satisfied by prose in a docblock. */
function code(src) {
  return src
    .replace(/\/\*[\s\S]*?\*\//g, ' ')
    .replace(/(^|[^:])\/\/[^\n]*/g, '$1 ');
}

describe('booth resilience', () => {
  test('the idle reset cannot fire during setup, play, or sandbox', async () => {
    // A 90 s idle timer that ignores the current screen throws a child back to the title
    // mid-round, and every level runs longer than 90 s. The timer must know where it is.
    const src = code(await read('src/ui/app.js'));
    assert.ok(/idle/i.test(src), 'expected an idle-timeout mechanism in app.js');

    // Scope the check to the idle scheduling function itself. Looking for SCREEN.* anywhere
    // in app.js is a false pass — the router mentions every screen constant already.
    const fn = src.match(/function\s+resetIdle\s*\([\s\S]*?\n\s{0,4}\}/);
    assert.ok(fn, 'could not locate the resetIdle function to inspect');

    const body = fn[0];
    // SCREEN.TITLE is the timer's DESTINATION, not a guard — matching it is a false pass.
    // A genuine gate must consult the current screen, or name a screen other than TITLE.
    const withoutDestination = body.replace(/SCREEN\.TITLE/g, '');
    const gated =
      /SCREEN\./.test(withoutDestination) ||
      /\bapp\.current\b|\bcurrent\b/.test(withoutDestination);
    assert.ok(
      gated,
      'resetIdle() schedules a jump to the title screen without consulting the current ' +
        'screen. Every level runs 180-230 s and the timeout is 90 s, so a child who places ' +
        'their cells and then watches the simulation — exactly what the game asks them to ' +
        'do — is ejected mid-round.\n\nresetIdle body:\n' + body
    );
  });

  test('one thrown frame cannot kill the animation loop for the rest of the day', async () => {
    const src = code(await read('src/ui/app.js'));
    const hasRaf = /requestAnimationFrame/.test(src);
    assert.ok(hasRaf, 'expected a requestAnimationFrame loop in app.js');
    assert.ok(
      /try\s*\{[\s\S]{0,400}?update[\s\S]{0,400}?\}\s*catch/.test(src),
      'the per-frame update call must be wrapped in try/catch and the loop re-armed, or a ' +
        'single exception silently stops the whole app until someone reloads'
    );
  });

  test('focus is moved to the new screen on navigation', async () => {
    const src = code(await read('src/ui/app.js'));
    assert.ok(
      /\.focus\s*\(/.test(src),
      'app.go() must move focus after mounting, or keyboard and screen-reader users are ' +
        'dumped at the document root on every navigation'
    );
  });
});

describe('offline story is real', () => {
  test('the service worker is actually registered', async () => {
    // index.html links a manifest, but a manifest alone caches nothing. Without a
    // register() call the documented "offline PWA" setup has no offline behaviour at all.
    const sources = await Promise.all([
      read('src/ui/app.js'),
      exists('index.html').then((ok) => (ok ? read('index.html') : '')),
    ]);
    const combined = sources.join('\n');
    assert.ok(
      /serviceWorker\s*\.\s*register|serviceWorker'\]\.register/.test(combined),
      'nothing calls navigator.serviceWorker.register(), so nothing is ever cached offline'
    );
  });

  test('service worker registration is guarded so it cannot break the file:// bundle', async () => {
    const src = code(await read('src/ui/app.js'));
    if (!/serviceWorker/.test(src)) return; // covered by the previous test
    const guarded =
      /'serviceWorker'\s+in\s+navigator/.test(src) || /serviceWorker\s*\)/.test(src);
    assert.ok(guarded, 'registration must be feature-detected');
    assert.ok(
      /file:|protocol/.test(src),
      'registration must be skipped for the file:// single-file bundle, where service ' +
        'workers are unavailable and the attempt throws'
    );
  });

  test('every file the service worker precaches actually exists', async () => {
    // cache.addAll is ATOMIC: one missing entry rejects the whole install and the worker
    // silently caches nothing. This is the single easiest way to ship a fake offline mode.
    const sw = await read('sw.js');
    const listed = [...sw.matchAll(/['"`](\.{0,2}\/[^'"`\s]+)['"`]/g)]
      .map((m) => m[1])
      .filter((p) => /\.(html|css|js|mjs|png|svg|webmanifest|json)$/i.test(p));

    const missing = [];
    for (const p of new Set(listed)) {
      const rel = p.replace(/^\.\//, '').replace(/^\//, '');
      if (!rel) continue;
      if (!(await exists(rel))) missing.push(p);
    }

    if (missing.length > 0) {
      // A resilient install (adding entries individually and tolerating failures) makes a
      // missing file survivable, so accept that as an alternative to a perfect list.
      const resilient = /catch|allSettled|Promise\.all\([\s\S]{0,300}?catch/.test(sw);
      assert.ok(
        resilient,
        `sw.js precaches files that do not exist and does not tolerate failures, so ` +
          `install rejects and NOTHING is cached: ${missing.join(', ')}`
      );
    }
  });

  test('the generated icons the manifest points at exist', async () => {
    const manifest = JSON.parse(await read('app.webmanifest'));
    const missing = [];
    for (const icon of manifest.icons || []) {
      const rel = String(icon.src).replace(/^\.\//, '').replace(/^\//, '');
      if (!(await exists(rel))) missing.push(icon.src);
    }
    assert.deepEqual(
      missing,
      [],
      `app.webmanifest points at icons that are not in the repo: ${missing.join(', ')} — ` +
        `run "node tools/make-icons.mjs"`
    );
  });
});

describe('touch and input safety', () => {
  test('holding still on the map does not delete the cell you meant to place', async () => {
    // Children rest a finger while deciding. A long-press-to-delete path turns the most
    // careful placement gesture into a destructive one.
    const src = code(await read('src/ui/setup.js'));
    const hasLongPressDelete =
      /setTimeout\([^)]*\b(remove|delete)\b/i.test(src) ||
      /\b(remove|delete)[A-Za-z]*\s*\([^)]*\)\s*[,;]?\s*\}\s*,\s*\d{3,}\s*\)/i.test(src);
    assert.ok(
      !hasLongPressDelete,
      'setup.js still arms a timer that removes a placement on a long press — a slow, ' +
        'deliberate tap will delete instead of place. Use the visible "Remove cells" toggle.'
    );
  });

  test('the start control never swallows a tap without explaining itself', async () => {
    const src = code(await read('src/ui/setup.js'));
    const hardDisabled = /start[A-Za-z]*\.disabled\s*=\s*(?!false)/i.test(src);
    assert.ok(
      !hardDisabled,
      'the Start control is disabled when no cells are placed. A disabled button fires no ' +
        'events, so a child tapping the biggest button on screen gets no response at all. ' +
        'Keep it enabled and explain the empty case on click.'
    );
  });

  test('the placement canvas is operable by keyboard', async () => {
    const src = code(await read('src/ui/setup.js'));
    assert.ok(
      /keydown|onKeyDown/i.test(src),
      'the placement canvas is a focus stop with no key handler, so a keyboard user lands ' +
        'on it and cannot place anything'
    );
  });
});

describe('operator controls are protected from children', () => {
  test('the reveal gesture is long enough that a child will not find it', async () => {
    const src = code(await read('src/ui/leaderboard.js'));
    const holds = [...src.matchAll(/(\d{4,})\s*\)?\s*[;,)]/g)]
      .map((m) => Number(m[1]))
      .filter((n) => n >= 1000 && n <= 60000);
    assert.ok(holds.length > 0, 'expected a press-and-hold duration in leaderboard.js');
    assert.ok(
      Math.max(...holds) >= 5000,
      `the operator panel opens after only ${Math.max(...holds)} ms of holding; a child ` +
        `resting a finger on the heading will find it. Require at least 5000 ms.`
    );
  });

  test('clearing a day of booth scores requires confirmation', async () => {
    const src = code(await read('src/ui/leaderboard.js'));
    assert.ok(
      /confirm|are you sure|pendingClear|confirmClear/i.test(src),
      'clearScores is reachable in one tap with no confirmation — a mis-tap destroys the ' +
        'whole day of scores irreversibly'
    );
  });
});

describe('screen-reader and reduced-motion correctness', () => {
  test('only one component announces the tissue summary', async () => {
    // The defect was two regions announcing THE SAME canvas summary — one of them re-firing
    // on a timer regardless of change — which makes the game unusable with a screen reader.
    //
    // It is NOT a defect to have several distinct live regions for distinct purposes (a
    // placement message, an operator status, a results confirmation). Asserting "exactly one
    // aria-live element in the whole app" would be wrong and would push someone to delete
    // legitimate announcements. So check the specific overlap instead: hud.js owns the
    // tissue summary, and live.js must not create a competing one.
    const hud = await read('src/render/hud.js');
    const live = await read('src/ui/live.js');

    const hudRegions = (code(hud).match(/aria-live/g) || []).length;
    assert.equal(
      hudRegions,
      1,
      `hud.js should own exactly one live region for the tissue summary, found ${hudRegions}`
    );

    const liveRegions = (code(live).match(/aria-live/g) || []).length;
    assert.equal(
      liveRegions,
      0,
      'live.js creates its own aria-live region, duplicating the summary hud.js already ' +
        'announces — a screen-reader user hears every update twice'
    );

    // And the surviving region must only speak when something actually changed.
    assert.ok(
      /setTextIfChanged|!==\s*last|previous|lastText/i.test(code(hud)),
      'hud.js must only write to its live region when the announced text changes; ' +
        'a timer-driven re-announcement of identical text is constant noise'
    );
  });

  test('reduced motion still reaches the final revealed state', async () => {
    const src = code(await read('src/ui/results.js'));
    if (!/reduced|prefers-reduced-motion/i.test(src)) return;
    const revealCount = (src.match(/is-revealed/g) || []).length;
    assert.ok(
      revealCount >= 2,
      'the score breakdown is revealed by adding "is-revealed", but the reduced-motion ' +
        'branch never adds it, so those rows stay permanently dimmed below the contrast ' +
        'floor. Skipping an animation must not change the END state.'
    );
  });
});

describe('the sandbox actually simulates', () => {
  test('the sandbox renders a live tissue view and is driven by the app loop', async () => {
    // Free experimentation is the entire point of the outreach exercise. A wall of sliders
    // with nothing to watch teaches nothing.
    const src = await read('src/ui/sandbox.js');
    const c = code(src);
    const hasView =
      /canvas/i.test(c) || /makeRoundView/.test(c) || /makeRenderer/.test(c) || /round-view/.test(src);
    assert.ok(
      hasView,
      'sandbox.js builds no tissue view — a child changes a slider and sees nothing happen'
    );
    assert.ok(
      /\bupdate\b\s*[:(]/.test(c),
      'sandbox.js must return an update(dt) from mount(), or the master animation loop ' +
        'never drives it and the simulation is frozen'
    );
  });
});
