/**
 * tumor.js owns adaptive PD-L1 resistance, quiescence, perfusion-limited
 * clonal division, and spontaneous tumor-cell death decisions.
 */

import { FIELD, STATE } from '../../core/contracts.js';
import { P } from '../params.js';

/**
 * Update one tumor cell without allocating.
 * @param {object} round
 * @param {number} i
 * @param {number} dt
 * @returns {void}
 */
export function updateTumor(round, i, dt) {
  const world = round.world;
  const ifng = round.grid.sample(FIELD.IFNG, world.x[i], world.y[i]);
  const baseline = round.level.tumor.pdl1Base;
  const inducibleMax = Math.min(1, baseline + round.level.tumor.pdl1Inducible);

  if (ifng > P.checkpoint.ifngSwitch) {
    world.a2[i] = Math.min(inducibleMax, world.a2[i] + P.checkpoint.inductionRate * dt);
    world.a1[i] = Math.min(1, world.a1[i] + P.checkpoint.inductionRate * dt);
  } else {
    world.a2[i] = Math.max(baseline, world.a2[i] - P.checkpoint.decayRate * dt);
  }

  if (world.a2[i] >= P.checkpoint.pdl1Critical) {
    world.state[i] = STATE.QUIESCENT;
  } else if (world.state[i] !== STATE.NECROTIC) {
    world.state[i] = STATE.PROLIFERATIVE;
  }

  // Inflamed tumor tissue continuously recruits immune cells — it produces CXCR3-ligand
  // chemokines and releases damage-associated signals whether or not it is under attack.
  // This is also what breaks a deadlock the game otherwise has: chemokine was produced only
  // by ENGAGED killers, so the moment they disengaged the gradient vanished, they random-
  // walked away, and never came back. Measured before this line existed: clearing stalled at
  // 15 of 40 cells and sat there for 150 seconds with killers standing on top of the tumor.
  round.grid.deposit(
    FIELD.CHEMOKINE,
    world.x[i],
    world.y[i],
    P.production.chemokineTumor * dt,
  );

  if (round.rng.bool(P.tumor.spontaneousDeathPerSec * dt)) {
    round._queueDeath(i, -1);
    return;
  }
  if (world.state[i] === STATE.QUIESCENT && !P.tumor.quiescentDivides) {
    return;
  }
  // Necrotic-core gate: an ABSOLUTE perfusion cutoff, never a comparison against the field
  // mean. Half of any field lies below its own mean, and tumor cells are clustered, so the
  // mean-based version blocked essentially every division — measured across all five levels,
  // an untreated tumor never divided once and instead slowly shrank.
  if (round._perfusionAt(world.x[i], world.y[i]) < P.tumor.perfusionMin) {
    return;
  }

  world.timer[i] -= dt;
  if (world.timer[i] > 0) {
    return;
  }

  const angle = round.rng.angle();
  const distance = world.radius[i] * 2;
  const daughterX = world.x[i] + Math.cos(angle) * distance;
  const daughterY = world.y[i] + Math.sin(angle) * distance;
  if (!round._hasDivisionClearance(i, daughterX, daughterY)) {
    return;
  }

  const interval = P.tumor.divideTimeSec * round.level.tumor.divideTimeScale;
  const daughterTimer = interval * round.rng.range(0.8, 1.2);
  if (round._queueSpawn(
    world.kind[i],
    daughterX,
    daughterY,
    world.a0[i],
    world.a1[i],
    world.a2[i],
    0,
    STATE.PROLIFERATIVE,
    daughterTimer,
  )) {
    world.timer[i] = interval * round.rng.range(0.8, 1.2);
  }
}
