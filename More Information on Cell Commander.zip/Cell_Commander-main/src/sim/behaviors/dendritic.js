/**
 * dendritic.js owns debris uptake, antigen loading, timed maturation, and
 * vessel-entry CD8 reinforcement waves with a bounded wave count.
 */

import { FIELD, STATE } from '../../core/contracts.js';
import { P } from '../params.js';

/**
 * Update one dendritic cell without allocating.
 * @param {object} round
 * @param {number} i
 * @param {number} dt
 * @returns {void}
 */
export function updateDendritic(round, i, dt) {
  const world = round.world;
  if (world.state[i] === STATE.IMMATURE) {
    const taken = round._takeDebris(world.x[i], world.y[i], dt);
    world.a0[i] = Math.min(P.dc.loadRequired, world.a0[i] + taken);
    if (world.a0[i] >= P.dc.loadRequired) {
      world.state[i] = STATE.LOADED;
      world.a1[i] = 0;
    }
    round._move(i, FIELD.DEBRIS, false);
    return;
  }

  if (world.state[i] === STATE.LOADED) {
    world.a1[i] = Math.min(1, world.a1[i] + dt / P.dc.maturationSec);
    if (world.a1[i] >= 1) {
      world.state[i] = STATE.MATURE;
      world.timer[i] = 0;
    }
    round._move(i, FIELD.CHEMOKINE, false);
    return;
  }

  if (world.state[i] === STATE.MATURE) {
    if (world.a3[i] < P.dc.maxWaves) {
      world.timer[i] -= dt;
      if (world.timer[i] <= 0 && round._queueWave(i)) {
        world.a3[i] += 1;
        world.timer[i] = P.dc.maturationSec;
      }
    }
    // world.a2 doubles as a countdown for the vessel-to-tumor guide chain queueWave arms
    // (see its own comment in engine.js): re-lay it roughly once per second, not every
    // tick, since the fast-decaying beacon signal needs frequent refreshing to stay ahead
    // of a slow-moving reinforcement but doesn't need refreshing 60 times a second to do it.
    if (world.a2[i] > 0) {
      const wholeSecondsBefore = Math.floor(world.a2[i]);
      world.a2[i] = Math.max(0, world.a2[i] - dt);
      if (Math.floor(world.a2[i]) < wholeSecondsBefore) {
        round._refreshWaveGuide(i);
      }
    }
  }
  round._move(i, FIELD.CHEMOKINE, false);
}
