/**
 * params.js — every biological constant in the game, with provenance.
 *
 * This game is a real-time descendant of the Hickey lab's published tumor microenvironment
 * agent-based model:
 *
 *   Hickey, J.W., Agmon, E., Horowitz, N., Lamore, M., Sunwoo, J.B., Covert, M.W. & Nolan, G.P.
 *   "Integrating Multiplexed Imaging and Multiscale Modeling Identifies Tumor Phenotype
 *   Transformation as a Critical Component of Therapeutic T Cell Efficacy." Cell Systems.
 *   Code: github.com/vivarium-collective/tumor-tcell
 *
 * PROVENANCE TAGS — every numeric constant below carries exactly one:
 *
 *   [MODEL]   Value taken directly from the research ABM. The source file and the original
 *             value (with its own literature citation) are recorded in the comment.
 *   [SCALED]  A research value deliberately rescaled for real-time play. The comment records
 *             the original value, the factor, and WHY the deviation was necessary.
 *   [DERIVED] Computed from other tagged values. The comment shows the arithmetic.
 *   [GAME]    A pure game-design number making no biological claim.
 *
 * An untagged constant is a bug; tests/params.test.js enforces this by scanning this file.
 *
 * ---------------------------------------------------------------------------
 * UNITS
 * ---------------------------------------------------------------------------
 * World units (wu): 1 µm = 2 wu, so the 1200 x 800 wu arena is 600 x 400 µm of tissue —
 * a realistic microscopy field of view. The 2x factor exists purely so that a 15 µm tumor
 * cell renders large enough for a child to see and tap.
 *
 * Time: rates are expressed per GAME SECOND. The research model runs in biological minutes.
 * One conversion constant, BIO_MIN_PER_GAME_SEC, links them, and it is applied in exactly
 * one place — here. Nothing else in the codebase converts time. Change it and every rate
 * stays in correct relative proportion.
 */

import { KIND, ANTIGEN, FIELD, FIELD_COUNT } from '../core/contracts.js';

/* =================================================================== *
 * TIME AND SPACE
 * =================================================================== */

/** [GAME] 1 µm of real tissue = 2 world units. Visual legibility only; no biological claim. */
export const WU_PER_UM = 2;

/**
 * [SCALED] Time compression: one game second represents 5 minutes of biology.
 *
 * Chosen from the killing rate, which is the mechanic a child must actually watch happen.
 * The research model needs 12,800 cytotoxic packets to kill a tumor cell, delivered at
 * 400 packets/min => 32 biological minutes for one T cell to kill one target.
 * At 5 bio-min per game-second that becomes 6.4 game seconds — slow enough to see the
 * struggle, fast enough that a 2-minute round clears a tumor.
 */
export const BIO_MIN_PER_GAME_SEC = 5;

/** [DERIVED] 5 bio-min/game-s x 60 = 300 biological seconds per game second. */
export const BIO_SEC_PER_GAME_SEC = BIO_MIN_PER_GAME_SEC * 60;

/**
 * [SCALED] Migration is rendered at 1/4 of the full time compression.
 *
 * HONEST NOTE — this is the one place the game knowingly departs from proportionality.
 * At full 300x compression a T cell moving at its real 10 µm/min would cross the whole
 * field in ~12 seconds, appearing as a blur, and contact-dependent killing would never be
 * visible because cells would pass through each other between frames.
 * RELATIVE speeds between every cell type are preserved exactly, so the biology being
 * taught (CD8 faster than macrophage, PD1+ slower than PD1-) is fully intact.
 */
export const MIGRATION_TIME_SCALE = 0.25;

/** [DERIVED] µm/min -> wu/game-s. = (µm/min) x WU_PER_UM x BIO_MIN_PER_GAME_SEC x MIGRATION_TIME_SCALE */
export function umPerMinToWuPerGameSec(umPerMin) {
  return umPerMin * WU_PER_UM * BIO_MIN_PER_GAME_SEC * MIGRATION_TIME_SCALE;
}

/** [DERIVED] A per-biological-minute rate -> per-game-second. */
export function perBioMinToPerGameSec(rate) {
  return rate * BIO_MIN_PER_GAME_SEC;
}

/* =================================================================== *
 * CELL GEOMETRY
 * =================================================================== */

const RADIUS = {
  // [MODEL] tumor.py defaults: 'diameter': 15 * units.um  -> radius 7.5 µm = 15 wu
  [KIND.TUMOR]: 15,
  // [MODEL] t_cell.py defaults: 'diameter': 7.5 * units.um -> radius 3.75 µm = 7.5 wu
  [KIND.CD8]: 7.5,
  // [MODEL] CAR-T is a genetically engineered T cell; same physical size as a T cell.
  [KIND.CART]: 7.5,
  // [SCALED] NK cells are slightly larger granular lymphocytes (~9 µm diameter, Orange 2008);
  // no NK cell exists in the research model, so this is from general lymphocyte morphology.
  [KIND.NK]: 9,
  // [SCALED] Macrophages ~21 µm diameter (Krombach 1997). Not in the research model.
  [KIND.MACRO]: 18,
  // [SCALED] dendritic_cell.py sets 'diameter': 10.0 µm (Morefield 2005) — a 5 µm radius,
  // i.e. 10 wu. Enlarged 1.4x to 14 wu purely so a dendritic cell is distinguishable from a
  // lymphocyte at a glance on a tablet; its long dendrites are the visual cue and they need
  // room to read. No biological claim is made by the increase.
  // (This previously carried a research-provenance tag claiming dendritic_cell.py used the
  // same 15 µm class as the tumor. That was simply false — exactly the kind of unverifiable
  // claim the tagging discipline exists to catch, and it is now checked mechanically by
  // tests/provenance-crosscheck.test.js against the research model's actual source.)
  [KIND.DC]: 14,
  // [MODEL] CD4 helper T cells are the same size class as CD8 (t_cell.py 7.5 µm).
  [KIND.CD4]: 7.5,
  // [MODEL] Regulatory T cells are a CD4 T cell subset, so they take the same size class
  // as every other T cell in t_cell.py ('diameter': 7.5 µm).
  [KIND.TREG]: 7.5,
  // [GAME] Vessels are drawn as a cross-section; size chosen for tappability, not anatomy.
  [KIND.VESSEL]: 22,
  // [SCALED] Generic human epithelial/stromal cell, ~8 µm radius (Milo & Phillips, Cell
  // Biology by the Numbers). Not in the research model, which contains only tumor and immune
  // cells. Set just larger than a lymphocyte and just smaller than a tumor cell so that
  // healthy tissue reads as background rather than as a target.
  [KIND.HEALTHY]: 16,
};

/* =================================================================== *
 * MIGRATION  (µm/min in the source, converted on export)
 * =================================================================== */

const SPEED_UM_MIN = {
  // [MODEL] t_cell.py 'PD1n_migration': 10.0 µm/min (Boissonnas 2007)
  [KIND.CD8]: 10.0,
  // [SCALED] CAR-T cells migrate as activated effector T cells; the research model has no
  // CAR-T. Set equal to the activated PD1- T cell value rather than inventing a faster number.
  [KIND.CART]: 10.0,
  // [SCALED] NK cells 8 µm/min. From the companion influenza ABM's literature-backed
  // velocity hierarchy (CD8 10 > neutrophil 9 > NK 8 > CD4 6 > B 5 > macrophage 3 = DC 3).
  [KIND.NK]: 8.0,
  // [SCALED] Macrophage 3 µm/min, same hierarchy.
  [KIND.MACRO]: 3.0,
  // [SCALED] Dendritic cell 3 µm/min, same hierarchy.
  [KIND.DC]: 3.0,
  // [SCALED] CD4 helper 6 µm/min, same hierarchy.
  [KIND.CD4]: 6.0,
  // [SCALED] Tregs are CD4 T cells; same 6 µm/min.
  [KIND.TREG]: 6.0,
  // [MODEL] tumor.py: tumor cells do not migrate.
  [KIND.TUMOR]: 0,
  [KIND.VESSEL]: 0,
  [KIND.HEALTHY]: 0,
};

/**
 * [MODEL] t_cell.py 'PD1p_migration': 5.0 µm/min vs PD1n 10.0 (Boissonnas 2007).
 * Exhausted T cells move at half speed. Preserved exactly as a ratio.
 */
export const EXHAUSTED_SPEED_FRAC = 0.5;

/**
 * [MODEL] t_cell.py 'migration_MHCIp_tumor_dwell_velocity': 0.0 µm/min (Thibaut 2020).
 * A T cell engaged with a recognized target ARRESTS. This is a real and important
 * observation — it is why killers cluster visibly on the tumor.
 * Set marginally above zero so engaged cells drift with the crowd rather than freezing.
 */
export const ENGAGED_SPEED_FRAC = 0.05;

/** [GAME] Heading persistence per tick; produces run-and-tumble rather than jitter. */
export const PERSISTENCE = 0.88;

/** [GAME] Random angular noise added to heading each tick, radians. */
export const TURN_NOISE = 0.35;

/** [GAME] How strongly each kind steers up its attractant gradient. */
const CHEMO_GAIN = {
  [KIND.CD8]: 1.0,
  [KIND.CART]: 1.0,
  [KIND.NK]: 0.9,
  [KIND.MACRO]: 0.7,
  [KIND.DC]: 0.35, // DCs migrate toward debris, then away (to the lymph node) once loaded
  [KIND.CD4]: 0.8,
  [KIND.TREG]: 0.6,
};

/* =================================================================== *
 * KILLING
 * =================================================================== */

/**
 * [MODEL] tumor.py 'cytotoxic_packet_threshold': 128 * 100 = 12800 packets required for
 * tumor cell death (Betts 2004; Zhang 2006).
 */
export const TUMOR_DEATH_PACKETS = 12800;

/**
 * [DERIVED] t_cell.py 'cytotoxic_transfer_rate': 400 packets/min transferred to a tumor cell
 * (Betts 2004; Zhang 2006). Converted: 400 x BIO_MIN_PER_GAME_SEC = 2000 packets/game-second.
 * => one CD8 kills one tumor cell in 12800/2000 = 6.4 game seconds of sustained contact.
 */
const CD8_PACKETS_PER_GAME_SEC = perBioMinToPerGameSec(400);

const KILL_RATE = {
  // [DERIVED] see above
  [KIND.CD8]: CD8_PACKETS_PER_GAME_SEC,
  // [SCALED] CAR-T cells deliver cytotoxicity ~1.6x faster than an unmodified CD8 T cell
  // in this game. Rationale: CAR recognition is MHC-independent and high-avidity, so it
  // does not wait on peptide-MHC availability. The research model has no CAR-T to copy;
  // this is a game-balance choice made explicit rather than hidden. => 4.0 s per kill.
  [KIND.CART]: CD8_PACKETS_PER_GAME_SEC * 1.6,
  // [SCALED] NK cells kill with comparable per-conjugate kinetics but shorter contacts.
  [KIND.NK]: CD8_PACKETS_PER_GAME_SEC * 0.85,
  // [SCALED] Macrophage phagocytic killing is far slower than lymphocyte cytotoxicity.
  // Set to 1/5 so macrophages read as support, not primary killers.
  [KIND.MACRO]: CD8_PACKETS_PER_GAME_SEC * 0.2,
};

/**
 * [GAME] Reduced CD8 cytotoxicity against MHC-I-low targets.
 *
 * HONEST CORRECTION. This was previously tagged [MODEL] and justified as
 * "'MHCIn_reduction_production': 400 vs 'cytotoxic_transfer_rate': 400 — a 4-fold
 * reduction". That comparison is arithmetically empty (400 against 400 is a ratio of one)
 * and the two constants are unrelated in the source: MHCIn_reduction_production is applied
 * as a DIVISOR on production (t_cell.py:424, :430, :480, :486 — a 400-fold reduction as
 * literally coded, though the source's own comment describes 4-fold), while
 * cytotoxic_transfer_rate is the per-minute transfer ceiling. Neither 4x nor 400x is what
 * this game uses, so 0.25 is a game-design value and is labelled as one.
 *
 * The underlying biology is real — CD8 killing is less efficient against MHC-I-low targets
 * (Bohm 1998; Merritt 2003) — but the magnitude here is chosen for play, not derived.
 *
 * CURRENTLY UNREACHABLE: CD8 recognition requires mhc > MHC_RECOGNITION_MIN, and this
 * penalty is applied below that same boundary, so no target satisfies both conditions and
 * the branch never fires. Making it meaningful needs a graded band — CD8 engages above the
 * recognition cutoff but takes this penalty between that cutoff and a higher
 * "MHC-adequate" level. Left in place rather than silently deleted so the gap is visible.
 */
export const MHC_LOW_KILL_PENALTY = 0.25;

/** [GAME] Extra distance beyond touching radii at which an engagement forms, wu. */
export const ENGAGE_MARGIN = 4;

/** [GAME] Pause after a kill before the killer re-targets, game seconds. Serial killing. */
export const KILL_COOLDOWN = 0.35;

/* =================================================================== *
 * RECOGNITION
 * =================================================================== */

/**
 * [MODEL] t_cell.py 'ligand_threshold': 1e4 molecules/neighbor cell needed to recognize
 * ligands on positive cells. Normalized here to a 0..1 MHC-I scale where
 * 1.0 = the PDL1p/MHCIp equilibrium of 5e4 (tumor.py 'PDL1p_MHCI_equilibrium').
 * => 1e4 / 5e4 = 0.2
 */
export const MHC_RECOGNITION_MIN = 0.2;

/**
 * [SCALED] NK "missing-self": NK cells are released from inhibition when MHC-I is low.
 * Set at the same 0.2 boundary so NK and CD8 recognition are exactly complementary —
 * every tumor cell is killable by exactly one of the two lineages. This complementarity
 * is the lesson of the Escape Artist level, and making the thresholds identical is what
 * guarantees no tumor cell is unkillable by any strategy.
 */
export const NK_MISSING_SELF_MAX = 0.2;

/* =================================================================== *
 * PD-1 / PD-L1 CHECKPOINT
 * =================================================================== */

/**
 * [MODEL] tumor.py 'PDL1p_PDL1_equilibrium': 5e4 molecules/cell, and
 * t_cell.py 'PDL1_critical_number': 1e4 = the threshold to induce PD-1 behavior.
 * Normalized to the 0..1 pdl1 scale: the brake begins biting at 1e4/5e4 = 0.2.
 */
export const PDL1_CRITICAL = 0.2;

/**
 * [DERIVED] Strength of the PD-1 brake in
 *   brake = 1 / (1 + pdl1 * pd1 * PD1_STRENGTH)
 * Calibrated against the research model's own 10-fold effect: t_cell.py gives PD1+ cells
 * 'PD1p_cytotoxic_packets_max': 1000 versus 'PD1n_cytotoxic_packets_max': 10000, a 10x
 * reduction (Zelinskyy 2005). At full pdl1 = 1 and full pd1 = 1 we want brake = 1/10,
 * so PD1_STRENGTH = 9.
 */
export const PD1_STRENGTH = 9;

/**
 * [SCALED] Local IFN-gamma at which a tumor cell starts raising PD-L1 (adaptive resistance).
 *
 * The research model's own trigger is tumor.py 'IFNg_threshold': 15000 molecules, but this
 * game tracks normalized field concentrations rather than molecule counts, so that number
 * cannot be carried over directly — it has to be calibrated against the concentrations the
 * game actually produces.
 *
 * It previously sat at 1.0, which was never checked: measured peak IFN-gamma around a busy
 * kill zone is only ~0.18, so the switch could never fire, tumor PD-L1 never rose above its
 * per-level baseline, and the whole adaptive-resistance mechanic -- the entire lesson of
 * level 2 -- was silently dead while still being described in the science cards.
 *
 * 0.06 is about a third of that measured peak: high enough that only sustained, concentrated
 * killing raises the shield (so it reads as cause and effect), low enough that it reliably
 * does.
 */
export const IFNG_STATE_SWITCH = 0.06;

/**
 * [SCALED] Rate at which a tumor cell's pdl1 rises toward 1.0 while exposed to IFN-gamma
 * above IFNG_STATE_SWITCH, per game second. This is ADAPTIVE RESISTANCE — the tumor
 * shields itself precisely because it is being attacked — and it is the single most
 * important concept level 2 teaches. Tuned so the shield becomes visible ~8 s into a
 * successful assault, i.e. after the first wave of kills, which is when it reads as
 * cause-and-effect to a child.
 */
export const PDL1_INDUCTION_RATE = 0.11;

/** [SCALED] pdl1 decays back down when IFN-gamma is absent. Slower than induction. */
export const PDL1_DECAY_RATE = 0.03;

/**
 * [GAME] The research model has no checkpoint-inhibitor drug, so this value cannot claim
 * research provenance. It is the game's representation of anti-PD-1 therapy. The MECHANISM is
 * real and correctly placed: an anti-PD-1 antibody blocks the receptor on the T cell, it
 * does not strip PD-L1 off the tumor — so the drug reduces effective pd1 availability and
 * leaves tumor pdl1 untouched. Residual 0.1 because clinical blockade is never complete.
 */
export const CHECKPOINT_RESIDUAL_PD1 = 0.1;

/* =================================================================== *
 * T CELL EXHAUSTION
 * =================================================================== */

/**
 * [MODEL] t_cell.py 'refractory_count_threshold': 3 with the comment that cells need
 * ~5 stimulations to become exhausted (Zhao 2020). Modeled here as a continuous 0..1
 * exhaustion variable rising with time-under-engagement rather than a discrete count,
 * so that a child sees a gradual fade rather than a sudden switch.
 * Rate set so ~5 full kills drives exhaustion to 1.0:
 *   5 kills x 6.4 s/kill = 32 s of engagement => 1/32 = 0.031 per engaged game second.
 */
export const EXHAUST_PER_ENGAGED_SEC = 0.031;

/**
 * [SCALED] Exhaustion recovers three times slower than it accumulates.
 *
 * HONEST CORRECTION. This was previously presented as [MODEL]-derived from a 6 h : 18 h
 * productive-to-refractory ratio in t_cell.py. That arithmetic does not hold:
 *   'activation_time': 21600 s            = 6 h
 *   'activation_refractory_time': 43200 s = 12 h, NOT 18 h
 * and the timers are absolute from activation onset, so the refractory window actually runs
 * from 6 h to 12 h — a 6 h : 6 h ratio, i.e. 1:1. (The research file's own comment says
 * "refractory period of 18 hours"; that comment disagrees with its own value, and this
 * project repeated the error instead of checking it.)
 *
 * The 1:3 divisor is therefore a GAME choice, not a derivation: at 1:1 a T cell recovers
 * fast enough that exhaustion stops being a consideration inside a two-minute round, and the
 * mechanic — and the IL-2 support that counters it — teaches nothing. Kept at 3 and labelled
 * for what it is.
 */
export const EXHAUST_RECOVERY_RATE = EXHAUST_PER_ENGAGED_SEC / 3;

/**
 * [SCALED] IL-2 opposes exhaustion. IL-2 support is standard adjunct therapy for adoptive
 * cell transfer. Multiplier on the recovery rate at saturating local IL-2.
 */
export const IL2_RECOVERY_BOOST = 4.0;

/** [DERIVED] Killing efficiency scales with (1 - exhaustion), floored so cells never fully stop. */
export const EXHAUSTED_KILL_FLOOR = 0.15;

/* =================================================================== *
 * TUMOR GROWTH AND DEATH
 * =================================================================== */

/**
 * [DERIVED] tumor.py 'PDL1n_growth': 0.6 = probability of division within 24 h (Eden 2011).
 * As a Poisson process: lambda = -ln(1 - 0.6) / 24 h = 0.0382/h => mean interval 26.2 h.
 * 26.2 h = 1572 bio-min => 1572 / BIO_MIN_PER_GAME_SEC = 314 game seconds.
 * Levels scale this with `divideTimeScale` to create growth pressure inside a 2-minute round.
 */
export const TUMOR_DIVIDE_TIME_SEC = 314;

/**
 * [MODEL] tumor.py comment: "PDL1p no growth - Cells arrested, do not divide"
 * (data; Thibaut 2020; Hoekstra 2020). A shielded tumor cell stops dividing.
 * This is a genuine and pleasing trade-off for the player: the shield protects the tumor
 * but also stalls it, so a stalled assault is not an automatic loss.
 */
export const QUIESCENT_DIVIDES = false;

/** [GAME] A tumor cell will not divide if a daughter cannot be placed without deep overlap. */
export const DIVIDE_MIN_CLEARANCE = 0.55;

/**
 * [GAME] Minimum local perfusion for a tumor cell to divide — the necrotic-core cutoff.
 *
 * This must be an ABSOLUTE threshold, not a comparison against the field's mean. The gate
 * was originally `perfusion < perfusionMean`, and a mean has, by construction, half the
 * field below it; because tumor cells are clustered in one place they nearly all landed on
 * the same side of it. Measured consequence: across all five levels an untreated tumor never
 * divided once — every one of them slowly SHRANK — so there was no growth pressure, no
 * urgency, and "The tumor escaped" could never fire, leaving tumorEscapeCap dead
 * configuration on every level.
 *
 * 0.22 keeps the biology the mechanic exists for — the poorly-supplied centre of a large
 * mass stays quiescent, which is what Deep Core is about — while letting the well-perfused
 * rim proliferate.
 */
export const TUMOR_PERFUSION_MIN = 0.22;

/**
 * [MODEL] tumor.py 'death_apoptosis': 0.5 per 5 days, described as "negligible compared to
 * growth/killing" (Gong 2017). Retained for honesty but effectively invisible in a
 * 2-minute round; included so the model does not imply tumor cells are immortal.
 */
export const TUMOR_SPONTANEOUS_DEATH_PER_SEC = 0.5 / (5 * 24 * 60 / BIO_MIN_PER_GAME_SEC);

/* =================================================================== *
 * FIELDS — production, diffusion, decay
 * =================================================================== */

/**
 * Field values are on a normalized 0..~3 scale rather than molecule counts. The research
 * model tracks absolute molecule counts (e.g. IFNg_threshold 15000 molecules); reproducing
 * that here would put every threshold at an unreadable magnitude with no gameplay benefit.
 * What is preserved exactly is the RATIOS between production rates and the RELATIVE
 * diffusion speeds, because those are what determine the spatial patterns kids observe.
 */

/**
 * [MODEL] t_cell.py 'PD1n_IFNg_production': 1.62e4/3600 molecules/cell/s (Bouchnita 2017)
 * versus 'PD1p_IFNg_production': 1.62e3/3600 (Zelinskyy 2005) — exactly 10x lower when
 * exhausted. Normalized to 1.0 for a healthy engaged T cell; the 10x ratio is preserved.
 */
export const IFNG_PRODUCTION = 1.0;
export const IFNG_PRODUCTION_EXHAUSTED = 0.1;

/** [GAME] Chemokine output of an activated killer, per game second. Attracts reinforcements. */
export const CHEMOKINE_PRODUCTION = 0.6;

/**
 * [SCALED] M1-polarized macrophages are among the dominant producers of the CXCR3-ligand
 * chemokines (CXCL9/10/11) that recruit T and NK cells, so their output is set above a
 * lymphocyte's rather than equal to it. Not in the research model, which has no macrophage.
 * The ratio matters more than the magnitude: it is what makes buying a macrophage a
 * meaningful way to pull reinforcements toward a cold tumor.
 */
export const CHEMOKINE_PRODUCTION_M1 = 1.1;

/**
 * [SCALED] Chemokine produced by each tumor cell, per game second.
 *
 * Real tumors are not passive targets: inflamed tumor tissue secretes CXCR3-ligand
 * chemokines and releases damage-associated molecular patterns, which is precisely why
 * tumor-infiltrating lymphocytes exist. Not in the research model, which has no chemotaxis.
 *
 * Magnitude chosen by sweep (0.085 / 0.2 / 0.4 / 0.8 / 1.5 across all levels, 3 seeds each).
 * The binding constraint is the ENDGAME: when only a few tumor cells remain they are the
 * sole chemokine source, and below ~0.2 the gradient is too weak for killers to find them,
 * so rounds stalled one or two cells short of a win. 0.4 clears every level reliably; going
 * higher stopped helping and began to swamp the players' own cells as the signal source.
 * Still below an engaged killer's 0.6 output, so an active fight remains the loudest signal.
 */
export const TUMOR_CHEMOKINE_PRODUCTION = 0.4;

/** [GAME] IL-2 output of a helper CD4 T cell. */
export const IL2_PRODUCTION = 0.9;

/** [GAME] Suppressive output (TGF-beta / IL-10 lumped) of a Treg. */
export const SUPPRESS_PRODUCTION_TREG = 1.0;

/** [SCALED] M2 macrophages are also suppressive, at roughly half a Treg's output. */
export const SUPPRESS_PRODUCTION_M2 = 0.5;

/**
 * [MODEL] tumor.py 'tumor_debris_amount': 1.4e15 molecules per cell released on death
 * (Apetoh 2007). Normalized to 1.0 unit of debris per dying tumor cell.
 */
export const DEBRIS_PER_DEATH = 1.0;

/**
 * DIFFUSION, wu^2 per game second.
 *
 * [MODEL] fields.py DIFFUSION_RATES:
 *   IFNg         1.25e-3 cm^2/day (Liao 2014)   = 1.447 µm^2/s = 5.79 wu^2/bio-s
 *   tumor_debris 0.0864 cm^2/day (Krouglova 2004) = 100 µm^2/s = 400 wu^2/bio-s
 *
 * [SCALED] Converting at the full 300 bio-s/game-s factor gives IFNg 1736 and debris
 * 120,000 wu^2/game-s. The debris figure would flood the entire 1200x800 field within a
 * single game second, erasing the spatial gradient that dendritic cells are supposed to
 * follow — the mechanic would become invisible. Debris is therefore held at a value that
 * preserves a visible crumb trail, and the deviation is recorded here rather than hidden.
 * IFN-gamma keeps its converted value; it is genuinely a fast-spreading small cytokine and
 * the near-global alarm signal is biologically correct.
 */
const DIFFUSION = new Float32Array(FIELD_COUNT);
// [SCALED] Chemokines are small, fast-diffusing, and — critically — form gradients that
// reach far across tissue. This value was chosen by sweep rather than assumed, because the
// gradient length it sets is what decides whether the game is playable at all.
// The pairing with a low decay below gives a gradient length of
// sqrt(D/decay) ~= 122 world units (~60 µm), which is realistic for a tissue chemokine field
// and is what makes the "Danger Scent" mechanic actually work.
// Swept against all five levels at 57 / 122 / 207 / 316 wu gradient lengths: at 57 wu a
// handful of surviving tumor cells made a beacon too small to find in a 1200 wu field and
// rounds stalled a few cells short of a win; beyond ~200 wu the gradient flattens out and
// stops giving useful direction. 122 wu cleared four of five levels on every seed.
DIFFUSION[FIELD.CHEMOKINE] = 1800;
DIFFUSION[FIELD.IFNG] = 1736;      // [DERIVED] 5.79 wu^2/bio-s x 300 bio-s/game-s
DIFFUSION[FIELD.IL2] = 1200;       // [SCALED] IL-2 is 15.5 kDa, comparable to IFN-gamma's 17 kDa
DIFFUSION[FIELD.SUPPRESS] = 700;   // [SCALED] TGF-beta is larger (25 kDa) and matrix-bound; slower
DIFFUSION[FIELD.DEBRIS] = 260;     // [SCALED] see note above — deliberately slowed to keep a gradient
// [GAME] Same diffusion as chemokine so a beacon's reach matches the mechanic it represents
// (a chemoattractant bolus); see DECAY below for why it is a separate field at all.
DIFFUSION[FIELD.BEACON] = 1800;

/**
 * DECAY, fraction lost per game second.
 * [SCALED] The research model handles cytokine removal by cellular internalization
 * (tumor.py 'Max_IFNg_internalization': 31/60 molecules/cell/s, A. Celada 1987) rather
 * than by a bulk decay term. A field-level decay is used here instead because the game has
 * no molecule-count bookkeeping. Values are set from the intended signal persistence:
 * alarm and chemoattractant signals are transient, suppression and debris persist.
 */
const DECAY = new Float32Array(FIELD_COUNT);
DECAY[FIELD.CHEMOKINE] = 0.12; // paired with DIFFUSION above to set the gradient length
DECAY[FIELD.IFNG] = 0.42;
DECAY[FIELD.IL2] = 0.30;
DECAY[FIELD.SUPPRESS] = 0.12;
DECAY[FIELD.DEBRIS] = 0.08;
/**
 * [GAME] A beacon is a one-time bolus, not sustained production, so it needs its own field
 * rather than sharing FIELD.CHEMOKINE's slow 0.12 decay. Diagnosed directly: a beacon trail
 * laid early to guide distant reinforcements was still present and dominant late in a round,
 * after the tumor had mostly cleared and the natural chemokine signal near the last few
 * survivors had thinned out — killers that finished a kill picked up the stale beacon trail
 * instead and walked back toward the vessel, away from the handful of cells still needing to
 * be found. Traced directly: a mass, synchronized disengagement (12 of 12 engaged killers
 * down to 1) around the point the tumor thinned, that did not happen without the beacon.
 * 0.9 gives a half-life of ~0.8s (vs chemokine's ~5.8s) — enough to meaningfully pull cells
 * for several seconds right after being dropped, faded to negligible within the same round
 * phase rather than lingering to compete with the tumor's own signal once it is mostly clear.
 */
DECAY[FIELD.BEACON] = 0.9;

/** [GAME] Saturation constants: field value at which an effect reaches half its maximum. */
export const K_HALF = Object.freeze({
  chemotaxis: 0.35,
  suppress: 0.8,
  il2: 0.7,
  ifng: 0.9,
  debris: 0.5,
});

/** [GAME] Multiplier strengths in the killing expression (see DESIGN.md section 5.5). */
export const SUPPRESS_STRENGTH = 2.2;
export const IL2_BOOST = 0.45;

/* =================================================================== *
 * DENDRITIC CELLS AND REINFORCEMENTS
 * =================================================================== */

/**
 * [SCALED] Debris a DC must accumulate to become loaded.
 * Lowered from 1.0 after diagnosing why DCs rarely completed loading: extraction
 * competes continuously against decay and outward diffusion, so the debris
 * concentration reachable at any one spot settles into a steady-state equilibrium
 * rather than accumulating without bound. Traced one DC precisely: its load climbed
 * in shrinking increments and converged to a fixed value just under threshold, then
 * never moved again for 90+ seconds of continued play — waiting longer does not help
 * once that ceiling is reached; only a higher nearby kill rate raises it. At the
 * original 1.0, only 1 of 4 placed DCs matured within a full Cold Tumor round, taking
 * until 150 of 180 available seconds to do so. At 0.15, all 4 reliably reach MATURE
 * and deliver their full reinforcement waves well within the round.
 */
export const DC_ANTIGEN_LOAD_REQUIRED = 0.15;

/**
 * [MODEL] dendritic_cell.py models antigen capture then migration to the lymph node for
 * T cell priming. t_cell.py 'LymphNode_delay_growth': 32400 s (9 h) before primed T cells
 * emerge. Converted: 32400 s = 540 bio-min / 5 = 108 game seconds — far longer than a
 * round. [SCALED] to 14 s so a child who invests in a dendritic cell sees the payoff
 * within the same round; without this the mechanic would be untestable in play.
 */
export const DC_MATURATION_SEC = 14;

/** [GAME] Number of CD8 T cells a matured DC calls in per wave. */
export const DC_WAVE_SIZE = 3;

/** [GAME] Maximum waves a single DC can call. Keeps DCs strong but not infinite. */
export const DC_MAX_WAVES = 3;

/**
 * [GAME] How long, in game-seconds, a DC keeps refreshing its vessel-to-tumor guide chain
 * after calling a wave. A CD8 reinforcement travels at roughly 10 wu/s; the longest
 * vessel-to-tumor distance in any level (Cold Tumor, ~950wu) takes ~95s to cross even in a
 * straight line, longer with any wandering. 120s gives real margin above that floor. See
 * queueWave's own comment in engine.js for why a one-time deposit is not enough on its own.
 */
export const DC_WAVE_GUIDE_DURATION_SEC = 120;

/* =================================================================== *
 * MACROPHAGE POLARIZATION
 * =================================================================== */

/**
 * [SCALED] IFN-gamma drives macrophages toward M1; IL-10/TGF-beta drive them toward M2.
 * Not in the research model, which has no macrophage. Rate chosen so a macrophage sitting
 * in an active kill zone visibly flips to M1 within a few seconds — the polarization has to
 * be observable inside one round or the mechanic teaches nothing.
 */
export const MACRO_POLARIZE_RATE = 0.22;

/** [GAME] Polarization above this reads as M1; below the negative of it, M2. */
export const MACRO_POLARIZE_THRESHOLD = 0.35;

/* =================================================================== *
 * PATIENT METERS — toxicity and cytokine release syndrome
 * =================================================================== */

/**
 * CRS (cytokine release syndrome) is the real, dangerous complication of CAR-T therapy.
 * It is driven by the aggregate inflammatory cytokine output of massively activated immune
 * cells — not by the tumor. Modeled as a 0..1 meter driven by the total IFN-gamma field
 * mass plus the count of simultaneously engaged killers, damped by a recovery term.
 * [GAME] All four constants are game-design values; the research model has no patient-level
 * physiology. The MECHANISM (more simultaneous killing => more cytokine => patient harm)
 * is real; the numbers are tuned for a 2-minute round.
 */
/**
 * The engine integrates CRS as `crs += drive*dt - recovery*crs*dt`, so the meter settles at
 * `crs = drive / recovery`. With drive = engagedKillers * CRS_PER_ENGAGED_KILLER, that means
 * the equilibrium is directly proportional to how many killers are fighting at once.
 *
 * Calibrated so a NORMAL roster is safe and only an excessive one is dangerous:
 *   14 engaged  ->  0.45   comfortably below the 0.6 danger threshold
 *   20 engaged  ->  0.64   just over — the meter starts flashing
 *   30 engaged  ->  0.96   severe cytokine release syndrome
 * With IL-2 support (x1.6) even 14 engaged reaches 0.72, which is exactly the intended
 * lesson that IL-2 buys potency at the cost of toxicity.
 *
 * The previous value of 0.0075 put the equilibrium at engaged/10, so a player fielding
 * seven CAR-T cells killed the patient. Balance testing caught it: Deep Core lost the
 * patient at 65 s every time.
 */
export const CRS_PER_ENGAGED_KILLER = 0.0024;
export const CRS_PER_IFNG_MASS = 0.00016;
export const CRS_IL2_MULTIPLIER = 1.6;
export const CRS_RECOVERY_PER_SEC = 0.075;

/** [GAME] CRS above this damages the patient. Below it, the patient tolerates therapy. */
export const CRS_DANGER_THRESHOLD = 0.6;

/** [GAME] Patient health lost per game second per unit of CRS above the danger threshold. */
export const CRS_HEALTH_DAMAGE = 26;

/**
 * [GAME] Patient health lost per healthy cell destroyed. This is ON-TARGET, OFF-TUMOR
 * TOXICITY — the reason CAR-T targets must be tumor-restricted, and the reason the
 * biopsy panel exists. The mechanism is real and clinically decisive.
 */
export const HEALTH_PER_HEALTHY_CELL = 3.5;

/** [GAME] Lymphodepletion conditioning is real standard-of-care, and it costs the patient. */
export const LYMPHODEPLETION_HEALTH_COST = 10;
export const LYMPHODEPLETION_TREG_KILL_FRACTION = 0.6;

/* =================================================================== *
 * ECONOMY — [GAME] throughout. No biological claim.
 * =================================================================== */

export const COST = Object.freeze({
  [KIND.CART]: 6,
  [KIND.CD8]: 4,
  [KIND.NK]: 5,
  [KIND.MACRO]: 3,
  [KIND.DC]: 7,
  [KIND.CD4]: 4,
  checkpoint: 20,
  il2: 15,
  lymphodepletion: 12,
});

/** [GAME] Rally beacons a player may drop during a round. */
export const BEACON_USES = 3;
export const BEACON_STRENGTH = 3.0;
export const BEACON_RADIUS = 90;

/**
 * [GAME] The automatic DC wave-guide chain (see queueWave/layWaveGuideChain in engine.js)
 * shares FIELD.BEACON with the player's manual beacon but must never be able to drown it
 * out -- a player choosing to spend one of their limited beacon uses is a deliberate
 * decision and should visibly matter. Measured directly: the chain at full BEACON_STRENGTH,
 * refreshed every ~1s for up to two minutes, held a steady-state field value of ~0.08
 * continuously, while a player's own one-time beacon (same strength) decayed to ~0.002
 * within 5s -- a 45x gap. A third of the player's own strength keeps the automatic chain
 * doing its real job (guiding reinforcements across a gap no single pulse reaches) without
 * outcompeting a deliberate player action for the whole time it takes to decay.
 */
export const DC_WAVE_GUIDE_STRENGTH = BEACON_STRENGTH / 3;

/**
 * [GAME] Random perpendicular offset applied to each guide-chain point on every refresh, so
 * repeated refreshes do not deposit at the exact same points every time. Without this,
 * multiple cells drawn to the same fixed line converge into a visible single-file "train"
 * instead of approaching the tumor independently. Scaled below BEACON_RADIUS so consecutive
 * points still overlap enough to form a continuous, followable path.
 */
export const DC_WAVE_GUIDE_JITTER = 50;

/* =================================================================== *
 * SCORING — [GAME] throughout. Weights chosen so that a fast, gentle, cheap
 * cure beats a fast, brutal one. See DESIGN.md section 7.
 * =================================================================== */

export const SCORE = Object.freeze({
  base: 1000,
  speedWeight: 3000,
  healthWeight: 20,
  efficiencyWeight: 10,
  crsPenalty: 15,
  healthyKilledPenalty: 25,
});

/* =================================================================== *
 * EXPORTS
 * =================================================================== */

/** Packets per game second delivered by a killer of the given kind. */
export function killRateFor(kind) {
  return KILL_RATE[kind] || 0;
}

/** Base migration speed in wu per game second. */
export function speedFor(kind) {
  return umPerMinToWuPerGameSec(SPEED_UM_MIN[kind] || 0);
}

/** Physical radius in world units. */
export function radiusFor(kind) {
  return RADIUS[kind] || 8;
}

/** Chemotaxis gain. */
export function chemoGainFor(kind) {
  return CHEMO_GAIN[kind] || 0;
}

export const P = Object.freeze({
  radius: RADIUS,
  speedUmMin: SPEED_UM_MIN,
  killRate: KILL_RATE,
  chemoGain: CHEMO_GAIN,
  diffusion: DIFFUSION,
  decay: DECAY,
  kHalf: K_HALF,
  cost: COST,
  score: SCORE,

  tumor: {
    divideTimeSec: TUMOR_DIVIDE_TIME_SEC,
    deathPackets: TUMOR_DEATH_PACKETS,
    quiescentDivides: QUIESCENT_DIVIDES,
    spontaneousDeathPerSec: TUMOR_SPONTANEOUS_DEATH_PER_SEC,
    divideMinClearance: DIVIDE_MIN_CLEARANCE,
    perfusionMin: TUMOR_PERFUSION_MIN,
  },
  checkpoint: {
    pdl1Critical: PDL1_CRITICAL,
    pd1Strength: PD1_STRENGTH,
    inductionRate: PDL1_INDUCTION_RATE,
    decayRate: PDL1_DECAY_RATE,
    residualPd1: CHECKPOINT_RESIDUAL_PD1,
    ifngSwitch: IFNG_STATE_SWITCH,
  },
  exhaustion: {
    perEngagedSec: EXHAUST_PER_ENGAGED_SEC,
    recoveryRate: EXHAUST_RECOVERY_RATE,
    il2Boost: IL2_RECOVERY_BOOST,
    killFloor: EXHAUSTED_KILL_FLOOR,
  },
  recognition: {
    mhcMin: MHC_RECOGNITION_MIN,
    nkMissingSelfMax: NK_MISSING_SELF_MAX,
    mhcLowPenalty: MHC_LOW_KILL_PENALTY,
    engageMargin: ENGAGE_MARGIN,
    killCooldown: KILL_COOLDOWN,
  },
  motion: {
    persistence: PERSISTENCE,
    turnNoise: TURN_NOISE,
    engagedFrac: ENGAGED_SPEED_FRAC,
    exhaustedFrac: EXHAUSTED_SPEED_FRAC,
  },
  production: {
    ifng: IFNG_PRODUCTION,
    ifngExhausted: IFNG_PRODUCTION_EXHAUSTED,
    chemokine: CHEMOKINE_PRODUCTION,
    chemokineM1: CHEMOKINE_PRODUCTION_M1,
    chemokineTumor: TUMOR_CHEMOKINE_PRODUCTION,
    il2: IL2_PRODUCTION,
    suppressTreg: SUPPRESS_PRODUCTION_TREG,
    suppressM2: SUPPRESS_PRODUCTION_M2,
    debrisPerDeath: DEBRIS_PER_DEATH,
  },
  dc: {
    loadRequired: DC_ANTIGEN_LOAD_REQUIRED,
    maturationSec: DC_MATURATION_SEC,
    waveSize: DC_WAVE_SIZE,
    maxWaves: DC_MAX_WAVES,
    waveGuideDurationSec: DC_WAVE_GUIDE_DURATION_SEC,
    waveGuideStrength: DC_WAVE_GUIDE_STRENGTH,
    waveGuideJitter: DC_WAVE_GUIDE_JITTER,
  },
  macro: {
    polarizeRate: MACRO_POLARIZE_RATE,
    polarizeThreshold: MACRO_POLARIZE_THRESHOLD,
  },
  patient: {
    crsPerEngagedKiller: CRS_PER_ENGAGED_KILLER,
    crsPerIfngMass: CRS_PER_IFNG_MASS,
    crsIl2Multiplier: CRS_IL2_MULTIPLIER,
    crsRecoveryPerSec: CRS_RECOVERY_PER_SEC,
    crsDanger: CRS_DANGER_THRESHOLD,
    crsHealthDamage: CRS_HEALTH_DAMAGE,
    healthPerHealthyCell: HEALTH_PER_HEALTHY_CELL,
    lymphoHealthCost: LYMPHODEPLETION_HEALTH_COST,
    lymphoTregKill: LYMPHODEPLETION_TREG_KILL_FRACTION,
  },
  beacon: {
    uses: BEACON_USES,
    strength: BEACON_STRENGTH,
    radius: BEACON_RADIUS,
  },
  suppressStrength: SUPPRESS_STRENGTH,
  il2Boost: IL2_BOOST,
});
