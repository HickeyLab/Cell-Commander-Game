/**
 * params.test.js — enforces scientific provenance discipline.
 *
 * The project's central promise is that every biological constant is traceable to either the
 * published research model or an explicit, justified game-design decision. That promise is
 * worth nothing if it is only in a document, so it is enforced here mechanically.
 */

import { test, describe } from 'node:test';
import assert from 'node:assert/strict';
import { readFile } from 'node:fs/promises';
import { fileURLToPath } from 'node:url';

import * as P from '../src/sim/params.js';
import { KIND, FIELD } from '../src/core/contracts.js';

const PARAMS_PATH = fileURLToPath(new URL('../src/sim/params.js', import.meta.url));
const source = await readFile(PARAMS_PATH, 'utf8');

const TAGS = ['[MODEL]', '[SCALED]', '[DERIVED]', '[GAME]'];
const SPLIT_RE = new RegExp('\r?\n');
const IMPORT_RE = new RegExp('^import\s');

/**
 * params.js opens with a legend that documents what each tag means. Those occurrences are
 * documentation of the convention, not claims about a value, so provenance checks start
 * below the header — at the first import statement.
 */
const BODY_START = (() => {
  const ls = source.split(SPLIT_RE);
  for (let i = 0; i < ls.length; i++) {
    if (ls[i].trimStart().startsWith('import ')) return i;
  }
  return 0;
})();

/**
 * Strip block and line comments, then find lines that assign a bare number.
 * Returns [{ line, text }] for every numeric assignment in executable code.
 */
function numericAssignments(src) {
  const lines = src.split(/\r?\n/);
  const out = [];
  let inBlockComment = false;

  for (let i = 0; i < lines.length; i++) {
    const raw = lines[i];
    let line = raw;

    if (inBlockComment) {
      const end = line.indexOf('*/');
      if (end === -1) continue;
      line = line.slice(end + 2);
      inBlockComment = false;
    }
    // Remove inline block comments, then detect an unterminated one.
    line = line.replace(/\/\*[\s\S]*?\*\//g, '');
    const open = line.indexOf('/*');
    if (open !== -1) {
      line = line.slice(0, open);
      inBlockComment = true;
    }
    // Strip line comments.
    const lc = line.indexOf('//');
    const code = lc === -1 ? line : line.slice(0, lc);
    if (!code.trim()) continue;

    // An assignment or object property. The VALUE side must contain a real numeric literal,
    // not merely an identifier that happens to contain a digit — `pdl1Critical: PDL1_CRITICAL`
    // re-exports an already-tagged constant and is not itself a value that needs provenance.
    const isAssignment =
      /(?:^|\s)(?:export\s+)?const\s+[A-Za-z_$][\w$]*\s*=/.test(code) ||
      /^\s*[A-Za-z_$\[][\w$.\]'"]*\s*:/.test(code) ||
      /^\s*[A-Z_]+\[[^\]]+\]\s*=/.test(code);

    if (!isAssignment) continue;

    // Take everything after the first ':' or '=', strip identifiers, and see if a digit
    // survives. What remains can only be a numeric literal.
    const sep = code.search(/[:=]/);
    if (sep === -1) continue;
    const valuePart = code.slice(sep + 1);
    const withoutIdentifiers = valuePart.replace(/[A-Za-z_$][\w$]*/g, '');
    if (!/\d/.test(withoutIdentifiers)) continue;

    // Ignore array indices, pure structural numbers, and re-exports of already-tagged names.
    if (/^\s*(import|export)\s+\{/.test(code)) continue;

    out.push({ line: i + 1, text: raw.trim() });
  }
  return out;
}

/**
 * A numeric assignment is considered documented if a provenance tag appears either
 * on the same line or anywhere in the contiguous comment block immediately above it.
 */
function hasProvenance(lines, lineNo) {
  const sameLine = lines[lineNo - 1] || '';
  if (TAGS.some((t) => sameLine.includes(t))) return true;

  // Walk upward looking for a tag that governs this value.
  //
  // A tag counts if it is in the comment block directly above the value, OR in the comment
  // block above the object literal the value sits inside. Group tagging is deliberate: the
  // nine entries of CHEMO_GAIN share one provenance, and repeating the tag on each would be
  // noise that makes the real per-value annotations harder to see.
  //
  // The walk stops at a closing brace, which prevents a tag from leaking across from an
  // unrelated preceding block.
  const isComment = (l) =>
    l.startsWith('//') || l.startsWith('*') || l.startsWith('/*') || l.startsWith('*/');
  // A sibling entry inside the same literal, or the literal's own opening line.
  const isSiblingOrOpener = (l) =>
    /^[A-Za-z_$\[][\w$.\]'"]*\s*:/.test(l) || // property entry
    /^[A-Z_]+\[[^\]]+\]\s*=/.test(l) || // typed-array index assignment
    /=\s*(Object\.freeze\()?\{?\s*$/.test(l) || // `const X = {` / `= Object.freeze({`
    /^(export\s+)?const\s/.test(l);

  for (let i = lineNo - 2; i >= 0; i--) {
    const l = (lines[i] || '').trim();
    if (l === '') continue;
    if (isComment(l)) {
      if (TAGS.some((t) => l.includes(t))) return true;
      continue;
    }
    if (isSiblingOrOpener(l)) continue;
    break; // a closing brace or unrelated statement — stop, do not leak across blocks
  }
  return false;
}

describe('parameter provenance', () => {
  const lines = source.split(/\r?\n/);
  const assignments = numericAssignments(source);

  test('the file actually contains constants to check', () => {
    assert.ok(
      assignments.length > 30,
      `expected many numeric constants, found ${assignments.length} — the scanner is probably broken`
    );
  });

  test('every numeric constant carries a provenance tag', () => {
    const untagged = assignments.filter((a) => !hasProvenance(lines, a.line));
    const report = untagged.map((a) => `  params.js:${a.line}  ${a.text}`).join('\n');
    assert.equal(
      untagged.length,
      0,
      `${untagged.length} numeric constant(s) lack a [MODEL]/[SCALED]/[DERIVED]/[GAME] tag:\n${report}`
    );
  });

  test('every [MODEL] tag names its source file or a citation', () => {
    // A [MODEL] claim asserts the value came from the research ABM. It must say from where,
    // otherwise the claim is unverifiable and therefore worthless.
    const modelBlocks = source
      .split(/\r?\n/)
      .map((l, i) => ({ l, i }))
      .filter(({ l, i }) => l.includes('[MODEL]') && i > BODY_START);

    assert.ok(modelBlocks.length > 5, 'expected several [MODEL]-tagged values');

    for (const { l, i } of modelBlocks) {
      // Look at the tagged line plus the next 4 lines for a source reference.
      const window = lines.slice(i, i + 5).join(' ');
      const namesSource =
        /\.py\b/.test(window) || // e.g. "t_cell.py"
        /\b(19|20)\d{2}\b/.test(window); // e.g. "(Betts 2004)"
      assert.ok(
        namesSource,
        `[MODEL] tag at params.js:${i + 1} names neither a source file nor a citation year:\n  ${l.trim()}`
      );
    }
  });

  test('every [SCALED] tag explains the deviation', () => {
    const idx = [];
    lines.forEach((l, i) => {
      if (l.includes('[SCALED]') && i > BODY_START) idx.push(i);
    });
    assert.ok(idx.length > 5, 'expected several [SCALED] values');

    for (const i of idx) {
      const raw = lines.slice(Math.max(0, i - 1), i + 8).join(' ');
      const window = raw.toLowerCase();

      // A [SCALED] value is accountable in either of two ways, and both are acceptable:
      //   (a) it cites its own independent source — a literature year or a research-model
      //       file — which is strictly BETTER provenance than prose; or
      //   (b) it gives prose reasoning for why it departs from the research model.
      const citesSource = /\((19|20)\d{2}\)|\b(19|20)\d{2}\)|\.py\b/.test(raw);
      const givesReasoning =
        window.includes('because') ||
        window.includes('rationale') ||
        window.includes('would ') ||
        window.includes('reason') ||
        window.includes('note') ||
        window.includes('rather than') ||
        window.includes('chosen') ||
        window.includes('not in the research model') ||
        window.includes('hierarchy') ||
        window.includes('set ') ||
        window.includes('so ');

      assert.ok(
        citesSource || givesReasoning,
        `[SCALED] tag at params.js:${i + 1} neither cites a source nor explains the deviation:\n  ${lines[i].trim()}`
      );
    }
  });
});

describe('parameter values are sane', () => {
  test('time compression is documented and positive', () => {
    assert.ok(P.BIO_MIN_PER_GAME_SEC > 0);
    assert.equal(P.BIO_SEC_PER_GAME_SEC, P.BIO_MIN_PER_GAME_SEC * 60);
  });

  test('a single CD8 kills a tumor cell in a watchable number of seconds', () => {
    // This is the load-bearing calibration: it links the research model's packet arithmetic
    // to something a child can actually sit through.
    const rate = P.killRateFor(KIND.CD8);
    const seconds = P.TUMOR_DEATH_PACKETS / rate;
    assert.ok(
      seconds > 3 && seconds < 12,
      `one CD8 should kill in 3-12 game seconds, got ${seconds.toFixed(2)}`
    );
  });

  test('CAR-T kills faster than an unmodified CD8, NK slower, macrophage slowest', () => {
    assert.ok(P.killRateFor(KIND.CART) > P.killRateFor(KIND.CD8));
    assert.ok(P.killRateFor(KIND.NK) < P.killRateFor(KIND.CD8));
    assert.ok(P.killRateFor(KIND.MACRO) < P.killRateFor(KIND.NK));
  });

  test('the PD-1 brake reproduces the research model\'s 10-fold effect', () => {
    // t_cell.py: PD1p max 1000 packets vs PD1n max 10000 => 10x reduction.
    const brake = 1 / (1 + 1 * 1 * P.PD1_STRENGTH);
    assert.ok(
      Math.abs(brake - 0.1) < 1e-9,
      `full PD-1 engagement should cut killing 10-fold, got ${(1 / brake).toFixed(2)}x`
    );
  });

  test('NK and CD8 recognition are exactly complementary', () => {
    // Every tumor cell must be killable by SOME lineage, or a level could be unwinnable.
    assert.equal(
      P.MHC_RECOGNITION_MIN,
      P.NK_MISSING_SELF_MAX,
      'a gap or overlap here would leave tumor cells that nothing can kill'
    );
  });

  test('exhausted cells still kill a little, never zero', () => {
    assert.ok(P.EXHAUSTED_KILL_FLOOR > 0 && P.EXHAUSTED_KILL_FLOOR < 1);
  });

  test('relative migration speeds match the literature hierarchy', () => {
    // CD8 > NK > CD4 > macrophage = DC
    assert.ok(P.speedFor(KIND.CD8) > P.speedFor(KIND.NK));
    assert.ok(P.speedFor(KIND.NK) > P.speedFor(KIND.CD4));
    assert.ok(P.speedFor(KIND.CD4) > P.speedFor(KIND.MACRO));
    assert.equal(P.speedFor(KIND.MACRO), P.speedFor(KIND.DC));
    assert.equal(P.speedFor(KIND.TUMOR), 0, 'tumor cells do not migrate in the research model');
  });

  test('a tumor cell is physically larger than a T cell', () => {
    // tumor.py 15 µm diameter vs t_cell.py 7.5 µm — exactly 2x.
    assert.equal(P.radiusFor(KIND.TUMOR) / P.radiusFor(KIND.CD8), 2);
  });

  test('all diffusion and decay values are finite and positive', () => {
    for (let f = 0; f < P.P.diffusion.length; f++) {
      assert.ok(Number.isFinite(P.P.diffusion[f]) && P.P.diffusion[f] > 0, `diffusion[${f}]`);
      assert.ok(Number.isFinite(P.P.decay[f]) && P.P.decay[f] > 0, `decay[${f}]`);
    }
  });

  test('IFN-gamma diffuses faster than the suppressive field and debris', () => {
    // Molecular weight ordering: IFN-g 17 kDa < TGF-b 25 kDa < cellular debris.
    assert.ok(P.P.diffusion[FIELD.IFNG] > P.P.diffusion[FIELD.SUPPRESS]);
    assert.ok(P.P.diffusion[FIELD.SUPPRESS] > P.P.diffusion[FIELD.DEBRIS]);
  });

  test('exhausted T cells produce 10x less IFN-gamma, per Zelinskyy 2005', () => {
    assert.ok(Math.abs(P.IFNG_PRODUCTION / P.IFNG_PRODUCTION_EXHAUSTED - 10) < 1e-9);
  });

  test('every purchasable item has a positive integer cost', () => {
    for (const [k, v] of Object.entries(P.COST)) {
      assert.ok(Number.isInteger(v) && v > 0, `cost of ${k} is ${v}`);
    }
  });
});
