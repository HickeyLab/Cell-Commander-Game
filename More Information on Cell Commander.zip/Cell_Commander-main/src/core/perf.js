/**
 * perf.js owns allocation-free rolling frame-time statistics and the asymmetric
 * hysteresis controller that selects one of the shared adaptive quality tiers.
 */

import { QUALITY, QUALITY_ORDER } from '../core/contracts.js';

const DEFAULT_SAMPLE_SIZE = 30;
const DROP_AFTER = 90;
const RAISE_AFTER = 300;
const DROP_THRESHOLD_MS = 20;
const RAISE_THRESHOLD_MS = 11;

function qualityAt(index) {
  const id = QUALITY_ORDER[index];
  if (id === 'low') return QUALITY.LOW;
  if (id === 'medium') return QUALITY.MEDIUM;
  return QUALITY.HIGH;
}

/**
 * Create a fixed-size rolling frame-time monitor.
 * @param {{sampleSize?:number}} [opts] Rolling window options.
 * @returns {object} Performance monitor API.
 */
export function makePerfMonitor(opts = {}) {
  const sampleSize = opts.sampleSize ?? DEFAULT_SAMPLE_SIZE;
  if (!Number.isInteger(sampleSize) || sampleSize <= 0) {
    throw new RangeError('sampleSize must be a positive integer');
  }

  const samples = new Float64Array(sampleSize);
  const sortedScratch = new Float64Array(sampleSize);
  let count = 0;
  let cursor = 0;

  function sortScratch() {
    for (let i = 0; i < count; i += 1) {
      sortedScratch[i] = samples[i];
    }
    for (let i = 1; i < count; i += 1) {
      const value = sortedScratch[i];
      let insertion = i - 1;
      while (insertion >= 0 && sortedScratch[insertion] > value) {
        sortedScratch[insertion + 1] = sortedScratch[insertion];
        insertion -= 1;
      }
      sortedScratch[insertion + 1] = value;
    }
  }

  function median() {
    if (count === 0) {
      return 0;
    }
    sortScratch();
    const middle = count >>> 1;
    if ((count & 1) === 1) {
      return sortedScratch[middle];
    }
    return (sortedScratch[middle - 1] + sortedScratch[middle]) * 0.5;
  }

  return {
    frame(ms) {
      samples[cursor] = ms;
      cursor += 1;
      if (cursor === sampleSize) {
        cursor = 0;
      }
      if (count < sampleSize) {
        count += 1;
      }
    },

    median,

    p95() {
      if (count === 0) {
        return 0;
      }
      sortScratch();
      return sortedScratch[Math.ceil(count * 0.95) - 1];
    },

    fps() {
      const frameMs = median();
      return frameMs > 0 ? 1000 / frameMs : 0;
    },

    reset() {
      samples.fill(0);
      count = 0;
      cursor = 0;
    },
  };
}

/**
 * Create the automatic quality-tier hysteresis controller.
 * @param {string} startTier Initial QUALITY tier id.
 * @returns {object} Quality controller API.
 */
export function makeQualityController(startTier) {
  let tierIndex = QUALITY_ORDER.indexOf(startTier);
  if (tierIndex < 0) {
    throw new RangeError(`unknown quality tier: ${startTier}`);
  }

  let slowStreak = 0;
  let fastStreak = 0;
  const controller = {
    tier: qualityAt(tierIndex),

    update(medianFrameMs) {
      if (medianFrameMs > DROP_THRESHOLD_MS) {
        slowStreak += 1;
        fastStreak = 0;
        if (slowStreak >= DROP_AFTER) {
          slowStreak = 0;
          if (tierIndex > 0) {
            tierIndex -= 1;
            controller.tier = qualityAt(tierIndex);
            return true;
          }
        }
        return false;
      }

      if (medianFrameMs < RAISE_THRESHOLD_MS) {
        fastStreak += 1;
        slowStreak = 0;
        if (fastStreak >= RAISE_AFTER) {
          fastStreak = 0;
          if (tierIndex < QUALITY_ORDER.length - 1) {
            tierIndex += 1;
            controller.tier = qualityAt(tierIndex);
            return true;
          }
        }
        return false;
      }

      slowStreak = 0;
      fastStreak = 0;
      return false;
    },

    forceTier(id) {
      const nextIndex = QUALITY_ORDER.indexOf(id);
      if (nextIndex < 0) {
        throw new RangeError(`unknown quality tier: ${id}`);
      }
      tierIndex = nextIndex;
      controller.tier = qualityAt(tierIndex);
      slowStreak = 0;
      fastStreak = 0;
    },
  };

  return controller;
}
