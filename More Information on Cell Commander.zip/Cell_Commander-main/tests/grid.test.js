/**
 * grid.test.js verifies the field grid's conservation, symmetry, stability,
 * interpolation derivatives, radius deposits, bounds, clearing, and resizing.
 */

import test from 'node:test';
import assert from 'node:assert/strict';

import { QUALITY, WORLD_H, WORLD_W } from '../src/core/contracts.js';
import { makeFieldGrid } from '../src/core/grid.js';

function substanceMass(grid, field) {
  return grid.total(field) * grid.cellW * grid.cellH;
}

test('zero-flux diffusion conserves mass across 500 steps with no decay', () => {
  const grid = makeFieldGrid({
    w: 20,
    h: 16,
    worldW: 200,
    worldH: 160,
    fieldCount: 1,
  });
  grid.deposit(0, 0, 0, 100);
  grid.deposit(0, 199.9, 159.9, 35);
  const initial = grid.total(0);

  for (let i = 0; i < 500; i += 1) {
    grid.step(0.1, { diffusion: [30], decay: [0] });
  }

  const relativeError = Math.abs(grid.total(0) - initial) / initial;
  assert.ok(relativeError < 1e-3, `relative mass error was ${relativeError}`);
});

test('a point deposit diffuses symmetrically to cardinal neighbors', () => {
  const grid = makeFieldGrid({
    w: 9,
    h: 9,
    worldW: 90,
    worldH: 90,
    fieldCount: 1,
  });
  grid.deposit(0, 45, 45, 100);
  // Capture the concentration BEFORE diffusing: the invariant is that the centre loses mass
  // to its neighbours, which is independent of how deposits are normalized.
  const centerBefore = grid.data[grid.idx(0, 4, 4)];
  grid.step(0.1, { diffusion: [20], decay: [0] });

  const center = grid.data[grid.idx(0, 4, 4)];
  const left = grid.data[grid.idx(0, 3, 4)];
  const right = grid.data[grid.idx(0, 5, 4)];
  const up = grid.data[grid.idx(0, 4, 3)];
  const down = grid.data[grid.idx(0, 4, 5)];

  assert.ok(center > 0 && center < centerBefore);
  assert.ok(left > 0);
  assert.equal(left, right);
  assert.equal(left, up);
  assert.equal(left, down);
});

test('large diffusion timesteps remain finite, non-negative, and bounded', () => {
  const grid = makeFieldGrid({
    w: 15,
    h: 15,
    worldW: 150,
    worldH: 150,
    fieldCount: 1,
  });
  grid.deposit(0, 75, 75, 100);
  grid.step(100, { diffusion: [100], decay: [0.05] });

  for (let i = 0; i < grid.data.length; i += 1) {
    assert.equal(Number.isFinite(grid.data[i]), true);
    assert.ok(grid.data[i] >= 0, `cell ${i} was ${grid.data[i]}`);
    assert.ok(grid.data[i] <= 100, `cell ${i} exceeded the initial peak`);
  }
  assert.ok(grid.total(0) <= 100);
});

test('gradient points up an analytic linear concentration ramp', () => {
  const grid = makeFieldGrid({
    w: 12,
    h: 10,
    worldW: 120,
    worldH: 100,
    fieldCount: 1,
  });

  for (let cy = 0; cy < grid.h; cy += 1) {
    const worldY = (cy + 0.5) * grid.cellH;
    for (let cx = 0; cx < grid.w; cx += 1) {
      const worldX = (cx + 0.5) * grid.cellW;
      grid.data[grid.idx(0, cx, cy)] = 3 * worldX - 2 * worldY + 500;
    }
  }

  const out = { x: 0, y: 0 };
  grid.gradient(0, 55, 45, out);

  assert.ok(Math.abs(out.x - 3) < 1e-5, `x gradient was ${out.x}`);
  assert.ok(Math.abs(out.y + 2) < 1e-5, `y gradient was ${out.y}`);
});

test('gradient of a constant field is zero at every wall and corner', () => {
  const grid = makeFieldGrid({
    w: 4,
    h: 4,
    worldW: 40,
    worldH: 40,
    fieldCount: 1,
  });
  grid.data.fill(7);
  const probes = [
    [0, 0],
    [20, 0],
    [39.999, 0],
    [0, 20],
    [39.999, 20],
    [0, 39.999],
    [20, 39.999],
    [39.999, 39.999],
  ];
  const out = { x: 0, y: 0 };

  for (const [x, y] of probes) {
    grid.gradient(0, x, y, out);
    assert.equal(out.x, 0, `x gradient at (${x}, ${y})`);
    assert.equal(out.y, 0, `y gradient at (${x}, ${y})`);
  }
});

test('step applies exact exponential decay and preserves data identity', () => {
  const grid = makeFieldGrid({
    w: 1,
    h: 1,
    worldW: 10,
    worldH: 10,
    fieldCount: 1,
  });
  grid.deposit(0, 5, 5, 8);
  const originalData = grid.data;
  grid.step(2, { diffusion: [0], decay: [0.5] });

  assert.equal(grid.data, originalData);
  assert.ok(Math.abs(substanceMass(grid, 0) - 8 * Math.exp(-1)) < 1e-6);
});

test('rectangular-grid substeps keep fields isolated and independently stable', () => {
  const grid = makeFieldGrid({
    w: 4,
    h: 3,
    worldW: 80,
    worldH: 30,
    fieldCount: 2,
  });
  grid.deposit(0, 10, 5, 50);
  for (let cy = 0; cy < grid.h; cy += 1) {
    for (let cx = 0; cx < grid.w; cx += 1) {
      grid.data[grid.idx(1, cx, cy)] = 2;
    }
  }
  const fieldZeroBefore = grid.total(0);
  const fieldOneBefore = grid.total(1);

  grid.step(10, { diffusion: [100, 1], decay: [0, 0.3] });

  assert.ok(Math.abs(grid.total(0) - fieldZeroBefore) / fieldZeroBefore < 1e-6);
  assert.ok(Math.abs(grid.total(1) - fieldOneBefore * Math.exp(-3)) < 1e-5);
  for (let i = 0; i < grid.data.length; i += 1) {
    assert.equal(Number.isFinite(grid.data[i]), true);
    assert.ok(grid.data[i] >= 0);
  }
});

test('depositRadius conserves the requested mass even at a boundary', () => {
  const grid = makeFieldGrid({
    w: 20,
    h: 20,
    worldW: 200,
    worldH: 200,
    fieldCount: 1,
  });
  grid.depositRadius(0, 5, 5, 37, 40);

  // Grid values are concentrations, so area-weighted total substance must conserve the deposit.
  assert.ok(Math.abs(substanceMass(grid, 0) - 37) < 1e-5);
  assert.ok(grid.max(0) > 0);
});

test('concentration reader units do not change stored substance mass', () => {
  const grid = makeFieldGrid({
    w: 1,
    h: 1,
    worldW: 10,
    worldH: 10,
    fieldCount: 1,
    concentrationUnitArea: 25,
  });
  grid.deposit(0, 5, 5, 8);

  assert.ok(Math.abs(substanceMass(grid, 0) - 8) < 1e-6);
  assert.ok(Math.abs(grid.sample(0, 5, 5) - 2) < 1e-6);
});

test('matching deposits produce closely matching concentrations across quality grids', () => {
  const makeQualityGrid = (quality) => makeFieldGrid({
    w: quality.gridW,
    h: quality.gridH,
    worldW: WORLD_W,
    worldH: WORLD_H,
    fieldCount: 1,
  });
  const high = makeQualityGrid(QUALITY.HIGH);
  const low = makeQualityGrid(QUALITY.LOW);
  const grids = [high, low];

  for (const grid of grids) {
    grid.deposit(0, 457, 311, 23);
    grid.depositRadius(0, 640, 420, 61, 90);
    grid.depositRadius(0, 920, 240, 37, 70);
  }

  for (const grid of grids) {
    assert.ok(Math.abs(substanceMass(grid, 0) - 121) < 1e-3);
  }

  const radiusProbes = [
    [640, 420],
    [700, 400],
    [920, 240],
  ];
  for (const [x, y] of radiusProbes) {
    const highValue = high.sample(0, x, y);
    const lowValue = low.sample(0, x, y);
    const relativeDifference = Math.abs(highValue - lowValue)
      / Math.max(highValue, lowValue, Number.EPSILON);
    assert.ok(
      relativeDifference < 0.05,
      `sample at (${x}, ${y}) differed by ${(relativeDifference * 100).toFixed(2)}%: `
        + `high=${highValue}, low=${lowValue}`,
    );
  }

  // A mathematical point has no finite, resolution-independent peak; diffusion gives that
  // conserved quantity physical width before comparing its interpolated concentration.
  for (const grid of grids) {
    for (let step = 0; step < 200; step += 1) {
      grid.step(0.1, { diffusion: [120], decay: [0] });
    }
  }
  for (const [x, y] of [[457, 311], [500, 340]]) {
    const highValue = high.sample(0, x, y);
    const lowValue = low.sample(0, x, y);
    const relativeDifference = Math.abs(highValue - lowValue)
      / Math.max(highValue, lowValue, Number.EPSILON);
    assert.ok(
      relativeDifference < 0.12,
      `diffused point sample at (${x}, ${y}) differed by `
        + `${(relativeDifference * 100).toFixed(2)}%: high=${highValue}, low=${lowValue}`,
    );
  }
});

test('sample returns zero outside the world bounds', () => {
  const grid = makeFieldGrid({
    w: 4,
    h: 4,
    worldW: 40,
    worldH: 40,
    fieldCount: 1,
  });
  grid.deposit(0, 20, 20, 10);

  assert.equal(grid.sample(0, -0.001, 20), 0);
  assert.equal(grid.sample(0, 20, -0.001), 0);
  assert.equal(grid.sample(0, 40, 20), 0);
  assert.equal(grid.sample(0, 20, 40), 0);
});

test('clear can target one field and resize replaces storage with cleared dimensions', () => {
  const grid = makeFieldGrid({
    w: 4,
    h: 3,
    worldW: 40,
    worldH: 30,
    fieldCount: 2,
  });
  grid.deposit(0, 5, 5, 2);
  grid.deposit(1, 5, 5, 3);

  grid.clear(0);
  assert.equal(grid.total(0), 0);
  assert.ok(Math.abs(substanceMass(grid, 1) - 3) < 1e-6);

  grid.resize(8, 6);
  assert.equal(grid.w, 8);
  assert.equal(grid.h, 6);
  assert.equal(grid.cellW, 5);
  assert.equal(grid.cellH, 5);
  assert.equal(grid.data.length, 2 * 8 * 6);
  assert.equal(grid.total(1), 0);

  grid.clear();
  assert.equal(grid.total(0), 0);
  assert.equal(grid.total(1), 0);
});
