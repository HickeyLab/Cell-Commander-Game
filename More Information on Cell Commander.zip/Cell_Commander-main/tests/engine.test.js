/**
 * engine.test.js verifies treatment-plan operations, recognition biology,
 * calibrated contact killing, resistance, clonal escape, toxicity, and stability.
 */

import test from 'node:test';
import assert from 'node:assert/strict';

import {
  ANTIGEN,
  FIELD,
  KIND,
  OUTCOME,
  QUALITY,
  STATE,
  TICK_DT,
} from '../src/core/contracts.js';
import {
  addPlacement,
  clearPlacements,
  makePlan,
  planCost,
  removePlacementAt,
  validatePlan,
} from '../src/sim/plan.js';
import { createRound } from '../src/sim/engine.js';
import { TUMOR_DEATH_PACKETS } from '../src/sim/params.js';

function makeLevel(overrides = {}) {
  const tumorOverrides = overrides.tumor || {};
  const healthyOverrides = overrides.healthy || {};
  return {
    id: overrides.id || 'engine-test',
    number: 99,
    name: 'Engine Test',
    subtitle: 'Test',
    teaches: 'Test',
    budget: overrides.budget ?? 1000,
    timeLimitSec: overrides.timeLimitSec ?? 0,
    tumorEscapeCap: overrides.tumorEscapeCap ?? 1000000,
    tumor: {
      count: tumorOverrides.count ?? 1,
      cx: tumorOverrides.cx ?? 600,
      cy: tumorOverrides.cy ?? 400,
      spreadWu: tumorOverrides.spreadWu ?? 1,
      antigenMix: tumorOverrides.antigenMix || { [ANTIGEN.GREEN]: 1 },
      mhcMean: tumorOverrides.mhcMean ?? 1,
      mhcSd: tumorOverrides.mhcSd ?? 0,
      pdl1Base: tumorOverrides.pdl1Base ?? 0,
      pdl1Inducible: tumorOverrides.pdl1Inducible ?? 1,
      divideTimeScale: tumorOverrides.divideTimeScale ?? 1000,
    },
    healthy: {
      count: healthyOverrides.count ?? 0,
      antigen: healthyOverrides.antigen ?? ANTIGEN.NONE,
    },
    vessels: overrides.vessels || [{ x: 50, y: 50 }],
    tregs: overrides.tregs ?? 0,
    startingSuppress: overrides.startingSuppress ?? 0,
    startingChemokine: overrides.startingChemokine ?? 0,
    unlocks: overrides.unlocks || [
      KIND.CART,
      KIND.CD8,
      KIND.NK,
      KIND.MACRO,
      KIND.DC,
      KIND.CD4,
      'checkpoint',
      'il2',
      'lymphodepletion',
    ],
    scienceCardId: 'test',
    hint: 'Test',
  };
}

function firstOfKind(world, kind) {
  for (let i = 0; i < world.capacity; i += 1) {
    if (world.alive[i] !== 0 && world.kind[i] === kind) {
      return i;
    }
  }
  return -1;
}

function contactRound({
  killerKind,
  targetAntigen = ANTIGEN.GREEN,
  mhc = 1,
  pdl1 = 0,
  carTarget = ANTIGEN.GREEN,
  checkpoint = false,
  targetKind = KIND.TUMOR,
}) {
  const level = makeLevel({
    healthy: {
      count: targetKind === KIND.HEALTHY ? 1 : 0,
      antigen: targetAntigen,
    },
  });
  const plan = makePlan({
    budget: level.budget,
    carTarget,
    checkpoint,
    placements: [{ kind: killerKind, x: 600, y: 400 }],
  });
  const round = createRound({
    level,
    plan,
    seed: 12345,
    quality: QUALITY.LOW,
  });
  const killer = firstOfKind(round.world, killerKind);
  const target = firstOfKind(round.world, targetKind);
  const tumor = firstOfKind(round.world, KIND.TUMOR);

  round.world.x[target] = 600;
  round.world.y[target] = 400;
  round.world.a0[target] = targetAntigen;
  round.world.a1[target] = mhc;
  round.world.a2[target] = pdl1;
  round.world.a3[target] = 0;
  round.world.timer[target] = 100000;
  round.world.x[killer] = 600 + round.world.radius[target]
    + round.world.radius[killer] + 1;
  round.world.y[killer] = 400;
  round.world.vx[killer] = 0;
  round.world.vy[killer] = 0;
  if (targetKind === KIND.HEALTHY) {
    round.world.x[tumor] = 1100;
    round.world.y[tumor] = 700;
  }
  round.hash.rebuild(round.world);
  return { level, plan, round, killer, target };
}

function tickFor(round, seconds) {
  const ticks = Math.ceil(seconds / TICK_DT);
  for (let i = 0; i < ticks; i += 1) {
    round.tick(TICK_DT);
  }
}

function timeUntilDead(round, target, maxSeconds) {
  const maxTicks = Math.ceil(maxSeconds / TICK_DT);
  for (let i = 0; i < maxTicks; i += 1) {
    round.tick(TICK_DT);
    if (round.world.alive[target] === 0) {
      return (i + 1) * TICK_DT;
    }
  }
  return Infinity;
}

test('treatment plans enforce costs, legal placements, and validation', () => {
  const level = makeLevel({ budget: 13, unlocks: [KIND.CD8, KIND.NK] });
  const plan = makePlan({ budget: 13, carTarget: ANTIGEN.BLUE });

  assert.equal(addPlacement(plan, KIND.CD8, 100, 100), true);
  assert.equal(addPlacement(plan, KIND.NK, 200, 200), true);
  assert.equal(addPlacement(plan, KIND.NK, 300, 300), false);
  assert.equal(addPlacement(plan, KIND.CART, -1, 10), false);
  assert.equal(planCost(plan), 9);
  assert.deepEqual(validatePlan(plan, level), { ok: true, errors: [] });
  assert.equal(removePlacementAt(plan, 201, 201, 5), true);
  assert.equal(planCost(plan), 4);
  clearPlacements(plan);
  assert.equal(plan.placements.length, 0);
  assert.equal(plan.spent, 0);
});

test('plan validation rejects a cell placed inside the tumor mass', () => {
  const level = makeLevel({ budget: 20, unlocks: [KIND.CD8] });
  const plan = makePlan({
    budget: 20,
    placements: [{ kind: KIND.CD8, x: level.tumor.cx, y: level.tumor.cy }],
  });
  const result = validatePlan(plan, level);

  assert.equal(result.ok, false);
  assert.ok(result.errors.some((error) => error.includes('inside the tumor')));
});

test('a single CD8 kills an antigen-positive high-MHC tumor in 6.4 +/- 0.6 seconds', () => {
  const { round, target } = contactRound({ killerKind: KIND.CD8 });
  const elapsed = timeUntilDead(round, target, 10);

  assert.ok(elapsed >= 5.8 && elapsed <= 7.0, `CD8 kill took ${elapsed} seconds`);
});

test('a CAR-T does not kill a tumor whose antigen differs from the plan target', () => {
  const { round, target } = contactRound({
    killerKind: KIND.CART,
    targetAntigen: ANTIGEN.BLUE,
    carTarget: ANTIGEN.GREEN,
  });
  tickFor(round, 30);

  assert.equal(round.world.alive[target], 1);
  assert.equal(round.world.a3[target], 0);
});

test('a CAR-T kills a matching low-MHC tumor without MHC recognition', () => {
  const { round, target } = contactRound({
    killerKind: KIND.CART,
    targetAntigen: ANTIGEN.GREEN,
    mhc: 0,
  });

  assert.ok(Number.isFinite(timeUntilDead(round, target, 8)));
});

test('an NK cell kills a low-MHC tumor and does not kill a high-MHC tumor', () => {
  const low = contactRound({ killerKind: KIND.NK, mhc: 0.05 });
  const high = contactRound({ killerKind: KIND.NK, mhc: 0.9 });

  assert.ok(Number.isFinite(timeUntilDead(low.round, low.target, 12)));
  tickFor(high.round, 30);
  assert.equal(high.round.world.alive[high.target], 1);
  assert.equal(high.round.world.a3[high.target], 0);
});

test('full tumor PD-L1 slows initial CD8 killing about tenfold and checkpoint blockade restores it', () => {
  const baseline = contactRound({ killerKind: KIND.CD8, pdl1: 0 });
  const shielded = contactRound({ killerKind: KIND.CD8, pdl1: 1 });
  const blocked = contactRound({ killerKind: KIND.CD8, pdl1: 1, checkpoint: true });

  tickFor(baseline.round, 1);
  tickFor(shielded.round, 1);
  tickFor(blocked.round, 1);
  const baselinePackets = baseline.round.world.a3[baseline.target];
  const shieldedPackets = shielded.round.world.a3[shielded.target];
  const blockedPackets = blocked.round.world.a3[blocked.target];

  assert.ok(
    baselinePackets / shieldedPackets >= 8
      && baselinePackets / shieldedPackets <= 12,
    `PD-L1 slowdown was ${baselinePackets / shieldedPackets}x`,
  );
  assert.ok(blockedPackets > shieldedPackets * 4);
  assert.ok(blockedPackets > baselinePackets * 0.45);
});

test('a tumor exposed to sustained high IFN-gamma raises PD-L1', () => {
  const { round, target } = contactRound({
    killerKind: KIND.CART,
    targetAntigen: ANTIGEN.BLUE,
    carTarget: ANTIGEN.GREEN,
    pdl1: 0.1,
  });
  const plane = round.grid.w * round.grid.h;
  const startingPdl1 = round.world.a2[target];

  for (let tick = 0; tick < 120; tick += 1) {
    round.grid.data.fill(4, FIELD.IFNG * plane, (FIELD.IFNG + 1) * plane);
    round.tick(TICK_DT);
  }

  assert.ok(round.world.a2[target] > startingPdl1 + 0.05);
  assert.equal(round.world.state[target], STATE.QUIESCENT);
});

test('antigen-negative tumor daughters inherit antigen-negative status', () => {
  const level = makeLevel({
    tumor: {
      count: 1,
      antigenMix: { [ANTIGEN.NONE]: 1 },
      divideTimeScale: 1,
    },
    vessels: [{ x: 100, y: 100 }],
  });
  const round = createRound({
    level,
    plan: makePlan({ budget: level.budget }),
    seed: 222,
    quality: QUALITY.LOW,
  });
  const parent = firstOfKind(round.world, KIND.TUMOR);
  round.world.x[parent] = 180;
  round.world.y[parent] = 100;
  round.world.a0[parent] = ANTIGEN.NONE;
  round.world.state[parent] = STATE.PROLIFERATIVE;
  round.world.timer[parent] = 0;
  round.tick(TICK_DT);

  assert.equal(round.world.countOf(KIND.TUMOR), 2);
  for (let i = 0; i < round.world.capacity; i += 1) {
    if (round.world.alive[i] !== 0 && round.world.kind[i] === KIND.TUMOR) {
      assert.equal(round.world.a0[i], ANTIGEN.NONE);
    }
  }
});

test('a CAR-T matching a healthy-cell antigen causes toxicity and lowers patient health', () => {
  const { round, target } = contactRound({
    killerKind: KIND.CART,
    targetKind: KIND.HEALTHY,
    targetAntigen: ANTIGEN.ORANGE,
    carTarget: ANTIGEN.ORANGE,
  });
  const startingHealth = round.patientHealth;

  assert.ok(Number.isFinite(timeUntilDead(round, target, 8)));
  assert.equal(round.stats.healthyKilled, 1);
  assert.ok(round.patientHealth < startingHealth);
});

test('native CD8 spares shared-antigen healthy cells while CAR-T causes toxicity', () => {
  const native = contactRound({
    killerKind: KIND.CD8,
    targetKind: KIND.HEALTHY,
    targetAntigen: ANTIGEN.ORANGE,
    carTarget: ANTIGEN.ORANGE,
  });
  const engineered = contactRound({
    killerKind: KIND.CART,
    targetKind: KIND.HEALTHY,
    targetAntigen: ANTIGEN.ORANGE,
    carTarget: ANTIGEN.ORANGE,
  });
  native.level.timeLimitSec = 12;
  engineered.level.timeLimitSec = 12;
  const nativeStartingHealth = native.round.patientHealth;
  const engineeredStartingHealth = engineered.round.patientHealth;

  tickFor(native.round, native.level.timeLimitSec + TICK_DT);
  tickFor(engineered.round, engineered.level.timeLimitSec + TICK_DT);

  assert.equal(native.round.outcome, OUTCOME.LOSS_TIMEOUT);
  assert.equal(native.round.stats.healthyKilled, 0);
  assert.equal(native.round.patientHealth, nativeStartingHealth);
  assert.equal(engineered.round.outcome, OUTCOME.LOSS_TIMEOUT);
  assert.equal(engineered.round.stats.healthyKilled, 1);
  assert.ok(engineered.round.patientHealth < engineeredStartingHealth);
});

test('2000 ticks with 600 agents produce no NaN positions, fields, or meters', () => {
  const placements = [];
  const placeable = [KIND.DC, KIND.CD4];
  for (let i = 0; i < 146; i += 1) {
    placements.push({
      kind: placeable[i % placeable.length],
      x: 80 + (i % 20) * 52,
      y: 80 + Math.floor(i / 20) * 82,
    });
  }
  const level = makeLevel({
    budget: 10000,
    tumor: {
      count: 200,
      cx: 600,
      cy: 400,
      spreadWu: 220,
      antigenMix: { [ANTIGEN.GREEN]: 0.7, [ANTIGEN.NONE]: 0.3 },
      mhcMean: 0.5,
      mhcSd: 0.2,
      divideTimeScale: 10,
    },
    healthy: { count: 200, antigen: ANTIGEN.NONE },
    vessels: [
      { x: 50, y: 50 },
      { x: 1150, y: 50 },
      { x: 50, y: 750 },
      { x: 1150, y: 750 },
    ],
    tregs: 50,
  });
  const round = createRound({
    level,
    plan: makePlan({
      budget: level.budget,
      carTarget: ANTIGEN.GREEN,
      placements,
    }),
    seed: 987654,
    quality: { ...QUALITY.LOW, maxAgents: 900 },
  });

  assert.equal(round.world.count, 600);
  for (let tick = 0; tick < 2000; tick += 1) {
    round.tick(TICK_DT);
  }

  for (let i = 0; i < round.world.capacity; i += 1) {
    assert.equal(Number.isNaN(round.world.x[i]), false, `x[${i}]`);
    assert.equal(Number.isNaN(round.world.y[i]), false, `y[${i}]`);
  }
  for (let i = 0; i < round.grid.data.length; i += 1) {
    assert.equal(Number.isNaN(round.grid.data[i]), false, `field[${i}]`);
  }
  assert.equal(Number.isNaN(round.patientHealth), false);
  assert.equal(Number.isNaN(round.crs), false);
  assert.ok(round.patientHealth >= 0 && round.patientHealth <= 100);
  assert.ok(round.crs >= 0 && round.crs <= 1);
  assert.notEqual(round.outcome, OUTCOME.LOSS_PATIENT_DIED);
});

test('healthy and tumor death use the shared cytotoxic packet threshold', () => {
  const tumor = contactRound({ killerKind: KIND.CD8 });
  tumor.round.world.a3[tumor.target] = TUMOR_DEATH_PACKETS - 1;
  tumor.round.tick(TICK_DT);
  assert.equal(tumor.round.world.alive[tumor.target], 0);
});
