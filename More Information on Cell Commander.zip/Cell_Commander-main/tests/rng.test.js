/**
 * rng.test.js verifies deterministic replay, stream separation, state snapshots,
 * output bounds, and local-calendar daily seeds for the core random generator.
 */

import test from 'node:test';
import assert from 'node:assert/strict';

import { dailySeed, makeRng, seedFromString } from '../src/core/rng.js';

test('same seed replays the same first 1000 values', () => {
  const first = makeRng(0x12345678);
  const second = makeRng(0x12345678);

  for (let i = 0; i < 1000; i += 1) {
    assert.equal(first.next(), second.next());
  }
});

test('seed 1 matches the canonical mulberry32 output vector', () => {
  const rng = makeRng(1);
  const expected = [
    0.6270739405881613,
    0.002735721180215478,
    0.5274470399599522,
    0.9810509674716741,
    0.9683778982143849,
  ];

  for (const value of expected) {
    assert.equal(rng.next(), value);
  }
});

test('different seeds produce different sequences', () => {
  const first = makeRng(1);
  const second = makeRng(2);
  let differs = false;

  for (let i = 0; i < 32; i += 1) {
    if (first.next() !== second.next()) {
      differs = true;
      break;
    }
  }

  assert.equal(differs, true);
});

test('fork salts create deterministic distinct streams', () => {
  const parent = makeRng(0xabcdef01);
  const forkOne = parent.fork(1);
  const forkTwo = parent.fork(2);
  const replay = makeRng(0xabcdef01).fork(1);
  let saltsDiffer = false;

  for (let i = 0; i < 64; i += 1) {
    const one = forkOne.next();
    assert.equal(one, replay.next());
    if (one !== forkTwo.next()) {
      saltsDiffer = true;
    }
  }

  assert.equal(saltsDiffer, true);
});

test('using a fork does not advance its parent stream', () => {
  const parent = makeRng(42);
  const untouchedReplay = makeRng(42);
  const fork = parent.fork(7);

  for (let i = 0; i < 100; i += 1) {
    fork.next();
  }

  assert.equal(parent.next(), untouchedReplay.next());
});

test('next always returns values in the half-open unit interval', () => {
  const rng = makeRng(0xffffffff);

  for (let i = 0; i < 10000; i += 1) {
    const value = rng.next();
    assert.ok(value >= 0);
    assert.ok(value < 1);
  }
});

test('state and restore replay all subsequent random values', () => {
  const rng = makeRng(8675309);
  rng.next();
  rng.gauss();
  const snapshot = rng.state();
  const expected = new Float64Array(100);

  for (let i = 0; i < expected.length; i += 1) {
    expected[i] = rng.next();
  }

  rng.restore(snapshot);
  for (let i = 0; i < expected.length; i += 1) {
    assert.equal(rng.next(), expected[i]);
  }
});

test('dailySeed is stable for one local date and changes across local dates', () => {
  const morning = new Date(2026, 6, 28, 0, 1);
  const evening = new Date(2026, 6, 28, 23, 59);
  const nextDay = new Date(2026, 6, 29, 0, 1);

  assert.equal(dailySeed('first-contact', morning), dailySeed('first-contact', evening));
  assert.notEqual(dailySeed('first-contact', morning), dailySeed('first-contact', nextDay));
  assert.notEqual(dailySeed('first-contact', morning), dailySeed('the-shield', morning));
});

test('seedFromString is a stable unsigned 32-bit hash', () => {
  const value = seedFromString('Cell Commander 🧬');

  assert.equal(value, seedFromString('Cell Commander 🧬'));
  assert.ok(Number.isInteger(value));
  assert.ok(value >= 0);
  assert.ok(value <= 0xffffffff);
  assert.notEqual(value, seedFromString('Cell Commander'));
});
