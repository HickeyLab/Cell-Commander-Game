# Cell Commander — Design Specification

**A hands-on immunotherapy strategy game for K–12 outreach.**
Kids build an immune-cell army, choose a CAR-T targeting strategy, and race to clear a tumor.
Underneath is a real agent-based model with diffusing cytokine fields — a playable, honest
miniature of the research simulation.

Status: v1 spec. This document is the contract. Every module codes against it.

---

## 1. Design goals, in priority order

1. **A kid gets it in 20 seconds and is playing in 40.** No reading required to start.
2. **Every mechanic is real biology.** No invented rules. If a rule is in the game, it exists
   in immunology, and we can name the concept it teaches.
3. **Losing teaches more than winning.** Every failure mode maps to a real reason CAR-T therapy
   fails in patients (antigen escape, checkpoint shutdown, cold tumor, cytokine release syndrome).
4. **Runs on an iPad at a booth, offline, all day.** 60 fps target, no install, no network.
5. **Replayable and competitive.** Deterministic seeds → a fair leaderboard.

Non-goals: clinical accuracy in absolute units; predicting real patient outcomes; being a
research tool. This is a *teaching* model that behaves qualitatively like the research model.

---

## 2. The science we are teaching

Each mechanic below is a real phenomenon. The "Science Card" column is the kid-facing sentence.

| Mechanic in game | Real biology | Science card |
|---|---|---|
| T cells must physically touch a tumor cell to kill it | Immune synapse, contact-dependent cytotoxicity | "Killer T cells have to *touch* a cancer cell to kill it." |
| Killing takes a few seconds of sustained contact | Granzyme/perforin delivery in cytotoxic packets | "It's not instant — the T cell has to inject its poison packets." |
| One T cell kills many tumor cells in a row | Serial killing | "One T cell can kill many cancer cells, one after another." |
| T cells follow a chemical trail to the tumor | Chemokine gradients (CXCL9/10), chemotaxis | "Immune cells smell their way to danger." |
| Tumor cells turn on a shield after being attacked | IFN-γ-induced PD-L1 upregulation (adaptive resistance) | "Attacking the tumor makes it put up a shield." |
| Checkpoint inhibitor drug removes the shield | Anti-PD-1 / anti-PD-L1 immunotherapy | "This drug cuts the tumor's 'stop' signal." |
| Some tumor cells don't have the target flag | Antigen-negative escape variants | "If the tumor hides the flag, CAR-T can't see it." |
| NK cells kill cells that have dropped their MHC-I "self badge" — a *different* escape route from losing the CAR flag | Missing-self recognition. Distinct from antigen escape: CAR recognition is MHC-independent, so losing the target antigen does not itself confer NK susceptibility. The two lineages pair because CD8 (MHC-high) and NK (MHC-low) between them cover the whole range. | "NK cells don't check the flag. They check for an ID badge." |
| Tregs and M2 macrophages shut your cells down | TGF-β / IL-10 immunosuppressive microenvironment | "Some cells tell the immune system to calm down. The tumor uses them." |
| Dendritic cells eat debris, then bring in reinforcements | Antigen presentation and T cell priming | "This cell shows the wanted poster to new soldiers." |
| Too many activated cells at once makes the patient sick | Cytokine release syndrome (CRS) | "Winning too hard can hurt the patient. Real doctors watch for this." |
| Picking a target found on healthy tissue causes damage | On-target, off-tumor toxicity | "Pick a flag *only* the cancer has." |
| T cells wear out after a lot of killing | T cell exhaustion (PD-1 high, reduced function) | "T cells get tired. IL-2 helps them keep going." |

---

## 3. Scientific grounding

Parameters derive from the Hickey lab's published tumor microenvironment ABM
(`tumor-tcell`, Vivarium; Hickey, Agmon, Horowitz, Lamore, Sunwoo, Covert & Nolan, *Cell Systems*),
which the game is a simplified real-time descendant of.

The rule: **every constant in `src/sim/params.js` carries a provenance comment** in one of four
tags, mirroring the lab's convention:

- `[MODEL]` — value taken from the research ABM. Cite the file and the original value.
- `[SCALED]` — research value, rescaled for real-time play. Record the original, the scale factor,
  and *why* (e.g. "3 sim-days compressed to 3 game-minutes → 1440× time compression").
- `[GAME]` — a pure game-design number with no biological claim (button size, score weight).
- `[DERIVED]` — computed from other tagged values; show the arithmetic.

An untagged constant is a bug. `tests/params.test.js` enforces this mechanically.

### 3.1 Time compression

The research model simulates ~3 days at a 60 s timestep. A booth round must last **90–230 s**.

The compression factor is not chosen from the total duration — it is chosen from the **killing
rate**, because that is the mechanic a child has to actually watch happen:

```
Research:  12,800 cytotoxic packets to kill a tumor cell, delivered at 400 packets/min
           => 32 biological minutes for one T cell to kill one target
Game:      that same kill should take about 6 seconds of visible contact
           => BIO_MIN_PER_GAME_SEC = 5   (1 game-second = 5 biological minutes, 300×)
```

So a 200-second round represents roughly 17 hours of biology, not three days. The game does not
attempt to cover the research model's full time course; it covers the window in which the
interesting things happen fast enough to see.

All rate constants (`per_min` in the research model) are converted once, in one place, by
`BIO_MIN_PER_GAME_SEC`. Nothing else in the codebase applies a time conversion. This keeps the
game honest: change one number and every rate stays in correct relative proportion.

**The one deliberate exception is migration**, scaled by an additional `MIGRATION_TIME_SCALE`
of 0.25. At the full 300× factor a T cell moving at its real 10 µm/min would cross the field in
about twelve seconds, appearing as a blur, and contact-dependent killing would become invisible
because cells would pass through one another between frames. Relative speeds between cell types
are preserved exactly, so the biology being taught is intact. The deviation is recorded at the
point of use in `params.js` rather than hidden.

---

## 4. Platform and performance budget

### 4.1 Why not a full-scale simulation

The research ABM is not runnable on a tablet, and we should be explicit about why:

| | Research ABM (`tumor-tcell`) | Cell Commander |
|---|---|---|
| Agents | ~1,200 tumor + T cells | 150–900 (adaptive) |
| Molecular fields | Multiple, fine grid, PDE solver | 5 fields on a 60×42 grid |
| Physics | pymunk rigid-body collision | circle overlap relaxation |
| Timestep | 60 s biological, implicit diffusion | 1/60 s wall-clock, explicit diffusion |
| Runtime | minutes to hours per run, desktop/cluster | real time, 60 fps |
| Output | CSVs, videos, analysis pipeline | a score |

The gap is not mostly agent count — it is **per-agent cost**. The research model runs a full
Vivarium process graph per agent per step (schema resolution, port lookups, update merging) plus
a physics engine and a PDE solve. Cell Commander runs a flat numeric update over typed arrays.
That is roughly a 10³–10⁴× per-agent-step difference, which is exactly what turns "minutes per
run" into "60 frames per second".

**So: a tablet cannot run the research model, and does not need to.** The game reproduces the
*rules and their qualitative consequences*, at a scale a kid can actually see and reason about.
900 visible cells is already more than anyone can track by eye.

### 4.2 Performance budget (per frame, 16.7 ms at 60 fps)

| Stage | Budget | Approach |
|---|---|---|
| Field diffusion | 2.0 ms | 5 fields × 2520 cells, explicit 5-point stencil, `Float32Array`, ping-pong buffers |
| Spatial hash rebuild | 0.5 ms | uniform grid bucket, cell size = 2× max interaction radius |
| Agent behavior | 5.0 ms | SoA typed arrays, one pass, no allocation in the hot loop |
| Overlap relaxation | 2.0 ms | 2 iterations, neighbor pairs from the hash |
| Render | 5.0 ms | single canvas, batched by type, offscreen-cached sprites |
| Headroom | 2.2 ms | |

**Hard rules for the hot loop:** no object allocation, no `Array.prototype` closures per agent,
no string keys per agent per frame. Agent state lives in parallel typed arrays (structure of
arrays), indexed by slot. Dead agents are recycled via a free list, never spliced.

### 4.3 Adaptive quality

An iPad at a booth may be an iPad Air M2 or a 2019 base iPad. The game measures its own frame
time (rolling median over 30 frames) and steps quality down/up automatically:

| Tier | Max agents | Field grid | Diffusion | Particles |
|---|---|---|---|---|
| `high` | 900 | 60×42 | every frame | full |
| `medium` | 500 | 48×34 | every 2nd frame | reduced |
| `low` | 260 | 40×28 | every 3rd frame | off |

Rule: drop a tier if median frame time > 20 ms for 90 consecutive frames; raise a tier if
< 11 ms for 300 consecutive frames (asymmetric, to avoid oscillation). Tier is visible in the
dev overlay, never in the kid-facing UI.

### 4.4 Fixed-timestep decoupling

Simulation runs at a **fixed 60 Hz logical tick** with an accumulator; rendering runs on
`requestAnimationFrame`. Max 3 catch-up ticks per frame (spiral-of-death guard). This makes the
simulation deterministic and frame-rate independent — required for the leaderboard to be fair
across a fast laptop and a slow iPad.

---

## 5. World model

### 5.1 Coordinates

World is `1200 × 800` world-units (wu). 1 wu ≈ 1 µm, so the arena is ~1.2 mm × 0.8 mm of tissue —
a realistic microscopy field of view. Canvas scales to fit; all logic is in world units.

### 5.2 Fields

Five diffusing scalar fields on a shared grid (`GRID_W × GRID_H`, default 60×42, cell = 20 wu):

| Field | Source | Effect | D (wu²/s) | half-life (game s) |
|---|---|---|---|---|
| `chemokine` | activated T/NK/M1/DC | attracts T, NK, macrophage (chemotaxis) | high | short |
| `ifng` | engaged T cells, NK | tumor → PD-L1 high + MHC-I high; macrophage → M1 | high | short |
| `il2` | CD4 help, IL-2 drug | T proliferation ↑, exhaustion ↓ | medium | medium |
| `suppress` | Treg, M2 | T/NK kill rate ↓, movement ↓ | medium | long |
| `debris` | dying tumor cells | DC food; DC uptake → maturation | low | long |

Plus one **static** scalar computed at level load: `perfusion` — distance falloff from vessels.
Governs where reinforcements enter and where the tumor core goes necrotic (no growth in the
lowest-perfusion region). Not diffused per frame.

Boundary condition: zero-flux (Neumann) at walls — molecules stay in the tissue.

### 5.3 Agents

One SoA store. Every agent has: `kind`, `x`, `y`, `vx`, `vy`, `radius`, `state`, `age`,
`timer`, `hp`, plus kind-specific numeric slots (`a0..a3`) documented per kind.

| Kind | Team | Radius (wu) | Speed (wu/s) | Notes |
|---|---|---|---|---|
| `TUMOR` | hostile | 10 | 0 | divides; `antigen` per-cell; `pdl1` inducible |
| `CD8` | player | 6 | 60 | native T cell; needs MHC-I; exhausts |
| `CART` | player | 6 | 70 | targets the chosen antigen; MHC-independent; strong; CRS risk |
| `NK` | player | 6.5 | 55 | kills MHC-I-**low** targets; ignores antigen |
| `MACRO` | player | 9 | 25 | M1 kills slowly + makes chemokine; M2 suppresses |
| `DC` | player | 8 | 20 | eats debris → matures → calls in a CD8 wave |
| `CD4` | player | 6 | 45 | makes IL-2 in a radius; boosts nearby T cells |
| `TREG` | hostile | 6 | 40 | makes `suppress` |
| `VESSEL` | neutral | 14 | 0 | static; spawn point for reinforcements |
| `HEALTHY` | neutral | 9 | 0 | normal tissue; may express a shared antigen → toxicity |

### 5.4 Tumor cell detail

- `antigen ∈ {GREEN, BLUE, ORANGE, NONE}` — which flag this cell displays. Per-level distribution.
- `mhc ∈ [0,1]` — MHC-I level. Low MHC → invisible to CD8/CAR-T recognition of *native* peptide,
  but **visible to NK** (missing-self).
- `pdl1 ∈ [0,1]` — starts at level baseline, rises with local `ifng` exposure.
- Divides every `TUMOR_DIVIDE_TIME`, jittered ±20%, only if local perfusion > threshold and
  there is physical room (no division into an overlapping spot).
- Dies when accumulated cytotoxic packets ≥ `TUMOR_DEATH_PACKETS`. On death → `debris` deposit.

### 5.5 Killing rule (the heart of the game)

A killer cell `K` and a target `T` engage when `dist(K,T) < K.radius + T.radius + ENGAGE_MARGIN`.
Per tick, while engaged:

```
recognized =
    K is CART : (T.antigen === plan.carTarget)            // CAR is MHC-independent
    K is CD8  : (T.mhc > MHC_RECOGNITION_MIN)             // peptide-MHC-I, ANY tumor peptide
    K is NK   : (T.mhc < NK_MISSING_SELF_MAX)             // missing-self
    K is MACRO(M1) : true                                 // phagocytosis, slow, non-specific

if (!recognized) → disengage, no damage

brake      = pd1_brake(K, T)     = 1 / (1 + T.pdl1 * K.pd1 * PD1_STRENGTH)   // 0 if checkpoint drug
suppression= 1 / (1 + suppress_local * SUPPRESS_STRENGTH)
boost      = 1 + il2_local * IL2_BOOST
fatigue    = 1 - K.exhaustion

packets   += KILL_RATE[K.kind] * brake * suppression * boost * fatigue * dt
K.exhaustion += EXHAUST_PER_KILL_SEC * dt   (reduced by local il2)
```

When `packets >= TUMOR_DEATH_PACKETS`, the target dies, the killer's `killCount++`, it enters a
short `KILL_COOLDOWN`, and it re-targets — serial killing.

This single expression carries five teachable concepts at once (recognition, checkpoint braking,
suppression, cytokine support, exhaustion) and each is individually visible in the HUD as a
"why is my T cell weak?" readout.

**CD8 recognition depends on MHC-I only, never on the CAR's target flag.** A native cytotoxic
T cell reads peptide-MHC-I and can kill a tumor cell that has lost the CAR antigen but still
presents other tumor peptides — which is exactly what happens in real CD19-negative relapse.
Gating CD8 on the CAR flag (an earlier version did) is not just a modelling shortcut, it opens
a hole in the recognition space: a cell with no flag and MHC-I just *above* the NK missing-self
cutoff would satisfy no killer at all and be literally invincible. Balance testing found 13 such
cells surviving every run of The Escape Artist. With the rule as written, CD8 (MHC-high) and NK
(MHC-low) partition the space completely, so **every tumor cell is killable by something** —
and `tests/params.test.js` pins `MHC_RECOGNITION_MIN === NK_MISSING_SELF_MAX` so the partition
cannot silently develop a gap again.

### 5.6 Movement

Each mobile agent per tick:
1. **Chemotaxis** — sample the gradient of its attractant field (central difference on the grid),
   steer toward it with weight `CHEMO_GAIN[kind]`.
2. **Persistence** — blend with previous heading (`PERSISTENCE`), giving realistic
   run-and-tumble rather than jitter.
3. **Random walk** — small angular noise.
4. **Braking on engagement** — engaged killers slow to `ENGAGED_SPEED_FRAC` (real: T cells
   arrest on contact).
5. **Overlap relaxation** — 2 iterations of pairwise push-apart, so cells don't stack.

---

## 6. The player's decisions

### 6.1 Setup phase (before pressing PLAY)

**A. Read the biopsy.** A panel shows the tumor's antigen breakdown as a bar
("62% green flags, 28% blue flags, 10% no flag") and a warning if healthy tissue shares a flag.
This is the kid's evidence for the next decision.

**B. Choose the CAR-T target flag.** GREEN / BLUE / ORANGE. This is the single highest-leverage
choice, and the "conditions for consideration of T cell therapy" made concrete:
- Match the dominant antigen → most tumor cells are killable.
- Choose a flag healthy tissue also displays → toxicity climbs, patient health falls.
- No choice covers the antigen-negative fraction → you need NK cells. That is the lesson.

**C. Spend the budget.** Each level gives a budget (e.g. 100 credits). Costs:

| Item | Cost | Effect |
|---|---|---|
| CAR-T cell | 6 | strong, specific killer; adds CRS |
| CD8 T cell | 4 | native killer; needs MHC-I |
| NK cell | 5 | kills flag-hiders |
| Macrophage | 3 | slow killer, makes chemokine |
| Dendritic cell | 7 | calls in free CD8 waves over time |
| CD4 helper | 4 | local IL-2, fights exhaustion |
| Checkpoint inhibitor (anti-PD-1) | 20 | removes the tumor's shield, whole map |
| IL-2 support | 15 | global proliferation boost, **raises CRS risk** |
| Lymphodepletion | 12 | removes 60% of Tregs at start, −10 patient health |

**D. Place the cells.** Drag from the palette onto the map. Placement is legal anywhere except
inside the tumor mass (you cannot teleport into the core — real cells must infiltrate). Placing
at vessels gives a small speed bonus for the first seconds ("extravasation"). Where a kid places
cells matters as much as what they buy — that is the spatial lesson the whole research program
is about.

### 6.2 Live phase

Minimal but real controls, all touch-first:
- **Pause / play / speed 1×–3×.**
- **Rally point** — tap the map to lay a chemokine beacon (limited uses). Teaches that chemokines
  direct traffic.
- **Emergency stop** — halts the therapy if CRS is spiking. Costs score, saves the patient.
  (Real: tocilizumab / steroid rescue.)

### 6.3 Meters (always visible)

- **Tumor cells remaining** — the headline number, big.
- **Patient health** (0–100) — falls from toxicity and healthy-tissue destruction. Zero = loss.
- **CRS / cytokine storm** — rises with total simultaneous killing + IL-2. In the red = damage.
- **Clock.**

---

## 7. Win, loss, and score

**Win:** tumor cells = 0 and patient health > 0.

**Loss:**
- Tumor cells ≥ `LEVEL_TUMOR_ESCAPE_CAP` → "The tumor escaped."
- Patient health = 0 → "The treatment was too harsh." (This is a *loss with dignity* — the card
  explains this is exactly the trade-off real oncologists manage.)
- Timer expires → "Out of time."

**Score** (leaderboard sorts on this; ties break on faster time):

```
base        = 1000
speedBonus  = round(3000 * clamp(1 - clearTime / timeLimit, 0, 1))
healthBonus = round(20 * patientHealth)              // up to 2000
efficiency  = round(10 * budgetUnspent)              // rewards not overtreating
toxPenalty  = round(15 * peakCrs + 25 * healthyKilled)
score       = max(0, base + speedBonus + healthBonus + efficiency - toxPenalty)
```

The weights are deliberately set so that **a fast, gentle, cheap cure beats a fast, brutal one**.
A kid who carpet-bombs with 16 CAR-T cells wins the race and loses the score — and the card
tells them why. That is the whole point.

### 7.1 Leaderboard fairness

Each level has a fixed **seed per day** (derived from the date) so every kid at the booth that
day plays an identical tumor. Scores are stored per `(level, seed)`. Cross-seed comparison is
never shown. Storage: `localStorage`, top 25 per level, initials (3 chars, profanity-filtered
against a small blocklist) + score + time. Export/import as JSON so the booth laptop can collect
iPad scores if wanted.

---

## 8. Levels

| # | Name | Teaches | Setup |
|---|---|---|---|
| 1 | First Contact | contact killing, placement, chemotaxis | 40 tumor cells, uniform GREEN antigen, no PD-L1, no Tregs. Budget 60. |
| 2 | The Shield | adaptive resistance → checkpoint inhibitor | PD-L1 rises fast with IFN-γ. Budget 100 (raised from 90 after CAR-T was removed as a playable option). Without the drug the kill stalls visibly. |
| 3 | The Escape Artist | antigen heterogeneity → combination therapy | 35% antigen-NONE + low MHC. NK catches low-MHC cells; CD8 catches high-MHC cells, including ones whose MHC-I drifts up mid-round. CAR-T removed as a playable option; budget raised to 160 to keep the level winnable on NK+CD8 alone. |
| 4 | Cold Tumor | trafficking, suppression, DC priming | Tregs + M2, near-zero baseline chemokine, tumor far from vessels. Budget 110. |
| 5 | Deep Core | infiltration, necrotic core, patience | Large dense mass, low perfusion center. Checkpoint unlocked alongside IL-2 -- without it, IL-2's CRS cost across the roster this tumor size demands was pushing average patient health to ~32/100. Budget 120. |
| 6 | Sandbox | free exploration | Every slider exposed: counts per cell type, antigen mix, PD-L1, Treg load, tumor growth rate, drug toggles. No score, no timer. |

**`src/content/levels.js` is authoritative for every number in this table.** The figures here
are indicative; the level file carries the live values plus a `BALANCE KNOBS` header explaining
which constant to move to make a level easier or harder. Several were retuned after headless
balance testing (`tests/balance.test.js`), which plays each level to completion and asserts both
that a sensible plan wins and that the naive plan the level exists to defeat loses.

Level 6 (Sandbox) is what the outreach ask is literally about — kids choose numbers, types,
subtypes and locations freely. Levels 1–5 are the guided on-ramp that teaches them what the
sliders *mean* first.

---

## 9. Kid-facing UX rules

- **Touch targets ≥ 56 px.** No hover-only affordances. No right-click. No keyboard requirement.
- **Reading level ≈ grade 4.** Max 25 words per instruction. Every instruction pairs with an icon.
- **Colorblind-safe.** Cell identity is carried by **shape + color + icon**, never color alone.
  Palette validated for deuteranopia/protanopia.
- **No fail-shame.** Loss screens open with what the kid discovered, then the science, then
  "Try again" as the biggest button.
- **Booth-resilient.** Auto-return to the title screen after 90 s idle on a results screen.
  A long-press on the logo (3 s) opens the reset/leaderboard-clear menu — invisible to kids.
- **No audio dependency.** Sound optional and off by default (booths are loud).
- **Reduced motion** honored via `prefers-reduced-motion` — particle effects downgrade.

---

## 10. Code architecture

```
src/
  core/
    contracts.js    Enumerations, agent-slot layout, shared constants. THE interface.
    rng.js          Deterministic seeded PRNG (mulberry32) + helpers. No Math.random anywhere else.
    grid.js         Field grid: diffuse, decay, deposit, sample, gradient.
    spatialhash.js  Uniform-grid neighbor queries.
    perf.js         Frame timing, adaptive quality tier.
  sim/
    params.js       All biological constants, each with a provenance tag.
    world.js        SoA agent store: spawn, kill, iterate, free list.
    engine.js       step(dt): fields → behaviors → movement → relaxation → events.
    behaviors/      One file per kind. Pure functions over (world, i, ctx).
    scoring.js      Score, win/loss evaluation.
    plan.js         The player's treatment plan (target, drugs, roster) + validation.
  render/
    canvas.js       Main draw: fields → agents → effects → overlays.
    sprites.js      Offscreen-cached cell sprites per kind/state.
    fx.js           Particles: kill bursts, cytokine puffs, division pops.
    hud.js          Meters, counters, clock.
  ui/
    app.js          Boot, screen router, the rAF loop.
    setup.js        Biopsy panel, target picker, budget shop, drag placement.
    live.js         In-round controls.
    results.js      Win/loss summary + tumor-count chart + science card.
    leaderboard.js  Storage, render, initials entry.
    sandbox.js      Level 6 slider panel.
  content/
    levels.js       Level definitions (data only).
    science.js      Science cards (data only).
```

**Dependency rule:** `sim/` must not import from `render/` or `ui/`, and must not touch `window`,
`document`, or `Math.random`. This is what makes the whole simulation unit-testable in Node and
deterministic. `tests/architecture.test.js` enforces it by scanning imports.

---

## 11. Verification plan

1. **Unit tests** (`node:test`, zero dependencies) — RNG determinism, grid diffusion conserves
   mass under zero-flux, spatial hash returns the same neighbors as brute force, kill arithmetic,
   scoring, level data validity, params all tagged, architecture boundary.
2. **Headless simulation tests** — run the engine 3,000 ticks for each level without a renderer;
   assert the level is winnable with a reference plan and losable with a naive plan. This is the
   real balance test and it runs in CI in seconds.
3. **Determinism test** — same seed + same plan ⇒ byte-identical score, twice.
4. **Browser playtest** — drive the actual page with Playwright: place cells, run a round, read
   the final DOM, screenshot each screen.
5. **Performance measurement** — instrumented benchmark reporting p50/p95 frame time at 300/600/900
   agents, so the iPad claim is measured rather than asserted.

Nothing is called "done" until it has been *observed working in a browser*.
