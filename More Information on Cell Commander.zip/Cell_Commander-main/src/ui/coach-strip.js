/**
 * coach-strip.js — owns the live commentary strip: sampling the round, deciding which rule
 * speaks, and showing one short sentence at a time.
 *
 * Kept out of live.js so the sampling logic stays readable and so live.js does not grow a
 * second responsibility. All copy and thresholds live in src/content/coach.js; this module
 * only observes and presents. It reads the round and never writes to it.
 */

import { ANTIGEN, KIND, OUTCOME } from '../core/contracts.js';
import { P } from '../sim/params.js';
import { COACH_RULES, COACH_MESSAGE_SEC, COACH_SAMPLE_SEC } from '../content/coach.js';

const PRIORITY_RANK = { high: 3, med: 2, low: 1 };

/**
 * Create the commentary strip.
 * @param {{reducedMotion?:boolean}} [opts]
 * @returns {{el:HTMLElement, update:(dt:number, round:object, plan:object)=>void,
 *            noteKill:()=>void, noteWave:()=>void, reset:()=>void, destroy:()=>void}}
 */
export function makeCoachStrip(opts = {}) {
  const el = document.createElement('div');
  el.className = 'coach-strip';
  if (opts.reducedMotion) el.classList.add('is-static');

  const text = document.createElement('p');
  text.className = 'coach-strip__text';
  el.append(text);

  // Sampling state.
  let sampleTimer = 0;
  let sinceEngagement = 0;
  let lastHealthyKilled = 0;
  let tumorStart = 0;
  let firstKillHappened = false;
  let waveCalled = false;
  const firedAt = new Map(); // rule id -> timeSec it last fired

  // Display state.
  let showing = null; // { rule, remaining }
  const queue = [];

  function reset() {
    sampleTimer = 0;
    sinceEngagement = 0;
    lastHealthyKilled = 0;
    tumorStart = 0;
    firstKillHappened = false;
    waveCalled = false;
    firedAt.clear();
    queue.length = 0;
    showing = null;
    text.textContent = '';
    el.classList.remove('is-visible');
  }

  /** Scan the world once to build the small snapshot the rules read. */
  function sample(round, plan) {
    const world = round.world;
    let tumor = 0;
    let flagless = 0;
    let flaglessMhcSum = 0;
    let pdl1Sum = 0;
    let killers = 0;
    let exhaustSum = 0;
    let engagedNow = 0;

    for (let i = 0; i < world.capacity; i++) {
      if (!world.alive[i]) continue;
      const kind = world.kind[i];
      if (kind === KIND.TUMOR) {
        tumor++;
        pdl1Sum += world.a2[i];
        if (world.a0[i] === ANTIGEN.NONE) {
          flagless++;
          flaglessMhcSum += world.a1[i];
        }
      } else if (kind === KIND.CART || kind === KIND.CD8 || kind === KIND.NK) {
        killers++;
        exhaustSum += world.a1[i];
        if (world.a3[i] >= 0) engagedNow++;
      }
    }

    if (tumorStart === 0) tumorStart = Math.max(tumor, round.tumorCount || 0);

    const healthyKilled = round.stats?.healthyKilled ?? 0;
    const healthyKilledDelta = Math.max(0, healthyKilled - lastHealthyKilled);
    lastHealthyKilled = healthyKilled;

    if (engagedNow > 0) sinceEngagement = 0;

    return {
      tumorCount: tumor,
      tumorStart,
      levelId: round.level?.id ?? null,
      meanTumorPdl1: tumor > 0 ? pdl1Sum / tumor : 0,
      meanKillerExhaustion: killers > 0 ? exhaustSum / killers : 0,
      crs: round.crs ?? 0,
      crsDanger: P.patient.crsDanger,
      healthyKilledDelta,
      flaglessFraction: tumor > 0 ? flagless / tumor : 0,
      meanFlaglessMhc: flagless > 0 ? flaglessMhcSum / flagless : 0,
      hasCD8: Boolean(round.level?.unlocks?.includes(KIND.CD8)),
      secondsSinceAnyEngagement: sinceEngagement,
      hasCheckpoint: Boolean(plan?.checkpoint),
      hasIl2: Boolean(plan?.il2),
      firstKillHappened,
      waveCalled,
      timeSec: round.timeSec ?? 0,
    };
  }

  function present(rule, timeSec) {
    firedAt.set(rule.id, timeSec);
    // Speak it too. The strip itself carries no aria-live: a second live region competing
    // with the HUD's is what previously made the game unusable with a screen reader.
    try {
      opts.announce?.(rule.text);
    } catch {
      // Never let an announcement failure interrupt play.
    }
    if (rule.id === 'first-kill') firstKillHappened = false;
    if (rule.id === 'wave') waveCalled = false;

    // A higher-priority message interrupts; anything else waits its turn.
    if (!showing || PRIORITY_RANK[rule.priority] > PRIORITY_RANK[showing.rule.priority]) {
      showing = { rule, remaining: COACH_MESSAGE_SEC };
      text.textContent = rule.text;
      el.classList.add('is-visible');
    } else if (!queue.some((r) => r.id === rule.id)) {
      queue.push(rule);
    }
  }

  return {
    el,
    reset,
    /** live.js calls these when it drains the corresponding simulation events. */
    noteKill() { firstKillHappened = true; },
    noteWave() { waveCalled = true; },

    update(dt, round, plan) {
      const step = Number.isFinite(dt) ? Math.max(0, Math.min(0.25, dt)) : 0;

      // Advance the visible message regardless of round state so it can finish and clear.
      if (showing) {
        showing.remaining -= step;
        if (showing.remaining <= 0) {
          showing = null;
          const next = queue.shift();
          if (next) {
            showing = { rule: next, remaining: COACH_MESSAGE_SEC };
            text.textContent = next.text;
          } else {
            el.classList.remove('is-visible');
          }
        }
      }

      if (!round || round.outcome !== OUTCOME.RUNNING) return;

      sinceEngagement += step;
      sampleTimer += step;
      if (sampleTimer < COACH_SAMPLE_SEC) return;
      sampleTimer = 0;

      const ctx = sample(round, plan);
      for (const rule of COACH_RULES) {
        const last = firedAt.get(rule.id);
        if (last !== undefined) {
          // `once` rules never repeat; the rest wait out their re-arm window.
          if (rule.once !== false) continue;
          if (ctx.timeSec - last < (rule.rearmSec ?? 15)) continue;
        }
        let fires = false;
        try {
          fires = Boolean(rule.test(ctx));
        } catch {
          fires = false; // a broken rule must never take the round down
        }
        if (fires) {
          present(rule, ctx.timeSec);
          break; // one new message per sample keeps the strip calm
        }
      }
    },

    destroy() {
      reset();
      el.remove();
    },
  };
}
