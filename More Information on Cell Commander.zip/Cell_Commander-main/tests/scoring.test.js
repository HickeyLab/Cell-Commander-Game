/**
 * scoring.test.js verifies outcome precedence and the exact design score formula,
 * especially that gentle, efficient treatment outranks equally fast overtreatment.
 */

import test from 'node:test';
import assert from 'node:assert/strict';

import { OUTCOME } from '../src/core/contracts.js';
import { computeScore, evaluateOutcome } from '../src/sim/scoring.js';

const level = {
  budget: 100,
  timeLimitSec: 120,
  tumorEscapeCap: 150,
};

test('computeScore implements the exact ordered score formula and breakdown', () => {
  const result = computeScore({
    timeSec: 30,
    patientHealth: 90,
    budgetUnspent: 20,
    peakCrs: 0.4,
    healthyKilled: 2,
  }, level);

  assert.deepEqual(result, {
    total: 5194,
    base: 1000,
    speed: 2250,
    health: 1800,
    efficiency: 200,
    penalty: 56,
    breakdown: [
      { label: 'Base score', value: 1000, good: true },
      { label: 'Fast cure', value: 2250, good: true },
      { label: 'Patient health', value: 1800, good: true },
      { label: 'Budget saved', value: 200, good: true },
      { label: 'Treatment harm', value: -56, good: false },
    ],
  });
});

test('a fast gentle cheap win scores higher than a fast brutal expensive win', () => {
  const gentle = computeScore({
    timeSec: 36,
    patientHealth: 96,
    budgetUnspent: 28,
    peakCrs: 0.2,
    healthyKilled: 0,
  }, level);
  const brutal = computeScore({
    timeSec: 36,
    patientHealth: 38,
    budgetUnspent: 0,
    peakCrs: 1,
    healthyKilled: 14,
  }, level);

  assert.ok(gentle.total > brutal.total);
});

test('evaluateOutcome applies patient safety, cure, escape, and timeout rules', () => {
  assert.equal(evaluateOutcome({
    outcome: OUTCOME.RUNNING,
    patientHealth: 0,
    tumorCount: 0,
    timeSec: 10,
  }, level), OUTCOME.LOSS_PATIENT_DIED);
  assert.equal(evaluateOutcome({
    outcome: OUTCOME.RUNNING,
    patientHealth: 80,
    tumorCount: 0,
    timeSec: 10,
  }, level), OUTCOME.WIN);
  assert.equal(evaluateOutcome({
    outcome: OUTCOME.RUNNING,
    patientHealth: 80,
    tumorCount: 150,
    timeSec: 10,
  }, level), OUTCOME.LOSS_TUMOR_ESCAPED);
  assert.equal(evaluateOutcome({
    outcome: OUTCOME.RUNNING,
    patientHealth: 80,
    tumorCount: 5,
    timeSec: 120,
  }, level), OUTCOME.LOSS_TIMEOUT);
  assert.equal(evaluateOutcome({
    outcome: OUTCOME.ABORTED,
    patientHealth: 80,
    tumorCount: 5,
    timeSec: 1,
  }, level), OUTCOME.ABORTED);
});
