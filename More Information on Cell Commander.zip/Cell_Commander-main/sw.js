/**
 * Offline app-shell service worker. URLs are resolved against the registration
 * scope so the same build works at a domain root or in a GitHub Pages subfolder.
 */

const CACHE = 'cell-commander-v1';
const APP_SHELL = [
  './',
  './index.html',
  './styles.css',
  './app.webmanifest',
  './assets/icon-192.png',
  './assets/icon-512.png',
  './assets/apple-touch-icon.png',
  './src/ui/app.js',
  './src/core/contracts.js',
  './src/core/perf.js',
  './src/core/rng.js',
  './src/sim/engine.js',
  './src/core/grid.js',
  './src/core/spatialhash.js',
  './src/sim/params.js',
  './src/sim/world.js',
  './src/sim/plan.js',
  './src/sim/scoring.js',
  './src/sim/behaviors/tumor.js',
  './src/sim/behaviors/tcell.js',
  './src/sim/behaviors/nk.js',
  './src/sim/behaviors/macrophage.js',
  './src/sim/behaviors/dendritic.js',
  './src/sim/behaviors/cd4.js',
  './src/sim/behaviors/treg.js',
  './src/sim/behaviors/healthy.js',
  './src/content/levels.js',
  './src/ui/components.js',
  './src/ui/setup.js',
  './src/ui/live.js',
  './src/render/canvas.js',
  './src/render/fx.js',
  './src/render/sprites.js',
  './src/render/hud.js',
  './src/ui/results.js',
  './src/content/science.js',
  './src/ui/leaderboard.js',
  './src/ui/round-view.js',
  './src/ui/sandbox.js',
];

self.addEventListener('install', (event) => {
  event.waitUntil((async () => {
    const cache = await caches.open(CACHE);
    const urls = APP_SHELL.map((path) => new URL(path, self.registration.scope).href);
    const results = await Promise.allSettled(urls.map((url) => cache.add(url)));
    for (let index = 0; index < results.length; index += 1) {
      if (results[index].status === 'rejected') {
        console.warn(`Could not precache ${APP_SHELL[index]}`, results[index].reason);
      }
    }
    await self.skipWaiting();
  })());
});

self.addEventListener('activate', (event) => {
  event.waitUntil((async () => {
    const names = await caches.keys();
    const oldCaches = names.filter((name) => (
      name.startsWith('cell-commander-') && name !== CACHE
    ));
    await Promise.all(oldCaches.map((name) => caches.delete(name)));
    await self.clients.claim();
  })());
});

self.addEventListener('fetch', (event) => {
  const request = event.request;
  if (request.method !== 'GET') return;

  const url = new URL(request.url);
  const scope = new URL(self.registration.scope);
  if (url.origin !== scope.origin || !url.href.startsWith(scope.href)) return;

  const serviceWorkerUrl = new URL('sw.js', self.registration.scope).href;
  if (url.href === serviceWorkerUrl) {
    event.respondWith(fetch(request));
    return;
  }

  event.respondWith((async () => {
    const cached = await caches.match(request);
    if (cached) return cached;
    try {
      const response = await fetch(request);
      if (response.ok) {
        const cache = await caches.open(CACHE);
        await cache.put(request, response.clone());
      }
      return response;
    } catch (error) {
      if (request.mode === 'navigate') {
        const fallback = await caches.match(new URL('./index.html', self.registration.scope));
        if (fallback) return fallback;
      }
      throw error;
    }
  })());
});
