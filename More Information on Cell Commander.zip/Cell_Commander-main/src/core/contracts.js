/**
 * contracts.js — the shared interface every module codes against.
 *
 * This file is the single source of truth for enumerations, the agent memory layout,
 * and the shapes passed between sim / render / ui. It has NO logic and NO imports.
 *
 * Rules enforced by tests:
 *   - sim/ never imports from render/ or ui/
 *   - sim/ never touches window, document, or Math.random
 *   - every numeric constant in sim/params.js carries a provenance tag
 */

/* ------------------------------------------------------------------ *
 * Agent kinds
 * ------------------------------------------------------------------ */

export const KIND = Object.freeze({
  NONE: 0,
  TUMOR: 1,
  CD8: 2,
  CART: 3,
  NK: 4,
  MACRO: 5,
  DC: 6,
  CD4: 7,
  TREG: 8,
  VESSEL: 9,
  HEALTHY: 10,
});

export const KIND_NAME = Object.freeze({
  [KIND.NONE]: 'none',
  [KIND.TUMOR]: 'tumor',
  [KIND.CD8]: 'cd8',
  [KIND.CART]: 'cart',
  [KIND.NK]: 'nk',
  [KIND.MACRO]: 'macrophage',
  [KIND.DC]: 'dendritic',
  [KIND.CD4]: 'cd4',
  [KIND.TREG]: 'treg',
  [KIND.VESSEL]: 'vessel',
  [KIND.HEALTHY]: 'healthy',
});

/** Kid-facing display names. Never show KIND_NAME in the UI. */
export const KIND_LABEL = Object.freeze({
  [KIND.TUMOR]: 'Cancer Cell',
  [KIND.CD8]: 'Killer T Cell',
  [KIND.CART]: 'CAR-T Cell',
  [KIND.NK]: 'NK Cell',
  [KIND.MACRO]: 'Macrophage',
  [KIND.DC]: 'Dendritic Cell',
  [KIND.CD4]: 'Helper T Cell',
  [KIND.TREG]: 'Treg (Blocker)',
  [KIND.VESSEL]: 'Blood Vessel',
  [KIND.HEALTHY]: 'Healthy Cell',
});

export const TEAM = Object.freeze({ NEUTRAL: 0, PLAYER: 1, HOSTILE: 2 });

export const KIND_TEAM = Object.freeze({
  [KIND.TUMOR]: TEAM.HOSTILE,
  [KIND.TREG]: TEAM.HOSTILE,
  [KIND.CD8]: TEAM.PLAYER,
  [KIND.CART]: TEAM.PLAYER,
  [KIND.NK]: TEAM.PLAYER,
  [KIND.MACRO]: TEAM.PLAYER,
  [KIND.DC]: TEAM.PLAYER,
  [KIND.CD4]: TEAM.PLAYER,
  [KIND.VESSEL]: TEAM.NEUTRAL,
  [KIND.HEALTHY]: TEAM.NEUTRAL,
});

/** Kinds the player can buy and place. Order defines palette order. */
export const PLACEABLE = Object.freeze([
  KIND.CART, KIND.CD8, KIND.NK, KIND.MACRO, KIND.DC, KIND.CD4,
]);

/* ------------------------------------------------------------------ *
 * States — one shared numeric space, interpreted per kind
 * ------------------------------------------------------------------ */

export const STATE = Object.freeze({
  // universal
  ALIVE: 0,
  DEAD: 1,
  // T cell / NK
  NAIVE: 10,
  ACTIVE: 11,
  ENGAGED: 12,
  EXHAUSTED: 13,
  // macrophage polarization
  M0: 20,
  M1: 21,
  M2: 22,
  // dendritic cell
  IMMATURE: 30,
  LOADED: 31,
  MATURE: 32,
  // tumor
  PROLIFERATIVE: 40,
  QUIESCENT: 41, // high MHC-I / high PD-L1, slow growth (research model's second tumor state)
  NECROTIC: 42,
});

export const STATE_NAME = Object.freeze(
  Object.fromEntries(Object.entries(STATE).map(([k, v]) => [v, k.toLowerCase()]))
);

/* ------------------------------------------------------------------ *
 * Antigens — the "flags" a kid picks a CAR-T against
 * ------------------------------------------------------------------ */

export const ANTIGEN = Object.freeze({ NONE: 0, GREEN: 1, BLUE: 2, ORANGE: 3 });

export const ANTIGEN_LABEL = Object.freeze({
  [ANTIGEN.NONE]: 'No Flag',
  [ANTIGEN.GREEN]: 'Green Flag',
  [ANTIGEN.BLUE]: 'Blue Flag',
  [ANTIGEN.ORANGE]: 'Orange Flag',
});

/** Real-world analogues, shown as a small subtitle for older kids / teachers. */
export const ANTIGEN_REAL = Object.freeze({
  [ANTIGEN.GREEN]: 'like GD2',
  [ANTIGEN.BLUE]: 'like CD19',
  [ANTIGEN.ORANGE]: 'like HER2',
});

/**
 * The real cancer type each antigen is a marker for, shown on the target picker so a
 * player is choosing "which cancer" rather than just "which color."
 */
export const ANTIGEN_TUMOR_NAME = Object.freeze({
  [ANTIGEN.GREEN]: 'Neuroblastoma',
  [ANTIGEN.BLUE]: 'B-cell Leukemia',
  [ANTIGEN.ORANGE]: 'HER2+ Breast Cancer',
});

/** One short, real fact about each tumor type's marker, for the target picker's subtitle. */
export const ANTIGEN_TUMOR_INFO = Object.freeze({
  [ANTIGEN.GREEN]: 'GD2 — a childhood nerve-cell cancer',
  [ANTIGEN.BLUE]: 'CD19 — found on every B cell in the body',
  [ANTIGEN.ORANGE]: 'HER2 — also on some healthy organs',
});

export const ANTIGEN_LIST = Object.freeze([ANTIGEN.GREEN, ANTIGEN.BLUE, ANTIGEN.ORANGE]);

/* ------------------------------------------------------------------ *
 * Diffusing fields
 * ------------------------------------------------------------------ */

export const FIELD = Object.freeze({
  CHEMOKINE: 0,
  IFNG: 1,
  IL2: 2,
  SUPPRESS: 3,
  DEBRIS: 4,
  BEACON: 5,
});

export const FIELD_COUNT = 6;

export const FIELD_NAME = Object.freeze({
  [FIELD.CHEMOKINE]: 'chemokine',
  [FIELD.IFNG]: 'ifng',
  [FIELD.IL2]: 'il2',
  [FIELD.SUPPRESS]: 'suppress',
  [FIELD.DEBRIS]: 'debris',
  [FIELD.BEACON]: 'beacon',
});

/** Kid-facing field names for the map legend / field-view toggle. */
export const FIELD_LABEL = Object.freeze({
  [FIELD.CHEMOKINE]: 'Danger Scent',
  [FIELD.IFNG]: 'Alarm Signal',
  [FIELD.IL2]: 'Energy Boost',
  [FIELD.SUPPRESS]: 'Calm-Down Signal',
  [FIELD.DEBRIS]: 'Cancer Crumbs',
});

/* ------------------------------------------------------------------ *
 * Agent memory layout (structure of arrays)
 * ------------------------------------------------------------------ *
 *
 * world.js allocates one typed array per column below, all of length `capacity`.
 * Behaviors read and write by slot index `i`. Nothing allocates per-agent objects
 * in the hot loop.
 *
 * The four generic slots a0..a3 mean different things per kind — documented here
 * so no module has to guess:
 *
 *   TUMOR : a0 = antigen (ANTIGEN.*)      a1 = mhc [0,1]
 *           a2 = pdl1 [0,1]               a3 = accumulated cytotoxic packets
 *   CD8   : a0 = pd1 [0,1]                a1 = exhaustion [0,1]
 *   CART  : a2 = kill count               a3 = target slot index (-1 = none)
 *   NK    : same layout as CD8
 *   MACRO : a0 = polarization [-1..1]  (−1 = M2, +1 = M1)
 *           a1 = exhaustion              a2 = kill count   a3 = target slot
 *   DC    : a0 = antigen load [0,1]       a1 = maturation [0,1]
 *           a2 = antigen it captured (ANTIGEN.*)   a3 = waves called
 *   CD4   : a0 = unused   a1 = unused   a2 = unused   a3 = unused
 *   TREG  : a0 = unused   a1 = unused   a2 = unused   a3 = unused
 *   HEALTHY: a0 = antigen (may be shared with tumor → off-tumor toxicity)
 *            a3 = accumulated damage packets
 *   VESSEL: a0 = unused
 */

export const AGENT_COLUMNS = Object.freeze([
  { name: 'kind', type: 'Uint8Array' },
  { name: 'state', type: 'Uint8Array' },
  { name: 'alive', type: 'Uint8Array' },
  { name: 'x', type: 'Float32Array' },
  { name: 'y', type: 'Float32Array' },
  { name: 'vx', type: 'Float32Array' },
  { name: 'vy', type: 'Float32Array' },
  { name: 'radius', type: 'Float32Array' },
  { name: 'age', type: 'Float32Array' },   // seconds alive (game time)
  { name: 'timer', type: 'Float32Array' }, // general-purpose countdown (division, cooldown)
  { name: 'hp', type: 'Float32Array' },    // 1 = healthy, 0 = dead
  { name: 'a0', type: 'Float32Array' },
  { name: 'a1', type: 'Float32Array' },
  { name: 'a2', type: 'Float32Array' },
  { name: 'a3', type: 'Float32Array' },
]);

/* ------------------------------------------------------------------ *
 * Treatment plan — what the kid decided before pressing PLAY
 * ------------------------------------------------------------------ */

/**
 * @typedef {Object} Placement
 * @property {number} kind  KIND.*
 * @property {number} x     world units
 * @property {number} y     world units
 */

/**
 * @typedef {Object} TreatmentPlan
 * @property {number}   carTarget      ANTIGEN.* the CAR-T cells recognize
 * @property {boolean}  checkpoint     anti-PD-1 purchased
 * @property {boolean}  il2            IL-2 support purchased
 * @property {boolean}  lymphodepletion
 * @property {Placement[]} placements  cells the kid dragged onto the map
 * @property {number}   spent          credits spent
 * @property {number}   budget         credits available
 */

export const PLAN_DEFAULTS = Object.freeze({
  carTarget: ANTIGEN.GREEN,
  checkpoint: false,
  il2: false,
  lymphodepletion: false,
  placements: [],
  spent: 0,
  budget: 100,
});

/* ------------------------------------------------------------------ *
 * Round outcome
 * ------------------------------------------------------------------ */

export const OUTCOME = Object.freeze({
  RUNNING: 0,
  WIN: 1,
  LOSS_TUMOR_ESCAPED: 2,
  LOSS_PATIENT_DIED: 3,
  LOSS_TIMEOUT: 4,
  ABORTED: 5,
});

export const OUTCOME_TITLE = Object.freeze({
  [OUTCOME.WIN]: 'Tumor Cleared!',
  [OUTCOME.LOSS_TUMOR_ESCAPED]: 'The Tumor Escaped',
  [OUTCOME.LOSS_PATIENT_DIED]: 'Too Harsh on the Patient',
  [OUTCOME.LOSS_TIMEOUT]: 'Out of Time',
  [OUTCOME.ABORTED]: 'Treatment Stopped',
});

/**
 * @typedef {Object} RoundStats
 * @property {number} outcome        OUTCOME.*
 * @property {number} timeSec        game seconds elapsed
 * @property {number} tumorStart
 * @property {number} tumorRemaining
 * @property {number} tumorKilled
 * @property {number} healthyKilled
 * @property {number} patientHealth  0..100
 * @property {number} peakCrs        0..1
 * @property {number} budgetUnspent
 * @property {number} killsByKind    map KIND -> count
 * @property {Array<{t:number,tumor:number,immune:number,crs:number}>} history  sampled ~1 Hz
 */

/* ------------------------------------------------------------------ *
 * Adaptive quality tiers
 * ------------------------------------------------------------------ */

export const QUALITY = Object.freeze({
  HIGH: {
    id: 'high', maxAgents: 900, gridW: 60, gridH: 42,
    diffuseEvery: 1, particles: 1.0,
  },
  MEDIUM: {
    id: 'medium', maxAgents: 500, gridW: 48, gridH: 34,
    diffuseEvery: 2, particles: 0.5,
  },
  LOW: {
    id: 'low', maxAgents: 260, gridW: 40, gridH: 28,
    diffuseEvery: 3, particles: 0.0,
  },
});

export const QUALITY_ORDER = Object.freeze(['low', 'medium', 'high']);

/* ------------------------------------------------------------------ *
 * World geometry & loop timing
 * ------------------------------------------------------------------ */

export const WORLD_W = 1200; // world units (~µm)
export const WORLD_H = 800;

/** Fixed logical tick. Simulation is frame-rate independent and deterministic. */
export const TICK_HZ = 60;
export const TICK_DT = 1 / TICK_HZ;
export const MAX_CATCHUP_TICKS = 3;

/* ------------------------------------------------------------------ *
 * Palette — colorblind-safe, validated for deuteranopia & protanopia.
 * Identity is carried by shape + color + icon together, never color alone.
 * ------------------------------------------------------------------ */

export const COLORS = Object.freeze({
  // Cell channels. These are emissive fluorophore colors meant to be drawn additively on
  // near-black, per docs/UX.md — saturated on purpose. Muting them breaks the micrograph look.
  tumor: '#FF3D8B',        // magenta
  tumorQuiescent: '#A32A5E', // dimmed + desaturated: shielded, arrested, not dividing
  cd8: '#3D8BFF',          // blue
  cart: '#22E0E8',         // cyan — the engineered cell reads as high-tech
  nk: '#FFB020',           // amber
  macro: '#A77BFF',        // violet
  dc: '#FF7AC8',           // pink
  cd4: '#46D97A',          // green
  treg: '#B08A4A',         // olive — reads as obstacle, not ally
  vessel: '#E0453A',       // arterial red
  healthy: '#90A4B4',      // pale grey-blue, deliberately low-chroma background tissue

  void: '#05080C',
  bgTissue: '#0A1018',
  bgTissueWarm: '#0E1620',
  bgPanel: '#101A26',
  panelEdge: '#1E2E40',
  ink: '#E8F2FA',
  inkDim: '#7E93A8',
  inkFaint: '#47586B',
  good: '#46D97A',
  warn: '#FFB020',
  bad: '#FF4D4D',
});

/**
 * Colors for the five diffusing molecular fields, used by the channel rail and the field
 * haze overlay. Deliberately distinct from every cell color so a lit channel can never be
 * mistaken for a cell type, and single-hue per field so each overlay reads as one
 * fluorophore rather than a rainbow heatmap.
 */
export const FIELD_COLOR = Object.freeze({
  [FIELD.CHEMOKINE]: '#2BD9C4', // teal — the trail immune cells follow
  [FIELD.IFNG]: '#FF6B3D',      // hot orange — an alarm
  [FIELD.IL2]: '#C6F24A',       // yellow-green — energy
  [FIELD.SUPPRESS]: '#7B6BFF',  // cool indigo — a damping signal
  [FIELD.DEBRIS]: '#C9A66B',    // dull gold — inert crumbs
});

/** Distinct shapes per kind so the game is readable without color. */
export const SHAPE = Object.freeze({
  [KIND.TUMOR]: 'blob',
  [KIND.CD8]: 'circle',
  [KIND.CART]: 'hexagon',
  [KIND.NK]: 'diamond',
  [KIND.MACRO]: 'amoeba',
  [KIND.DC]: 'star',
  [KIND.CD4]: 'circle',
  [KIND.TREG]: 'square',
  [KIND.VESSEL]: 'ring',
  [KIND.HEALTHY]: 'circle',
});

/* ------------------------------------------------------------------ *
 * Screens
 * ------------------------------------------------------------------ */

export const SCREEN = Object.freeze({
  TITLE: 'title',
  LEVEL_SELECT: 'levels',
  SETUP: 'setup',
  PLAYING: 'playing',
  RESULTS: 'results',
  LEADERBOARD: 'leaderboard',
  SANDBOX: 'sandbox',
});
