/**
 * cd4.js owns local helper-cell IL-2 secretion and chemotactic movement.
 */

import { FIELD } from '../../core/contracts.js';
import { P } from '../params.js';

/**
 * Update one CD4 helper cell without allocating.
 * @param {object} round
 * @param {number} i
 * @param {number} dt
 * @returns {void}
 */
export function updateCD4(round, i, dt) {
  const world = round.world;
  round.grid.depositRadius(
    FIELD.IL2,
    world.x[i],
    world.y[i],
    P.production.il2 * dt,
    round.grid.cellW * 2,
  );
  round._move(i, FIELD.CHEMOKINE, false);
}
