#!/usr/bin/env node
/**
 * Headless simulation benchmark. It dynamically loads the engine because the
 * simulation is developed independently from this infrastructure.
 *
 * The preferred API is the documented createRound(opts) / round.tick(dt)
 * contract. A createEngine({ agentCount, level, seed }) / tick(dt) shape is
 * also accepted for a lightweight standalone engine implementation.
 */

import { mkdir, writeFile } from 'node:fs/promises';
import { dirname, join } from 'node:path';
import { performance } from 'node:perf_hooks';
import { fileURLToPath } from 'node:url';

const ROOT = fileURLToPath(new URL('..', import.meta.url));
const FRAME_MS = 16.7;
const TICK_DT = 1 / 60;
const WARMUP_TICKS = 100;
const args = process.argv.slice(2);

function flagValue(name, fallback) {
  const index = args.indexOf(name);
  return index >= 0 && args[index + 1] ? args[index + 1] : fallback;
}

function parsePositiveInteger(value, name, minimum = 1) {
  const number = Number(value);
  if (!Number.isInteger(number) || number < minimum) {
    throw new Error(`${name} must be an integer >= ${minimum}`);
  }
  return number;
}

function parseAgentCounts(value) {
  return value.split(',').map((part) => parsePositiveInteger(part.trim(), '--agents'));
}

function percentile(sorted, fraction) {
  const index = Math.min(sorted.length - 1, Math.ceil(fraction * sorted.length) - 1);
  return sorted[Math.max(0, index)];
}

function timingSnapshot(target) {
  const candidate = typeof target.getTimings === 'function'
    ? target.getTimings()
    : (target.lastTimings || target.timings || target.timing);
  if (!candidate || typeof candidate !== 'object') return null;
  const snapshot = {};
  for (const [key, value] of Object.entries(candidate)) {
    if (Number.isFinite(value)) snapshot[key] = Number(value);
  }
  return Object.keys(snapshot).length > 0 ? snapshot : null;
}

function observedAgentCount(target) {
  if (Number.isFinite(target?.world?.count)) return target.world.count;
  if (Number.isFinite(target?.agentCount)) return target.agentCount;
  if (Array.isArray(target?.agents) || ArrayBuffer.isView(target?.agents)) {
    return target.agents.length;
  }
  return null;
}

function cloneLevelForBenchmark(level, agentCount) {
  const clone = structuredClone(level);
  if (clone.tumor && Number.isFinite(clone.tumor.count)) {
    const vesselCount = Array.isArray(clone.vessels) ? clone.vessels.length : 0;
    clone.tumor.count = Math.max(1, agentCount - vesselCount);
  }
  if (clone.healthy && Number.isFinite(clone.healthy.count)) clone.healthy.count = 0;
  if (Number.isFinite(clone.tregs)) clone.tregs = 0;
  clone.tumorEscapeCap = Math.max(agentCount * 4, clone.tumorEscapeCap || 0);
  clone.timeLimitSec = Math.max(3600, clone.timeLimitSec || 0);
  return clone;
}

async function normalizeWorldCount(target, agentCount, kind) {
  const world = target?.world;
  if (!world || typeof world.spawn !== 'function') return;

  while (world.count < agentCount) {
    const index = world.count;
    const x = 20 + ((index * 37) % Math.max(40, (world.worldW || 1200) - 40));
    const y = 20 + ((index * 53) % Math.max(40, (world.worldH || 800) - 40));
    if (world.spawn(kind, x, y) < 0) {
      throw new Error(`engine capacity stopped at ${world.count} agents (requested ${agentCount})`);
    }
  }
  if (world.count > agentCount && typeof world.kill === 'function') {
    const indices = typeof world.aliveIndices === 'function'
      ? Array.from(world.aliveIndices())
      : Array.from(world.alive || [], (alive, index) => alive ? index : -1).filter((i) => i >= 0);
    for (let i = indices.length - 1; world.count > agentCount && i >= 0; i -= 1) {
      world.kill(indices[i]);
    }
  }
}

async function createTarget(engineModule, agentCount, levelId) {
  if (typeof engineModule.createRound === 'function') {
    const [levelsModule, planModule, contractsModule] = await Promise.all([
      import('../src/content/levels.js'),
      import('../src/sim/plan.js'),
      import('../src/core/contracts.js'),
    ]);
    const levels = levelsModule.LEVELS || [];
    let baseLevel = null;
    if (levelId && typeof levelsModule.getLevel === 'function') {
      try {
        baseLevel = levelsModule.getLevel(levelId);
      } catch {
        baseLevel = null;
      }
    }
    baseLevel ||= levelId
      ? levels.find((level) => (
        String(level.id) === String(levelId)
        || String(level.number) === String(levelId)
        || String(level.name).toLowerCase() === String(levelId).toLowerCase()
      ))
      : levels[0];
    if (!baseLevel) throw new Error(`level "${levelId}" is not available`);

    const level = cloneLevelForBenchmark(baseLevel, agentCount);
    const plan = typeof planModule.makePlan === 'function'
      ? planModule.makePlan({ budget: level.budget || 100 })
      : { placements: [], budget: level.budget || 100 };
    const quality = contractsModule.QUALITY?.HIGH || {
      id: 'high',
      maxAgents: Math.max(900, agentCount),
      gridW: 60,
      gridH: 42,
      diffuseEvery: 1,
      particles: 0,
    };
    const target = await engineModule.createRound({ level, plan, seed: 1, quality });
    await normalizeWorldCount(target, agentCount, contractsModule.KIND?.TUMOR || 1);
    return target;
  }

  if (typeof engineModule.createEngine === 'function') {
    return engineModule.createEngine({
      agentCount,
      agents: agentCount,
      level: levelId,
      seed: 1,
    });
  }
  throw new Error('engine must export createRound() or createEngine()');
}

function tickFunction(target) {
  const tick = typeof target.tick === 'function'
    ? target.tick.bind(target)
    : (typeof target.step === 'function' ? target.step.bind(target) : null);
  if (!tick) throw new Error('engine instance must expose tick(dt) or step(dt)');
  return tick;
}

async function measure(engineModule, agentCount, ticks, levelId) {
  const target = await createTarget(engineModule, agentCount, levelId);
  const actualCount = observedAgentCount(target);
  if (actualCount !== null && actualCount !== agentCount) {
    throw new Error(`engine created ${actualCount} agents; requested ${agentCount}`);
  }
  const tick = tickFunction(target);

  for (let i = 0; i < WARMUP_TICKS; i += 1) {
    const result = tick(TICK_DT);
    if (result && typeof result.then === 'function') await result;
  }

  const samples = new Float64Array(ticks);
  const timingTotals = new Map();
  const timingCounts = new Map();
  for (let i = 0; i < ticks; i += 1) {
    const start = performance.now();
    const result = tick(TICK_DT);
    if (result && typeof result.then === 'function') await result;
    samples[i] = performance.now() - start;
    const timings = timingSnapshot(target);
    if (timings) {
      for (const [key, value] of Object.entries(timings)) {
        timingTotals.set(key, (timingTotals.get(key) || 0) + value);
        timingCounts.set(key, (timingCounts.get(key) || 0) + 1);
      }
    }
  }

  const sorted = Array.from(samples).sort((a, b) => a - b);
  const mean = sorted.reduce((sum, value) => sum + value, 0) / sorted.length;
  const breakdown = {};
  for (const [key, total] of timingTotals) {
    breakdown[key] = total / timingCounts.get(key);
  }
  return {
    agents: agentCount,
    ticks,
    warmupTicks: WARMUP_TICKS,
    meanMs: mean,
    p50Ms: percentile(sorted, 0.50),
    p95Ms: percentile(sorted, 0.95),
    p99Ms: percentile(sorted, 0.99),
    framePercent: (mean / FRAME_MS) * 100,
    breakdown,
  };
}

function fixed(value) {
  return value.toFixed(3);
}

function breakdownText(breakdown) {
  const entries = Object.entries(breakdown);
  if (entries.length === 0) return 'total only';
  return entries.map(([key, value]) => `${key}=${fixed(value)} ms`).join('; ');
}

async function main() {
  const knownFlags = new Set(['--agents', '--ticks', '--level']);
  for (let i = 0; i < args.length; i += 1) {
    if (!args[i].startsWith('--')) continue;
    if (!knownFlags.has(args[i])) throw new Error(`unknown option: ${args[i]}`);
    i += 1;
  }

  let engineModule;
  try {
    engineModule = await import('../src/sim/engine.js');
  } catch {
    console.log('engine not available yet — src/sim/engine.js could not be imported; benchmark skipped.');
    return;
  }

  const agentCounts = parseAgentCounts(flagValue('--agents', '150,300,600,900'));
  const ticks = parsePositiveInteger(flagValue('--ticks', '600'), '--ticks', 600);
  const levelId = flagValue('--level', '');
  const results = [];
  for (const agentCount of agentCounts) {
    results.push(await measure(engineModule, agentCount, ticks, levelId));
  }

  console.log('| Agents | Mean ms | p50 ms | p95 ms | p99 ms | Frame headroom | Timing breakdown |');
  console.log('| ---: | ---: | ---: | ---: | ---: | :--- | :--- |');
  for (const row of results) {
    const freeMs = FRAME_MS - row.meanMs;
    console.log(
      `| ${row.agents} | ${fixed(row.meanMs)} | ${fixed(row.p50Ms)} | `
      + `${fixed(row.p95Ms)} | ${fixed(row.p99Ms)} | sim uses `
      + `${row.framePercent.toFixed(1)}% of the frame (${freeMs.toFixed(2)} ms free) | `
      + `${breakdownText(row.breakdown)} |`
    );
  }

  const payload = {
    generatedAt: new Date().toISOString(),
    frameBudgetMs: FRAME_MS,
    level: levelId,
    results,
  };
  const outputPath = join(ROOT, 'bench-results', 'latest.json');
  await mkdir(dirname(outputPath), { recursive: true });
  await writeFile(outputPath, `${JSON.stringify(payload, null, 2)}\n`);
  console.log(`\nWrote bench-results/latest.json`);
}

main().catch((error) => {
  console.error(`bench: ${error.message}`);
  process.exitCode = 1;
});
