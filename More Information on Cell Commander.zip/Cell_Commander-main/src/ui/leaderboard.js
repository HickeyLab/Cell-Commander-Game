/**
 * leaderboard.js — owns safe, top-25 score persistence and initials filtering for
 * per-level, per-daily-seed leaderboards plus the booth leaderboard screen.
 */

import { SCREEN } from '../core/contracts.js';
import {
  button,
  chip,
} from './components.js';

const SCORE_PREFIX = 'cc.scores.v1.';
export const SCORE_LIMIT = 25;
const BLOCKED_INITIALS = new Set([
  'ASS', 'CUM', 'FAG', 'FUC', 'FUK', 'KKK', 'NGR', 'SEX',
]);

let storageBackend;
const memoryStore = new Map();
const knownKeys = new Set();

function scoreKey(levelId, seed) {
  return `${SCORE_PREFIX}${String(levelId)}.${String(seed)}`;
}

function getBackend() {
  if (storageBackend !== undefined) {
    return storageBackend;
  }
  try {
    return globalThis.localStorage ?? null;
  } catch {
    return null;
  }
}

function safeGet(key) {
  const backend = getBackend();
  if (backend) {
    try {
      const value = backend.getItem(key);
      if (value !== null) {
        return value;
      }
    } catch {
      // Session memory remains available when Safari denies storage access.
    }
  }
  return memoryStore.get(key) ?? null;
}

function safeSet(key, value) {
  memoryStore.set(key, value);
  knownKeys.add(key);
  const backend = getBackend();
  if (!backend) {
    return;
  }
  try {
    backend.setItem(key, value);
  } catch {
    // Keeping the memory copy is the intentional private-browsing fallback.
  }
}

function safeRemove(key) {
  memoryStore.delete(key);
  knownKeys.delete(key);
  const backend = getBackend();
  if (!backend) {
    return;
  }
  try {
    backend.removeItem(key);
  } catch {
    // There is nothing else to remove from the session fallback.
  }
}

function allScoreKeys() {
  const keys = new Set([...knownKeys, ...memoryStore.keys()]);
  const backend = getBackend();
  if (backend) {
    try {
      for (let index = 0; index < backend.length; index += 1) {
        const key = backend.key(index);
        if (typeof key === 'string' && key.startsWith(SCORE_PREFIX)) {
          keys.add(key);
        }
      }
    } catch {
      // Known session keys are still sufficient for degraded operation.
    }
  }
  return [...keys].filter((key) => key.startsWith(SCORE_PREFIX));
}

function normalizeInitials(initials) {
  return String(initials ?? '')
    .toUpperCase()
    .replace(/[^A-Z0-9]/g, '')
    .slice(0, 3);
}

function normalizeEntry(entry) {
  if (!entry || !Number.isFinite(Number(entry.score))
    || !Number.isFinite(Number(entry.timeSec))) {
    return null;
  }
  const initials = normalizeInitials(entry.initials);
  const safeInitials = initials && isInitialsAllowed(initials)
    ? initials.padEnd(3, '·')
    : '***';
  return {
    initials: safeInitials,
    score: Math.max(0, Math.round(Number(entry.score))),
    timeSec: Math.max(0, Number(entry.timeSec)),
    when: Number.isFinite(Number(entry.when)) ? Number(entry.when) : Date.now(),
  };
}

function sortAndCap(entries) {
  return entries
    .map(normalizeEntry)
    .filter(Boolean)
    .sort((a, b) => b.score - a.score || a.timeSec - b.timeSec || a.when - b.when)
    .slice(0, SCORE_LIMIT);
}

function readKey(key) {
  const raw = safeGet(key);
  if (!raw) {
    return [];
  }
  try {
    const parsed = JSON.parse(raw);
    return Array.isArray(parsed) ? sortAndCap(parsed) : [];
  } catch {
    return [];
  }
}

/**
 * Injects a Storage-compatible backend. Passing undefined restores automatic
 * localStorage discovery. Primarily useful for deterministic tests.
 * @param {Storage|object|undefined} backend
 */
export function setStorageBackend(backend) {
  storageBackend = backend;
  memoryStore.clear();
  knownKeys.clear();
}

/**
 * Reports whether a candidate is safe to display on the booth leaderboard.
 * @param {string} initials
 * @returns {boolean}
 */
export function isInitialsAllowed(initials) {
  const normalized = normalizeInitials(initials);
  return normalized.length > 0 && !BLOCKED_INITIALS.has(normalized);
}

/**
 * Loads sorted scores for one level and deterministic seed.
 * @param {string|number} levelId
 * @param {string|number} seed
 * @returns {Array<{initials:string,score:number,timeSec:number,when:number}>}
 */
export function loadScores(levelId, seed) {
  return readKey(scoreKey(levelId, seed));
}

/**
 * Saves one entry and returns the updated sorted top 25.
 * @param {string|number} levelId
 * @param {string|number} seed
 * @param {{initials:string,score:number,timeSec:number,when:number}} entry
 * @returns {Array<{initials:string,score:number,timeSec:number,when:number}>}
 */
export function saveScore(levelId, seed, entry) {
  const key = scoreKey(levelId, seed);
  const updated = sortAndCap([...readKey(key), entry]);
  safeSet(key, JSON.stringify(updated));
  return updated;
}

/**
 * Clears every score group, or only groups belonging to one level.
 * @param {string|number} [levelId]
 * @returns {void}
 */
export function clearScores(levelId) {
  const prefix = levelId === undefined
    ? SCORE_PREFIX
    : `${SCORE_PREFIX}${String(levelId)}.`;
  for (const key of allScoreKeys()) {
    if (key.startsWith(prefix)) {
      safeRemove(key);
    }
  }
}

/**
 * Exports all leaderboard groups as versioned JSON.
 * @returns {string}
 */
export function exportScores() {
  const scores = {};
  for (const key of allScoreKeys().sort()) {
    scores[key] = readKey(key);
  }
  return JSON.stringify({ version: 1, scores });
}

/**
 * Imports a versioned leaderboard export, merging and re-sorting each group.
 * @param {string} json
 * @returns {void}
 */
export function importScores(json) {
  const parsed = JSON.parse(json);
  if (!parsed || parsed.version !== 1 || !parsed.scores
    || typeof parsed.scores !== 'object' || Array.isArray(parsed.scores)) {
    throw new TypeError('That file is not a Cell Commander score export.');
  }
  for (const [key, entries] of Object.entries(parsed.scores)) {
    if (!key.startsWith(SCORE_PREFIX) || !Array.isArray(entries)) {
      continue;
    }
    const merged = sortAndCap([...readKey(key), ...entries]);
    safeSet(key, JSON.stringify(merged));
  }
}

function formatTime(timeSec) {
  const total = Math.max(0, Math.round(Number(timeSec) || 0));
  return `${Math.floor(total / 60)}:${String(total % 60).padStart(2, '0')}`;
}

function renderRows(tableBody, scores) {
  tableBody.replaceChildren();
  if (scores.length === 0) {
    const row = document.createElement('tr');
    const cell = document.createElement('td');
    cell.colSpan = 4;
    cell.className = 'leaderboard-empty';
    cell.textContent = 'No scores yet. Be the first.';
    row.append(cell);
    tableBody.append(row);
    return;
  }
  scores.forEach((entry, index) => {
    const row = document.createElement('tr');
    for (const value of [
      String(index + 1).padStart(2, '0'),
      entry.initials,
      entry.score.toLocaleString('en-US'),
      formatTime(entry.timeSec),
    ]) {
      const cell = document.createElement('td');
      cell.textContent = value;
      row.append(cell);
    }
    tableBody.append(row);
  });
}

/**
 * Mounts the public top-25 table and hidden booth-operator controls.
 * @param {HTMLElement} rootEl
 * @param {{app:object,level:object}} ctx
 * @returns {{unmount:()=>void}}
 */
export function mount(rootEl, ctx) {
  // Only levels 1-5 are scored, and only those get a tab in the strip below. Inheriting
  // ctx.level blindly meant that arriving here straight from Sandbox showed the heading
  // "Level 6: Sandbox" with an empty table and no tab highlighted — the player could not tell
  // what they were looking at or that other levels existed. Fall back to the first scoreable
  // level whenever the incoming one has no board.
  const scoreable = (ctx.app.levels ?? []).filter((item) => Number(item.number) <= 5);
  const incoming = ctx.level;
  const isScoreable = incoming && Number(incoming.number) <= 5;
  let level = (isScoreable ? incoming : scoreable[0])
    ?? ctx.app.levels?.[0]
    ?? { id: '1', number: 1, name: 'First Contact' };
  let seed = ctx.app.dailySeedFor?.(level.id) ?? ctx.app.seed ?? 'today';
  let operatorPressTimer = 0;

  const screen = document.createElement('main');
  screen.className = 'cc-screen leaderboard-screen';
  const header = document.createElement('header');
  header.className = 'screen-header leaderboard-header';
  const headingWrap = document.createElement('div');
  const eyebrow = document.createElement('p');
  eyebrow.className = 'instrument-label';
  eyebrow.textContent = 'Booth record / Daily specimen';
  const title = document.createElement('h1');
  title.textContent = 'Leaderboard';
  headingWrap.append(eyebrow, title);
  const operatorControl = button('⚙', {
    className: 'cc-button--quiet',
    ariaLabel: 'Booth operator controls',
  });
  const back = button('← Back', {
    className: 'cc-button--quiet',
    onClick: () => ctx.app.go(SCREEN.TITLE),
  });
  header.append(headingWrap, operatorControl, back);

  const operatorPrompt = document.createElement('div');
  operatorPrompt.className = 'operator-actions';
  operatorPrompt.hidden = true;
  const operatorPromptText = document.createElement('span');
  operatorPromptText.textContent = 'Open operator controls?';
  const confirmOperator = button('Yes', {
    className: 'cc-button--quiet',
    onClick: () => {
      operatorPrompt.hidden = true;
      operator.hidden = false;
      hideOperator.focus();
    },
  });
  const cancelOperator = button('Cancel', {
    className: 'cc-button--quiet',
    onClick: () => {
      operatorPrompt.hidden = true;
      operatorControl.focus();
    },
  });
  operatorPrompt.append(operatorPromptText, confirmOperator, cancelOperator);

  const levelStrip = document.createElement('nav');
  levelStrip.className = 'leaderboard-levels';
  levelStrip.setAttribute('aria-label', 'Choose leaderboard level');
  const levelButtons = new Map();
  const tableTitle = document.createElement('h2');
  const tableBody = document.createElement('tbody');

  function refresh(nextLevel = level) {
    level = nextLevel;
    seed = ctx.app.dailySeedFor?.(level.id) ?? seed;
    ctx.app.seed = seed;
    tableTitle.textContent = `Level ${level.number}: ${level.name}`;
    renderRows(tableBody, loadScores(level.id, seed));
    for (const [id, control] of levelButtons) {
      const selected = String(id) === String(level.id);
      control.classList.toggle('is-active', selected);
      control.setAttribute('aria-pressed', String(selected));
    }
  }

  const levels = (ctx.app.levels ?? [level]).filter((item) => Number(item.number) <= 5);
  for (const item of levels) {
    const control = button(`L${item.number}`, {
      className: 'cc-button--quiet leaderboard-level',
      pressed: String(item.id) === String(level.id),
      ariaLabel: `Show ${item.name} scores`,
    });
    control.addEventListener('click', () => refresh(item));
    levelButtons.set(item.id, control);
    levelStrip.append(control);
  }

  const dailyNote = document.createElement('aside');
  dailyNote.className = 'daily-tumor-note';
  dailyNote.append(
    chip('Today’s tumor', { tone: 'science', icon: '◉' }),
    document.createTextNode(
      'Every kid today faces the identical tumor. Tomorrow brings a new specimen.',
    ),
  );

  const board = document.createElement('section');
  board.className = 'leaderboard-board instrument-panel';
  const table = document.createElement('table');
  table.className = 'leaderboard-table';
  const head = document.createElement('thead');
  const headingRow = document.createElement('tr');
  for (const text of ['Rank', 'Initials', 'Score', 'Time']) {
    const cell = document.createElement('th');
    cell.scope = 'col';
    cell.textContent = text;
    headingRow.append(cell);
  }
  head.append(headingRow);
  table.append(head, tableBody);
  board.append(tableTitle, table);

  const operator = document.createElement('section');
  operator.className = 'operator-panel';
  operator.hidden = true;
  const operatorTitle = document.createElement('h2');
  operatorTitle.textContent = 'Booth operator';
  const hideOperator = button('Hide operator controls', {
    className: 'cc-button--quiet',
    onClick: () => {
      operator.hidden = true;
      operatorPrompt.hidden = true;
      cancelClearConfirmation();
      operatorControl.focus();
    },
  });
  const operatorHelp = document.createElement('p');
  operatorHelp.textContent = 'Reset this level or move scores between booth devices.';
  const scoreData = document.createElement('textarea');
  scoreData.className = 'operator-data';
  scoreData.rows = 5;
  scoreData.spellcheck = false;
  scoreData.setAttribute('aria-label', 'Score export or import JSON');
  const operatorStatus = document.createElement('p');
  operatorStatus.className = 'inline-caution';
  operatorStatus.setAttribute('aria-live', 'polite');
  const operatorActions = document.createElement('div');
  operatorActions.className = 'operator-actions';
  const reset = button('Clear this level', {
    className: 'cc-button--danger',
    onClick: () => {
      pendingClearLevel = level;
      const count = loadScores(level.id, seed).length;
      clearPromptText.textContent = `Clear ${count} scores for Level ${level.number}?`;
      reset.hidden = true;
      clearPrompt.hidden = false;
      confirmClear.focus();
    },
  });
  const exportButton = button('Export all', {
    className: 'cc-button--quiet',
    onClick: () => {
      scoreData.value = exportScores();
      scoreData.select();
      operatorStatus.textContent = 'Score JSON is ready to copy.';
    },
  });
  const importButton = button('Import JSON', {
    className: 'cc-button--quiet',
    onClick: () => {
      try {
        importScores(scoreData.value);
        refresh();
        operatorStatus.textContent = 'Scores imported.';
      } catch (error) {
        operatorStatus.textContent = error instanceof Error
          ? error.message
          : 'That score export could not be read.';
      }
    },
  });
  operatorActions.append(reset, exportButton, importButton);
  const clearPrompt = document.createElement('div');
  clearPrompt.className = 'operator-actions';
  clearPrompt.hidden = true;
  const clearPromptText = document.createElement('span');
  let pendingClearLevel = null;
  const confirmClear = button('Clear', {
    className: 'cc-button--danger',
    onClick: () => {
      if (!pendingClearLevel) {
        return;
      }
      const clearedLevel = pendingClearLevel;
      clearScores(clearedLevel.id);
      cancelClearConfirmation();
      refresh();
      operatorStatus.textContent = `Level ${clearedLevel.number} scores cleared.`;
    },
  });
  const cancelClear = button('Cancel', {
    className: 'cc-button--quiet',
    onClick: () => {
      cancelClearConfirmation();
      reset.focus();
    },
  });
  clearPrompt.append(clearPromptText, confirmClear, cancelClear);
  operator.append(
    operatorTitle,
    hideOperator,
    operatorHelp,
    scoreData,
    operatorActions,
    clearPrompt,
    operatorStatus,
  );

  function cancelClearConfirmation() {
    pendingClearLevel = null;
    clearPrompt.hidden = true;
    reset.hidden = false;
  }

  function beginOperatorPress() {
    clearTimeout(operatorPressTimer);
    operatorPressTimer = setTimeout(() => {
      operatorPrompt.hidden = false;
      confirmOperator.focus();
    }, 5000);
  }
  function endOperatorPress() {
    clearTimeout(operatorPressTimer);
  }
  operatorControl.addEventListener('pointerdown', beginOperatorPress);
  operatorControl.addEventListener('pointerup', endOperatorPress);
  operatorControl.addEventListener('pointercancel', endOperatorPress);
  operatorControl.addEventListener('pointerleave', endOperatorPress);

  screen.append(header, operatorPrompt, levelStrip, dailyNote, board, operator);
  rootEl.replaceChildren(screen);
  refresh();

  return {
    unmount() {
      clearTimeout(operatorPressTimer);
      screen.remove();
    },
  };
}
