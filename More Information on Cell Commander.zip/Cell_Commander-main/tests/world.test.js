/**
 * world.test.js verifies slot lifecycle, typed-column reset, capacity handling,
 * alive iteration, and order-independent deterministic hashing.
 */

import test from 'node:test';
import assert from 'node:assert/strict';

import { ANTIGEN, KIND, STATE } from '../src/core/contracts.js';
import { makeRng } from '../src/core/rng.js';
import { makeWorld } from '../src/sim/world.js';

test('spawn, kill, and free-list reuse preserve slots and reset every column', () => {
  const world = makeWorld({
    capacity: 3,
    worldW: 1200,
    worldH: 800,
    rng: makeRng(11),
  });
  const first = world.spawn(KIND.TUMOR, 100, 120);
  const second = world.spawn(KIND.CD8, 200, 220);

  world.vx[first] = 9;
  world.vy[first] = -8;
  world.age[first] = 7;
  world.timer[first] = 6;
  world.a0[first] = ANTIGEN.ORANGE;
  world.a1[first] = 0.2;
  world.a2[first] = 0.9;
  world.a3[first] = 1234;
  world.kill(first);

  assert.equal(world.count, 1);
  assert.equal(world.alive[first], 0);
  assert.equal(world.state[first], STATE.DEAD);

  const reused = world.spawn(KIND.HEALTHY, 300, 320);
  assert.equal(reused, first);
  assert.equal(world.count, 2);
  assert.equal(world.kind[reused], KIND.HEALTHY);
  assert.equal(world.alive[reused], 1);
  assert.equal(world.x[reused], 300);
  assert.equal(world.y[reused], 320);
  assert.equal(world.vx[reused], 0);
  assert.equal(world.vy[reused], 0);
  assert.equal(world.age[reused], 0);
  assert.equal(world.timer[reused], 0);
  assert.equal(world.hp[reused], 1);
  assert.equal(world.a0[reused], ANTIGEN.NONE);
  assert.equal(world.a1[reused], 0);
  assert.equal(world.a2[reused], 0);
  assert.equal(world.a3[reused], 0);
  assert.equal(world.alive[second], 1);
});

test('capacity is respected without corrupting count or existing slots', () => {
  const world = makeWorld({
    capacity: 2,
    worldW: 1200,
    worldH: 800,
    rng: makeRng(12),
  });

  assert.equal(world.spawn(KIND.TUMOR, 10, 20), 0);
  assert.equal(world.spawn(KIND.NK, 30, 40), 1);
  assert.equal(world.spawn(KIND.CD4, 50, 60), -1);
  assert.equal(world.count, 2);
  assert.deepEqual(Array.from(world.alive), [1, 1]);
  assert.deepEqual(Array.from(world.kind), [KIND.TUMOR, KIND.NK]);
});

test('countOf, forEachAlive, and aliveIndices ignore dead slots', () => {
  const world = makeWorld({
    capacity: 5,
    worldW: 1200,
    worldH: 800,
    rng: makeRng(13),
  });
  const tumorA = world.spawn(KIND.TUMOR, 1, 2);
  const cd8 = world.spawn(KIND.CD8, 3, 4);
  world.spawn(KIND.TUMOR, 5, 6);
  world.kill(tumorA);

  const visited = [];
  world.forEachAlive((i) => visited.push(i));

  assert.deepEqual(visited, [cd8, 2]);
  assert.deepEqual(Array.from(world.aliveIndices()), [cd8, 2]);
  assert.equal(world.countOf(KIND.TUMOR), 1);
  assert.equal(world.countOf(KIND.CD8), 1);
  assert.equal(world.count, 2);
});

test('hash is independent of slot and spawn order for the same live state', () => {
  const specs = [
    [KIND.TUMOR, 101.25, 202.5, ANTIGEN.BLUE, 0.75, 0.2, 400],
    [KIND.CD8, 303.75, 404.5, 1, 0.125, 2, -1],
    [KIND.HEALTHY, 505.25, 606.5, ANTIGEN.ORANGE, 0, 0, 200],
  ];

  function build(order) {
    const world = makeWorld({
      capacity: 8,
      worldW: 1200,
      worldH: 800,
      rng: makeRng(99),
    });
    for (const specIndex of order) {
      const spec = specs[specIndex];
      const i = world.spawn(spec[0], spec[1], spec[2]);
      world.a0[i] = spec[3];
      world.a1[i] = spec[4];
      world.a2[i] = spec[5];
      world.a3[i] = spec[6];
      world.age[i] = 1.5;
      world.timer[i] = 2.25;
    }
    return world;
  }

  const forward = build([0, 1, 2]);
  const reverse = build([2, 1, 0]);

  assert.equal(forward.hash(), reverse.hash());
  reverse.x[0] += 0.5;
  assert.notEqual(forward.hash(), reverse.hash());
});
