# Cell Commander

**Build an immune army. Pick your target. Clear the tumor before it takes over.**

A hands-on immunotherapy strategy game for K–12 outreach. Kids choose which immune cells to
deploy, where to put them, and what their CAR-T cells should hunt — then watch a real
agent-based simulation play out on a live fluorescence-microscope view of the tissue.

It runs in a browser, works offline on an iPad, needs no installation, and every rule in it
is real immunology.

---

## Why this exists

Explaining cancer immunotherapy to a 10-year-old normally means a poster and a lot of talking.
This turns it into something they *do*. In about ninety seconds a kid discovers, by playing:

- Killer T cells have to physically touch a cancer cell to kill it, and it takes time.
- Attacking a tumor makes it put up a shield — and there is a drug that removes the shield.
- Some cancer cells hide the flag your CAR-T was built to find, so one therapy is rarely enough.
- Immune cells follow chemical trails, so *where* you put them decides whether they ever arrive.
- Winning too hard hurts the patient. Real oncologists manage that trade-off every day.

Those are not simplifications invented for a game. They are checkpoint blockade, antigen escape,
chemotaxis, and cytokine release syndrome — the actual reasons CAR-T therapy succeeds and fails
in patients.

---

## Play it

Three ways, in order of how little setup they need. Full instructions in [`docs/DEPLOY.md`](docs/DEPLOY.md).

**On an iPad with no internet** — copy `dist/cell-commander.html` to the iPad (AirDrop, email,
or a USB drive), open it from Files, tap "Open in Safari". One file, no server, fully offline.

**From a laptop, for several iPads at once**
```bash
npm run serve
```
Open the printed `Tablet:` URL on each iPad over the same Wi-Fi.

**As a home-screen app** — host the repo on any static host, open it in Safari, and use
Share → Add to Home Screen. It installs as a full-screen offline app with no browser chrome,
which is what you want at a booth.

---

## What's under it

A genuine agent-based model, not an animation. Every frame it:

1. Diffuses five molecular fields (chemokine, IFN-γ, IL-2, suppressive signals, tumor debris)
   across a grid with zero-flux boundaries.
2. Runs a behavior pass over every cell — chemotaxis up its attractant gradient, recognition
   of targets, cytotoxic packet delivery, state transitions.
3. Resolves physical overlap so cells crowd realistically.
4. Updates patient-level meters and checks win/loss.

The simulation is deterministic: the same seed and the same plan produce the identical result
every time. That is what makes the leaderboard fair and the whole thing testable.

### Where the science comes from

Cell Commander is a real-time descendant of the Hickey lab's published tumor microenvironment
agent-based model:

> Hickey, J.W., Agmon, E., Horowitz, N., Lamore, M., Sunwoo, J.B., Covert, M.W. & Nolan, G.P.
> *Integrating Multiplexed Imaging and Multiscale Modeling Identifies Tumor Phenotype
> Transformation as a Critical Component of Therapeutic T Cell Efficacy.* Cell Systems.

Parameters are taken from that model wherever it has them. Every constant in
[`src/sim/params.js`](src/sim/params.js) carries one of four provenance tags:

| Tag | Meaning |
|---|---|
| `[MODEL]` | Taken from the research model. Names the source file and its literature citation. |
| `[SCALED]` | A research value deliberately rescaled for real-time play. Records the original, the factor, and why. |
| `[DERIVED]` | Computed from other tagged values, with the arithmetic shown. |
| `[GAME]` | A game-design number making no biological claim. |

This is enforced, not promised: `tests/params.test.js` fails the build if any constant is
untagged, if a `[MODEL]` tag names no source, or if a `[SCALED]` tag does not justify its
deviation. Writing that test immediately caught three real defects, including a value tagged
`[MODEL]` that the research model does not actually contain.

**The one honest departure** is time. The research model simulates three days; a booth round has
to finish in two minutes. One constant, `BIO_MIN_PER_GAME_SEC`, does that conversion in a single
place, so every rate stays in correct relative proportion. Cell migration is additionally slowed
to a quarter of that rate — at full compression cells would cross the field in twelve seconds and
contact-dependent killing would be invisible. Relative speeds between cell types are preserved
exactly. Both decisions are documented at the point of use rather than buried.

---

## Can a tablet really run this?

Not the research model — and it does not need to.

| | Research ABM | Cell Commander |
|---|---|---|
| Agents | ~1,200 | 150–900, adaptive |
| Fields | fine grid, PDE solver | 5 fields on a 60×42 grid |
| Physics | pymunk rigid-body | circle overlap relaxation |
| Runtime | minutes to hours per run | real time, 60 fps |

The gap is not mainly agent count — it is cost per agent. The research model evaluates a full
process graph per agent per step, plus a physics engine and a PDE solve. Cell Commander runs a
flat numeric update over typed arrays with no allocation in the hot loop. That difference is what
turns "minutes per run" into "sixty frames per second".

The game measures its own frame time and steps quality down automatically on slower hardware, so
an old iPad gets fewer cells rather than a slideshow. Measured numbers are in
[`docs/PERFORMANCE.md`](docs/PERFORMANCE.md); reproduce them with `npm run bench`.

---

## Develop

No dependencies, no build step, no `node_modules`. Requires Node 18+ only for the tests and
the dev server.

```bash
npm test          # unit + simulation tests (node:test)
npm run serve     # dev server at localhost:8080
npm run bench     # headless performance measurement
npm run build     # produce the single-file offline bundle in dist/
```

### Layout

```
src/core/      seeded RNG, diffusion grid, spatial hash, frame-time monitor
src/sim/       the model: world state, engine, per-cell-type behaviors, scoring
src/render/    canvas drawing — reads the simulation, never writes to it
src/ui/        screens, touch input, leaderboard
src/content/   level definitions and the kid-facing science cards
```

The layering is enforced by `tests/architecture.test.js`: `src/sim/` may not use `Math.random`,
may not touch the DOM, and may not import from `render/` or `ui/`. Those three rules are what
keep the model deterministic, headless, testable, and reusable.

### Documents

| File | What it's for |
|---|---|
| [`DESIGN.md`](DESIGN.md) | The full specification: mechanics, levels, scoring, performance budget |
| [`docs/UX.md`](docs/UX.md) | Visual and interaction design brief |
| [`docs/API.md`](docs/API.md) | Module interface contract |
| [`docs/DEPLOY.md`](docs/DEPLOY.md) | Running it at a booth |
| [`docs/SCIENCE.md`](docs/SCIENCE.md) | Every mechanic mapped to the immunology it teaches |

---

## For teachers and volunteers

`docs/SCIENCE.md` maps each game mechanic to the concept it teaches and gives you a sentence to
say when a kid asks why something happened. Every level ends with a card naming the real biology,
written at two levels — one for the kid, one for the adult reading over their shoulder.

Nothing in the game is graded, timed against other kids unfairly, or punishing. Losing screens
lead with what the player discovered.

## License

MIT.
