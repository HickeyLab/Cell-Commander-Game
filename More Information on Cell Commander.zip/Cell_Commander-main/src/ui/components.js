/**
 * components.js — dependency-free DOM factories for Cell Commander's shared,
 * touch-first instrument controls and accessible status displays.
 */

function makeElement(tag, className, text) {
  const node = document.createElement(tag);
  if (className) {
    node.className = className;
  }
  if (text !== undefined) {
    node.textContent = text;
  }
  return node;
}

/**
 * Creates a chunky, keyboard-operable action button.
 * @param {string} label
 * @param {{className?:string,onClick?:(event:Event)=>void,disabled?:boolean,
 * type?:string,ariaLabel?:string,pressed?:boolean}} [options]
 * @returns {HTMLButtonElement}
 */
export function button(label, options = {}) {
  const node = makeElement('button', `cc-button ${options.className ?? ''}`.trim(), label);
  node.type = options.type ?? 'button';
  node.disabled = Boolean(options.disabled);
  if (options.ariaLabel) {
    node.setAttribute('aria-label', options.ariaLabel);
  }
  if (options.pressed !== undefined) {
    node.setAttribute('aria-pressed', String(options.pressed));
  }
  if (options.onClick) {
    node.addEventListener('click', options.onClick);
  }
  return node;
}

/**
 * Creates a compact status or hint chip.
 * @param {string} text
 * @param {{tone?:string,icon?:string}} [options]
 * @returns {HTMLSpanElement}
 */
export function chip(text, options = {}) {
  const node = makeElement('span', `cc-chip cc-chip--${options.tone ?? 'neutral'}`);
  if (options.icon) {
    node.append(icon(options.icon));
  }
  node.append(document.createTextNode(text));
  return node;
}

/**
 * Creates an accessible labeled meter with an imperative update helper.
 * @param {string} label
 * @param {number} value
 * @param {{max?:number,unit?:string,tone?:string}} [options]
 * @returns {HTMLElement & {setValue:(value:number,max?:number)=>void}}
 */
export function meter(label, value, options = {}) {
  const max = options.max ?? 100;
  const root = makeElement('div', `cc-meter cc-meter--${options.tone ?? 'normal'}`);
  const row = makeElement('div', 'cc-meter__row');
  const labelEl = makeElement('span', 'instrument-label', label);
  const readout = makeElement('output', 'cc-meter__value');
  const track = makeElement('div', 'cc-meter__track');
  const fill = makeElement('span', 'cc-meter__fill');
  track.setAttribute('role', 'meter');
  track.setAttribute('aria-label', label);
  track.append(fill);
  row.append(labelEl, readout);
  root.append(row, track);

  root.setValue = (nextValue, nextMax = max) => {
    const safeMax = Math.max(1, Number(nextMax) || 1);
    const safeValue = Math.max(0, Math.min(safeMax, Number(nextValue) || 0));
    const percent = (safeValue / safeMax) * 100;
    readout.textContent = `${Math.round(safeValue)}${options.unit ?? ''}`;
    fill.style.width = `${percent}%`;
    track.setAttribute('aria-valuemin', '0');
    track.setAttribute('aria-valuemax', String(safeMax));
    track.setAttribute('aria-valuenow', String(safeValue));
  };
  root.setValue(value, max);
  return root;
}

/**
 * Creates a modal surface. Call its close method to remove it.
 * @param {string} title
 * @param {Node|string} content
 * @param {{dismissLabel?:string,onClose?:()=>void}} [options]
 * @returns {HTMLElement & {close:()=>void}}
 */
export function modal(title, content, options = {}) {
  const scrim = makeElement('div', 'cc-modal');
  const surface = makeElement('section', 'cc-modal__surface');
  const heading = makeElement('h2', 'cc-modal__title', title);
  const body = makeElement('div', 'cc-modal__body');
  const closeButton = button(options.dismissLabel ?? 'Close', { className: 'cc-button--quiet' });
  scrim.setAttribute('role', 'dialog');
  scrim.setAttribute('aria-modal', 'true');
  scrim.setAttribute('aria-labelledby', `modal-${Date.now()}`);
  heading.id = scrim.getAttribute('aria-labelledby');
  body.append(typeof content === 'string' ? document.createTextNode(content) : content);
  surface.append(heading, body, closeButton);
  scrim.append(surface);
  scrim.close = () => {
    scrim.remove();
    options.onClose?.();
  };
  closeButton.addEventListener('click', scrim.close);
  return scrim;
}

/**
 * Creates a labeled range input with a stable numeric readout.
 * @param {string} label
 * @param {{min:number,max:number,value:number,step?:number,unit?:string,
 * onInput?:(value:number)=>void,onCommit?:(value:number)=>void}} options
 * @returns {HTMLElement & {input:HTMLInputElement,setValue:(value:number)=>void}}
 */
export function slider(label, options) {
  const root = makeElement('label', 'cc-slider');
  const row = makeElement('span', 'cc-slider__row');
  const labelEl = makeElement('span', 'instrument-label', label);
  const output = makeElement('output', 'cc-slider__value');
  const input = makeElement('input', 'cc-slider__input');
  input.type = 'range';
  input.min = String(options.min);
  input.max = String(options.max);
  input.step = String(options.step ?? 1);
  input.value = String(options.value);
  const renderValue = (value) => {
    output.textContent = `${value}${options.unit ?? ''}`;
  };
  renderValue(options.value);
  input.addEventListener('input', () => {
    const value = Number(input.value);
    renderValue(value);
    options.onInput?.(value);
  });
  input.addEventListener('change', () => options.onCommit?.(Number(input.value)));
  input.addEventListener('pointerup', () => options.onCommit?.(Number(input.value)));
  row.append(labelEl, output);
  root.append(row, input);
  root.input = input;
  root.setValue = (value) => {
    input.value = String(value);
    renderValue(value);
  };
  return root;
}

/**
 * Creates a single-choice segmented control.
 * @param {Array<{value:string|number,label:string,icon?:string}>} items
 * @param {{value:string|number,label:string,onChange:(value:string|number)=>void}} options
 * @returns {HTMLElement & {setValue:(value:string|number)=>void}}
 */
export function segmentedControl(items, options) {
  const root = makeElement('div', 'cc-segmented');
  const label = makeElement('span', 'sr-only', options.label);
  const controls = new Map();
  root.setAttribute('role', 'group');
  root.setAttribute('aria-label', options.label);
  root.append(label);
  const select = (value, notify) => {
    for (const [itemValue, control] of controls) {
      const selected = String(itemValue) === String(value);
      control.classList.toggle('is-active', selected);
      control.setAttribute('aria-pressed', String(selected));
    }
    if (notify) {
      options.onChange(value);
    }
  };
  for (const item of items) {
    const control = button('', { className: 'cc-segmented__item' });
    if (item.icon) {
      control.append(icon(item.icon));
    }
    control.append(document.createTextNode(item.label));
    control.addEventListener('click', () => select(item.value, true));
    controls.set(item.value, control);
    root.append(control);
  }
  root.setValue = (value) => select(value, false);
  root.setValue(options.value);
  return root;
}

/**
 * Creates a decorative text icon whose identity also appears in adjacent text.
 * @param {string} glyph
 * @param {string} [className]
 * @returns {HTMLSpanElement}
 */
export function icon(glyph, className = '') {
  const node = makeElement('span', `cc-icon ${className}`.trim(), glyph);
  node.setAttribute('aria-hidden', 'true');
  return node;
}

/**
 * Creates the five-channel microscope rail.
 * @param {Array<{id:number,label:string,glyph:string,className:string}>} channels
 * @param {(id:number|null)=>void} [onChange]
 * @returns {HTMLElement}
 */
export function channelRail(channels, onChange) {
  const rail = makeElement('nav', 'channel-rail');
  const heading = makeElement('span', 'instrument-label channel-rail__title', 'Channels');
  let active = null;
  rail.setAttribute('aria-label', 'Molecular image channels');
  rail.append(heading);
  for (const channel of channels) {
    const control = button('', {
      className: `channel-toggle ${channel.className}`,
      ariaLabel: `Show ${channel.label}`,
      pressed: false,
    });
    control.append(
      icon(channel.glyph, 'channel-toggle__dot'),
      makeElement('span', 'channel-toggle__short', channel.label),
    );
    control.addEventListener('click', () => {
      active = active === channel.id ? null : channel.id;
      for (const node of rail.querySelectorAll('.channel-toggle')) {
        node.setAttribute('aria-pressed', String(node === control && active !== null));
      }
      onChange?.(active);
    });
    rail.append(control);
  }
  return rail;
}
