/**
 * coach.test.js verifies the live Coach's data-only rule contract and the
 * child-facing labels consumed by Inspect.
 */

import test from 'node:test';
import assert from 'node:assert/strict';

import * as Coach from '../src/content/coach.js';

const PRIORITIES = new Set(['high', 'med', 'low']);

const RULE_CASES = Object.freeze({
  'tumor-shield': {
    priority: 'high',
    trigger: { meanTumorPdl1: 0.36 },
  },
  'shield-without-checkpoint': {
    priority: 'high',
    trigger: { meanTumorPdl1: 0.36, hasCheckpoint: false },
  },
  'killer-exhaustion': {
    priority: 'med',
    trigger: { meanKillerExhaustion: 0.51 },
  },
  'crs-danger': {
    priority: 'high',
    trigger: { crs: 0.61 },
  },
  'flagless-mhc-drift': {
    priority: 'high',
    trigger: { meanFlaglessMhc: 0.3, hasCD8: true },
  },
  'suggest-il2-escape-artist': {
    priority: 'med',
    trigger: { levelId: 'the-escape-artist', hasIl2: false, timeSec: 16 },
  },
  'no-engagement': {
    priority: 'med',
    trigger: { secondsSinceAnyEngagement: 8 },
  },
  'first-kill': {
    priority: 'low',
    trigger: { firstKillHappened: true },
  },
  'tumor-quarter': {
    priority: 'low',
    trigger: { tumorCount: 9 },
  },
  'dendritic-wave': {
    priority: 'low',
    trigger: { waveCalled: true },
  },
});

function neutralCtx(overrides = {}) {
  return {
    tumorCount: 30,
    tumorStart: 40,
    meanTumorPdl1: 0.1,
    meanKillerExhaustion: 0.1,
    crs: 0.2,
    crsDanger: 0.6,
    healthyKilledDelta: 0,
    flaglessFraction: 0.2,
    meanFlaglessMhc: 0.1,
    hasCD8: true,
    levelId: 'the-escape-artist',
    hasIl2: true,
    secondsSinceAnyEngagement: 2,
    hasCheckpoint: true,
    firstKillHappened: false,
    waveCalled: false,
    timeSec: 12,
    ...overrides,
  };
}

test('COACH_RULES contains every rule once and in trigger-table order', () => {
  assert.ok(Array.isArray(Coach.COACH_RULES));
  const ids = Coach.COACH_RULES.map((rule) => rule.id);
  assert.equal(new Set(ids).size, ids.length, 'coach rule ids must be unique');
  assert.deepEqual(ids, Object.keys(RULE_CASES));
});

test('every coach rule has a valid priority and short non-empty text', () => {
  for (const rule of Coach.COACH_RULES) {
    const expected = RULE_CASES[rule.id];
    assert.ok(expected, `unexpected coach rule ${rule.id}`);
    assert.ok(PRIORITIES.has(rule.priority), `${rule.id} has invalid priority`);
    assert.equal(rule.priority, expected.priority, `${rule.id} priority`);
    assert.equal(typeof rule.test, 'function', `${rule.id}.test`);
    assert.equal(typeof rule.text, 'string', `${rule.id}.text`);
    assert.notEqual(rule.text.trim(), '', `${rule.id}.text must not be empty`);
    assert.ok(rule.text.length <= 90, `${rule.id}.text is ${rule.text.length} characters`);
  }
});

test('every coach rule stays quiet for a neutral round context', () => {
  for (const rule of Coach.COACH_RULES) {
    assert.equal(rule.test(neutralCtx()), false, `${rule.id} fired on the neutral context`);
  }
});

test('every coach rule fires for its triggering round context', () => {
  for (const rule of Coach.COACH_RULES) {
    const trigger = RULE_CASES[rule.id]?.trigger;
    assert.ok(trigger, `missing trigger fixture for ${rule.id}`);
    assert.equal(
      rule.test(neutralCtx(trigger)),
      true,
      `${rule.id} did not fire for ${JSON.stringify(trigger)}`,
    );
  }
});

test('INSPECT_LABELS contains only usable child-facing display strings', () => {
  assert.ok(Coach.INSPECT_LABELS && typeof Coach.INSPECT_LABELS === 'object');
  assert.ok(Object.keys(Coach.INSPECT_LABELS).length >= 10);

  for (const [key, label] of Object.entries(Coach.INSPECT_LABELS)) {
    const rendered = typeof label === 'function' ? label('green flag') : label;
    assert.equal(typeof rendered, 'string', `INSPECT_LABELS.${key}`);
    assert.notEqual(rendered.trim(), '', `INSPECT_LABELS.${key} must not be empty`);
  }
});
