/**
 * lab-data.test.js — guards the two places where this game cites the lab's own research.
 *
 * Both are claims about someone else's work, which makes them the easiest thing to get
 * quietly wrong: a density that drifts from the measured value, a caveat that gets dropped on
 * the way into the UI, an interaction ID that no longer exists upstream, or a mechanic
 * claimed as "verified" when it was invented for the game. Each of those would be a small
 * edit and a large misrepresentation, so they are checked rather than trusted.
 */

import { test, describe } from 'node:test';
import assert from 'node:assert/strict';
import { readFile } from 'node:fs/promises';

import {
  CODEX_DENSITY_PER_MM2,
  CODEX_CAVEATS,
  CODEX_PROVENANCE,
  GAME_BOARD_COUNTS,
  GAME_TISSUE_AREA_MM2,
  REAL_IMMUNE_ROSTER,
  cellCountsForArea,
  surprisingFacts,
} from '../src/content/real-tissue.js';
import {
  LAB_PROVENANCE,
  LAB_SOURCE_LABEL,
  provenanceLine,
  verifiedMechanics,
} from '../src/content/lab-provenance.js';
import { KIND } from '../src/core/contracts.js';

describe('measured tissue composition', () => {
  test('densities match the values recorded in the research code', () => {
    // These are transcribed from Influenza_Modeling parameters.py CODEX_CELL_DENSITIES.
    // If the upstream measurement is revised, this test should fail and force a conscious
    // update rather than letting the game quietly cite a stale number.
    const expected = {
      epithelial: 762.9,
      fibroblast: 758.3,
      macrophage: 239.0,
      endothelial: 215.7,
      nk_cell: 99.8,
      b_cell: 83.7,
      cd4_t_cell: 64.4,
      cd8_t_cell: 32.7,
      dendritic_cell: 15.2,
      neutrophil: 11.2,
    };
    for (const [type, density] of Object.entries(expected)) {
      assert.ok(CODEX_DENSITY_PER_MM2[type], `missing cell type ${type}`);
      assert.equal(CODEX_DENSITY_PER_MM2[type].density, density, `${type} density drifted`);
    }
  });

  test('every cell type records the markers used to identify it', () => {
    // A density without its gating markers is an unfalsifiable number.
    for (const [type, entry] of Object.entries(CODEX_DENSITY_PER_MM2)) {
      assert.equal(typeof entry.markers, 'string');
      assert.ok(entry.markers.length > 3, `${type} has no marker combination recorded`);
    }
  });

  test('the preliminary caveats travel with the data', () => {
    // The research file marks these PRELIMINARY. Dropping that on the way into a public
    // exhibit would be the single most misleading thing this file could do.
    assert.ok(CODEX_CAVEATS.length >= 3, 'caveats were dropped');
    const joined = CODEX_CAVEATS.join(' ').toLowerCase();
    assert.ok(joined.includes('half'), 'the partial-classification caveat is missing');
    assert.ok(
      joined.includes('species') || joined.includes('condition'),
      'the unknown-specimen caveat is missing'
    );
    assert.ok(joined.includes('expert') || joined.includes('valid'), 'the gating caveat is missing');
  });

  test('provenance of the imaging run is recorded', () => {
    assert.equal(CODEX_PROVENANCE.cells, 255000);
    assert.equal(CODEX_PROVENANCE.markers, 35);
    assert.equal(CODEX_PROVENANCE.pixelToMicron, 0.376);
    assert.ok(CODEX_PROVENANCE.classifiedFraction < 1);
  });

  test('scaling to area is linear and matches the research helper', () => {
    // parameters.py: count = max(1, round(density * area_mm2)); area = (x/1000)*(y/1000).
    const oneMm2 = cellCountsForArea(1);
    assert.equal(oneMm2.macrophage, 239);
    const quarter = cellCountsForArea(0.25);
    assert.equal(quarter.macrophage, Math.max(1, Math.round(239.0 * 0.25)));
    // Never zero: an empty tissue would misrepresent a rare-but-present population.
    const tiny = cellCountsForArea(0.0001);
    for (const value of Object.values(tiny)) assert.ok(value >= 1);
  });

  test('the game board area is the stated 600 x 400 microns', () => {
    assert.ok(Math.abs(GAME_TISSUE_AREA_MM2 - 0.24) < 1e-9);
  });

  test('killer T cells really are the rare ones — the lesson holds', () => {
    // If this ever inverts, the surprising fact the exhibit is built on is no longer true.
    assert.ok(
      GAME_BOARD_COUNTS.macrophage > GAME_BOARD_COUNTS.cd8_t_cell * 3,
      'macrophages should substantially outnumber killer T cells'
    );
    assert.ok(
      GAME_BOARD_COUNTS.nk_cell > GAME_BOARD_COUNTS.cd8_t_cell,
      'NK cells should outnumber killer T cells'
    );
    assert.ok(GAME_BOARD_COUNTS.cd8_t_cell < 20, 'killer T cells should be strikingly few');
  });

  test('the spoken facts are derived from the numbers, not written by hand', () => {
    const facts = surprisingFacts();
    assert.ok(facts.length >= 3);
    assert.ok(
      facts[0].includes(String(GAME_BOARD_COUNTS.cd8_t_cell)),
      'the headline fact does not quote the computed count'
    );
    for (const fact of facts) assert.ok(fact.length <= 90, `too long to say: "${fact}"`);
  });

  test('the real-tissue roster has no CAR-T cells', () => {
    // Engineered cells are infused, not resident. Offering them as "real tissue" would
    // teach the opposite of the point.
    assert.equal(REAL_IMMUNE_ROSTER[KIND.CART], 0);
    assert.ok(REAL_IMMUNE_ROSTER[KIND.MACRO] > 0);
    assert.ok(REAL_IMMUNE_ROSTER[KIND.CD8] > 0);
  });
});

describe('mechanic provenance in the research models', () => {
  test('every entry names a source, an id, and a status', () => {
    const validSources = new Set(['flu', 'tumor', 'none']);
    const validStatus = new Set(['covered', 'implemented', 'game-only']);
    for (const [key, links] of Object.entries(LAB_PROVENANCE)) {
      assert.ok(Array.isArray(links) && links.length > 0, `${key} has no links`);
      for (const link of links) {
        assert.ok(validSources.has(link.source), `${key}: bad source "${link.source}"`);
        assert.ok(validStatus.has(link.status), `${key}: bad status "${link.status}"`);
        assert.ok(typeof link.id === 'string' && link.id.length > 0, `${key}: missing id`);
        assert.ok(link.description?.length > 10, `${key}: description too thin`);
      }
    }
  });

  test('a mechanic claimed as verified names the test that verifies it', () => {
    // "covered" in the source inventory means a pairwise test matched AND a mechanism audit
    // certified the right code path fired. Claiming that without naming the test is empty.
    for (const [key, links] of Object.entries(LAB_PROVENANCE)) {
      for (const link of links) {
        if (link.status !== 'covered') continue;
        assert.ok(
          typeof link.test === 'string' && link.test.length > 0,
          `${key}/${link.id} claims verification but names no test`
        );
      }
    }
  });

  test('game-only mechanics are never dressed up as research findings', () => {
    for (const [key, links] of Object.entries(LAB_PROVENANCE)) {
      const gameOnly = links.some((l) => l.status === 'game-only');
      if (!gameOnly) continue;
      assert.ok(
        links.every((l) => l.source === 'none'),
        `${key} mixes an invented mechanic with a research citation`
      );
      assert.match(
        provenanceLine(key),
        /Added for this game/,
        `${key} does not disclose that it was invented`
      );
    }
  });

  test('the mechanics the exhibit leans on hardest are the verified ones', () => {
    const verified = new Set(verifiedMechanics());
    for (const key of ['missing-self', 'combination-therapy', 'contact-killing']) {
      assert.ok(verified.has(key), `${key} should be backed by a verified interaction`);
    }
  });

  test('every source has a human-readable label', () => {
    for (const source of ['flu', 'tumor', 'none']) {
      assert.ok(LAB_SOURCE_LABEL[source]?.length > 5);
    }
  });

  test('the influenza model is never described as a tumor model', () => {
    // The immune interactions were verified in a viral-infection context. Blurring that
    // would overclaim what the lab has actually shown.
    assert.ok(!/tumou?r/i.test(LAB_SOURCE_LABEL.flu));
    for (const [key, links] of Object.entries(LAB_PROVENANCE)) {
      for (const link of links) {
        if (link.source !== 'flu') continue;
        assert.ok(
          !/\btumou?r\b/i.test(link.description),
          `${key}/${link.id} cites the influenza model for a tumor claim`
        );
      }
    }
  });
});

describe('tissue architecture from the H&E slide', () => {
  test('the map is the real cropped grid, not a placeholder', async () => {
    const T = await import('../src/content/tissue-architecture.js');
    assert.equal(T.TISSUE_COLS, 50, 'source grid is 50 patches wide');
    assert.equal(T.TISSUE_MAP.length, T.TISSUE_ROWS);
    for (const row of T.TISSUE_MAP) {
      assert.equal(row.length, T.TISSUE_COLS, 'ragged row — the crop is malformed');
      assert.match(row, /^[.0-3]+$/, 'unexpected symbol in the tissue map');
    }
  });

  test('the crop matches the board aspect so tissue is not distorted', async () => {
    const T = await import('../src/content/tissue-architecture.js');
    const aspect = T.TISSUE_COLS / T.TISSUE_ROWS;
    assert.ok(Math.abs(aspect - 1.5) < 0.06, `aspect ${aspect.toFixed(2)} is not ~3:2`);
  });

  test('it contains genuine empty space as well as tissue', async () => {
    // A map that is all tissue would mean the crop missed the slide edge, and the board
    // would lose the structure that makes it read as a real section.
    const T = await import('../src/content/tissue-architecture.js');
    assert.ok(T.TISSUE_FRACTION > 0.3 && T.TISSUE_FRACTION < 0.9, `tissue ${T.TISSUE_FRACTION}`);
    const joined = T.TISSUE_MAP.join('');
    assert.ok(joined.includes('.'), 'no background at all');
    for (let c = 0; c < T.TISSUE_CLUSTERS; c++) {
      assert.ok(joined.includes(String(c)), `neighbourhood ${c} vanished from the crop`);
    }
  });

  test('lookups agree with the map and are safe out of bounds', async () => {
    const T = await import('../src/content/tissue-architecture.js');
    for (let row = 0; row < T.TISSUE_ROWS; row++) {
      for (let col = 0; col < T.TISSUE_COLS; col++) {
        const ch = T.TISSUE_MAP[row][col];
        assert.equal(T.hasTissue(col, row), ch !== '.');
        assert.equal(T.neighbourhoodAt(col, row), ch === '.' ? -1 : Number(ch));
      }
    }
    assert.equal(T.hasTissue(-1, 0), false);
    assert.equal(T.hasTissue(0, 9999), false);
    assert.equal(T.neighbourhoodAt(9999, 0), -1);
  });

  test('the neighbourhoods are never given tissue-type names', async () => {
    // The source config states cluster identities have not been manually assigned. Naming
    // them alveolar/vascular/stromal here would invent a result the lab has not produced.
    const src = await readFile(new URL('../src/content/tissue-architecture.js', import.meta.url), 'utf8');
    const code = src.replace(/\/\*[\s\S]*?\*\//g, ' ');
    for (const name of ['alveolar', 'bronchiolar', 'vascular', 'stromal']) {
      assert.ok(
        !new RegExp(`['"\`][^'"\`]*${name}`, 'i').test(code),
        `a neighbourhood is labelled "${name}" in code, which the source has not established`
      );
    }
  });
});
