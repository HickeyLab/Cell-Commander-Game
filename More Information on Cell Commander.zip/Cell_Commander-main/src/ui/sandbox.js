/**
 * sandbox.js — owns free-play experiment controls, normalized antigen settings,
 * kid-language live interpretation, and a guarded fast round-restart seam.
 */

import { REAL_IMMUNE_ROSTER, surprisingFacts, CODEX_CAVEATS } from '../content/real-tissue.js';
import {
  ANTIGEN,
  KIND,
  KIND_LABEL,
  PLACEABLE,
  SCREEN,
  WORLD_H,
} from '../core/contracts.js';
import * as Engine from '../sim/engine.js';
import {
  button,
  chip,
  icon,
  slider,
} from './components.js';
import { makeRoundView } from './round-view.js';

const DEFAULT_COUNTS = Object.freeze({
  [KIND.CD8]: 6,
  [KIND.NK]: 4,
  [KIND.MACRO]: 3,
  [KIND.DC]: 2,
  [KIND.CD4]: 3,
});

const CELL_GLYPH = Object.freeze({
  [KIND.CD8]: '◕',
  [KIND.NK]: '◆',
  [KIND.MACRO]: '✣',
  [KIND.DC]: '✦',
  [KIND.CD4]: '●',
});

function normalizeMix(weights) {
  const total = Math.max(1, weights.green + weights.blue + weights.orange);
  return {
    [ANTIGEN.NONE]: 0,
    [ANTIGEN.GREEN]: weights.green / total,
    [ANTIGEN.BLUE]: weights.blue / total,
    [ANTIGEN.ORANGE]: weights.orange / total,
  };
}

function describeSettings(settings) {
  const killers = settings.counts[KIND.CD8]
    + settings.counts[KIND.NK]
    + settings.counts[KIND.MACRO];
  const ratio = killers / Math.max(1, settings.tumorCount);
  const teamLine = ratio >= 2
    ? 'You have at least twice as many killer cells as cancer cells.'
    : ratio >= 1
      ? 'Your killer team is about the same size as the tumor.'
      : `About ${Math.round(1 / Math.max(0.01, ratio))} cancer cells face each killer cell.`;
  const mix = normalizeMix(settings.antigenWeights);
  const dominantEntry = [
    [ANTIGEN.GREEN, 'green'],
    [ANTIGEN.BLUE, 'blue'],
    [ANTIGEN.ORANGE, 'orange'],
  ].sort((a, b) => mix[b[0]] - mix[a[0]])[0];
  const shieldLine = settings.pdl1 >= 70
    ? 'The tumor has a strong shield. T cells may slow down.'
    : settings.pdl1 >= 30
      ? 'The tumor shield is partly raised.'
      : 'The tumor shield is low, so T cells can keep working.';
  const blockerLine = settings.tregs >= 30
    ? 'Many Treg blockers are calming the immune attack.'
    : 'Only a few Treg blockers are calming the attack.';
  return [
    teamLine,
    `Most cancer cells fly the ${dominantEntry[1]} flag.`,
    shieldLine,
    blockerLine,
  ];
}

function buildPlan(basePlan, settings) {
  const plan = {
    ...basePlan,
    budget: 100000,
    spent: 0,
    placements: [],
    checkpoint: settings.drugs.checkpoint,
    il2: settings.drugs.il2,
    lymphodepletion: settings.drugs.lymphodepletion,
  };
  let slot = 0;
  for (const kind of PLACEABLE) {
    for (let index = 0; index < settings.counts[kind]; index += 1) {
      const column = slot % 14;
      const row = Math.floor(slot / 14);
      plan.placements.push({
        kind,
        x: 45 + (column % 10) * 24,
        y: 55 + (row * 34) % (WORLD_H - 110),
      });
      slot += 1;
    }
  }
  return plan;
}

function buildLevel(baseLevel, settings) {
  const mix = normalizeMix(settings.antigenWeights);
  return {
    ...baseLevel,
    timeLimitSec: Number.POSITIVE_INFINITY,
    tumorEscapeCap: Number.POSITIVE_INFINITY,
    tumor: {
      ...baseLevel.tumor,
      count: settings.tumorCount,
      antigenMix: mix,
      pdl1Base: settings.pdl1 / 100,
      pdl1Inducible: settings.pdl1 / 100,
      divideTimeScale: 100 / settings.growthRate,
    },
    tregs: settings.tregs,
  };
}

/**
 * Mounts the no-score, no-timer sandbox controls.
 * @param {HTMLElement} rootEl
 * @param {{app:object,level:object,plan:object,quality:object}} ctx
 * @returns {{unmount:()=>void,update:(dt:number)=>void}}
 */
export function mount(rootEl, ctx) {
  const settings = {
    counts: { ...DEFAULT_COUNTS },
    tumorCount: 60,
    antigenWeights: { green: 60, blue: 25, orange: 15 },
    pdl1: 30,
    tregs: 10,
    growthRate: 100,
    drugs: {
      checkpoint: false,
      il2: false,
      lymphodepletion: false,
    },
  };
  let restartTimer = 0;

  const screen = document.createElement('main');
  screen.className = 'cc-screen sandbox-screen';
  const header = document.createElement('header');
  header.className = 'screen-header';
  const headingWrap = document.createElement('div');
  const eyebrow = document.createElement('p');
  eyebrow.className = 'instrument-label';
  eyebrow.textContent = 'Level 6 / Free play';
  const heading = document.createElement('h1');
  heading.textContent = 'Sandbox';
  const subtitle = document.createElement('p');
  subtitle.textContent = 'Change one thing. Watch what the immune system does.';
  headingWrap.append(eyebrow, heading, subtitle);
  const back = button('← Levels', {
    className: 'cc-button--quiet',
    onClick: () => ctx.app.go(SCREEN.LEVEL_SELECT),
  });
  header.append(headingWrap, back);

  const layout = document.createElement('div');
  layout.className = 'sandbox-layout';
  const controls = document.createElement('section');
  controls.className = 'sandbox-controls instrument-panel';
  const controlsTitle = document.createElement('h2');
  controlsTitle.textContent = 'Build the experiment';
  controls.append(controlsTitle);

  const roundView = makeRoundView({
    quality: ctx.quality,
    ariaLabel: 'Live sandbox tissue field',
  });
  // STYLE-NOTE: would add class .sandbox-observation for the tissue view + interpretation stack.
  const interpretation = document.createElement('aside');
  interpretation.className = 'sandbox-interpretation science-card';
  const liveLabel = document.createElement('p');
  liveLabel.className = 'instrument-label';
  liveLabel.textContent = 'Live tissue';
  const interpretationTitle = document.createElement('h2');
  interpretationTitle.textContent = 'What your settings mean';
  const interpretationList = document.createElement('ul');
  const runStatus = document.createElement('div');
  runStatus.className = 'sandbox-run-status';
  runStatus.setAttribute('aria-live', 'polite');
  interpretation.append(
    liveLabel,
    roundView.el,
    interpretationTitle,
    interpretationList,
    chip('No timer. No score. Just test your idea.', { tone: 'science', icon: '⌬' }),
    runStatus,
  );

  function updateDescription() {
    interpretationList.replaceChildren();
    for (const line of describeSettings(settings)) {
      const item = document.createElement('li');
      item.textContent = line;
      interpretationList.append(item);
    }
  }

  function restartRound() {
    clearTimeout(restartTimer);
    restartTimer = setTimeout(() => {
      updateDescription();
      const level = buildLevel(ctx.level, settings);
      const plan = buildPlan(ctx.plan, settings);
      try {
        if (typeof Engine.createRound !== 'function') {
          throw new TypeError('Round engine unavailable');
        }
        const round = Engine.createRound({
          level,
          plan,
          seed: ctx.app.seed ?? 1,
          quality: ctx.quality,
        });
        roundView.setRound(round);
        ctx.app.level = level;
        ctx.app.plan = plan;
        ctx.app.round = round;
        runStatus.textContent = 'The experiment restarted with your new settings.';
      } catch {
        runStatus.textContent = 'Settings are ready. The live model is connecting.';
      }
    }, 80);
  }

  const cellGroup = document.createElement('fieldset');
  const cellLegend = document.createElement('legend');
  cellLegend.textContent = 'Immune cell counts';
  cellGroup.append(cellLegend);
  const cellSliders = new Map();
  for (const kind of PLACEABLE) {
    if (!ctx.level?.unlocks?.includes(kind)) {
      continue;
    }
    const control = slider(`${CELL_GLYPH[kind]} ${KIND_LABEL[kind]}`, {
      min: 0,
      max: 60,
      value: settings.counts[kind],
      onInput: (value) => {
        settings.counts[kind] = value;
        updateDescription();
      },
      onCommit: restartRound,
    });
    cellSliders.set(kind, control);
    cellGroup.append(control);
  }

  // "Real tissue" preset: set every immune slider to the abundance our own CODEX imaging
  // actually measured in human lung. This is the most valuable button on the screen — a
  // child who has just placed a dozen killer T cells discovers that real tissue holds about
  // eight killer T cells, outnumbered seven to one by macrophages. The numbers come from
  // 255,000 segmented cells across 35 markers, not from illustration.
  const realPreset = button('Use real tissue numbers', {
    className: 'cc-button--quiet sandbox-preset',
    onClick: () => {
      for (const [kind, count] of Object.entries(REAL_IMMUNE_ROSTER)) {
        const kindKey = Number(kind);
        settings.counts[kindKey] = count;
        const control = cellSliders.get(kindKey);
        const input = control?.querySelector('input[type="range"]');
        if (input) {
          input.value = String(Math.min(Number(input.max), count));
          input.dispatchEvent(new Event('input', { bubbles: true }));
          input.dispatchEvent(new Event('change', { bubbles: true }));
        }
      }
      updateDescription();
      restartRound();
    },
  });

  const realNote = document.createElement('p');
  realNote.className = 'sandbox-real-note';
  realNote.textContent = surprisingFacts()[1];

  const realCaveat = document.createElement('p');
  realCaveat.className = 'sandbox-real-caveat';
  realCaveat.textContent = `Measured, not exact: ${CODEX_CAVEATS[0]}`;

  cellGroup.append(realPreset, realNote, realCaveat);

  const tumorGroup = document.createElement('fieldset');
  const tumorLegend = document.createElement('legend');
  tumorLegend.textContent = 'Tumor';
  tumorGroup.append(
    tumorLegend,
    slider('Cancer cells', {
      min: 10,
      max: 300,
      step: 5,
      value: settings.tumorCount,
      onInput: (value) => {
        settings.tumorCount = value;
        updateDescription();
      },
      onCommit: restartRound,
    }),
    slider('PD-L1 shield', {
      min: 0,
      max: 100,
      step: 5,
      value: settings.pdl1,
      unit: '%',
      onInput: (value) => {
        settings.pdl1 = value;
        updateDescription();
      },
      onCommit: restartRound,
    }),
    slider('Treg blockers', {
      min: 0,
      max: 80,
      step: 2,
      value: settings.tregs,
      onInput: (value) => {
        settings.tregs = value;
        updateDescription();
      },
      onCommit: restartRound,
    }),
    slider('Tumor growth', {
      min: 25,
      max: 200,
      step: 5,
      value: settings.growthRate,
      unit: '%',
      onInput: (value) => {
        settings.growthRate = value;
        updateDescription();
      },
      onCommit: restartRound,
    }),
  );

  const antigenGroup = document.createElement('fieldset');
  const antigenLegend = document.createElement('legend');
  antigenLegend.textContent = 'Cancer flag mix';
  antigenGroup.append(antigenLegend);
  for (const [key, label, className] of [
    ['green', '⚑ Green flag', 'antigen--green'],
    ['blue', '⚑ Blue flag', 'antigen--blue'],
    ['orange', '⚑ Orange flag', 'antigen--orange'],
  ]) {
    const control = slider(label, {
      min: 0,
      max: 100,
      step: 5,
      value: settings.antigenWeights[key],
      unit: ' parts',
      onInput: (value) => {
        settings.antigenWeights[key] = value;
        updateDescription();
      },
      onCommit: restartRound,
    });
    control.classList.add(className);
    antigenGroup.append(control);
  }

  const drugGroup = document.createElement('fieldset');
  const drugLegend = document.createElement('legend');
  drugLegend.textContent = 'Treatment supports';
  drugGroup.append(drugLegend);
  for (const [key, label, glyph] of [
    ['checkpoint', 'Checkpoint inhibitor', '◉'],
    ['il2', 'IL-2 support', '✦'],
    ['lymphodepletion', 'Lymphodepletion', '⌁'],
  ]) {
    const control = button('', {
      className: 'sandbox-toggle',
      pressed: false,
      ariaLabel: `Toggle ${label}`,
    });
    control.append(icon(glyph), document.createTextNode(label));
    control.addEventListener('click', () => {
      settings.drugs[key] = !settings.drugs[key];
      control.setAttribute('aria-pressed', String(settings.drugs[key]));
      control.classList.toggle('is-active', settings.drugs[key]);
      restartRound();
    });
    drugGroup.append(control);
  }
  controls.append(cellGroup, tumorGroup, antigenGroup, drugGroup);
  layout.append(controls, interpretation);
  screen.append(header, layout);
  rootEl.replaceChildren(screen);
  roundView.resize();
  updateDescription();
  restartRound();

  return {
    update(dt) {
      roundView.update(dt);
    },
    unmount() {
      clearTimeout(restartTimer);
      roundView.destroy();
      screen.remove();
    },
  };
}
