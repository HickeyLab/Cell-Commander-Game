/**
 * treg.js owns local immunosuppressive cytokine secretion and chemotactic
 * movement for regulatory T cells.
 */

import { FIELD } from '../../core/contracts.js';
import { P } from '../params.js';

/**
 * Update one regulatory T cell without allocating.
 * @param {object} round
 * @param {number} i
 * @param {number} dt
 * @returns {void}
 */
export function updateTreg(round, i, dt) {
  const world = round.world;
  round.grid.depositRadius(
    FIELD.SUPPRESS,
    world.x[i],
    world.y[i],
    P.production.suppressTreg * dt,
    round.grid.cellW * 2,
  );
  round._move(i, FIELD.CHEMOKINE, false);
}
