/**
 * engine.js owns deterministic round construction and the fixed-order simulation
 * tick: fields, spatial index, behaviors, movement, overlap, mutations, then meters.
 */

import {
  ANTIGEN,
  FIELD,
  FIELD_COUNT,
  KIND,
  OUTCOME,
  QUALITY,
  STATE,
  WORLD_H,
  WORLD_W,
} from '../core/contracts.js';
import { makeFieldGrid } from '../core/grid.js';
import { makeRng } from '../core/rng.js';
import { makeSpatialHash } from '../core/spatialhash.js';
import {
  P,
  chemoGainFor,
  killRateFor,
  speedFor,
} from './params.js';
import { makeWorld } from './world.js';
import { planCost } from './plan.js';
import { evaluateOutcome } from './scoring.js';
import { updateTumor } from './behaviors/tumor.js';
import { updateTCell } from './behaviors/tcell.js';
import { updateNK } from './behaviors/nk.js';
import { updateMacrophage } from './behaviors/macrophage.js';
import { updateDendritic } from './behaviors/dendritic.js';
import { updateCD4 } from './behaviors/cd4.js';
import { updateTreg } from './behaviors/treg.js';
import { updateHealthy } from './behaviors/healthy.js';

const MAX_EVENTS_PER_TICK = 256;
const EVENT_KILL = 1;
const EVENT_DIVIDE = 2;
const EVENT_ENGAGE = 3;
const FIELD_CONCENTRATION_UNIT_AREA = (WORLD_W / QUALITY.HIGH.gridW)
  * (WORLD_H / QUALITY.HIGH.gridH);
const EVENT_POLARIZE = 4;
const EVENT_WAVE = 5;
const EVENT_TOXICITY = 6;
const MAX_TARGET_RADIUS = Math.max(P.radius[KIND.TUMOR], P.radius[KIND.HEALTHY]);
const MAX_AGENT_RADIUS = P.radius[KIND.VESSEL];

// Allocation-free callback scratch. Calls are synchronous, so no query state escapes.
let queryRound = null;
let queryKiller = -1;
let relaxRound = null;
let relaxSlot = -1;

function clamp(value, lo, hi) {
  return Math.max(lo, Math.min(hi, value));
}

function isImmuneKind(kind) {
  return kind === KIND.CD8
    || kind === KIND.CART
    || kind === KIND.NK
    || kind === KIND.MACRO
    || kind === KIND.DC
    || kind === KIND.CD4;
}

function sampleAntigen(mix, rng) {
  const draw = rng.next();
  let cumulative = 0;
  let fallback = ANTIGEN.NONE;
  for (const key in mix) {
    fallback = Number(key);
    cumulative += mix[key];
    if (draw < cumulative) {
      return fallback;
    }
  }
  return fallback;
}

/** Rejection-sampling attempts before falling back to a hard clamp at the cutoff. */
const MHC_RESAMPLE_LIMIT = 200;

/**
 * Draw a tumor cell's MHC-I level from the level's configured distribution.
 *
 * Antigen-negative cells are the "flag-hiders" this game is about: a cell that has lost its
 * CAR target only completes the intended escape phenotype if it has ALSO downregulated
 * MHC-I, which is what makes it recognizable to NK's missing-self pathway instead. Antigen
 * and MHC were previously drawn as two independent Gaussians, so a fixed fraction of
 * antigen-negative cells landed above the NK cutoff purely by chance, with nothing in some
 * levels' rosters able to catch them (CD8, the other half of the complementary pair in
 * targetPredicate, isn't unlocked in every level). Rejection-sampling the antigen-negative
 * draw back under the NK cutoff makes "no flag" and "low MHC" the single combined escape
 * phenotype the level hints and science cards already describe, instead of two independent
 * coin flips that only usually land together.
 *
 * @param {object} rng
 * @param {object} tumorDef level.tumor
 * @param {number} antigen the a0 value just sampled for this cell
 * @returns {number}
 */
function sampleMhc(rng, tumorDef, antigen) {
  let value = clamp(rng.gauss(tumorDef.mhcMean, tumorDef.mhcSd), 0, 1);
  if (antigen !== ANTIGEN.NONE) {
    return value;
  }
  let attempts = 0;
  while (value >= P.recognition.nkMissingSelfMax && attempts < MHC_RESAMPLE_LIMIT) {
    value = clamp(rng.gauss(tumorDef.mhcMean, tumorDef.mhcSd), 0, 1);
    attempts += 1;
  }
  if (value >= P.recognition.nkMissingSelfMax) {
    // Parameters made the cutoff essentially unreachable within budget; clamp rather
    // than silently ship an uncatchable cell.
    value = Math.max(0, P.recognition.nkMissingSelfMax - 1e-3);
  }
  return value;
}

function targetPredicate(target) {
  const round = queryRound;
  const world = round.world;
  const killer = queryKiller;
  if (target === killer || world.alive[target] === 0 || round._deathQueued[target] !== 0) {
    return false;
  }

  const targetKind = world.kind[target];
  const killerKind = world.kind[killer];
  if (targetKind !== KIND.TUMOR && targetKind !== KIND.HEALTHY) {
    return false;
  }

  const dx = world.x[target] - world.x[killer];
  const dy = world.y[target] - world.y[killer];
  const engageDistance = world.radius[target] + world.radius[killer]
    + P.recognition.engageMargin;
  if (dx * dx + dy * dy >= engageDistance * engageDistance) {
    return false;
  }

  if (killerKind === KIND.CART) {
    return world.a0[target] === round.plan.carTarget;
  }
  if (killerKind === KIND.CD8 && targetKind === KIND.TUMOR) {
    // A native CD8 T cell recognizes peptide-MHC-I, NOT the CAR's target flag. A tumor cell
    // that has lost the CAR antigen still presents other tumor peptides on MHC-I and remains
    // killable by ordinary cytotoxic T cells — which is true of real CD19-negative relapse.
    //
    // Requiring `antigen !== NONE` here imported CAR logic into a native T cell and left a
    // hole in the recognition space: a cell with no CAR flag and MHC-I just ABOVE the NK
    // missing-self cutoff satisfied no killer at all and was literally invincible. Balance
    // testing found 13 such cells surviving every run of The Escape Artist, making the level
    // unwinnable. With this rule, CD8 (MHC-high) and NK (MHC-low) partition the space
    // completely, so every tumor cell is killable by something.
    return world.a1[target] > P.recognition.mhcMin;
  }
  if (killerKind === KIND.NK) {
    return targetKind === KIND.TUMOR
      && world.a1[target] < P.recognition.nkMissingSelfMax;
  }
  return killerKind === KIND.MACRO && targetKind === KIND.TUMOR;
}

function findTarget(i) {
  queryRound = this;
  queryKiller = i;
  const world = this.world;
  const radius = world.radius[i] + MAX_TARGET_RADIUS + P.recognition.engageMargin;
  const target = this.hash.nearest(
    world.x[i],
    world.y[i],
    radius,
    targetPredicate,
  );
  queryRound = null;
  queryKiller = -1;
  return target;
}

function queueDeath(i, killer) {
  if (i < 0 || i >= this.world.capacity
    || this.world.alive[i] === 0 || this._deathQueued[i] !== 0) {
    return false;
  }
  const position = this._deathCount;
  if (position >= this._deathSlots.length) {
    return false;
  }
  this._deathQueued[i] = 1;
  this._deathSlots[position] = i;
  this._deathKillers[position] = killer;
  this._deathCount += 1;
  this.world.hp[i] = 0;
  return true;
}

function queueSpawn(kind, x, y, a0, a1, a2, a3, state, timer) {
  if (!Number.isFinite(x) || !Number.isFinite(y)
    || x < 0 || x > WORLD_W || y < 0 || y > WORLD_H) {
    return false;
  }
  if (this.world.count + this._spawnCount - this._deathCount >= this.world.capacity) {
    return false;
  }
  const position = this._spawnCount;
  if (position >= this._spawnKind.length) {
    return false;
  }
  this._spawnKind[position] = kind;
  this._spawnX[position] = x;
  this._spawnY[position] = y;
  this._spawnA0[position] = a0;
  this._spawnA1[position] = a1;
  this._spawnA2[position] = a2;
  this._spawnA3[position] = a3;
  this._spawnState[position] = state;
  this._spawnTimer[position] = timer;
  this._spawnCount += 1;
  return true;
}

function queueEvent(code, x, y, p0, p1) {
  const position = this._eventCount;
  if (position >= MAX_EVENTS_PER_TICK) {
    return false;
  }
  this._eventCode[position] = code;
  this._eventX[position] = x;
  this._eventY[position] = y;
  this._eventP0[position] = p0;
  this._eventP1[position] = p1;
  this._eventCount += 1;
  return true;
}

function damageTarget(killer, target, dt) {
  const world = this.world;
  if (world.alive[target] === 0 || this._deathQueued[target] !== 0) {
    return;
  }

  const killerKind = world.kind[killer];
  const targetKind = world.kind[target];
  const pdl1 = targetKind === KIND.TUMOR ? world.a2[target] : 0;
  const pd1 = killerKind === KIND.MACRO ? 0 : world.a0[killer];
  const effectivePd1 = this.plan.checkpoint
    ? pd1 * P.checkpoint.residualPd1
    : pd1;
  const brake = 1 / (1 + pdl1 * effectivePd1 * P.checkpoint.pd1Strength);
  const suppress = this.grid.sample(FIELD.SUPPRESS, world.x[target], world.y[target]);
  const il2 = sampleField(this, FIELD.IL2, world.x[killer], world.y[killer]);
  const suppression = 1 / (1 + suppress * P.suppressStrength);
  const boost = 1 + il2 * P.il2Boost;
  const fatigue = Math.max(P.exhaustion.killFloor, 1 - world.a1[killer]);

  // API-NOTE: The contract requires CD8 recognition only above mhcMin but separately
  // requests a penalty for "low MHC" without exporting a second low/high cutoff.
  // Literal recognition therefore makes the below-threshold penalty unreachable.
  const mhcFactor = killerKind === KIND.CD8
    && targetKind === KIND.TUMOR
    && world.a1[target] <= P.recognition.mhcMin
    ? P.recognition.mhcLowPenalty
    : 1;
  const packets = killRateFor(killerKind)
    * brake
    * suppression
    * boost
    * fatigue
    * mhcFactor
    * dt;
  world.a3[target] += packets;

  const recoveryReduction = 1 + il2 * P.exhaustion.il2Boost;
  const engagedRecovery = P.exhaustion.recoveryRate * recoveryReduction;
  world.a1[killer] = clamp(
    world.a1[killer]
      + P.exhaustion.perEngagedSec * dt / recoveryReduction
      - engagedRecovery * dt,
    0,
    1,
  );

  if (world.a3[target] >= P.tumor.deathPackets) {
    queueDeath.call(this, target, killer);
  }
}

function recoverKiller(i, dt) {
  const world = this.world;
  const il2 = sampleField(this, FIELD.IL2, world.x[i], world.y[i]);
  world.a1[i] = Math.max(
    0,
    world.a1[i]
      - P.exhaustion.recoveryRate * (1 + il2 * P.exhaustion.il2Boost) * dt,
  );
}

function sampleField(round, field, x, y) {
  const local = round.grid.sample(field, x, y);
  if (field === FIELD.IL2 && round.plan.il2) {
    return local + P.kHalf.il2;
  }
  return local;
}

function moveAgent(i, field, engaged) {
  const world = this.world;
  const kind = world.kind[i];
  const baseSpeed = speedFor(kind);
  if (!(baseSpeed > 0)) {
    world.vx[i] = 0;
    world.vy[i] = 0;
    return;
  }

  // An ENGAGED killer holds its synapse: it steers toward its target, not up the chemokine
  // gradient. Without this, the small residual drift allowed while engaged is enough to walk
  // a killer out of contact range mid-kill — measured: a CAR-T reached 7,997 of the 12,800
  // packets needed, drifted from 24.5 to 27.5 world units over three seconds, disengaged,
  // and wandered off, abandoning a kill it had almost finished. Real cytotoxic T cells arrest
  // on contact (the research model gives them a dwell velocity of exactly zero), so holding
  // position on the target is both the correct biology and what makes killing reliable.
  const engagedTarget = engaged ? world.a3[i] : -1;
  if (engagedTarget >= 0 && engagedTarget < world.capacity && world.alive[engagedTarget]) {
    const toX = world.x[engagedTarget] - world.x[i];
    const toY = world.y[engagedTarget] - world.y[i];
    const toLen = Math.hypot(toX, toY);
    if (toLen > Number.EPSILON) {
      const speed = baseSpeed * P.motion.engagedFrac;
      world.vx[i] = (toX / toLen) * speed;
      world.vy[i] = (toY / toLen) * speed;
      return;
    }
  }

  const gradient = this._gradientScratch;
  this.grid.gradient(field, world.x[i], world.y[i], gradient);
  let local = this.grid.sample(field, world.x[i], world.y[i]);
  // A beacon shares the chemotaxis channel but decays on its own, much faster, clock (see
  // DECAY[FIELD.BEACON]'s comment in params.js) — blending it in here means every cell that
  // already follows chemokine benefits from a fresh beacon without needing its own field
  // parameter threaded through every calling behavior file.
  if (field === FIELD.CHEMOKINE) {
    const beaconGradient = this._beaconGradientScratch;
    this.grid.gradient(FIELD.BEACON, world.x[i], world.y[i], beaconGradient);
    gradient.x += beaconGradient.x;
    gradient.y += beaconGradient.y;
    local += this.grid.sample(FIELD.BEACON, world.x[i], world.y[i]);
  }
  const gradientLength = Math.hypot(gradient.x, gradient.y);
  const randomAngle = this.rng.angle();
  const randomX = Math.cos(randomAngle);
  const randomY = Math.sin(randomAngle);
  let desiredX = randomX;
  let desiredY = randomY;
  if (gradientLength > Number.EPSILON) {
    const half = field === FIELD.DEBRIS ? P.kHalf.debris : P.kHalf.chemotaxis;
    const gain = chemoGainFor(kind);
    const chemotaxisWeight = clamp(gain * local / (half + local), 0, 1);
    desiredX = gradient.x / gradientLength * chemotaxisWeight
      + randomX * (1 - chemotaxisWeight);
    desiredY = gradient.y / gradientLength * chemotaxisWeight
      + randomY * (1 - chemotaxisWeight);
  }
  const noiseAngle = this.rng.range(-P.motion.turnNoise, P.motion.turnNoise);
  const noiseCos = Math.cos(noiseAngle);
  const noiseSin = Math.sin(noiseAngle);
  const rotatedX = desiredX * noiseCos - desiredY * noiseSin;
  desiredY = desiredX * noiseSin + desiredY * noiseCos;
  desiredX = rotatedX;

  const velocityLength = Math.hypot(world.vx[i], world.vy[i]);
  let previousX = desiredX;
  let previousY = desiredY;
  if (velocityLength > Number.EPSILON) {
    previousX = world.vx[i] / velocityLength;
    previousY = world.vy[i] / velocityLength;
  }
  let headingX = P.motion.persistence * previousX
    + (1 - P.motion.persistence) * desiredX;
  let headingY = P.motion.persistence * previousY
    + (1 - P.motion.persistence) * desiredY;
  const headingLength = Math.hypot(headingX, headingY);
  if (headingLength > Number.EPSILON) {
    headingX /= headingLength;
    headingY /= headingLength;
  }

  const exhaustion = (kind === KIND.CD8 || kind === KIND.CART
    || kind === KIND.NK || kind === KIND.MACRO)
    ? world.a1[i]
    : 0;
  const exhaustionSpeed = 1 - exhaustion * (1 - P.motion.exhaustedFrac);
  const suppress = this.grid.sample(FIELD.SUPPRESS, world.x[i], world.y[i]);
  const suppressionSpeed = 1 / (1 + suppress * P.suppressStrength);
  const engagementSpeed = engaged ? P.motion.engagedFrac : 1;
  const speed = baseSpeed * exhaustionSpeed * suppressionSpeed * engagementSpeed;
  world.vx[i] = headingX * speed;
  world.vy[i] = headingY * speed;
}

function perfusionAt(x, y) {
  let cx = Math.floor(x / this.grid.cellW);
  let cy = Math.floor(y / this.grid.cellH);
  if (cx < 0) cx = 0;
  if (cx >= this.grid.w) cx = this.grid.w - 1;
  if (cy < 0) cy = 0;
  if (cy >= this.grid.h) cy = this.grid.h - 1;
  return this.perfusion[cy * this.grid.w + cx];
}

function hasDivisionClearance(parent, x, y) {
  const world = this.world;
  const radius = world.radius[parent];
  if (x < radius || x > WORLD_W - radius || y < radius || y > WORLD_H - radius) {
    return false;
  }
  for (let i = 0; i < world.capacity; i += 1) {
    if (i === parent || world.alive[i] === 0 || this._deathQueued[i] !== 0) {
      continue;
    }
    const dx = world.x[i] - x;
    const dy = world.y[i] - y;
    const clearance = (world.radius[i] + radius) * P.tumor.divideMinClearance;
    if (dx * dx + dy * dy < clearance * clearance) {
      return false;
    }
  }
  return true;
}

function takeDebris(x, y, dt) {
  let cx = Math.floor(x / this.grid.cellW);
  let cy = Math.floor(y / this.grid.cellH);
  if (cx < 0) cx = 0;
  if (cx >= this.grid.w) cx = this.grid.w - 1;
  if (cy < 0) cy = 0;
  if (cy >= this.grid.h) cy = this.grid.h - 1;
  const index = this.grid.idx(FIELD.DEBRIS, cx, cy);
  const cellArea = this.grid.cellW * this.grid.cellH;
  const storedConcentration = this.grid.data[index];
  const available = storedConcentration * cellArea;
  const taken = Math.min(available, available * dt);
  this.grid.data[index] = storedConcentration - taken / cellArea;
  return taken;
}

/**
 * Lay a chain of fast-decaying beacon pulses from a vessel toward the current level's
 * tumor center, spaced roughly at chemokine's natural gradient reach (~120wu) so a cell
 * following the signal never finds itself between two pulses with nothing to follow.
 * Shared by queueWave's initial deposit and the periodic refresh in updateDendritic, since
 * a one-time deposit decays (by design; see DECAY[FIELD.BEACON]'s comment) long before a
 * cell moving at normal speed can cross a gap the size of Cold Tumor's vessel-to-tumor
 * distance.
 */
function layWaveGuideChain(round, originX, originY, destX, destY) {
  const dx = destX - originX;
  const dy = destY - originY;
  const distance = Math.hypot(dx, dy);
  if (distance < 1) {
    return;
  }
  const steps = Math.max(1, Math.round(distance / 120));
  // Perpendicular unit vector, for jitter across the corridor's width.
  const perpX = -dy / distance;
  const perpY = dx / distance;
  for (let s = 1; s <= steps; s += 1) {
    const t = s / (steps + 1);
    const jitter = round.rng.range(-P.dc.waveGuideJitter, P.dc.waveGuideJitter);
    round.grid.depositRadius(
      FIELD.BEACON,
      originX + dx * t + perpX * jitter,
      originY + dy * t + perpY * jitter,
      P.dc.waveGuideStrength,
      P.beacon.radius,
    );
  }
}

/**
 * Where to aim a guide chain: a live tumor cell's actual current position, not the level's
 * static geometric tumor center. Measured directly why this matters: in Cold Tumor
 * (spreadWu 90), by mid-round the *closest* surviving tumor cell to the geometric center was
 * 133wu away, average 163wu -- well outside engagement range. A chain that always terminates
 * at that fixed, often-empty point pulls arriving reinforcements to a spot with nothing to
 * fight, and the persistent refresh then holds them orbiting there instead of letting them
 * fan out to where cells actually are.
 *
 * Picks the *nearest* live cell to the origin, not a random one -- tried random first and it
 * made things worse: since this runs on every ~1s refresh, a fresh random pick each call kept
 * changing the destination faster than a cell moving at normal speed could reach the previous
 * one, so the signal never stayed put long enough to actually be followed. Nearest-to-origin
 * is deterministic and only changes when that specific cell dies, giving a stable target for
 * the whole time a wave's reinforcements are in transit.
 *
 * Falls back to the level's tumor center only if no tumor cells remain (e.g. round already
 * effectively won).
 */
function findWaveGuideDestination(round, originX, originY) {
  const world = round.world;
  let nearest = -1;
  let nearestDistanceSq = Infinity;
  for (let i = 0; i < world.capacity; i += 1) {
    if (world.alive[i] === 0 || world.kind[i] !== KIND.TUMOR) {
      continue;
    }
    const dx = world.x[i] - originX;
    const dy = world.y[i] - originY;
    const distanceSq = dx * dx + dy * dy;
    if (distanceSq < nearestDistanceSq) {
      nearest = i;
      nearestDistanceSq = distanceSq;
    }
  }
  if (nearest >= 0) {
    return { x: world.x[nearest], y: world.y[nearest] };
  }
  const tumor = round.level?.tumor;
  return tumor ? { x: tumor.cx, y: tumor.cy } : null;
}

function findNearestVessel(world, x, y) {
  let vessel = -1;
  let nearestDistanceSq = Infinity;
  for (let i = 0; i < world.capacity; i += 1) {
    if (world.alive[i] === 0 || world.kind[i] !== KIND.VESSEL) {
      continue;
    }
    const dx = world.x[i] - x;
    const dy = world.y[i] - y;
    const distanceSq = dx * dx + dy * dy;
    if (distanceSq < nearestDistanceSq) {
      vessel = i;
      nearestDistanceSq = distanceSq;
    }
  }
  return vessel;
}

function queueWave(dc) {
  const world = this.world;
  const vessel = findNearestVessel(world, world.x[dc], world.y[dc]);
  if (vessel < 0) {
    return false;
  }

  let queued = 0;
  const entryDistance = world.radius[vessel] + P.radius[KIND.CD8];
  for (let n = 0; n < P.dc.waveSize; n += 1) {
    const angle = this.rng.angle();
    const x = clamp(world.x[vessel] + Math.cos(angle) * entryDistance, 0, WORLD_W);
    const y = clamp(world.y[vessel] + Math.sin(angle) * entryDistance, 0, WORLD_H);
    if (queueSpawn.call(
      this,
      KIND.CD8,
      x,
      y,
      1,
      0,
      0,
      -1,
      STATE.NAIVE,
      0,
    )) {
      queued += 1;
    }
  }
  if (queued > 0) {
    queueEvent.call(
      this,
      EVENT_WAVE,
      world.x[vessel],
      world.y[vessel],
      KIND.CD8,
      queued,
    );
    // A freshly-called wave has nowhere to go but "toward the tumor" -- lay a guiding chain
    // now, and arm updateDendritic's periodic refresh (world.a2, while MATURE) to keep
    // re-laying it for DC_WAVE_GUIDE_DURATION_SEC. These new arrivals have no existing
    // productive position a signal could pull them away from, and one deposit alone fades
    // long before a cell moving at normal speed can cross a gap this large.
    const dest = findWaveGuideDestination(this, world.x[vessel], world.y[vessel]);
    if (dest) {
      layWaveGuideChain(this, world.x[vessel], world.y[vessel], dest.x, dest.y);
    }
    world.a2[dc] = Math.max(world.a2[dc], P.dc.waveGuideDurationSec);
  }
  return queued > 0;
}

/**
 * Re-lay the vessel-to-tumor guide chain for a DC that already has an active guide window
 * (world.a2[dc] > 0, armed by queueWave). Called on roughly a 1-second cadence from
 * updateDendritic rather than every tick -- frequent enough that a slow-moving reinforcement
 * never outruns the fading signal, without paying the deposit cost 60 times a second.
 */
function refreshWaveGuide(dc) {
  const world = this.world;
  const vessel = findNearestVessel(world, world.x[dc], world.y[dc]);
  if (vessel < 0) {
    return;
  }
  const dest = findWaveGuideDestination(this, world.x[vessel], world.y[vessel]);
  if (!dest) {
    return;
  }
  layWaveGuideChain(this, world.x[vessel], world.y[vessel], dest.x, dest.y);
}

function relaxNeighbor(other) {
  const round = relaxRound;
  const world = round.world;
  const i = relaxSlot;
  if (other <= i || world.alive[other] === 0
    || round._deathQueued[other] !== 0) {
    return;
  }

  let dx = world.x[other] - world.x[i];
  let dy = world.y[other] - world.y[i];
  let distanceSq = dx * dx + dy * dy;
  const minDistance = world.radius[i] + world.radius[other];
  if (distanceSq >= minDistance * minDistance) {
    return;
  }
  if (distanceSq <= Number.EPSILON) {
    dx = ((i + other) & 1) === 0 ? 1 : -1;
    dy = 0;
    distanceSq = 1;
  }
  const distance = Math.sqrt(distanceSq);
  const overlap = minDistance - distance;
  const nx = dx / distance;
  const ny = dy / distance;
  const fixedI = world.kind[i] === KIND.VESSEL;
  const fixedOther = world.kind[other] === KIND.VESSEL;
  if (fixedI && fixedOther) {
    return;
  }
  if (fixedI) {
    world.x[other] += nx * overlap;
    world.y[other] += ny * overlap;
  } else if (fixedOther) {
    world.x[i] -= nx * overlap;
    world.y[i] -= ny * overlap;
  } else {
    const half = overlap * 0.5;
    world.x[i] -= nx * half;
    world.y[i] -= ny * half;
    world.x[other] += nx * half;
    world.y[other] += ny * half;
  }
}

function relaxOverlaps(round) {
  const world = round.world;
  relaxRound = round;
  for (let iteration = 0; iteration < 2; iteration += 1) {
    for (let i = 0; i < world.capacity; i += 1) {
      if (world.alive[i] === 0 || round._deathQueued[i] !== 0) {
        continue;
      }
      relaxSlot = i;
      round.hash.forEachNeighbor(
        world.x[i],
        world.y[i],
        MAX_AGENT_RADIUS * 2,
        relaxNeighbor,
      );
    }
  }
  relaxSlot = -1;
  relaxRound = null;
}

function applyDeaths(round) {
  const world = round.world;
  for (let n = 0; n < round._deathCount; n += 1) {
    const victim = round._deathSlots[n];
    const killer = round._deathKillers[n];
    if (world.alive[victim] === 0) {
      round._deathQueued[victim] = 0;
      continue;
    }
    const victimKind = world.kind[victim];
    const x = world.x[victim];
    const y = world.y[victim];
    let killerKind = KIND.NONE;
    if (killer >= 0 && world.alive[killer] !== 0) {
      killerKind = world.kind[killer];
      world.a2[killer] += 1;
      world.a3[killer] = -1;
      world.timer[killer] = P.recognition.killCooldown;
      world.state[killer] = STATE.ACTIVE;
      round.stats.killsByKind[killerKind] += 1;
    }

    if (victimKind === KIND.TUMOR) {
      round.stats.tumorKilled += 1;
      round.grid.deposit(FIELD.DEBRIS, x, y, P.production.debrisPerDeath);
    } else if (victimKind === KIND.HEALTHY) {
      round.stats.healthyKilled += 1;
      round.patientHealth = Math.max(
        0,
        round.patientHealth - P.patient.healthPerHealthyCell,
      );
      queueEvent.call(round, EVENT_TOXICITY, x, y, 0, 0);
    }

    world.kill(victim);
    round._deathQueued[victim] = 0;
    queueEvent.call(round, EVENT_KILL, x, y, killerKind, victimKind);
  }
}

function applySpawns(round) {
  const world = round.world;
  for (let n = 0; n < round._spawnCount; n += 1) {
    const kind = round._spawnKind[n];
    const i = world.spawn(kind, round._spawnX[n], round._spawnY[n]);
    if (i < 0) {
      continue;
    }
    world.a0[i] = round._spawnA0[n];
    world.a1[i] = round._spawnA1[n];
    world.a2[i] = round._spawnA2[n];
    world.a3[i] = round._spawnA3[n];
    world.state[i] = round._spawnState[n];
    world.timer[i] = round._spawnTimer[n];
    if (kind === KIND.TUMOR) {
      queueEvent.call(
        round,
        EVENT_DIVIDE,
        round._spawnX[n],
        round._spawnY[n],
        0,
        0,
      );
    }
  }
}

function materializeEvents(round) {
  const events = round.events;
  for (let i = 0; i < round._eventCount; i += 1) {
    const code = round._eventCode[i];
    const x = round._eventX[i];
    const y = round._eventY[i];
    if (code === EVENT_KILL) {
      events.push({
        type: 'kill',
        x,
        y,
        killerKind: round._eventP0[i],
        victimKind: round._eventP1[i],
      });
    } else if (code === EVENT_DIVIDE) {
      events.push({ type: 'divide', x, y });
    } else if (code === EVENT_ENGAGE) {
      events.push({ type: 'engage', x, y });
    } else if (code === EVENT_POLARIZE) {
      events.push({ type: 'polarize', x, y, to: round._eventP0[i] });
    } else if (code === EVENT_WAVE) {
      events.push({
        type: 'wave',
        x,
        y,
        kind: round._eventP0[i],
        n: round._eventP1[i],
      });
    } else if (code === EVENT_TOXICITY) {
      events.push({ type: 'toxicity', x, y });
    }
  }
}

function updateMeters(round, dt) {
  const world = round.world;
  round.timeSec += dt;
  round.tumorCount = world.countOf(KIND.TUMOR);
  let immuneCount = 0;
  let engaged = 0;
  for (let i = 0; i < world.capacity; i += 1) {
    if (world.alive[i] === 0) {
      continue;
    }
    if (isImmuneKind(world.kind[i])) {
      immuneCount += 1;
    }
    if (world.state[i] === STATE.ENGAGED) {
      engaged += 1;
    }
  }
  round.immuneCount = immuneCount;

  let crsDrive = engaged * P.patient.crsPerEngagedKiller
    + round.grid.total(FIELD.IFNG)
      * round.grid.cellW
      * round.grid.cellH
      * P.patient.crsPerIfngMass;
  if (round.plan.il2) {
    crsDrive *= P.patient.crsIl2Multiplier;
  }
  round.crs = clamp(
    round.crs + crsDrive * dt - P.patient.crsRecoveryPerSec * round.crs * dt,
    0,
    1,
  );
  if (round.crs > P.patient.crsDanger) {
    round.patientHealth = Math.max(
      0,
      round.patientHealth
        - (round.crs - P.patient.crsDanger) * P.patient.crsHealthDamage * dt,
    );
  }

  round.stats.timeSec = round.timeSec;
  round.stats.tumorRemaining = round.tumorCount;
  round.stats.patientHealth = round.patientHealth;
  if (round.crs > round.stats.peakCrs) {
    round.stats.peakCrs = round.crs;
  }
  round.outcome = evaluateOutcome(round, round.level);
  round.stats.outcome = round.outcome;

  round._historyAccum += dt;
  if (round._historyAccum >= 1) {
    round._historyAccum -= 1;
    round.stats.history.push({
      t: round.timeSec,
      tumor: round.tumorCount,
      immune: round.immuneCount,
      crs: round.crs,
    });
  }
}

function tickRound(dt) {
  if (this.outcome !== OUTCOME.RUNNING || !(dt > 0)) {
    return;
  }
  this.events.length = 0;
  this._deathCount = 0;
  this._spawnCount = 0;
  this._eventCount = 0;
  this._deathQueued.fill(0);

  this._diffuseAccum += dt;
  this._diffuseTicks += 1;
  if (this._diffuseTicks >= this.quality.diffuseEvery) {
    this.grid.step(this._diffuseAccum, this._fieldParams);
    this._diffuseAccum = 0;
    this._diffuseTicks = 0;
  }

  this.hash.rebuild(this.world);

  const world = this.world;
  for (let i = 0; i < world.capacity; i += 1) {
    if (world.alive[i] === 0 || this._deathQueued[i] !== 0) {
      continue;
    }
    world.age[i] += dt;
    const kind = world.kind[i];
    if (kind === KIND.TUMOR) {
      updateTumor(this, i, dt);
    } else if (kind === KIND.CD8 || kind === KIND.CART) {
      updateTCell(this, i, dt);
    } else if (kind === KIND.NK) {
      updateNK(this, i, dt);
    } else if (kind === KIND.MACRO) {
      updateMacrophage(this, i, dt);
    } else if (kind === KIND.DC) {
      updateDendritic(this, i, dt);
    } else if (kind === KIND.CD4) {
      updateCD4(this, i, dt);
    } else if (kind === KIND.TREG) {
      updateTreg(this, i, dt);
    } else if (kind === KIND.HEALTHY) {
      updateHealthy(this, i, dt);
    }
  }

  for (let i = 0; i < world.capacity; i += 1) {
    if (world.alive[i] === 0 || this._deathQueued[i] !== 0) {
      continue;
    }
    world.x[i] = clamp(
      world.x[i] + world.vx[i] * dt,
      world.radius[i],
      WORLD_W - world.radius[i],
    );
    world.y[i] = clamp(
      world.y[i] + world.vy[i] * dt,
      world.radius[i],
      WORLD_H - world.radius[i],
    );
  }

  relaxOverlaps(this);
  for (let i = 0; i < world.capacity; i += 1) {
    if (world.alive[i] !== 0) {
      world.x[i] = clamp(world.x[i], world.radius[i], WORLD_W - world.radius[i]);
      world.y[i] = clamp(world.y[i], world.radius[i], WORLD_H - world.radius[i]);
    }
  }

  applyDeaths(this);
  applySpawns(this);
  materializeEvents(this);
  updateMeters(this, dt);
}

function drainEvents() {
  const drained = this.events;
  this.events = this._eventSpare;
  this.events.length = 0;
  this._eventSpare = drained;
  return drained;
}

function setSpeed(multiplier) {
  if (multiplier !== 1 && multiplier !== 2 && multiplier !== 3) {
    throw new RangeError('speed multiplier must be 1, 2, or 3');
  }
  this.speed = multiplier;
}

function abortRound() {
  if (this.outcome === OUTCOME.RUNNING) {
    this.outcome = OUTCOME.ABORTED;
    this.stats.outcome = OUTCOME.ABORTED;
  }
}

function computePerfusion(level, grid) {
  const perfusion = new Float32Array(grid.w * grid.h);
  const diagonal = Math.hypot(WORLD_W, WORLD_H);
  let total = 0;
  for (let cy = 0; cy < grid.h; cy += 1) {
    const y = (cy + 0.5) * grid.cellH;
    for (let cx = 0; cx < grid.w; cx += 1) {
      const x = (cx + 0.5) * grid.cellW;
      let nearest = diagonal;
      for (let v = 0; v < level.vessels.length; v += 1) {
        const dx = level.vessels[v].x - x;
        const dy = level.vessels[v].y - y;
        const distance = Math.hypot(dx, dy);
        if (distance < nearest) {
          nearest = distance;
        }
      }
      const value = Math.max(0, 1 - nearest / diagonal);
      perfusion[cy * grid.w + cx] = value;
      total += value;
    }
  }
  return {
    data: perfusion,
    mean: perfusion.length > 0 ? total / perfusion.length : 0,
  };
}

function spawnInitialAgents(round) {
  const world = round.world;
  const level = round.level;
  const rng = round.rng;

  for (let v = 0; v < level.vessels.length; v += 1) {
    world.spawn(KIND.VESSEL, level.vessels[v].x, level.vessels[v].y);
  }

  for (let n = 0; n < level.tumor.count; n += 1) {
    const x = clamp(
      rng.gauss(level.tumor.cx, level.tumor.spreadWu * 0.5),
      P.radius[KIND.TUMOR],
      WORLD_W - P.radius[KIND.TUMOR],
    );
    const y = clamp(
      rng.gauss(level.tumor.cy, level.tumor.spreadWu * 0.5),
      P.radius[KIND.TUMOR],
      WORLD_H - P.radius[KIND.TUMOR],
    );
    const i = world.spawn(KIND.TUMOR, x, y);
    if (i < 0) break;
    const antigen = sampleAntigen(level.tumor.antigenMix, rng);
    world.a0[i] = antigen;
    world.a1[i] = sampleMhc(rng, level.tumor, antigen);
    world.a2[i] = level.tumor.pdl1Base;
    world.a3[i] = 0;
    world.timer[i] = P.tumor.divideTimeSec
      * level.tumor.divideTimeScale
      * rng.range(0.8, 1.2);
  }

  for (let n = 0; n < level.healthy.count; n += 1) {
    const x = rng.range(P.radius[KIND.HEALTHY], WORLD_W - P.radius[KIND.HEALTHY]);
    const y = rng.range(P.radius[KIND.HEALTHY], WORLD_H - P.radius[KIND.HEALTHY]);
    const i = world.spawn(KIND.HEALTHY, x, y);
    if (i < 0) break;
    world.a0[i] = level.healthy.antigen;
  }

  const retainedTregs = round.plan.lymphodepletion
    ? Math.round(level.tregs * (1 - P.patient.lymphoTregKill))
    : level.tregs;
  for (let n = 0; n < retainedTregs; n += 1) {
    const x = clamp(
      rng.gauss(level.tumor.cx, level.tumor.spreadWu),
      P.radius[KIND.TREG],
      WORLD_W - P.radius[KIND.TREG],
    );
    const y = clamp(
      rng.gauss(level.tumor.cy, level.tumor.spreadWu),
      P.radius[KIND.TREG],
      WORLD_H - P.radius[KIND.TREG],
    );
    if (world.spawn(KIND.TREG, x, y) < 0) break;
  }

  for (let n = 0; n < round.plan.placements.length; n += 1) {
    const placement = round.plan.placements[n];
    if (world.spawn(
      placement.kind,
      clamp(placement.x, 0, WORLD_W),
      clamp(placement.y, 0, WORLD_H),
    ) < 0) {
      break;
    }
  }
}

// Exported for regression testing (see tests/mhc-independence.test.js), which needs to
// spawn cells with the exact same distributions the real game uses rather than a
// reimplementation that could silently drift out of sync with this file.
export { sampleAntigen, sampleMhc };

/**
 * Create a seeded headless simulation round from a level and treatment plan.
 * @param {{level:object, plan:object, seed:number, quality:object}} opts
 * @returns {object}
 */
export function createRound(opts) {
  const rng = makeRng(opts.seed);
  const quality = opts.quality;
  const world = makeWorld({
    capacity: quality.maxAgents,
    worldW: WORLD_W,
    worldH: WORLD_H,
    rng,
  });
  const grid = makeFieldGrid({
    w: quality.gridW,
    h: quality.gridH,
    worldW: WORLD_W,
    worldH: WORLD_H,
    fieldCount: FIELD_COUNT,
    concentrationUnitArea: FIELD_CONCENTRATION_UNIT_AREA,
  });
  const hash = makeSpatialHash({
    worldW: WORLD_W,
    worldH: WORLD_H,
    cellSize: MAX_AGENT_RADIUS * 2 + P.recognition.engageMargin,
  });
  const perfusionResult = computePerfusion(opts.level, grid);
  const capacity = quality.maxAgents;
  const killsByKind = new Uint32Array(KIND.HEALTHY + 1);
  const startingHealth = opts.plan.lymphodepletion
    ? 100 - P.patient.lymphoHealthCost
    : 100;

  // API-NOTE: params.js exports no perfusion falloff or division threshold.
  // The static field is normalized by world diagonal and "lowest" is interpreted
  // relatively: after spawning, cells below the initial tumor's mean perfusion cannot divide.
  const round = {
    level: opts.level,
    plan: opts.plan,
    quality,
    world,
    grid,
    hash,
    rng,
    perfusion: perfusionResult.data,
    perfusionMean: perfusionResult.mean,
    timeSec: 0,
    outcome: OUTCOME.RUNNING,
    tumorCount: 0,
    immuneCount: 0,
    patientHealth: startingHealth,
    crs: 0,
    speed: 1,
    events: [],
    stats: {
      outcome: OUTCOME.RUNNING,
      timeSec: 0,
      tumorStart: 0,
      tumorRemaining: 0,
      tumorKilled: 0,
      healthyKilled: 0,
      patientHealth: startingHealth,
      peakCrs: 0,
      budgetUnspent: Math.max(0, opts.level.budget - planCost(opts.plan)),
      killsByKind,
      history: [],
    },
    _eventSpare: [],
    _fieldParams: { diffusion: P.diffusion, decay: P.decay },
    _gradientScratch: { x: 0, y: 0 },
    _beaconGradientScratch: { x: 0, y: 0 },
    _diffuseAccum: 0,
    _diffuseTicks: 0,
    _historyAccum: 0,
    _deathQueued: new Uint8Array(capacity),
    _deathSlots: new Int32Array(capacity),
    _deathKillers: new Int32Array(capacity),
    _deathCount: 0,
    _spawnKind: new Uint8Array(capacity),
    _spawnState: new Uint8Array(capacity),
    _spawnX: new Float32Array(capacity),
    _spawnY: new Float32Array(capacity),
    _spawnA0: new Float32Array(capacity),
    _spawnA1: new Float32Array(capacity),
    _spawnA2: new Float32Array(capacity),
    _spawnA3: new Float32Array(capacity),
    _spawnTimer: new Float32Array(capacity),
    _spawnCount: 0,
    _eventCode: new Uint8Array(MAX_EVENTS_PER_TICK),
    _eventX: new Float32Array(MAX_EVENTS_PER_TICK),
    _eventY: new Float32Array(MAX_EVENTS_PER_TICK),
    _eventP0: new Int32Array(MAX_EVENTS_PER_TICK),
    _eventP1: new Int32Array(MAX_EVENTS_PER_TICK),
    _eventCount: 0,
    _findTarget: findTarget,
    _queueDeath: queueDeath,
    _queueSpawn: queueSpawn,
    _queueEvent: queueEvent,
    _damageTarget: damageTarget,
    _recoverKiller: recoverKiller,
    _move: moveAgent,
    _perfusionAt: perfusionAt,
    _hasDivisionClearance: hasDivisionClearance,
    _takeDebris: takeDebris,
    _queueWave: queueWave,
    _refreshWaveGuide: refreshWaveGuide,
    tick: tickRound,
    drainEvents,
    setSpeed,
    abort: abortRound,
  };

  const planeSize = grid.w * grid.h;
  grid.data.fill(
    opts.level.startingChemokine / grid.concentrationUnitArea,
    FIELD.CHEMOKINE * planeSize,
    (FIELD.CHEMOKINE + 1) * planeSize,
  );
  grid.data.fill(
    opts.level.startingSuppress / grid.concentrationUnitArea,
    FIELD.SUPPRESS * planeSize,
    (FIELD.SUPPRESS + 1) * planeSize,
  );
  spawnInitialAgents(round);
  hash.rebuild(world);
  round.tumorCount = world.countOf(KIND.TUMOR);
  round.stats.tumorStart = round.tumorCount;
  round.stats.tumorRemaining = round.tumorCount;
  let immuneCount = 0;
  let tumorPerfusionTotal = 0;
  let tumorPerfusionCount = 0;
  for (let i = 0; i < world.capacity; i += 1) {
    if (world.alive[i] === 0) {
      continue;
    }
    if (isImmuneKind(world.kind[i])) {
      immuneCount += 1;
    } else if (world.kind[i] === KIND.TUMOR) {
      tumorPerfusionTotal += round._perfusionAt(world.x[i], world.y[i]);
      tumorPerfusionCount += 1;
    }
  }
  if (tumorPerfusionCount > 0) {
    round.perfusionMean = tumorPerfusionTotal / tumorPerfusionCount;
  }
  round.immuneCount = immuneCount;
  return round;
}
