# Cell Commander — Module API Contract

**Every module must implement exactly these signatures.** They are what the other modules
import. Do not rename, do not change argument order, do not add required arguments. Adding
*optional* arguments or extra exports is fine.

If you believe a signature is wrong, implement it as written and leave a `// API-NOTE:` comment
explaining the concern. Integration is done by the orchestrator, who will resolve it.

All files are ES modules (`import`/`export`), no build step, no dependencies.

---

## `src/core/rng.js`

Deterministic PRNG. **`Math.random` is banned everywhere else in the codebase.**

```js
export function makeRng(seed: number): Rng
// Rng = {
//   next(): number            // uniform [0,1)
//   int(nExclusive): number   // integer [0, n)
//   range(lo, hi): number     // uniform [lo, hi)
//   pick(array): any
//   bool(p): boolean          // true with probability p
//   gauss(mean=0, sd=1): number
//   angle(): number           // uniform [0, 2*PI)
//   fork(salt: number): Rng   // independent stream, deterministic from (seed, salt)
//   state(): number           // current internal state, for snapshot/restore
//   restore(s: number): void
// }

export function seedFromString(s: string): number   // stable 32-bit hash
export function dailySeed(levelId: string, date?: Date): number
//   Stable per (level, calendar day) so everyone at the booth on one day
//   plays the identical tumor. Uses local date, not UTC.
```

Implementation: mulberry32. Must be exactly reproducible across Node and browsers.

---

## `src/core/grid.js`

Diffusing scalar fields on a shared uniform grid.

```js
export function makeFieldGrid(opts: {
  w: number,          // grid columns
  h: number,          // grid rows
  worldW: number,
  worldH: number,
  fieldCount: number,
}): FieldGrid
```

`FieldGrid` API:

```js
grid.w, grid.h, grid.cellW, grid.cellH, grid.fieldCount
grid.data: Float32Array          // length = fieldCount * w * h, field-major
grid.idx(f, cx, cy): number      // index into data; caller guarantees in-bounds
grid.clear(f?): void             // clear one field, or all if omitted

grid.deposit(f, worldX, worldY, amount): void
//   Add `amount` to the cell containing (worldX, worldY). Clamped to bounds.

grid.depositRadius(f, worldX, worldY, amount, radiusWu): void
//   Spread `amount` over a disc, weights summing to 1 (mass-conserving).

grid.sample(f, worldX, worldY): number
//   Bilinear sample. Returns 0 outside bounds.

grid.gradient(f, worldX, worldY, out: {x:number,y:number}): void
//   Central-difference gradient in world units, written into `out` (no allocation).

grid.step(dt, params): void
//   One diffusion + decay step for ALL fields.
//   params: { diffusion: Float32Array|number[], decay: Float32Array|number[] }
//     diffusion[f] in wu^2/s ; decay[f] = fractional loss per second.
//   Zero-flux (Neumann) boundaries. Uses ping-pong buffers, allocates nothing per call.
//   MUST be numerically stable: internally clamp the diffusion number
//   alpha = D*dt/cell^2 to <= 0.24 by sub-stepping, so a big dt can never blow up.

grid.total(f): number            // sum of a field (used by mass-conservation tests)
grid.max(f): number
grid.resize(w, h): void          // reallocate for a quality-tier change; clears fields
```

---

## `src/core/spatialhash.js`

```js
export function makeSpatialHash(opts: {
  worldW: number, worldH: number, cellSize: number
}): SpatialHash

hash.rebuild(world): void
//   Bucket every ALIVE agent by slot index. Allocation-free after first call.

hash.forEachNeighbor(x, y, radius, fn: (slotIndex:number) => void): void
//   Calls fn for every alive agent whose CENTER is within `radius` of (x,y).
//   May include the querying agent — callers filter by index themselves.

hash.nearest(x, y, radius, predicate: (i:number)=>boolean): number
//   Slot index of the nearest agent satisfying predicate, or -1.

hash.cellSize: number
```

---

## `src/core/perf.js`

```js
export function makePerfMonitor(opts?: { sampleSize?: number }): PerfMonitor

perf.frame(ms: number): void      // record one frame's total time
perf.median(): number
perf.p95(): number
perf.fps(): number
perf.reset(): void

export function makeQualityController(startTier: string): QualityController
qc.tier: object                    // one of QUALITY.* from contracts.js
qc.update(medianFrameMs: number): boolean   // returns true if the tier CHANGED
qc.forceTier(id: string): void
//   Drop a tier if median > 20ms for 90 consecutive updates.
//   Raise a tier if median < 11ms for 300 consecutive updates.
```

---

## `src/sim/params.js`

Owned by the orchestrator. Exports one frozen object `P` plus helpers. Read it; never edit it.

```js
export const P                       // all biological constants
export const BIO_MIN_PER_GAME_SEC    // time compression factor
export function killRateFor(kind)    // packets/sec
export const COST                    // credit cost per purchasable item, keyed by KIND or string
```

---

## `src/sim/world.js`

The SoA agent store.

```js
export function makeWorld(opts: {
  capacity: number, worldW: number, worldH: number, rng: Rng
}): World

world.capacity, world.worldW, world.worldH, world.rng
world.count            // number of ALIVE agents
world.kind, world.state, world.alive, world.x, world.y, world.vx, world.vy,
world.radius, world.age, world.timer, world.hp, world.a0, world.a1, world.a2, world.a3
                       // typed arrays, length = capacity  (see AGENT_COLUMNS in contracts.js)

world.spawn(kind, x, y): number
//   Returns slot index, or -1 if at capacity. Initializes ALL columns for that kind
//   (defaults from params.js): radius, state, hp=1, a0..a3.

world.kill(i): void    // mark dead, push slot onto the free list
world.compactIfNeeded(): void

world.forEachAlive(fn: (i:number) => void): void
world.countOf(kind): number
world.aliveIndices(): Int32Array   // reused buffer; valid until next call

world.snapshot(): object           // small plain object for tests/determinism hashing
world.hash(): number               // order-independent numeric digest of live state
```

`world.hash()` is the determinism test's tool: same seed + same plan ⇒ identical hash at
every tick. Must not depend on slot ordering.

---

## `src/sim/plan.js`

```js
export function makePlan(overrides?): TreatmentPlan     // see contracts.js typedef
export function planCost(plan): number
export function validatePlan(plan, level): { ok: boolean, errors: string[] }
export function addPlacement(plan, kind, x, y): boolean  // false if unaffordable/illegal
export function removePlacementAt(plan, x, y, radius): boolean
export function clearPlacements(plan): void
```

---

## `src/sim/engine.js`

```js
export function createRound(opts: {
  level: LevelDef, plan: TreatmentPlan, seed: number, quality: object
}): Round

round.world, round.grid, round.hash, round.rng
round.timeSec           // elapsed game seconds
round.outcome           // OUTCOME.*
round.stats             // live RoundStats (see contracts.js)
round.tumorCount, round.immuneCount, round.patientHealth, round.crs

round.tick(dt): void
//   ONE fixed timestep. Order is fixed and must not change:
//     1. grid.step  (respecting quality.diffuseEvery)
//     2. hash.rebuild
//     3. behaviors, one pass per agent
//     4. movement integration
//     5. overlap relaxation (2 iterations)
//     6. spawns/deaths applied, events emitted
//     7. meters (crs, patientHealth), outcome check, history sampling
//
round.events: Array<Event>   // drained by the renderer each frame; see below
round.drainEvents(): Array<Event>

round.setSpeed(multiplier): void    // 1, 2, or 3 — applied by the caller running more ticks
round.abort(): void                 // player pressed emergency stop
```

**Events** (for particles/sound; renderer-only, sim must work with nobody listening):

```js
{ type: 'kill',     x, y, killerKind, victimKind }
{ type: 'divide',   x, y }
{ type: 'engage',   x, y }
{ type: 'polarize', x, y, to }     // M1 / M2
{ type: 'wave',     x, y, kind, n } // DC called in reinforcements
{ type: 'toxicity', x, y }
```

Cap `round.events` at 256 per tick; drop the excess. Never let it grow unbounded.

---

## `src/sim/behaviors/*.js`

One file per kind. Each exports a single function with this exact shape:

```js
export function updateTumor(round, i, dt): void
export function updateTCell(round, i, dt): void      // handles CD8 and CART
export function updateNK(round, i, dt): void
export function updateMacrophage(round, i, dt): void
export function updateDendritic(round, i, dt): void
export function updateCD4(round, i, dt): void
export function updateTreg(round, i, dt): void
export function updateHealthy(round, i, dt): void
```

Pure with respect to module state: read/write only `round.*`. No module-level mutable state,
no allocation inside the function body (hoist scratch objects to module scope).

---

## `src/sim/scoring.js`

```js
export function evaluateOutcome(round, level): number     // OUTCOME.*
export function computeScore(stats, level): {
  total: number, base: number, speed: number, health: number,
  efficiency: number, penalty: number, breakdown: Array<{label, value, good}>
}
```

`breakdown` drives the results screen's animated score tally. `good` is a boolean for coloring.

---

## `src/content/levels.js`

```js
export const LEVELS: LevelDef[]
export function getLevel(id: string): LevelDef

// LevelDef = {
//   id, number, name, subtitle,
//   teaches: string,             // one kid-facing sentence
//   budget: number,
//   timeLimitSec: number,
//   tumorEscapeCap: number,
//   tumor: {
//     count, cx, cy, spreadWu,
//     antigenMix: { [ANTIGEN.*]: fraction },   // must sum to 1
//     mhcMean, mhcSd,
//     pdl1Base, pdl1Inducible,                 // 0..1
//     divideTimeScale,                          // multiplier on P.tumor.divideTimeSec
//   },
//   healthy: { count, antigen },               // ANTIGEN.NONE = no toxicity risk
//   vessels: Array<{x,y}>,
//   tregs: number,
//   startingSuppress: number,
//   startingChemokine: number,
//   unlocks: Array<KIND|string>,               // what the shop offers
//   scienceCardId: string,
//   hint: string,                              // <= 20 words, shown in setup
// }
```

`LEVELS` must satisfy `tests/levels.test.js`: antigen mixes sum to 1, every `scienceCardId`
resolves, budgets are affordable enough to buy a winning plan, vessels are inside the world.

---

## `src/content/science.js`

```js
export const SCIENCE_CARDS   // { [id]: { id, title, kidText, realText, concept, icon } }
export function getCard(id)
```

- `kidText`: ≤ 40 words, ~grade-4 reading level, second person, no jargon without a gloss.
- `realText`: 1–2 sentences naming the actual immunology term, for teachers and older kids.
- `concept`: the textbook term, e.g. `"adaptive resistance (IFN-γ-induced PD-L1)"`.

---

## `src/render/*`

```js
// sprites.js
export function buildSpriteCache(dpr: number): SpriteCache
cache.get(kind, state, variantKey): HTMLCanvasElement|OffscreenCanvas
cache.invalidate(): void

// fx.js
export function makeFx(opts:{max:number}): Fx
fx.emitKill(x,y,color) ; fx.emitDivide(x,y) ; fx.emitPuff(x,y,color) ; fx.emitToxic(x,y)
fx.update(dt) ; fx.draw(ctx, view) ; fx.clear() ; fx.setBudget(fraction)

// canvas.js
export function makeRenderer(canvas, opts): Renderer
r.resize(cssW, cssH): void
r.setView(view): void            // { scale, offsetX, offsetY } world -> screen
r.draw(round, uiState, dt): void
r.worldToScreen(wx, wy, out): void
r.screenToWorld(sx, sy, out): void
r.setFieldOverlay(fieldIdOrNull): void

// hud.js
export function makeHud(rootEl): Hud
hud.update(round, level): void
hud.setVisible(b): void
```

The renderer must never mutate `round`. It reads and draws. Enforced by review.

---

## `src/ui/*`

```js
// app.js  — the only module that touches document/window at boot
export function boot(rootEl): App
app.go(screen, payload): void       // SCREEN.*
app.current: string
app.destroy(): void
```

Each screen module exports:

```js
export function mount(rootEl, ctx): { unmount(): void, update?(dt): void }
// ctx = { app, level, plan, round, rng, storage, quality }
```

```js
// leaderboard.js
export function loadScores(levelId, seed): Entry[]
export function saveScore(levelId, seed, entry): Entry[]   // returns updated sorted list
export function clearScores(levelId?): void
export function exportScores(): string      // JSON
export function importScores(json): void
// Entry = { initials: string, score: number, timeSec: number, when: number }
// Storage key: `cc.scores.v1.<levelId>.<seed>` in localStorage.
// MUST degrade gracefully when localStorage is unavailable (Safari private mode)
// — fall back to an in-memory store, never throw.
```

---

## Coding standards

- ES2022. Modules. No transpiler, no bundler at dev time, no dependencies.
- 2-space indent, semicolons, single quotes.
- JSDoc on every exported function.
- **Hot loop discipline:** no `new`, no array literals, no closures inside per-agent loops.
  Hoist scratch vectors to module scope.
- No `console.log` in shipped paths (a `DEBUG` flag guard is fine).
- Every file starts with a one-paragraph comment saying what it owns.
