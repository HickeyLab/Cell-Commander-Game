# Running Cell Commander at a Booth

Cell Commander can run without internet access. Choose one of the three setups below, then test it on every iPad before visitors arrive.

## Option 1: Open one offline HTML file

This is the simplest and most reliable setup for one iPad. The finished file contains the game, code, styles, and images. It needs no server and no Wi-Fi. Rebuilding and AirDropping the file is required whenever the game changes.

On a laptop, open a terminal in the Cell Commander folder and run:

```sh
node tools/make-icons.mjs
npm run build
```

The booth file is `dist/cell-commander.html`. AirDrop it to the iPad, choose **Save to Files**, open the Files app, and tap the file. Test it with Airplane Mode on before the event.

Use this option when each iPad can keep its own independent game and scores. Service workers and “Add to Home Screen” are not used when opening a file directly.

## Option 2: Serve the game from a laptop

This is the easiest setup for several iPads opening the same hosted copy on a local network. The laptop must stay awake and all devices must remain on the same Wi-Fi. The internet itself is not required, but some guest networks block devices from seeing one another.

Generate the icons, then start the server:

```sh
node tools/make-icons.mjs
npm run serve
```

The terminal prints addresses like:

```text
Tablet:  http://192.168.1.23:8080/    <- open this on the iPad
```

Open the printed **Tablet** address in Safari on every iPad. Keep the terminal window open. Each iPad still keeps its own browser storage; this option shares the running app, not a synchronized leaderboard.

If port 8080 is already in use, run:

```sh
node tools/serve.mjs --port 8081
```

## Option 3: GitHub Pages offline PWA

This gives each iPad a full-screen home-screen icon with offline caching. It is convenient for repeat events and remote setup, but the first visit and every update require internet access. GitHub Pages must serve the repository over HTTPS for the service worker to work.

Before publishing, generate the icons and verify the standalone build:

```sh
node tools/make-icons.mjs
npm test
npm run build
node tools/bundle.mjs --check
```

Push the site files to the branch used for deployment. In the GitHub repository:

1. Open **Settings → Pages**.
2. Under **Build and deployment**, choose **Deploy from a branch**.
3. Select the deployment branch and the repository root, then save.
4. Open the published Pages URL once on each iPad while online.
5. In Safari, tap **Share → Add to Home Screen → Add**.
6. Launch **Cell Cmdr** from the new icon, then test again in Airplane Mode.

After publishing an update, fully close and reopen the home-screen app. The versioned cache activates on the next launch.

## iPad booth checklist

- Charge the iPad and connect it to continuous power.
- Open the game once and complete a short test round.
- Turn off auto-lock: **Settings → Display & Brightness → Auto-Lock → Never**.
- Set brightness high enough for the booth, but below maximum if heat or battery life is a concern.
- Hold the iPad in landscape and turn on **Rotation Lock** in Control Center.
- Turn on Guided Access: **Settings → Accessibility → Guided Access**.
- In the game, triple-click the top or Home button, circle any controls that visitors should not use, then tap **Start**.
- Confirm the Guided Access passcode is known to booth staff.
- For a direct-file or previously cached PWA setup, enable Airplane Mode and verify the title screen and a full round.
- Keep one tested backup copy of `dist/cell-commander.html` in Files.

## Troubleshooting

### The HTML file is blank or Safari says it cannot open it

Make sure you opened `dist/cell-commander.html`, not `index.html`. Rebuild it with `npm run build` and check that the command reports no external references.

### The bundler says `index.html` is missing

The game entry page has not been created in this checkout. Get the complete project files, then run `npm run build` again.

### An iPad cannot reach the laptop

Confirm both devices are on the same Wi-Fi, use the exact **Tablet** URL printed by `npm run serve`, and keep the server terminal open. Allow Node through the laptop firewall. If the venue network isolates devices, use a personal hotspot or the direct-file option.

### The home-screen app does not work offline

Open the GitHub Pages URL in Safari while online and wait for the app to load before using **Add to Home Screen**. Service workers do not run from `file://` pages or ordinary insecure HTTP hosts. Remove the old home-screen icon, revisit the HTTPS Pages URL, and add it again.

### An update does not appear

Close every Safari tab and home-screen window for Cell Commander, then relaunch it while online. If it is still stale, remove the home-screen icon, clear Safari website data for the Pages site, and add the app again.

### The icons are missing

Run `node tools/make-icons.mjs`, confirm all three files are reported as valid PNGs, and publish the `assets/` folder alongside the app.

### The iPad sleeps, rotates, or visitors leave the app

Recheck Auto-Lock, Rotation Lock, and Guided Access in the booth checklist. Guided Access must be started after the game is open.
