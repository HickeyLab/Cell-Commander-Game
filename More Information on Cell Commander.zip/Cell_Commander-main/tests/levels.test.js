/**
 * levels.test.js verifies the public level-data contract, balance-teaching guardrails,
 * enum usage, world geometry, and links from levels to their science cards.
 */

import test from 'node:test';
import assert from 'node:assert/strict';

import { LEVELS, getLevel } from '../src/content/levels.js';
import { SCIENCE_CARDS } from '../src/content/science.js';
import { ANTIGEN, KIND, WORLD_H, WORLD_W } from '../src/core/contracts.js';
import { TUMOR_DIVIDE_TIME_SEC } from '../src/sim/params.js';

const LEVEL_KEYS = [
  'budget',
  'healthy',
  'hint',
  'id',
  'name',
  'number',
  'scienceCardId',
  'startingChemokine',
  'startingSuppress',
  'subtitle',
  'teaches',
  'timeLimitSec',
  'tregs',
  'tumor',
  'tumorEscapeCap',
  'tumorMarkerInfo',
  'tumorProfile',
  'tumorTypeName',
  'unlocks',
  'vessels',
].sort();

const TUMOR_KEYS = [
  'antigenMix',
  'count',
  'cx',
  'cy',
  'divideTimeScale',
  'mhcMean',
  'mhcSd',
  'pdl1Base',
  'pdl1Inducible',
  'spreadWu',
].sort();

const HEALTHY_KEYS = ['antigen', 'count'];
const VESSEL_KEYS = ['x', 'y'];
const VALID_ANTIGENS = new Set(Object.values(ANTIGEN));
const VALID_KINDS = new Set(Object.values(KIND));

function wordCount(text) {
  return text.trim().split(/\s+/u).length;
}

function assertFiniteNumber(value, label) {
  assert.equal(typeof value, 'number', `${label} must be a number`);
  assert.ok(Number.isFinite(value), `${label} must be finite`);
}

test('LEVELS contains six exact LevelDef records and getLevel resolves them', () => {
  assert.equal(LEVELS.length, 6);

  for (const level of LEVELS) {
    assert.deepEqual(Object.keys(level).sort(), LEVEL_KEYS, `${level.id} LevelDef keys`);
    assert.deepEqual(Object.keys(level.tumor).sort(), TUMOR_KEYS, `${level.id} tumor keys`);
    assert.deepEqual(Object.keys(level.healthy).sort(), HEALTHY_KEYS, `${level.id} healthy keys`);

    for (const vessel of level.vessels) {
      assert.deepEqual(Object.keys(vessel).sort(), VESSEL_KEYS, `${level.id} vessel keys`);
    }

    assert.equal(getLevel(level.id), level);
  }

  assert.equal(getLevel('not-a-level'), undefined);
});

test('level ids are unique and level numbers are 1 through 6 with no gaps', () => {
  const ids = LEVELS.map((level) => level.id);
  const numbers = LEVELS.map((level) => level.number).sort((a, b) => a - b);

  assert.equal(new Set(ids).size, LEVELS.length);
  assert.deepEqual(numbers, [1, 2, 3, 4, 5, 6]);
});

test('every antigen mix sums to 1.0 within 1e-9', () => {
  for (const level of LEVELS) {
    const sum = Object.values(level.tumor.antigenMix)
      .reduce((total, fraction) => total + fraction, 0);

    assert.ok(
      Math.abs(sum - 1) <= 1e-9,
      `${level.id} antigenMix sums to ${sum}, not 1`,
    );
  }
});

test('every antigenMix key is an ANTIGEN value and every fraction is valid', () => {
  for (const level of LEVELS) {
    for (const [key, fraction] of Object.entries(level.tumor.antigenMix)) {
      assert.ok(VALID_ANTIGENS.has(Number(key)), `${level.id} uses invalid antigen ${key}`);
      assertFiniteNumber(fraction, `${level.id} antigen ${key} fraction`);
      assert.ok(fraction >= 0 && fraction <= 1, `${level.id} antigen ${key} fraction`);
    }
  }
});

test('every scienceCardId resolves in SCIENCE_CARDS', () => {
  for (const level of LEVELS) {
    assert.ok(
      SCIENCE_CARDS[level.scienceCardId],
      `${level.id} references missing card ${level.scienceCardId}`,
    );
  }
});

test('every vessel coordinate is inside the contract world bounds', () => {
  for (const level of LEVELS) {
    assert.ok(level.vessels.length > 0, `${level.id} must have vessels`);

    for (const vessel of level.vessels) {
      assertFiniteNumber(vessel.x, `${level.id} vessel x`);
      assertFiniteNumber(vessel.y, `${level.id} vessel y`);
      assert.ok(vessel.x >= 0 && vessel.x <= WORLD_W, `${level.id} vessel x ${vessel.x}`);
      assert.ok(vessel.y >= 0 && vessel.y <= WORLD_H, `${level.id} vessel y ${vessel.y}`);
    }
  }
});

test('budgets, timers, caps, and counts are finite and valid', () => {
  for (const level of LEVELS) {
    assertFiniteNumber(level.budget, `${level.id} budget`);
    assert.ok(level.budget > 0, `${level.id} budget must be positive`);

    assertFiniteNumber(level.timeLimitSec, `${level.id} timer`);
    if (level.id === 'sandbox') {
      assert.equal(level.timeLimitSec, 0, 'sandbox timer uses 0 for unlimited');
    } else {
      assert.ok(level.timeLimitSec > 0, `${level.id} timer must be positive`);
    }

    assertFiniteNumber(level.tumorEscapeCap, `${level.id} escape cap`);
    assert.ok(level.tumorEscapeCap > 0, `${level.id} escape cap must be positive`);

    assertFiniteNumber(level.tumor.count, `${level.id} tumor count`);
    assert.ok(Number.isInteger(level.tumor.count) && level.tumor.count > 0);

    assertFiniteNumber(level.healthy.count, `${level.id} healthy count`);
    assert.ok(Number.isInteger(level.healthy.count) && level.healthy.count > 0);

    assertFiniteNumber(level.tregs, `${level.id} Treg count`);
    assert.ok(Number.isInteger(level.tregs) && level.tregs >= 0);
  }
});

test('all remaining numeric level tunables are finite and in their contract ranges', () => {
  for (const level of LEVELS) {
    const { tumor } = level;

    for (const [name, value] of Object.entries({
      cx: tumor.cx,
      cy: tumor.cy,
      spreadWu: tumor.spreadWu,
      mhcMean: tumor.mhcMean,
      mhcSd: tumor.mhcSd,
      pdl1Base: tumor.pdl1Base,
      pdl1Inducible: tumor.pdl1Inducible,
      divideTimeScale: tumor.divideTimeScale,
      startingSuppress: level.startingSuppress,
      startingChemokine: level.startingChemokine,
    })) {
      assertFiniteNumber(value, `${level.id} ${name}`);
    }

    assert.ok(tumor.cx >= 0 && tumor.cx <= WORLD_W);
    assert.ok(tumor.cy >= 0 && tumor.cy <= WORLD_H);
    assert.ok(tumor.spreadWu > 0);
    assert.ok(tumor.mhcMean >= 0 && tumor.mhcMean <= 1);
    assert.ok(tumor.mhcSd >= 0 && tumor.mhcSd <= 1);
    assert.ok(tumor.pdl1Base >= 0 && tumor.pdl1Base <= 1);
    assert.ok(tumor.pdl1Inducible >= 0 && tumor.pdl1Inducible <= 1);
    assert.ok(tumor.divideTimeScale > 0);
    assert.ok(level.startingSuppress >= 0 && level.startingSuppress <= 1);
    assert.ok(level.startingChemokine >= 0 && level.startingChemokine <= 1);
    assert.ok(VALID_ANTIGENS.has(level.healthy.antigen));

    for (const unlock of level.unlocks) {
      assert.ok(
        typeof unlock === 'string' || VALID_KINDS.has(unlock),
        `${level.id} has invalid unlock ${unlock}`,
      );
    }
  }
});

test('every timed level can divide before its clock expires', () => {
  for (const level of LEVELS) {
    if (level.timeLimitSec === 0) continue;
    assert.ok(
      level.tumor.divideTimeScale > 0 && level.tumor.divideTimeScale < 1,
      `${level.id} divideTimeScale must be between 0 and 1`,
    );
    assert.ok(
      TUMOR_DIVIDE_TIME_SEC * level.tumor.divideTimeScale < level.timeLimitSec,
      `${level.id} division interval must fit inside its ${level.timeLimitSec}s clock`,
    );
  }
});

test('setup hints remain at or below the 20-word API limit', () => {
  for (const level of LEVELS) {
    assert.ok(wordCount(level.hint) <= 20, `${level.id} hint has ${wordCount(level.hint)} words`);
  }
});

test('level balance knobs encode each requested teaching setup', () => {
  const first = getLevel('first-contact');
  assert.equal(first.tumor.count, 40);
  assert.deepEqual(first.tumor.antigenMix, { [ANTIGEN.GREEN]: 1 });
  assert.equal(first.tumor.pdl1Base, 0);
  assert.equal(first.tumor.pdl1Inducible, 0);
  assert.equal(first.tregs, 0);
  assert.equal(first.budget, 60);

  const shield = getLevel('the-shield');
  assert.ok(shield.tumor.pdl1Inducible >= 0.8);
  assert.ok(
    shield.budget >= 100,
    `checkpoint-dependent level needs a purse that covers the correct roster, got ${shield.budget}`
  );
  assert.ok(shield.unlocks.includes('checkpoint'));

  const escape = getLevel('the-escape-artist');
  assert.ok(escape.tumor.antigenMix[ANTIGEN.NONE] >= 0.3);
  assert.ok(escape.tumor.antigenMix[ANTIGEN.NONE] <= 0.4);
  assert.ok(escape.tumor.mhcMean < 0.3);
  // This level requires a COMBINATION (NK plus native CD8), which costs more than a
  // single-lineage roster. Balance testing raised the purse from 100 so that the correct
  // answer is affordable; assert a floor rather than an exact figure so tuning stays possible.
  assert.ok(
    escape.budget >= 110,
    `a combination-therapy level needs a purse that can afford a combination, got ${escape.budget}`
  );
  assert.ok(!escape.unlocks.includes(KIND.CART));
  assert.ok(escape.unlocks.includes(KIND.NK));

  const cold = getLevel('cold-tumor');
  assert.ok(cold.startingChemokine <= 0.05);
  assert.ok(cold.tregs >= 3);
  assert.ok(cold.startingSuppress >= 0.5);
  assert.ok(cold.unlocks.includes(KIND.DC));
  assert.ok(cold.unlocks.includes('rally'));
  assert.ok(
    cold.vessels.every((vessel) => Math.hypot(
      vessel.x - cold.tumor.cx,
      vessel.y - cold.tumor.cy,
    ) > 600),
    'cold-tumor vessels must be far from the tumor',
  );

  const core = getLevel('deep-core');
  assert.ok(core.tumor.count >= 100);
  assert.ok(core.tumor.spreadWu >= 140);
  assert.ok(core.vessels.every((vessel) => (
    vessel.x <= 150
    || vessel.x >= WORLD_W - 150
    || vessel.y <= 100
    || vessel.y >= WORLD_H - 100
  )));

  const sandbox = getLevel('sandbox');
  assert.equal(sandbox.timeLimitSec, 0);
  assert.equal(sandbox.tumorEscapeCap, Number.MAX_SAFE_INTEGER);
  assert.ok(sandbox.budget >= 500);
  for (const kind of [KIND.CD8, KIND.NK, KIND.MACRO, KIND.DC, KIND.CD4]) {
    assert.ok(sandbox.unlocks.includes(kind), `sandbox is missing KIND ${kind}`);
  }
  assert.ok(!sandbox.unlocks.includes(KIND.CART));
  for (const control of ['checkpoint', 'il2', 'lymphodepletion', 'rally']) {
    assert.ok(sandbox.unlocks.includes(control), `sandbox is missing ${control}`);
  }
});
