/**
 * science.test.js verifies complete science-card coverage, the kid-reading limit,
 * public lookup behavior, single-emoji icons, and glossary definitions.
 */

import test from 'node:test';
import assert from 'node:assert/strict';

import { GLOSSARY, SCIENCE_CARDS, getCard } from '../src/content/science.js';

const CARD_FIELDS = ['concept', 'icon', 'id', 'kidText', 'realText', 'title'].sort();
const REQUIRED_CARD_IDS = [
  'level-first-contact',
  'level-the-shield',
  'level-the-escape-artist',
  'level-cold-tumor',
  'level-deep-core',
  'level-sandbox',
  'serial-killing',
  'chemotaxis',
  'adaptive-resistance',
  'checkpoint-blockade',
  'antigen-escape',
  'missing-self-nk',
  'immunosuppressive-microenvironment',
  'dendritic-antigen-presentation',
  'cytokine-release-syndrome',
  'on-target-off-tumor-toxicity',
  't-cell-exhaustion',
];

const REQUIRED_GLOSSARY_TERMS = [
  'adaptive resistance',
  'antigen',
  'antigen escape',
  'antigen presentation',
  'CAR-T cell',
  'checkpoint blockade',
  'chemokine',
  'chemotaxis',
  'cytokine',
  'cytokine release syndrome (CRS)',
  'dendritic cell',
  'IFN-gamma',
  'immune synapse',
  'immunosuppressive microenvironment',
  'MHC-I',
  'missing-self',
  'NK cell',
  'on-target off-tumor toxicity',
  'PD-1',
  'PD-L1',
  'perforin and granzymes',
  'serial killing',
  'T cell exhaustion',
  'Treg',
];

function wordCount(text) {
  return text.trim().split(/\s+/u).length;
}

test('SCIENCE_CARDS contains every per-level and cross-cutting card', () => {
  assert.deepEqual(Object.keys(SCIENCE_CARDS).sort(), [...REQUIRED_CARD_IDS].sort());
});

test('every card has exactly the required non-empty string fields', () => {
  for (const [id, card] of Object.entries(SCIENCE_CARDS)) {
    assert.deepEqual(Object.keys(card).sort(), CARD_FIELDS, `${id} card fields`);
    assert.equal(card.id, id);

    for (const field of CARD_FIELDS) {
      assert.equal(typeof card[field], 'string', `${id}.${field} must be a string`);
      assert.notEqual(card[field].trim(), '', `${id}.${field} must not be empty`);
    }
  }
});

test('every kidText is at most 40 words and speaks directly to the child', () => {
  for (const card of Object.values(SCIENCE_CARDS)) {
    const words = wordCount(card.kidText);
    assert.ok(words <= 40, `${card.id} kidText has ${words} words`);
    assert.match(card.kidText, /\b(?:you|your)\b/iu, `${card.id} must use you/your`);
  }
});

test('every realText contains one or two complete sentences', () => {
  for (const card of Object.values(SCIENCE_CARDS)) {
    const sentenceEndings = card.realText.match(/[.!?](?=\s|$)/gu) ?? [];
    assert.ok(
      sentenceEndings.length >= 1 && sentenceEndings.length <= 2,
      `${card.id} realText must contain 1-2 sentences`,
    );
  }
});

test('every icon is one non-empty emoji grapheme', () => {
  const segmenter = new Intl.Segmenter('en', { granularity: 'grapheme' });

  for (const card of Object.values(SCIENCE_CARDS)) {
    const graphemes = [...segmenter.segment(card.icon)];
    assert.equal(graphemes.length, 1, `${card.id} icon must be one grapheme`);
    assert.match(card.icon, /\p{Extended_Pictographic}/u, `${card.id} icon must be an emoji`);
  }
});

test('getCard resolves every card and returns undefined for an unknown id', () => {
  for (const [id, card] of Object.entries(SCIENCE_CARDS)) {
    assert.equal(getCard(id), card);
  }

  assert.equal(getCard('not-a-card'), undefined);
});

test('GLOSSARY covers required jargon with one-line kid definitions', () => {
  for (const term of REQUIRED_GLOSSARY_TERMS) {
    assert.ok(Object.hasOwn(GLOSSARY, term), `missing glossary term: ${term}`);
  }

  for (const [term, definition] of Object.entries(GLOSSARY)) {
    assert.equal(typeof term, 'string');
    assert.notEqual(term.trim(), '');
    assert.equal(typeof definition, 'string', `${term} definition must be a string`);
    assert.notEqual(definition.trim(), '', `${term} definition must not be empty`);
    assert.doesNotMatch(definition, /[\r\n]/u, `${term} definition must stay on one line`);
  }
});
