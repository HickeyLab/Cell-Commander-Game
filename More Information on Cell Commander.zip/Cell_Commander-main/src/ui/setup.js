/**
 * setup.js — owns the evidence-first treatment setup flow: a tumor briefing,
 * budgeted shop controls, and touch/pointer cell placement.
 */

import {
  ANTIGEN,
  ANTIGEN_TUMOR_INFO,
  ANTIGEN_TUMOR_NAME,
  COLORS,
  KIND,
  KIND_LABEL,
  PLACEABLE,
  SCREEN,
  SHAPE,
  WORLD_H,
  WORLD_W,
} from '../core/contracts.js';
import * as Params from '../sim/params.js';
import * as Plan from '../sim/plan.js';
import {
  button,
  chip,
  icon,
  meter,
} from './components.js';

const DRUGS = Object.freeze([
  {
    key: 'checkpoint',
    planKey: 'checkpoint',
    label: 'Checkpoint inhibitor',
    icon: '◉',
    detail: 'Drops the tumor shield.',
  },
  {
    key: 'il2',
    planKey: 'il2',
    label: 'IL-2 support',
    icon: '✦',
    detail: 'Boosts cells, but can raise fever.',
  },
  {
    key: 'lymphodepletion',
    planKey: 'lymphodepletion',
    label: 'Lymphodepletion',
    icon: '⌁',
    detail: 'Clears blockers. Costs patient health.',
  },
]);

const ANTIGEN_CLASS = Object.freeze({
  [ANTIGEN.NONE]: 'none',
  [ANTIGEN.GREEN]: 'green',
  [ANTIGEN.BLUE]: 'blue',
  [ANTIGEN.ORANGE]: 'orange',
});

const KIND_COLOR_KEY = Object.freeze({
  [KIND.CART]: 'cart',
  [KIND.CD8]: 'cd8',
  [KIND.NK]: 'nk',
  [KIND.MACRO]: 'macro',
  [KIND.DC]: 'dc',
  [KIND.CD4]: 'cd4',
});

const KIND_GLYPH = Object.freeze({
  [KIND.CART]: '⬢',
  [KIND.CD8]: '◕',
  [KIND.NK]: '◆',
  [KIND.MACRO]: '✣',
  [KIND.DC]: '✦',
  [KIND.CD4]: '●',
});

function makeSection(step, title) {
  const section = document.createElement('section');
  section.className = `setup-step setup-step--${step}`;
  const number = document.createElement('span');
  number.className = 'setup-step__number instrument-label';
  number.textContent = step.toUpperCase();
  const heading = document.createElement('h2');
  heading.textContent = title;
  section.append(number, heading);
  return section;
}

function costFor(key) {
  const value = Number(Params.COST?.[key]);
  return Number.isFinite(value) ? value : null;
}

function isUnlocked(level, key) {
  if (!Array.isArray(level?.unlocks)) {
    return true;
  }
  return level.unlocks.some((item) => String(item) === String(key));
}

function fallbackCost(plan) {
  const cellCost = plan.placements.reduce(
    (sum, placement) => sum + (costFor(placement.kind) ?? 0),
    0,
  );
  const drugCost = DRUGS.reduce(
    (sum, drug) => sum + (plan[drug.planKey] ? (costFor(drug.key) ?? 0) : 0),
    0,
  );
  return cellCost + drugCost;
}

function syncSpent(plan) {
  try {
    plan.spent = Number(Plan.planCost(plan));
  } catch {
    plan.spent = fallbackCost(plan);
  }
  if (!Number.isFinite(plan.spent)) {
    plan.spent = fallbackCost(plan);
  }
}

function remaining(plan) {
  return Math.max(0, Number(plan.budget) - Number(plan.spent));
}

function isInsideTumor(level, x, y) {
  const dx = x - Number(level.tumor.cx);
  const dy = y - Number(level.tumor.cy);
  return Math.hypot(dx, dy) <= Number(level.tumor.spreadWu);
}

// API-NOTE: This setup canvas intentionally owns a minimal draw layer until
// src/render/canvas.js replaces drawing; mapping and pointer hit-testing stay reusable.
function makePlacementBoard(canvas, level, plan, onMessage) {
  const context = canvas.getContext('2d');
  const view = { scale: 1, offsetX: 0, offsetY: 0, cssW: 1, cssH: 1 };
  let ghost = null;
  let keyboardCursor = null;

  function resize() {
    const rect = canvas.getBoundingClientRect();
    const dpr = Math.max(1, canvas.ownerDocument.defaultView?.devicePixelRatio ?? 1);
    const width = Math.max(1, Math.round(rect.width * dpr));
    const height = Math.max(1, Math.round(rect.height * dpr));
    if (canvas.width !== width || canvas.height !== height) {
      canvas.width = width;
      canvas.height = height;
    }
    view.cssW = Math.max(1, rect.width);
    view.cssH = Math.max(1, rect.height);
    view.scale = Math.min(view.cssW / WORLD_W, view.cssH / WORLD_H);
    view.offsetX = (view.cssW - WORLD_W * view.scale) / 2;
    view.offsetY = (view.cssH - WORLD_H * view.scale) / 2;
    context.setTransform(dpr, 0, 0, dpr, 0, 0);
  }

  function worldToScreen(x, y) {
    return {
      x: view.offsetX + x * view.scale,
      y: view.offsetY + y * view.scale,
    };
  }

  function clientToWorld(clientX, clientY) {
    const rect = canvas.getBoundingClientRect();
    return {
      x: Math.max(0, Math.min(WORLD_W, (clientX - rect.left - view.offsetX) / view.scale)),
      y: Math.max(0, Math.min(WORLD_H, (clientY - rect.top - view.offsetY) / view.scale)),
      inside: clientX >= rect.left && clientX <= rect.right
        && clientY >= rect.top && clientY <= rect.bottom,
      screenX: clientX - rect.left,
      screenY: clientY - rect.top,
    };
  }

  function drawShape(shape, x, y, radius, color, alpha = 1) {
    context.save();
    context.globalAlpha = alpha;
    context.fillStyle = color;
    context.strokeStyle = color;
    context.lineWidth = 2;
    context.beginPath();
    if (shape === 'hexagon' || shape === 'diamond' || shape === 'star') {
      const points = shape === 'hexagon' ? 6 : shape === 'diamond' ? 4 : 10;
      for (let index = 0; index < points; index += 1) {
        const outer = shape !== 'star' || index % 2 === 0;
        const angle = -Math.PI / 2 + (index * Math.PI * 2) / points;
        const pointRadius = outer ? radius : radius * 0.42;
        const px = x + Math.cos(angle) * pointRadius;
        const py = y + Math.sin(angle) * pointRadius;
        if (index === 0) {
          context.moveTo(px, py);
        } else {
          context.lineTo(px, py);
        }
      }
      context.closePath();
    } else if (shape === 'amoeba') {
      for (let index = 0; index < 12; index += 1) {
        const angle = (index * Math.PI * 2) / 12;
        const wobble = index % 3 === 0 ? 1.25 : 0.88;
        const px = x + Math.cos(angle) * radius * wobble;
        const py = y + Math.sin(angle) * radius * wobble;
        if (index === 0) {
          context.moveTo(px, py);
        } else {
          context.lineTo(px, py);
        }
      }
      context.closePath();
    } else {
      context.arc(x, y, radius, 0, Math.PI * 2);
    }
    context.fill();
    context.stroke();
    context.restore();
  }

  function draw() {
    resize();
    context.clearRect(0, 0, view.cssW, view.cssH);
    context.fillStyle = '#05080C';
    context.fillRect(0, 0, view.cssW, view.cssH);
    context.fillStyle = '#0A1018';
    context.fillRect(
      view.offsetX,
      view.offsetY,
      WORLD_W * view.scale,
      WORLD_H * view.scale,
    );

    const tumor = worldToScreen(level.tumor.cx, level.tumor.cy);
    const tumorRadius = level.tumor.spreadWu * view.scale;
    const gradient = context.createRadialGradient(
      tumor.x,
      tumor.y,
      0,
      tumor.x,
      tumor.y,
      tumorRadius,
    );
    gradient.addColorStop(0, 'rgba(255,61,139,.42)');
    gradient.addColorStop(0.72, 'rgba(255,61,139,.18)');
    gradient.addColorStop(1, 'rgba(255,61,139,0)');
    context.fillStyle = gradient;
    context.beginPath();
    context.arc(tumor.x, tumor.y, tumorRadius, 0, Math.PI * 2);
    context.fill();
    context.strokeStyle = 'rgba(255,61,139,.66)';
    context.setLineDash([8, 8]);
    context.stroke();
    context.setLineDash([]);

    for (const placement of plan.placements) {
      const point = worldToScreen(placement.x, placement.y);
      // contracts.js COLORS is used here because these dots preview render-owned cells.
      const color = COLORS[KIND_COLOR_KEY[placement.kind]] ?? COLORS.ink;
      drawShape(SHAPE[placement.kind], point.x, point.y, 8, color);
    }
    if (ghost) {
      const point = worldToScreen(ghost.x, ghost.y);
      const color = COLORS[KIND_COLOR_KEY[ghost.kind]] ?? COLORS.ink;
      drawShape(SHAPE[ghost.kind], point.x, point.y, 10, color, 0.55);
    }
    if (keyboardCursor) {
      const point = worldToScreen(keyboardCursor.x, keyboardCursor.y);
      context.save();
      context.strokeStyle = '#FFFFFF';
      context.lineWidth = 2;
      context.setLineDash([4, 3]);
      context.beginPath();
      context.arc(point.x, point.y, 14, 0, Math.PI * 2);
      context.stroke();
      context.setLineDash([]);
      context.beginPath();
      context.moveTo(point.x - 19, point.y);
      context.lineTo(point.x + 19, point.y);
      context.moveTo(point.x, point.y - 19);
      context.lineTo(point.x, point.y + 19);
      context.stroke();
      context.restore();
    }
  }

  function setGhost(kind, clientX, clientY) {
    const point = clientToWorld(clientX, clientY);
    ghost = point.inside && kind !== null && kind !== undefined
      ? { kind, x: point.x, y: point.y }
      : null;
    draw();
    return point;
  }

  function clearGhost() {
    ghost = null;
    draw();
  }

  function setKeyboardCursor(point) {
    keyboardCursor = point
      ? {
        x: Math.max(0, Math.min(WORLD_W, point.x)),
        y: Math.max(0, Math.min(WORLD_H, point.y)),
      }
      : null;
    draw();
    if (!keyboardCursor) {
      return null;
    }
    const screenPoint = worldToScreen(keyboardCursor.x, keyboardCursor.y);
    return {
      ...keyboardCursor,
      inside: true,
      screenX: screenPoint.x,
      screenY: screenPoint.y,
    };
  }

  function explain(message, point) {
    onMessage(message, point.screenX, point.screenY);
  }

  function place(kind, point) {
    const cost = costFor(kind);
    if (cost === null || remaining(plan) < cost) {
      explain(`You need ${cost ?? '?'} credits for that cell.`, point);
      return false;
    }
    if (isInsideTumor(level, point.x, point.y)) {
      explain('Your cells have to travel in — they can’t start inside the tumor.', point);
      return false;
    }
    let added = false;
    try {
      added = typeof Plan.addPlacement === 'function'
        ? Plan.addPlacement(plan, kind, point.x, point.y)
        : false;
    } catch {
      added = false;
    }
    if (!added) {
      explain('That spot is blocked. Try a clear edge of the tissue.', point);
      return false;
    }
    syncSpent(plan);
    draw();
    return true;
  }

  function remove(point) {
    let removed = false;
    try {
      removed = typeof Plan.removePlacementAt === 'function'
        ? Plan.removePlacementAt(plan, point.x, point.y, 42)
        : false;
    } catch {
      removed = false;
    }
    if (removed) {
      syncSpent(plan);
      draw();
    } else {
      explain('Press closer to a cell to remove it.', point);
    }
    return removed;
  }

  draw();
  return {
    clearGhost,
    clientToWorld,
    draw,
    place,
    remove,
    setGhost,
    setKeyboardCursor,
  };
}

/**
 * Mounts the treatment setup screen.
 * @param {HTMLElement} rootEl
 * @param {{app:object,level:object,plan:object}} ctx
 * @returns {{unmount:()=>void}}
 */
export function mount(rootEl, ctx) {
  const { level, plan } = ctx;
  syncSpent(plan);

  const screen = document.createElement('main');
  screen.className = 'cc-screen setup-screen';
  const header = document.createElement('header');
  header.className = 'screen-header';
  const headingWrap = document.createElement('div');
  const eyebrow = document.createElement('p');
  eyebrow.className = 'instrument-label';
  eyebrow.textContent = `Treatment setup / Level ${level.number}`;
  const heading = document.createElement('h1');
  heading.textContent = level.name;
  headingWrap.append(eyebrow, heading);
  const back = button('← Levels', {
    className: 'cc-button--quiet',
    onClick: () => ctx.app.go(SCREEN.LEVEL_SELECT),
  });
  header.append(headingWrap, back);

  const workflow = document.createElement('div');
  workflow.className = 'setup-workflow';

  // "Tumor briefing" replaces the earlier two-step "read the biopsy, then pick a target"
  // flow. Every scripted level's tumor is the same real marker (GD2 / green), so picking
  // among three flags was never a genuine decision -- the only real choice was always
  // already made. This is a static specs card instead: what the cells actually are,
  // told plainly, with plan.carTarget defaulting to PLAN_DEFAULTS.carTarget (ANTIGEN.GREEN)
  // rather than requiring a tap.
  const specs = makeSection('a', 'Tumor briefing');
  const tumorName = document.createElement('strong');
  tumorName.className = 'tumor-specs__name';
  tumorName.textContent = level.tumorTypeName ?? ANTIGEN_TUMOR_NAME[plan.carTarget] ?? 'Unknown tumor';
  const tumorMarker = document.createElement('p');
  tumorMarker.className = 'tumor-specs__marker';
  tumorMarker.textContent = level.tumorMarkerInfo ?? ANTIGEN_TUMOR_INFO[plan.carTarget] ?? '';
  const tumorStats = document.createElement('p');
  tumorStats.className = 'tumor-specs__stats';
  tumorStats.textContent = `${level.tumor.count} cancer cells`;
  const tumorProfile = document.createElement('p');
  tumorProfile.className = 'tumor-specs__profile';
  tumorProfile.textContent = level.tumorProfile ?? '';
  const specsCard = document.createElement('div');
  specsCard.className = `tumor-specs-card antigen--${ANTIGEN_CLASS[plan.carTarget]}`;
  specsCard.append(tumorName, tumorMarker, tumorStats, tumorProfile);
  specs.append(specsCard);
  const healthyShare = Number(level.tumor.antigenMix?.[level.healthy.antigen] ?? 0);
  if (level.healthy.antigen !== ANTIGEN.NONE && healthyShare > 0) {
    specs.append(chip(
      `Healthy cells also carry this marker. Your cells may hurt them.`,
      { tone: 'warn', icon: '△' },
    ));
  }

  const shop = makeSection('b', 'Build your team');
  shop.classList.add('instrument-panel');
  const shopIntro = document.createElement('p');
  shopIntro.textContent = 'Choose immune cells for your team below, then tap the map to place each one.';
  const budgetMeter = meter('Credits used', plan.spent, {
    max: plan.budget,
    unit: ` / ${plan.budget}`,
  });
  const budgetText = document.createElement('p');
  budgetText.className = 'budget-remaining';
  const cellShop = document.createElement('div');
  cellShop.className = 'shop-list';
  const drugShop = document.createElement('div');
  drugShop.className = 'shop-list shop-list--drugs';
  const paletteControls = new Map();
  let activeBrush = null;
  let trashMode = false;

  const placement = makeSection('c', 'Place your cells');
  placement.classList.add('placement-step');
  const placementIntro = document.createElement('p');
  placementIntro.textContent = 'Tap a cell, then tap the tissue. Or drag it onto the map.';
  const boardWrap = document.createElement('div');
  boardWrap.className = 'placement-board-wrap';
  const canvas = document.createElement('canvas');
  canvas.className = 'placement-board';
  canvas.setAttribute('role', 'application');
  canvas.setAttribute(
    'aria-label',
    'Treatment placement map. Use arrow keys to move, Enter or Space to place a cell, Backspace or Delete to remove the nearest cell.',
  );
  canvas.tabIndex = 0;
  const boardMessage = document.createElement('div');
  boardMessage.className = 'placement-message';
  boardMessage.setAttribute('aria-live', 'polite');
  boardWrap.append(canvas, boardMessage);
  const placementTools = document.createElement('div');
  placementTools.className = 'placement-tools';
  const trashButton = button('⌫ Remove mode: Off', {
    className: 'cc-button--quiet',
    pressed: false,
  });
  const clearMessageTimer = { id: 0 };
  function showBoardMessage(message, x, y) {
    boardMessage.textContent = message;
    boardMessage.style.left = `${Math.max(8, Math.min(canvas.clientWidth - 230, x))}px`;
    boardMessage.style.top = `${Math.max(8, Math.min(canvas.clientHeight - 72, y))}px`;
    boardMessage.classList.add('is-visible');
    clearTimeout(clearMessageTimer.id);
    clearMessageTimer.id = setTimeout(
      () => boardMessage.classList.remove('is-visible'),
      2200,
    );
  }
  const board = makePlacementBoard(canvas, level, plan, showBoardMessage);
  const keyboardCursor = {
    x: Math.max(
      0,
      Math.min(WORLD_W, Number(level.tumor.cx) + Number(level.tumor.spreadWu) + 24),
    ),
    y: Math.max(0, Math.min(WORLD_H, Number(level.tumor.cy))),
  };

  function updateShop() {
    syncSpent(plan);
    budgetMeter.setValue(plan.spent, plan.budget);
    budgetText.textContent = `${remaining(plan)} credits left`;
    for (const [kind, control] of paletteControls) {
      const cost = costFor(kind);
      const unlocked = isUnlocked(level, kind);
      const affordable = cost !== null && remaining(plan) >= cost;
      control.disabled = !unlocked || !affordable;
      const reason = control.querySelector('.shop-item__reason');
      reason.textContent = !unlocked
        ? 'Unlocks in a later level.'
        : cost === null
          ? 'Cost data is loading.'
          : !affordable
            ? `Need ${cost - remaining(plan)} more credits.`
            : activeBrush === kind
              ? 'Selected. Tap the map.'
              : 'Tap or drag to place.';
      control.classList.toggle('is-active', activeBrush === kind);
    }
    for (const control of drugShop.children) {
      const drug = DRUGS.find((item) => item.key === control.dataset.drug);
      const cost = costFor(drug.key);
      const bought = Boolean(plan[drug.planKey]);
      const unlocked = isUnlocked(level, drug.key);
      const affordable = bought || (cost !== null && remaining(plan) >= cost);
      control.disabled = !unlocked || !affordable;
      control.setAttribute('aria-pressed', String(bought));
      control.classList.toggle('is-active', bought);
      const reason = control.querySelector('.shop-item__reason');
      reason.textContent = !unlocked
        ? 'Not available in this level.'
        : cost === null
          ? 'Cost data is loading.'
          : !affordable
            ? `Need ${cost - remaining(plan)} more credits.`
            : bought
              ? 'Purchased. Tap to return it.'
              : drug.detail;
    }
    trashButton.setAttribute('aria-pressed', String(trashMode));
    trashButton.classList.toggle('is-active', trashMode);
    trashButton.textContent = trashMode ? '⌫ Remove mode: On' : '⌫ Remove mode: Off';
    startReason.textContent = plan.placements.length === 0
      ? 'Place at least one immune cell first.'
      : `${plan.placements.length} cells ready.`;
  }

  for (const kind of PLACEABLE) {
    if (!isUnlocked(level, kind)) {
      continue;
    }
    const cost = costFor(kind);
    const control = button('', {
      className: 'shop-item shop-item--cell',
      ariaLabel: `${KIND_LABEL[kind]}, ${cost ?? 'unknown'} credits`,
    });
    control.dataset.kind = String(kind);
    const identity = document.createElement('span');
    identity.className = `cell-identity cell-identity--${KIND_COLOR_KEY[kind]}`;
    identity.append(icon(KIND_GLYPH[kind]), document.createTextNode(KIND_LABEL[kind]));
    const price = document.createElement('strong');
    price.textContent = `${cost ?? '—'} cr`;
    const reason = document.createElement('small');
    reason.className = 'shop-item__reason';
    control.append(identity, price, reason);

    let dragState = null;
    control.addEventListener('pointerdown', (event) => {
      if (control.disabled) {
        return;
      }
      dragState = {
        pointerId: event.pointerId,
        startX: event.clientX,
        startY: event.clientY,
        moved: false,
      };
      control.setPointerCapture?.(event.pointerId);
    });
    control.addEventListener('pointermove', (event) => {
      if (!dragState || dragState.pointerId !== event.pointerId) {
        return;
      }
      dragState.moved ||= Math.hypot(
        event.clientX - dragState.startX,
        event.clientY - dragState.startY,
      ) > 8;
      if (dragState.moved) {
        board.setGhost(kind, event.clientX, event.clientY);
      }
    });
    control.addEventListener('pointerup', (event) => {
      if (!dragState || dragState.pointerId !== event.pointerId) {
        return;
      }
      const point = board.clientToWorld(event.clientX, event.clientY);
      if (dragState.moved && point.inside) {
        board.place(kind, point);
      } else {
        activeBrush = kind;
      }
      dragState = null;
      board.clearGhost();
      updateShop();
    });
    control.addEventListener('pointercancel', () => {
      dragState = null;
      board.clearGhost();
    });
    control.addEventListener('click', () => {
      if (!control.disabled) {
        activeBrush = kind;
        trashMode = false;
        updateShop();
      }
    });
    paletteControls.set(kind, control);
    cellShop.append(control);
  }

  for (const drug of DRUGS) {
    const cost = costFor(drug.key);
    const control = button('', {
      className: 'shop-item shop-item--drug',
      pressed: Boolean(plan[drug.planKey]),
      ariaLabel: `${drug.label}, ${cost ?? 'unknown'} credits`,
    });
    control.dataset.drug = drug.key;
    const name = document.createElement('span');
    name.className = 'cell-identity';
    name.append(icon(drug.icon), document.createTextNode(drug.label));
    const price = document.createElement('strong');
    price.textContent = `${cost ?? '—'} cr`;
    const reason = document.createElement('small');
    reason.className = 'shop-item__reason';
    control.append(name, price, reason);
    control.addEventListener('click', () => {
      const bought = Boolean(plan[drug.planKey]);
      if (!bought && (cost === null || remaining(plan) < cost)) {
        return;
      }
      plan[drug.planKey] = !bought;
      syncSpent(plan);
      updateShop();
    });
    drugShop.append(control);
  }

  trashButton.addEventListener('click', () => {
    trashMode = !trashMode;
    activeBrush = null;
    updateShop();
  });
  placementTools.append(trashButton, chip(level.hint, { tone: 'hint', icon: '?' }));
  placement.append(placementIntro, boardWrap, placementTools);

  let boardPress = null;
  canvas.addEventListener('pointerdown', (event) => {
    board.setKeyboardCursor(null);
    board.setGhost(activeBrush, event.clientX, event.clientY);
    boardPress = {
      pointerId: event.pointerId,
    };
    canvas.setPointerCapture?.(event.pointerId);
  });
  canvas.addEventListener('pointermove', (event) => {
    if (!boardPress || boardPress.pointerId !== event.pointerId) {
      return;
    }
    board.setGhost(activeBrush, event.clientX, event.clientY);
  });
  canvas.addEventListener('pointerup', (event) => {
    if (!boardPress || boardPress.pointerId !== event.pointerId) {
      return;
    }
    const point = board.clientToWorld(event.clientX, event.clientY);
    if (trashMode) {
      board.remove(point);
    } else if (activeBrush !== null) {
      board.place(activeBrush, point);
    } else {
      showBoardMessage('Pick a cell first, then tap the tissue.', point.screenX, point.screenY);
    }
    boardPress = null;
    board.clearGhost();
    updateShop();
  });
  canvas.addEventListener('pointercancel', () => {
    boardPress = null;
    board.clearGhost();
  });
  canvas.addEventListener('focus', () => {
    board.setKeyboardCursor(keyboardCursor);
  });
  canvas.addEventListener('blur', () => {
    board.setKeyboardCursor(null);
  });
  canvas.addEventListener('keydown', (event) => {
    const direction = {
      ArrowUp: [0, -1],
      ArrowDown: [0, 1],
      ArrowLeft: [-1, 0],
      ArrowRight: [1, 0],
    }[event.key];
    const isPlaceKey = event.key === 'Enter' || event.key === ' ';
    const isRemoveKey = event.key === 'Backspace' || event.key === 'Delete';
    if (!direction && !isPlaceKey && !isRemoveKey) {
      return;
    }
    event.preventDefault();

    if (direction) {
      const step = event.shiftKey ? 96 : 24;
      keyboardCursor.x = Math.max(
        0,
        Math.min(WORLD_W, keyboardCursor.x + direction[0] * step),
      );
      keyboardCursor.y = Math.max(
        0,
        Math.min(WORLD_H, keyboardCursor.y + direction[1] * step),
      );
      board.setKeyboardCursor(keyboardCursor);
      return;
    }

    const point = board.setKeyboardCursor(keyboardCursor);
    if (isPlaceKey) {
      if (activeBrush === null) {
        showBoardMessage(
          'Pick a cell first, then tap the tissue.',
          point.screenX,
          point.screenY,
        );
      } else if (board.place(activeBrush, point)) {
        showBoardMessage('Placed.', point.screenX, point.screenY);
      }
    } else if (board.remove(point)) {
      showBoardMessage('Removed.', point.screenX, point.screenY);
    }
    updateShop();
  });

  shop.append(shopIntro, budgetMeter, budgetText, drugShop);
  // Steps A-C share ONE scroll container instead of being three independently-scrolling
  // boxes. Previously each panel was given a fixed slice of the column height and had to
  // scroll inside itself — at 1280x700 panel B needed 507px in a 155px box — so a child had
  // to discover and operate three separate tiny scrollbars to see the choices. One rail that
  // scrolls naturally shows each step at its full height.
  const rail = document.createElement('div');
  rail.className = 'setup-rail';
  rail.append(specs, shop);
  workflow.append(rail, placement);

  const bottom = document.createElement('footer');
  bottom.className = 'setup-bottom-bar';
  bottom.setAttribute('aria-label', 'Immune cell palette and start controls');
  cellShop.classList.add('setup-palette');
  const startWrap = document.createElement('div');
  startWrap.className = 'start-treatment-wrap';
  const startButton = button('▶ Start treatment', {
    className: 'cc-button--primary cc-button--start',
    onClick: () => {
      if (plan.placements.length === 0) {
        showBoardMessage(
          'Place at least one immune cell first.',
          canvas.clientWidth / 2,
          canvas.clientHeight - 88,
        );
        return;
      }
      ctx.app.go(SCREEN.PLAYING, { level, plan });
    },
  });
  const startReason = document.createElement('small');
  startReason.className = 'disabled-reason';
  startWrap.append(startButton, startReason);
  bottom.append(cellShop, startWrap);

  screen.append(header, workflow, bottom);
  rootEl.replaceChildren(screen);
  updateShop();

  const resizeObserver = typeof ResizeObserver === 'function'
    ? new ResizeObserver(() => board.draw())
    : null;
  resizeObserver?.observe(canvas);

  return {
    unmount() {
      clearTimeout(clearMessageTimer.id);
      resizeObserver?.disconnect();
      screen.remove();
    },
  };
}
