# Cell Commander — Visual & Interaction Design Brief

This is binding. Render and UI code derives every color, size, and motion decision from here.

---

## 1. The idea

**The game board is a live fluorescence micrograph.**

Not a cartoon battlefield, not a tower-defense lawn. The screen shows what an immunologist
actually stares at all day: a near-black tissue field with glowing, saturated cells, and soft
diffuse haze where signaling molecules are concentrated. The chrome around it is a **microscope
control panel** — chunky, labeled, precise, and friendly.

Why this and not something cuter: the lab's real work is multiplexed imaging of human tissue.
Making the game look like the data means a kid who plays it and then sees a real CODEX image
recognizes it. That is the whole point of outreach. It is also, bluntly, more beautiful than a
cartoon — glowing cells on black is a look with genuine visual authority, and kids read
"glowing = powerful" instantly.

**Signature element: the channel rail.** A vertical strip of five illuminated toggles down the
left edge, one per molecular field, each with its fluorophore-colored dot. Tap one and that
molecule blooms across the tissue as colored haze. This is precisely the interaction a scientist
performs on multiplexed data — turning channels on and off to see what is where. For a kid it is
"show me the smell trail the immune cells are following." It teaches that invisible chemical
signals exist, it is genuinely fun to poke, and it is the thing they will remember.

---

## 2. Constraints that shape everything

- **No external resources, ever.** No web fonts, no CDNs, no remote images. The game must run
  from a single file on an offline iPad. All typography is system stacks; all art is drawn in
  canvas or inline SVG.
- **Landscape iPad is the primary target.** Design for 1180×820 CSS px first. Must also work on a
  laptop (up to 1920 wide) and degrade to portrait tablet without breaking.
- **Touch only.** No hover-dependent information. No right-click. No keyboard requirement
  (but full keyboard operability for accessibility).
- **Sticky fingers, loud room, 90-second attention span.**

---

## 3. Color

The palette is a fluorescence channel set. High chroma, emissive, on near-black. Cells are drawn
with a soft outer glow and a brighter core, mimicking a point-spread function.

```
--void        #05080C   page background, outside the tissue
--tissue      #0A1018   the imaged field
--tissue-warm #0E1620   subtle vignette / stroma texture
--panel       #101A26   instrument chrome
--panel-edge  #1E2E40   1px borders, tick marks

--ink         #E8F2FA   primary text
--ink-dim     #7E93A8   labels, secondary
--ink-faint   #47586B   disabled, tick labels

Channels (cells and their matching field haze):
--ch-tumor    #FF3D8B   magenta      cancer cells
--ch-cart     #22E0E8   cyan         CAR-T
--ch-cd8      #3D8BFF   blue         killer T
--ch-nk       #FFB020   amber        NK
--ch-macro    #A77BFF   violet       macrophage
--ch-dc       #FF7AC8   pink         dendritic
--ch-cd4      #46D97A   green        helper T
--ch-treg     #B08A4A   olive        Treg
--ch-vessel   #E0453A   red          vessels
--ch-healthy  #90A4B4   grey-blue    healthy tissue

Status:
--ok          #46D97A
--warn        #FFB020
--danger      #FF4D4D
```

Rules:
- Cells render **additively** (`globalCompositeOperation = 'lighter'`) for the glow layer, then
  normally for the core. Overlapping cells brighten, exactly like real fluorescence.
- Field haze uses the channel color at low alpha with a wide blur. Never a rainbow heatmap —
  each field is a single hue, like a single fluorophore.
- **Color is never the only signal.** Every cell type also has a distinct silhouette (see §5)
  and every UI state that uses color also carries an icon or text.
- Verified against deuteranopia and protanopia: the four *player* killer types (cyan / blue /
  amber / violet) separate on both shape and brightness, not just hue.

---

## 4. Typography

No web fonts. Two roles, both from system stacks:

```
--font-instrument: ui-monospace, 'SF Mono', 'Cascadia Mono', Menlo, Consolas, monospace;
--font-display:    system-ui, -apple-system, 'Segoe UI Variable Display', 'Segoe UI', sans-serif;
```

**The chrome is monospace.** All labels, counters, buttons, meter readouts, and the leaderboard
use `--font-instrument`, uppercase, with generous letter-spacing (`0.08em`) at small sizes. This
is what makes it read as a laboratory instrument rather than a website, and it costs nothing
because SF Mono ships on every iPad.

`--font-display` is used only for the few large moments: the title, the screen headings, the
science-card body text, and the big tumor counter. Heavy weight (700–800), tight tracking
(`-0.02em`).

**All numerals use `font-variant-numeric: tabular-nums`.** Counters must not jitter as digits
change — instrument readouts hold still.

Type scale (rem, 16px root):
```
display  3.5   title only
h1       2.0   screen headings
h2       1.375 section headings
body     1.0625
label    0.8125  uppercase, tracked, mono
micro    0.6875  tick marks, footnotes, mono
```

Body copy for kids never goes below 1.0625rem. Minimum contrast 4.5:1 against its background;
the science cards run higher.

---

## 5. Cell rendering

Each cell is drawn in three passes: outer glow (additive, radius ×2.2, alpha ~0.18), body fill,
then a state accent. Silhouettes must be identifiable at 12 px:

| Cell | Silhouette | State accents |
|---|---|---|
| Cancer | irregular blob, slightly lumpy, slowly wobbling | shield ring when PD-L1 high; a small colored dot marks its antigen flag; dim + desaturated when quiescent |
| CAR-T | hexagon | bright ring when engaged; notched/dimmed ring when exhausted; a receptor "prong" pointing at its target |
| Killer T | circle with a bite out of one side | same engagement ring |
| NK | diamond | granule speckles that deplete as it kills |
| Macrophage | soft amoeba with 3–4 pseudopods | M1 = spiky and bright; M2 = round and dim |
| Dendritic | star / many thin dendrites | dendrites lengthen as it matures |
| Helper T | small circle with a soft pulsing halo (the IL-2 field it emits) | — |
| Treg | rounded square | emits a slow dark ripple |
| Vessel | thick ring, pulsing slowly | — |
| Healthy | pale plain circle, low opacity | flickers when damaged |

Engaged killer–target pairs draw a short bright synapse line between them. This one detail makes
the core mechanic legible: kids instantly see *who is fighting whom*.

---

## 6. Layout (landscape)

```
┌─┬──────────────────────────────────────────────┬────────────────┐
│C│                                              │  INSTRUMENT    │
│H│                                              │  PANEL         │
│A│                                              │                │
│N│              TISSUE FIELD                    │  Tumor    142  │
│N│              (canvas, dominant)              │  ▓▓▓▓▓░░░░░    │
│E│                                              │                │
│L│                                              │  Patient   96  │
│ │                                              │  Cytokines ▓░  │
│R│                                              │  Time    0:47  │
│A│                                              │  ───────────   │
│I│                                              │  your roster   │
│L│                                              │  ⬢ 6  ● 4  ◆ 2 │
├─┴──────────────────────────────────────────────┴────────────────┤
│  [ CELL PALETTE — setup only ]        [ ▶ START TREATMENT ]     │
└─────────────────────────────────────────────────────────────────┘
```

- Channel rail: 64 px wide, five 56 px toggles, always present.
- Instrument panel: 280 px, right side (right-handed reach on a propped iPad).
- Bottom bar: 96 px during setup (the palette), 72 px during play (pause / speed / beacon / stop).
- Tissue field takes all remaining space, letterboxed to the world aspect (3:2) and centered.

Portrait fallback: instrument panel moves below the field, channel rail becomes a horizontal
strip. Nothing is hidden.

---

## 7. Motion

One orchestrated moment, then restraint.

**Acquisition sequence** (once, on entering a level, ~1.1 s): the tissue field starts black; a
thin cyan scan line sweeps left→right; cells fade in behind it with a brief bloom, as if the
image is being captured on a confocal. The instrument panel's readouts count up from zero to
their starting values. This is the page-load thesis, it is drawn from the subject's own world,
and it buys the 1 second needed to seed the simulation anyway.

In-play motion is functional only:
- engaged cells pulse gently (2 Hz, subtle)
- a kill produces a short bloom and 6–10 scattering particles in the victim's color
- division pinches the parent and pops the daughter
- the CRS meter shudders when in the red
- field haze breathes slowly as it diffuses (this is the simulation, not an effect)

`prefers-reduced-motion: reduce` → no scan line (instant fade), no particles, no pulsing;
state changes become instant. The game stays fully playable and legible.

---

## 8. Copy voice

Direct, active, second person, sentence case. Say what happens. No exclamation spam, no
mascot chatter, no apologizing.

| Situation | Write | Not |
|---|---|---|
| Start button | `Start treatment` | `Let's go!!` |
| Choosing a target | `Pick the flag your CAR-T cells will hunt.` | `Select target antigen` |
| PD-L1 stall | `The tumor put up a shield. Your T cells are slowing down.` | `Error: efficacy reduced` |
| Antigen escape | `Some cancer cells hid their flag. Your CAR-T can't see them.` | `Antigen-negative subpopulation detected` |
| CRS warning | `The patient is getting a fever. Ease off.` | `Warning: CRS index elevated` |
| Loss by toxicity | `You cleared the tumor, but the treatment was too harsh. Real doctors balance this every day.` | `You lose.` |
| Empty leaderboard | `No scores yet. Be the first.` | `No data available` |

Every loss screen leads with what the kid discovered, then names the real science, then offers
`Try again` as the largest button on screen.

---

## 9. Quality floor

- Every interactive target ≥ 56×56 px with ≥ 8 px separation.
- Visible focus ring (2 px, `--ch-cart`) on every focusable element; full keyboard operation.
- Screen reader: the canvas has a live-region summary ("32 cancer cells left, patient health 96")
  updated at most once per second.
- Text contrast ≥ 4.5:1; large text ≥ 3:1.
- Nothing depends on sound. Sound is off by default.
- No layout shift when numbers change (tabular numerals, fixed-width slots).
- 60 fps is a design requirement, not an optimization. If an effect costs frames, cut the effect.
