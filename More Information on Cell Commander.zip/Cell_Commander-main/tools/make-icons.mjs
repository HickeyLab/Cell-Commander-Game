#!/usr/bin/env node
/**
 * Generate Cell Commander PWA icons without an image dependency. The PNG
 * encoder writes RGBA scanlines into IHDR/IDAT/IEND chunks and validates every
 * chunk CRC after writing.
 */

import { mkdir, readFile, writeFile } from 'node:fs/promises';
import { join } from 'node:path';
import { deflateSync } from 'node:zlib';
import { fileURLToPath } from 'node:url';

const ROOT = fileURLToPath(new URL('..', import.meta.url));
const PNG_SIGNATURE = Buffer.from([137, 80, 78, 71, 13, 10, 26, 10]);
const COLORS = {
  navy: [0x0E, 0x15, 0x20, 0xFF],
  cyan: [0x00, 0xC2, 0xD1, 0xFF],
  magenta: [0x8B, 0x2E, 0x5F, 0xFF],
};

const CRC_TABLE = new Uint32Array(256);
for (let n = 0; n < 256; n += 1) {
  let c = n;
  for (let k = 0; k < 8; k += 1) {
    c = (c & 1) ? (0xEDB88320 ^ (c >>> 1)) : (c >>> 1);
  }
  CRC_TABLE[n] = c >>> 0;
}

function crc32(buffer) {
  let crc = 0xFFFFFFFF;
  for (const byte of buffer) {
    crc = CRC_TABLE[(crc ^ byte) & 0xFF] ^ (crc >>> 8);
  }
  return (crc ^ 0xFFFFFFFF) >>> 0;
}

function chunk(type, data) {
  const typeBytes = Buffer.from(type, 'ascii');
  const output = Buffer.alloc(12 + data.length);
  output.writeUInt32BE(data.length, 0);
  typeBytes.copy(output, 4);
  data.copy(output, 8);
  output.writeUInt32BE(crc32(Buffer.concat([typeBytes, data])), 8 + data.length);
  return output;
}

function pointInRoundedSquare(x, y, inset, radius) {
  if (x < inset || x > 1 - inset || y < inset || y > 1 - inset) return false;
  const cx = x < inset + radius ? inset + radius
    : (x > 1 - inset - radius ? 1 - inset - radius : x);
  const cy = y < inset + radius ? inset + radius
    : (y > 1 - inset - radius ? 1 - inset - radius : y);
  const dx = x - cx;
  const dy = y - cy;
  return dx * dx + dy * dy <= radius * radius;
}

function pointInPolygon(x, y, vertices) {
  let inside = false;
  for (let i = 0, j = vertices.length - 1; i < vertices.length; j = i, i += 1) {
    const xi = vertices[i][0];
    const yi = vertices[i][1];
    const xj = vertices[j][0];
    const yj = vertices[j][1];
    const crosses = ((yi > y) !== (yj > y))
      && (x < ((xj - xi) * (y - yi)) / (yj - yi) + xi);
    if (crosses) inside = !inside;
  }
  return inside;
}

function inTumorBlob(x, y) {
  const lobes = [
    [0.69, 0.64, 0.105],
    [0.75, 0.68, 0.090],
    [0.67, 0.72, 0.085],
    [0.76, 0.75, 0.075],
  ];
  return lobes.some(([cx, cy, radius]) => {
    const dx = x - cx;
    const dy = y - cy;
    return dx * dx + dy * dy <= radius * radius;
  });
}

function drawIcon(size) {
  const pixels = Buffer.alloc(size * size * 4);
  const hexagon = Array.from({ length: 6 }, (_, index) => {
    const angle = Math.PI / 6 + index * Math.PI / 3;
    return [0.42 + Math.cos(angle) * 0.255, 0.45 + Math.sin(angle) * 0.255];
  });

  for (let py = 0; py < size; py += 1) {
    for (let px = 0; px < size; px += 1) {
      const x = (px + 0.5) / size;
      const y = (py + 0.5) / size;
      let color = [0, 0, 0, 0];
      if (pointInRoundedSquare(x, y, 0.035, 0.18)) color = COLORS.navy;
      if (pointInPolygon(x, y, hexagon)) color = COLORS.cyan;
      if (inTumorBlob(x, y)) color = COLORS.magenta;
      const offset = (py * size + px) * 4;
      pixels[offset] = color[0];
      pixels[offset + 1] = color[1];
      pixels[offset + 2] = color[2];
      pixels[offset + 3] = color[3];
    }
  }
  return pixels;
}

function encodePng(width, height, pixels) {
  const ihdr = Buffer.alloc(13);
  ihdr.writeUInt32BE(width, 0);
  ihdr.writeUInt32BE(height, 4);
  ihdr[8] = 8;
  ihdr[9] = 6;
  ihdr[10] = 0;
  ihdr[11] = 0;
  ihdr[12] = 0;

  const stride = width * 4;
  const scanlines = Buffer.alloc((stride + 1) * height);
  for (let y = 0; y < height; y += 1) {
    const row = y * (stride + 1);
    scanlines[row] = 0;
    pixels.copy(scanlines, row + 1, y * stride, (y + 1) * stride);
  }

  return Buffer.concat([
    PNG_SIGNATURE,
    chunk('IHDR', ihdr),
    chunk('IDAT', deflateSync(scanlines, { level: 9 })),
    chunk('IEND', Buffer.alloc(0)),
  ]);
}

function validatePng(buffer, expectedSize) {
  if (buffer.length < PNG_SIGNATURE.length
      || !buffer.subarray(0, PNG_SIGNATURE.length).equals(PNG_SIGNATURE)) {
    throw new Error('invalid PNG signature');
  }

  let offset = PNG_SIGNATURE.length;
  const chunks = [];
  while (offset < buffer.length) {
    if (offset + 12 > buffer.length) throw new Error('truncated PNG chunk');
    const length = buffer.readUInt32BE(offset);
    const end = offset + 12 + length;
    if (end > buffer.length) throw new Error('PNG chunk extends beyond the file');
    const typeBytes = buffer.subarray(offset + 4, offset + 8);
    const data = buffer.subarray(offset + 8, offset + 8 + length);
    const storedCrc = buffer.readUInt32BE(offset + 8 + length);
    const actualCrc = crc32(Buffer.concat([typeBytes, data]));
    const type = typeBytes.toString('ascii');
    if (storedCrc !== actualCrc) throw new Error(`${type} CRC mismatch`);
    chunks.push(type);
    if (type === 'IHDR') {
      if (data.readUInt32BE(0) !== expectedSize || data.readUInt32BE(4) !== expectedSize) {
        throw new Error(`unexpected PNG dimensions (wanted ${expectedSize}x${expectedSize})`);
      }
    }
    offset = end;
    if (type === 'IEND') break;
  }

  for (const required of ['IHDR', 'IDAT', 'IEND']) {
    if (!chunks.includes(required)) throw new Error(`PNG is missing ${required}`);
  }
  if (offset !== buffer.length) throw new Error('unexpected bytes after IEND');
}

async function main() {
  const assetsDir = join(ROOT, 'assets');
  await mkdir(assetsDir, { recursive: true });
  const icons = [
    { name: 'icon-192.png', size: 192 },
    { name: 'icon-512.png', size: 512 },
    { name: 'apple-touch-icon.png', size: 180 },
  ];

  for (const icon of icons) {
    const path = join(assetsDir, icon.name);
    await writeFile(path, encodePng(icon.size, icon.size, drawIcon(icon.size)));
    const written = await readFile(path);
    validatePng(written, icon.size);
    console.log(`valid PNG: assets/${icon.name} (${written.length} bytes, ${icon.size}x${icon.size})`);
  }
}

main().catch((error) => {
  console.error(`make-icons: ${error.message}`);
  process.exitCode = 1;
});
