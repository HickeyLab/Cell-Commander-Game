/**
 * spatialhash.test.js compares exact neighbor and nearest queries with brute
 * force, including dead slots, large radii, bucket boundaries, and world corners.
 */

import test from 'node:test';
import assert from 'node:assert/strict';

import { makeSpatialHash } from '../src/core/spatialhash.js';

function makeSequence(seed) {
  let state = seed >>> 0;
  return () => {
    state ^= state << 13;
    state ^= state >>> 17;
    state ^= state << 5;
    return (state >>> 0) / 4294967296;
  };
}

function bruteNeighbors(world, x, y, radius) {
  const result = [];
  const radiusSq = radius * radius;
  for (let i = 0; i < world.capacity; i += 1) {
    if (world.alive[i] !== 0) {
      const dx = world.x[i] - x;
      const dy = world.y[i] - y;
      if (dx * dx + dy * dy <= radiusSq) {
        result.push(i);
      }
    }
  }
  return result;
}

function hashNeighbors(hash, x, y, radius) {
  const result = [];
  hash.forEachNeighbor(x, y, radius, (i) => {
    result.push(i);
  });
  result.sort((a, b) => a - b);
  return result;
}

test('neighbor queries exactly match brute force for 500 random agents', () => {
  const worldW = 1200;
  const worldH = 800;
  const capacity = 500;
  const random = makeSequence(0xc0ffee);
  const world = {
    capacity,
    alive: new Uint8Array(capacity),
    x: new Float32Array(capacity),
    y: new Float32Array(capacity),
  };

  for (let i = 0; i < capacity; i += 1) {
    world.alive[i] = random() < 0.82 ? 1 : 0;
    world.x[i] = random() * worldW;
    world.y[i] = random() * worldH;
  }

  const hash = makeSpatialHash({ worldW, worldH, cellSize: 37 });
  hash.rebuild(world);
  const radii = [0, 1, 18.5, 37, 74, 150, 500];

  for (let query = 0; query < 24; query += 1) {
    const x = random() * worldW;
    const y = random() * worldH;
    for (const radius of radii) {
      const expected = bruteNeighbors(world, x, y, radius);
      const actual = hashNeighbors(hash, x, y, radius);
      assert.deepEqual(actual, expected, `query ${query}, radius ${radius}`);
    }
  }
});

test('bucket boundaries and all world corners are queried exactly', () => {
  const world = {
    capacity: 8,
    alive: Uint8Array.from([1, 1, 1, 1, 1, 1, 1, 0]),
    x: Float32Array.from([0, 20, 40, 100, 0, 100, 20, 20]),
    y: Float32Array.from([0, 20, 20, 100, 100, 0, 40, 20]),
  };
  const hash = makeSpatialHash({ worldW: 100, worldH: 100, cellSize: 20 });
  hash.rebuild(world);

  assert.deepEqual(hashNeighbors(hash, 20, 20, 20), [1, 2, 6]);
  assert.deepEqual(hashNeighbors(hash, 0, 0, 0), [0]);
  assert.deepEqual(hashNeighbors(hash, 100, 100, 0), [3]);
  assert.deepEqual(hashNeighbors(hash, 0, 100, 0), [4]);
  assert.deepEqual(hashNeighbors(hash, 100, 0, 0), [5]);
});

test('nearest returns the closest predicate match and rebuild removes dead slots', () => {
  const world = {
    length: 5,
    alive: Uint8Array.from([1, 1, 1, 1, 1]),
    x: Float32Array.from([10, 18, 24, 80, 13]),
    y: Float32Array.from([10, 10, 10, 80, 14]),
  };
  const hash = makeSpatialHash({ worldW: 100, worldH: 100, cellSize: 10 });
  hash.rebuild(world);

  assert.equal(hash.cellSize, 10);
  assert.equal(hash.nearest(10, 10, 20, (i) => i >= 1 && i <= 3), 1);
  assert.equal(hash.nearest(10, 10, 20, (i) => i === 3), -1);

  world.alive[1] = 0;
  hash.rebuild(world);
  assert.equal(hash.nearest(10, 10, 20, (i) => i >= 1 && i <= 3), 2);
  assert.deepEqual(hashNeighbors(hash, 18, 10, 0), []);
});
