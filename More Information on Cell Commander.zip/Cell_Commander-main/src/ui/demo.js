/**
 * demo.js — an autopilot that plays the game for you, with narration.
 *
 * Built for presenting: open the page with ?demo=1 (or press "Watch it play" on the title
 * screen) and the game drives itself through a full round while a caption bar explains each
 * step in presenter language. It loops, so it can be left running on a projector.
 *
 * HOW IT WORKS, AND WHY THAT WAY
 *
 * The autopilot drives the REAL UI — it clicks the same buttons and dispatches the same
 * pointer events a child would. It does not reach into the simulation or take a shortcut
 * path. That matters for a demo: whatever the audience watches is genuinely the game
 * working, not a scripted animation of the game working. If a mechanic breaks, the demo
 * breaks, which is the correct behaviour for something shown to colleagues.
 *
 * The trade-off is that it depends on the DOM, so every lookup is defensive and every step
 * can fail without stopping the run. A demo that skips a beat is recoverable; one that
 * throws in front of a room is not.
 *
 * The narration is deliberately T-cell centred: the T cell is the protagonist of this story
 * and of the lab's work, so the script follows one — engineering it, giving it a target,
 * placing it, watching it find, touch, and kill, then watching it tire.
 */

const CAPTION_ID = 'cc-demo-caption';

/** Wait for a predicate to become true, polling. Resolves null on timeout rather than throwing. */
function waitFor(predicate, timeoutMs = 6000, stepMs = 120) {
  return new Promise((resolve) => {
    const started = Date.now();
    const tick = () => {
      let value = null;
      try {
        value = predicate();
      } catch {
        value = null;
      }
      if (value) return resolve(value);
      if (Date.now() - started > timeoutMs) return resolve(null);
      setTimeout(tick, stepMs);
    };
    tick();
  });
}

const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

/** Find a visible control by its text. */
function findControl(pattern) {
  const re = new RegExp(pattern, 'i');
  return [...document.querySelectorAll('button, a')].find(
    (el) => re.test(el.textContent || '') && el.offsetParent !== null && !el.disabled,
  ) || null;
}

/** Tap the tissue canvas at a world-ish fraction of its box, the way a finger would. */
function tapCanvas(canvas, fx, fy) {
  const rect = canvas.getBoundingClientRect();
  const x = rect.left + rect.width * fx;
  const y = rect.top + rect.height * fy;
  const base = {
    bubbles: true,
    cancelable: true,
    clientX: x,
    clientY: y,
    pointerId: 1,
    pointerType: 'touch',
    isPrimary: true,
    button: 0,
    buttons: 1,
  };
  canvas.dispatchEvent(new PointerEvent('pointerdown', base));
  canvas.dispatchEvent(new PointerEvent('pointerup', { ...base, buttons: 0 }));
  canvas.dispatchEvent(new MouseEvent('click', { bubbles: true, cancelable: true, clientX: x, clientY: y }));
}

/**
 * Start the self-playing demo.
 * @param {{loop?: boolean}} [options]
 * @returns {{stop: () => void}}
 */
export function startDemo(options = {}) {
  const loop = options.loop !== false;
  let stopped = false;

  // ---- caption bar -------------------------------------------------------
  const bar = document.createElement('div');
  bar.id = CAPTION_ID;
  bar.className = 'demo-caption';

  const badge = document.createElement('span');
  badge.className = 'demo-caption__badge';
  badge.textContent = 'Auto-playing';

  const text = document.createElement('p');
  text.className = 'demo-caption__text';
  text.setAttribute('aria-live', 'polite');

  const takeOver = document.createElement('button');
  takeOver.type = 'button';
  takeOver.className = 'cc-button cc-button--quiet demo-caption__stop';
  takeOver.textContent = 'Take over';
  takeOver.addEventListener('click', () => stop());

  bar.append(badge, text, takeOver);
  document.body.append(bar);

  function say(message) {
    text.textContent = message;
  }

  function stop() {
    stopped = true;
    bar.remove();
    document.documentElement.classList.remove('is-demo');
  }

  document.documentElement.classList.add('is-demo');

  // ---- the script --------------------------------------------------------
  async function beat(message, ms) {
    if (stopped) return false;
    say(message);
    await sleep(ms);
    return !stopped;
  }

  async function runOnce() {
    // 1. Title
    if (!(await beat('Cell Commander — a tumor, and the immune cells sent to clear it.', 5000))) return;
    findControl('^\\s*▶?\\s*Play')?.click();

    // 2. Level select
    if (!(await waitFor(() => findControl('Study this tumor')))) return;
    if (!(await beat('Six missions. Each one teaches a different reason immunotherapy succeeds or fails.', 5000))) return;
    findControl('Study this tumor')?.click();

    // 3. Setup — the tumor briefing (a static specs card now, not a biopsy + target pick)
    const specs = await waitFor(() => document.querySelector('.setup-step--a'));
    if (!specs) return;
    if (!(await beat('Every mission starts with a briefing: what exactly are we fighting?', 5000))) return;
    const tumorName = document.querySelector('.tumor-specs__name')?.textContent?.trim();
    const tumorMarker = document.querySelector('.tumor-specs__marker')?.textContent?.trim();
    if (tumorName && tumorMarker) {
      if (!(await beat(`${tumorName}. ${tumorMarker}.`, 5000))) return;
    }

    // 4. Seed the T cells — the protagonists
    if (!(await beat('Pick a killer T cell — a natural cell already built to find and kill cancer.', 5000))) return;
    const cartTool = [...document.querySelectorAll('.setup-palette button, .setup-palette .shop-item')]
      .find((b) => /Killer T/i.test(b.textContent || ''));
    cartTool?.click();
    await sleep(500);

    const board = document.querySelector('.placement-board-wrap canvas');
    if (!board) return;
    if (!(await beat('Seed them around the tumor. Where they start decides whether they ever arrive.', 5000))) return;

    // Ring the tumor, one tap at a time so the audience can watch each cell land.
    for (let i = 0; i < 9 && !stopped; i += 1) {
      const angle = (i / 9) * Math.PI * 2;
      tapCanvas(board, 0.62 + Math.cos(angle) * 0.17, 0.5 + Math.sin(angle) * 0.26);
      await sleep(260);
    }
    if (stopped) return;

    // 5. Run
    if (!(await beat('Start the treatment. From here the simulation decides what happens.', 5000))) return;
    findControl('Start treatment')?.click();
    if (!(await waitFor(() => document.querySelector('.live-screen')))) return;
    await sleep(1200);

    if (!(await beat('Each T cell has to physically find a cancer cell and touch it.', 5000))) return;
    if (!(await beat('Watch the bright line — that is the immune synapse, poison packets going in.', 5000))) return;

    findControl('^2×$')?.click();
    if (!(await beat('One T cell kills, lets go, and finds another. That is serial killing.', 5000))) return;
    if (!(await beat('The strip along the bottom explains what the simulation is doing, as it happens.', 5000))) return;

    findControl('^3×$')?.click();
    if (!(await beat('Speeding up. Every number here comes from our own published model.', 5000))) return;

    // 6. Wait for the round to end
    const ended = await waitFor(
      () => /Tumor Cleared|Out of Time|Escaped|Too Harsh/i.test(document.body.innerText),
      90000,
      400,
    );
    if (stopped) return;

    if (ended) {
      if (!(await beat('Cleared. The score rewards a fast, gentle, cheap cure — not a brutal one.', 5200))) return;
      if (!(await beat('The chart shows the cancer cells falling and the immune cells holding.', 5000))) return;
      if (!(await beat('Then the science card: what just happened, and what it is called.', 5000))) return;
    } else {
      if (!(await beat('The round is still running — the simulation is not on rails.', 5000))) return;
    }

    // 7. Back to the start
    if (!(await beat('That is one mission. Five more, plus a sandbox with real measured tissue.', 5000))) return;
    findControl('Try again|Levels|Title')?.click();
    await sleep(1200);
    findControl('Title')?.click();
    await sleep(1200);
  }

  (async () => {
    do {
      await runOnce();
      if (stopped) break;
      await sleep(1500);
    } while (loop && !stopped);
    if (!stopped) stop();
  })();

  return { stop };
}

/** True when the page was opened asking for the demo. */
export function demoRequested(win = window) {
  try {
    return new URLSearchParams(win.location.search).has('demo');
  } catch {
    return false;
  }
}
