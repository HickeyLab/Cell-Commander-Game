/**
 * round-view.js — owns a reusable tissue canvas, renderer lifecycle, resizing,
 * and fixed-step simulation updates for screens that display a live round.
 */

import {
  MAX_CATCHUP_TICKS,
  OUTCOME,
  TICK_DT,
  WORLD_H,
  WORLD_W,
} from '../core/contracts.js';
import * as CanvasRender from '../render/canvas.js';

// live.js should adopt this module later once its level-specific interactions can be refactored safely.

/** The simulated world is 3:2; the drawn canvas must match it or the tissue is distorted. */
const WORLD_ASPECT = WORLD_W / WORLD_H;

/**
 * Creates a live tissue view whose simulation round can be replaced in place.
 * @param {{quality?:object,round?:object,ariaLabel?:string}} [opts]
 * @returns {{
 *   el:HTMLElement,
 *   setRound:(round:object|null)=>void,
 *   update:(dt:number)=>void,
 *   resize:()=>void,
 *   destroy:()=>void
 * }}
 */
export function makeRoundView(opts = {}) {
  const el = document.createElement('section');
  el.className = 'tissue-region';
  const canvas = document.createElement('canvas');
  canvas.className = 'tissue-canvas';
  canvas.setAttribute('aria-label', opts.ariaLabel ?? 'Live tissue field');
  canvas.tabIndex = 0;
  el.append(canvas);

  let round = opts.round ?? null;
  let renderer = null;
  let accumulator = 0;
  let destroyed = false;
  const renderState = {};

  try {
    renderer = typeof CanvasRender.makeRenderer === 'function'
      ? CanvasRender.makeRenderer(canvas, { quality: opts.quality })
      : null;
  } catch {
    renderer = null;
  }

  function resize() {
    if (destroyed) {
      return;
    }
    // Measure the HOST and letterbox the world aspect inside it — never measure the canvas.
    //
    // renderer.resize() writes canvas.style.width/height inline, so measuring the canvas is a
    // fixed point: once sized, it can never grow when its container does. That is exactly
    // what happened in the sandbox — the tissue stayed pinned at 338px after the column was
    // widened to 567px, because every resize re-measured the size it had just written.
    //
    // Computing a letterboxed box from the host is both idempotent (the box is always <= the
    // host, so re-measuring the host gives the same answer) and aspect-correct, which avoids
    // the earlier bug where a mismatched backing store squashed the simulation vertically.
    const hostRect = el.getBoundingClientRect();
    let availW = hostRect.width;
    let availH = hostRect.height;
    if (!(availW > 0)) return; // not laid out yet; the ResizeObserver will call us again
    if (!(availH > 0)) availH = availW / WORLD_ASPECT;

    let w = availW;
    let h = w / WORLD_ASPECT;
    if (h > availH) {
      h = availH;
      w = h * WORLD_ASPECT;
    }

    if (renderer) {
      try {
        renderer.resize(w, h);
        return;
      } catch {
        renderer = null;
      }
    }
    const dpr = Math.max(1, canvas.ownerDocument.defaultView?.devicePixelRatio ?? 1);
    canvas.style.width = `${w}px`;
    canvas.style.height = `${h}px`;
    canvas.width = Math.max(1, Math.round(w * dpr));
    canvas.height = Math.max(1, Math.round(h * dpr));
  }

  function drawFallback() {
    const context = canvas.getContext('2d');
    if (!context) {
      return;
    }
    const dpr = Math.max(1, canvas.ownerDocument.defaultView?.devicePixelRatio ?? 1);
    const cssW = canvas.width / dpr;
    const cssH = canvas.height / dpr;
    context.setTransform(dpr, 0, 0, dpr, 0, 0);
    context.fillStyle = '#0A1018';
    context.fillRect(0, 0, cssW, cssH);
    context.fillStyle = '#7E93A8';
    context.font = '14px ui-monospace, monospace';
    context.textAlign = 'center';
    context.fillText(
      round ? 'Specimen renderer is connecting…' : 'Experiment model is connecting…',
      cssW / 2,
      cssH / 2,
    );
  }

  const resizeObserver = typeof ResizeObserver === 'function'
    ? new ResizeObserver(resize)
    : null;
  resizeObserver?.observe(el);

  return {
    el,
    setRound(nextRound) {
      if (destroyed) {
        throw new Error('Cannot set a round on a destroyed tissue view');
      }
      accumulator = 0;
      try {
        renderer?.fx?.clear();
      } catch {
        // Dropping the old round reference is still sufficient for simulation cleanup.
      }
      round = nextRound ?? null;
    },
    update(dt) {
      if (destroyed) {
        return;
      }
      const frameDt = Number.isFinite(dt)
        ? Math.max(0, Math.min(0.1, dt))
        : 0;
      if (round && round.outcome === OUTCOME.RUNNING) {
        accumulator += frameDt;
        let ticks = 0;
        while (accumulator >= TICK_DT && ticks < MAX_CATCHUP_TICKS) {
          round.tick(TICK_DT);
          accumulator -= TICK_DT;
          ticks += 1;
        }
      }
      if (renderer && round) {
        try {
          renderer.draw(round, renderState, frameDt);
        } catch {
          renderer = null;
          drawFallback();
        }
      } else {
        drawFallback();
      }
    },
    resize,
    destroy() {
      if (destroyed) {
        return;
      }
      destroyed = true;
      resizeObserver?.disconnect();
      try {
        renderer?.fx?.clear();
      } catch {
        // Removing the owned DOM and references below completes teardown.
      }
      accumulator = 0;
      round = null;
      renderer = null;
      canvas.remove();
      el.remove();
    },
  };
}
