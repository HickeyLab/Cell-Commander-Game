/**
 * healthy.js owns the intentionally inert healthy-tissue behavior; healthy
 * cells only change when recognized by an on-target off-tumor killer.
 */

/**
 * Keep one healthy cell static without allocating.
 * @param {object} round
 * @param {number} i
 * @param {number} dt
 * @returns {void}
 */
export function updateHealthy(round, i, dt) {
  void dt;
  round.world.vx[i] = 0;
  round.world.vy[i] = 0;
}
