/**
 * coach.js owns the data-only live Coach rules and the child-facing display
 * strings used by Inspect. Presentation code supplies a plain round snapshot.
 */

export const COACH_MESSAGE_SEC = 5;
export const COACH_SAMPLE_SEC = 0.5;
export const HEALTHY_DEATH_REARM_SEC = 15;
export const INSPECT_DURATION_SEC = 5;
export const TUMOR_SHIELD_THRESHOLD = 0.35;
/**
 * Coach-tier threshold for "clearly drifted," not the exact mechanical NK cutoff
 * (P.recognition.nkMissingSelfMax = 0.2). Same pattern as TUMOR_SHIELD_THRESHOLD sitting
 * above PDL1_CRITICAL: waits for a confidently visible signal rather than firing the
 * instant the mean statistically crosses the real threshold.
 */
export const FLAGLESS_MHC_DRIFT_THRESHOLD = 0.3;

function rule(definition) {
  return Object.freeze(definition);
}

/**
 * Ordered to match docs/LIVE-FEEDBACK.md. Rules describe only when and what to
 * say; once-per-round scheduling and healthy-death re-arming stay in live.js.
 */
export const COACH_RULES = Object.freeze([
  rule({
    id: 'tumor-shield',
    priority: 'high',
    test: (ctx) => ctx.meanTumorPdl1 > TUMOR_SHIELD_THRESHOLD,
    text: "The tumor just put up a shield. That's its answer to being attacked.",
  }),
  rule({
    id: 'shield-without-checkpoint',
    priority: 'high',
    test: (ctx) => (
      ctx.meanTumorPdl1 > TUMOR_SHIELD_THRESHOLD
      && !ctx.hasCheckpoint
    ),
    text: 'The shield is slowing your cells. The checkpoint medicine removes it.',
  }),
  rule({
    id: 'killer-exhaustion',
    priority: 'med',
    test: (ctx) => ctx.meanKillerExhaustion > 0.5,
    text: 'Your T cells are getting tired. Helper cells and IL-2 keep them going.',
  }),
  rule({
    id: 'crs-danger',
    priority: 'high',
    test: (ctx) => ctx.crs > ctx.crsDanger,
    text: 'The patient is running a fever. Too many cells fighting at once.',
  }),
  // 'healthy-death' and 'flagless-tumor' were removed here after CAR-T was removed as a
  // playable option. CAR-T was the only killer type whose recognition check does not require
  // targetKind === TUMOR -- it matches purely on antigen, so it was the only kind able to hit
  // a HEALTHY cell at all (the real on-target/off-tumor toxicity mechanic). CD8, NK, and
  // MACRO all explicitly require targetKind === TUMOR. Without CAR-T, a healthy cell can
  // never be killed, so 'healthy-death' can never fire; and antigen/flag status no longer
  // has any bearing on which killer can catch a cell, so 'flagless-tumor' had nothing
  // actionable left to say. Flagging this here because it is a genuine loss, not just a
  // text fix: the on-target/off-tumor safety lesson these two rules supported is no longer
  // reachable in play anywhere in the game, including Sandbox.
  rule({
    id: 'flagless-mhc-drift',
    priority: 'high',
    test: (ctx) => (
      ctx.tumorCount > 0
      && ctx.flaglessFraction > 0
      && ctx.hasCD8
      && ctx.meanFlaglessMhc >= FLAGLESS_MHC_DRIFT_THRESHOLD
    ),
    text: 'Some no-flag cells raised their badge again — CD8 cells can catch those.',
  }),
  rule({
    id: 'suggest-il2-escape-artist',
    priority: 'med',
    test: (ctx) => (
      ctx.levelId === 'the-escape-artist'
      && !ctx.hasIl2
      && ctx.timeSec > 15
    ),
    text: 'This is a long fight. Energy Boost (IL-2) helps your T cells survive and keep dividing.',
  }),
  rule({
    id: 'no-engagement',
    priority: 'med',
    test: (ctx) => (
      ctx.tumorCount > 0
      && ctx.secondsSinceAnyEngagement >= 8
    ),
    text: "Your cells can't find the tumor. Drop a rally beacon to call them over.",
  }),
  rule({
    id: 'first-kill',
    priority: 'low',
    test: (ctx) => ctx.firstKillHappened === true,
    text: "That's a kill. One T cell can do that over and over.",
  }),
  rule({
    id: 'tumor-quarter',
    priority: 'low',
    test: (ctx) => (
      ctx.tumorStart > 0
      && ctx.tumorCount > 0
      && ctx.tumorCount < ctx.tumorStart * 0.25
    ),
    text: "You're winning. Keep the pressure on.",
  }),
  rule({
    id: 'dendritic-wave',
    priority: 'low',
    test: (ctx) => ctx.waveCalled === true,
    text: 'Your dendritic cell brought in reinforcements.',
  }),
]);

/**
 * Every status fragment shown by Inspect lives here so its vocabulary can be
 * reviewed alongside the Coach and science-card copy.
 */
export const INSPECT_LABELS = Object.freeze({
  huntingFlag: (flag) => `Hunting: ${flag}`,
  huntingWithBadge: 'Hunting: cancer with an ID badge',
  huntingWithoutBadge: 'Hunting: cells with no ID badge',
  gettingTired: (percent) => `Getting tired (${percent}%)`,
  flag: (flag) => `Flag: ${flag}`,
  flagNone: 'Flag: none',
  shieldUp: 'Shield: up',
  shieldDown: 'Shield: down',
  macrophageAttacking: 'Mode: attacking cancer',
  macrophageCalming: 'Mode: calming the fight',
  macrophageListening: 'Mode: listening for clues',
  macrophageJob: 'Job: eating cancer cells',
  dendriticJob: 'Job: calling reinforcements',
  wavesCalled: (count) => `Waves called: ${count}`,
  helperJob: 'Job: helping T cells keep going',
  tregJob: 'Job: slowing your immune cells',
  vesselJob: 'Reinforcements arrive here',
  healthyCell: 'Normal healthy tissue',
});
