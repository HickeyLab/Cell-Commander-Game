# The Science Behind Cell Commander

For teachers, volunteers, and anyone standing next to a kid who just asked "why did that happen?"

Every mechanic in the game is a real phenomenon. This document gives you, for each one: what the
kid sees, what it actually is, and a sentence you can say out loud.

---

## The premise

The player is running an **adoptive cell therapy** — taking immune cells and putting them into a
patient to attack a tumor. This is real medicine. CAR-T cell therapy has been FDA-approved since
2017 and cures some blood cancers that nothing else could touch. It also fails, often, and the
reasons it fails are exactly what the game is about.

---

## 1. Killing requires contact, and it takes time

**What the kid sees.** A T cell has to reach a cancer cell and stay on it. A short bright line
connects them while they're engaged. After a few seconds, the cancer cell dies.

**What it is.** Cytotoxic T cells kill through an **immune synapse** — a tight contact where the
T cell releases perforin and granzymes directly into the target. This is not instantaneous;
the research model this game is built on requires roughly 12,800 cytotoxic "packets" delivered at
about 400 per minute, so a single T cell takes about half an hour to kill one target.

**Say this.** "It has to touch it. It's injecting the poison packets one at a time — that's why
it takes a moment."

## 2. One T cell kills many cancer cells

**What the kid sees.** After a kill, the same T cell pauses briefly and moves to the next target.

**What it is.** **Serial killing.** A single cytotoxic T lymphocyte can kill multiple targets
sequentially, reloading its granules between kills. It is why a small number of T cells can
clear a large tumor — and why the number you deploy matters less than whether they can reach it.

**Say this.** "That same cell is going to do it again. One T cell can kill a lot of cancer cells."

## 3. Immune cells follow chemical trails

**What the kid sees.** Cells wander when there's nothing to follow, then stream purposefully
once the fight starts. Turning on the "Danger Scent" channel shows the trail as a glowing haze.

**What it is.** **Chemotaxis** along chemokine gradients — CXCL9, CXCL10 and CXCL11 are made at
sites of inflammation and immune cells crawl up the concentration gradient toward them. This is
why *where* the player places cells is often more decisive than *how many* they buy.

**Say this.** "They're smelling their way there. If nothing's making the smell, they just wander."

## 4. Attacking the tumor makes it defend itself

**What the kid sees.** The assault goes well, then stalls. Cancer cells grow a visible ring.

**What it is.** **Adaptive resistance.** When T cells kill, they release **interferon-γ**. IFN-γ
makes tumor cells upregulate **PD-L1**, which binds **PD-1** on the T cell and shuts down its
killing. The tumor's shield is *caused by* the attack. In the research model this same IFN-γ
exposure flips tumor cells into a high-PD-L1, high-MHC-I, non-dividing state.

There's a genuine trade-off built into that, and it's real: shielded tumor cells also stop
dividing. Stalling is not the same as losing.

**Say this.** "Fighting it is what switched the shield on. That's a real problem doctors have."

## 5. There's a drug that removes the shield

**What the kid sees.** With the checkpoint inhibitor purchased, the stall doesn't happen.

**What it is.** **Checkpoint blockade** — anti-PD-1 antibodies like pembrolizumab and nivolumab.
Note what the game does and doesn't model: the drug blocks the **receptor on the T cell**. It
does *not* strip PD-L1 off the tumor. The tumor still has its shield; the T cell just stops
listening to it. Blockade is also never complete, so a little braking remains.

The 2018 Nobel Prize in Physiology or Medicine went to Allison and Honjo for this idea.

**Say this.** "The tumor still has the stop sign. This drug just stops the T cell from reading it."

## 6. Some cancer cells hide the flag

**What the kid sees.** CAR-T cells clear most of the tumor and then simply ignore what's left.
The survivors keep dividing, and their daughters are also ignored.

**What it is.** **Antigen escape**, the single most common way CAR-T therapy relapses. A CAR-T
cell is engineered to recognize exactly one molecule. Tumor cells that don't express it are
invisible to that CAR, they survive selection, and — because their daughters inherit the same
phenotype — they **clonally expand**. In CD19-directed CAR-T for B-cell leukemia, CD19-negative
relapse is a well-documented and frequent outcome.

The game implements inheritance honestly: daughters inherit antigen and MHC-I from the parent.
The escape variants really do take over.

**Say this.** "Your cells were built to find one flag. Those ones don't have it — and now they're
the only ones left."

## 7. NK cells check a different thing entirely

**What the kid sees.** Adding NK cells clears cells the CAR-T cells were leaving alone.

**What it is.** **Missing-self recognition.** Natural killer cells are *inhibited* by MHC-I. A
cell displaying normal MHC-I is left alone; a cell that has lost MHC-I releases NK cells from
that inhibition and gets killed.

**Be careful here — these are two different escape routes, not one.** It is tempting to say the
NK cells "hunt the flag-hiders", and that is wrong:

- **CAR-T escape** is loss of the one engineered target antigen (the flag). It says nothing
  about MHC-I. CAR recognition is MHC-independent, which is the whole point of a CAR.
- **NK missing-self** is loss of MHC-I. It says nothing about the CAR's target.

A cell can lose one, the other, both, or neither. The reason the two lineages pair well is not
that one escape causes the other — it is that between them, CD8 (which needs MHC-I) and NK
(which needs its absence) cover the whole MHC-I range, so **no tumor cell is invisible to
everything**. That is the real lesson, and it is what the game implements: NK targeting in the
code reads MHC-I only and never looks at the antigen flag.

In The Escape Artist the tumor is broadly MHC-I-low, so the NK cells help against much of the
mass, not only against the flag-hiders. Real tumors under immune pressure often do accumulate
several evasion mechanisms at once — but that is selection acting repeatedly, not one mechanism
causing another.

**Say this.** "NK cells don't check the flag at all. They check for an ID badge — and they kill
whatever isn't showing one."

## 8. The tumor recruits help against you

**What the kid sees.** Olive-colored cells sit near the tumor and everything nearby gets sluggish.

**What it is.** The **immunosuppressive tumor microenvironment**. Regulatory T cells (Tregs) and
M2-polarized macrophages secrete TGF-β and IL-10, which suppress effector function. Tumors
actively recruit these cells. This is why some tumors are called "cold" — not because no immune
cells exist, but because the ones there have been switched off.

**Say this.** "Those are the tumor's bodyguards. They're telling your cells to calm down."

## 9. Macrophages can switch sides

**What the kid sees.** A macrophage placed in an active fight becomes spiky and bright; one
sitting in the suppressive zone goes round and dim.

**What it is.** **Macrophage polarization.** IFN-γ pushes macrophages toward the inflammatory
**M1** state; IL-10 and TGF-β push them toward **M2**, which is tissue-repairing and
tumor-promoting. The same cell type helps or hinders depending on the signals around it. Real
macrophage phenotype is a spectrum, not two boxes, and the game models it as a continuous value.

**Say this.** "Same cell — the signals around it decide whose side it's on."

## 10. Dendritic cells bring reinforcements

**What the kid sees.** A dendritic cell eats the debris from dead cancer cells, then new killer
T cells arrive at a blood vessel.

**What it is.** **Antigen presentation.** Dendritic cells engulf debris, migrate to a lymph node,
and present tumor antigen to naive T cells, which then proliferate and traffic back to the tumor.
This closes the **cancer-immunity cycle**: killing produces antigen, antigen produces more killers.

The game compresses this heavily — in the research model, primed T cells take about nine hours to
emerge. In a two-minute round that would be invisible, so it's shortened, and that shortening is
documented in `params.js`.

**Say this.** "It's taking a wanted poster back to headquarters to recruit more soldiers."

## 11. T cells get tired

**What the kid sees.** A T cell that has killed several times fades and slows down. IL-2 helps it
recover.

**What it is.** **T cell exhaustion** — progressive loss of function after chronic stimulation,
marked by high PD-1 and reduced cytokine production. In the research model, exhausted (PD1+)
T cells make ten times less IFN-γ and move at half speed. Reversing exhaustion is one of the
central goals of modern immunotherapy research.

**Say this.** "It's worn out. Real T cells do that after a long fight."

## 12. You can hurt the patient

Two ways, and both are real.

**Cytokine release syndrome.** Massive simultaneous immune activation floods the body with
inflammatory cytokines, causing high fever and dangerous drops in blood pressure. It is the most
common serious toxicity of CAR-T therapy, it is *worse* when the therapy is working hardest, and
it is treated with tocilizumab and steroids — which is what the game's emergency stop represents.

**On-target, off-tumor toxicity.** If the molecule the CAR-T was built to find also appears on
healthy tissue, the cells attack that tissue too. This has killed patients in real trials. It is
why choosing the target antigen is the most consequential decision in the setup screen, and why
the game shows the player a biopsy panel warning them before they choose.

**Say this.** "The treatment is working — that's the problem. Real doctors have to balance this
every single day."

---

## What the game deliberately does not claim

Being honest about the boundaries matters more than looking impressive:

- **Absolute numbers are not clinical.** Timings are compressed roughly 300-fold. A round is not
  a patient course.
- **The tissue is 2D.** Real tumors are three-dimensional, and infiltration is harder in 3D.
- **There is no lymph node.** Priming is abstracted into the dendritic cell's timer.
- **Antigens are "flags," not molecules.** Real antigen expression is continuous, not four
  categories.
- **The patient is two numbers.** Real toxicity involves organ systems the game does not have.
- **Several cell types are not in the research model at all** — NK cells, macrophages, and
  dendritic-cell reinforcement waves were added for teaching value. Every one of those constants
  is tagged `[SCALED]` or `[GAME]` in `src/sim/params.js` rather than being passed off as
  research-derived.

If a kid asks "is this exactly what happens in a person?" the honest answer is: *the rules are
real, the sizes and speeds are adjusted so you can see them, and real scientists run a bigger,
slower version of this same model to study actual patient tissue.*

---

## Source

The model behind the game descends from:

> Hickey, J.W., Agmon, E., Horowitz, N., Lamore, M., Sunwoo, J.B., Covert, M.W. & Nolan, G.P.
> *Integrating Multiplexed Imaging and Multiscale Modeling Identifies Tumor Phenotype
> Transformation as a Critical Component of Therapeutic T Cell Efficacy.* Cell Systems.

Parameters carried over from that model cite their own primary literature in `src/sim/params.js`
— Betts 2004 and Zhang 2006 for cytotoxic packet delivery, Boissonnas 2007 for T cell migration
speeds, Petrovas 2007 for PD-1-related death rates, Zelinskyy 2005 for the tenfold reduction in
exhausted-cell output, Eden 2011 for tumor division, Thibaut 2020 for engagement dwell times,
Liao 2014 for IFN-γ diffusion, and Salerno 2017 and Gallegos 2016 for activation and refractory
periods.

---

## Where this comes from in our own research

Two claims in this game are not general textbook immunology — they are the lab's own work, and
they are cited as such in code.

### The interactions are ones we have verified

`src/content/lab-provenance.js` maps each mechanic in the game to the interaction that
implements it in the lab's research models, the automated test that exercises it, and whether
a mechanism audit has certified that the correct code path actually fired.

| What the game teaches | Interaction | Verified by |
|---|---|---|
| Killing needs contact and takes time | CD8-03, NK-03 | `cd8_epithelial_killing`, `nk_epithelial_killing` |
| NK cells kill cells that lost their ID badge | NK-02 | `nk_epithelial_killing` |
| Two killer types together clear faster than either alone | NK-11, CD8-06 | `cytotoxic_triad` |
| Immune cells follow chemical trails | MAC-04, NK-06 | `endothelial_mcp1_recruitment`, `dormant_nk_cxcl10_recruitment` |
| Macrophages switch between attacking and calming | MAC-02, IFN2-03 | `nk_macrophage_bcell_coordination`, `cd4_th1_effector_function` |
| Some cells tell the immune system to calm down | MAC-10, MAC-16 | `macrophage_il10_m2_resolution` |
| Dendritic cells bring reinforcements | DC-06, DC-03 | `cd4_th1_effector_function`, `dc_antigen_capture` |

**An honest distinction.** Those interactions were verified in the lab's *influenza* tissue
model, in a viral-infection context, not a tumor one. The cell biology is the same — missing-self
recognition, packet-based cytotoxicity, macrophage polarization, dendritic-cell priming — but the
disease is not, and the code says so rather than blurring it. The tumor-specific mechanics
(PD-1/PD-L1 braking, IFN-γ-driven tumor state switching, the cytotoxic packet threshold) come
instead from the lab's published tumor microenvironment model.

**And an honest gap.** Three things the game teaches have no counterpart in either research
model, and are labelled `game-only`: antigen escape from a CAR, cytokine release syndrome, and
on-target off-tumor toxicity. The mechanisms are real clinical phenomena; they simply are not
things these models implement. `tests/lab-data.test.js` fails the build if an invented mechanic
is ever dressed up as a research finding.

### The tissue composition is measured, not illustrative

The Sandbox has a **Use real tissue numbers** button. It sets every immune-cell slider to the
abundance the lab's own CODEX multiplexed imaging actually measured in human lung: 255,000
cells across 35 markers, segmented with Mesmer and assigned to lineages by marker gating, over
a 6.5 × 8.3 mm field of view.

Scaled to the game's tissue window (600 × 400 µm), that is:

| Cell | Count | Identified by |
|---|---:|---|
| Lung (epithelial) | 183 | SFTPC+ or AQP5+ or CK5+p63+, CD45− |
| Fibroblast | 182 | aSMA+ or Vimentin+, CD31−, CD45− |
| Macrophage | 57 | CD68hi, CD45+ |
| Endothelial | 52 | CD31+, CD45− |
| NK cell | 24 | CD56+CD3− |
| B cell | 20 | CD20+ |
| Helper T cell | 15 | CD3+CD57− |
| **Killer T cell** | **8** | CD3+CD57+ |
| Dendritic cell | 4 | HLADR+CD11b+ |
| Neutrophil | 3 | CD66+ |

**This is the most surprising thing in the exhibit.** A child who has just placed a dozen CAR-T
cells discovers that a real piece of lung that size holds about *eight* killer T cells,
outnumbered seven to one by macrophages and three to one by NK cells. It reframes everything
they just did — and it explains why adoptive cell therapy means *infusing* cells rather than
waiting for the ones already there.

**Say this:** "Everything you just built was imaginary. This is what's actually in there."

**Carry the caveats.** The research file marks these numbers PRELIMINARY, and the game repeats
that rather than dropping it: only about half the cells in the image were confidently
identified, the specimen's species and condition are still to be confirmed, and the marker
thresholds have not yet been checked against a human expert. So this is "what our imaging
measured", not "what human lung definitively contains". `tests/lab-data.test.js` asserts those
caveats travel with the data.
