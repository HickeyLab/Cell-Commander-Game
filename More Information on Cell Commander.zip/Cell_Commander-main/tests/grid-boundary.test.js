/**
 * grid-boundary.test.js — regression tests for field behavior at the domain walls.
 *
 * These live apart from grid.test.js because they pin a specific bug rather than the general
 * contract: sample() returns 0 outside the world, so a naive central-difference gradient
 * invents a steep inward slope along every edge. In a uniform field a cell standing near the
 * wall would read a strong pull toward the centre and drift inward for no physical reason —
 * silently corrupting chemotaxis anywhere a tumor sits near the edge of the tissue, which is
 * exactly where several levels place it.
 */

import { test, describe } from 'node:test';
import assert from 'node:assert/strict';
import { makeFieldGrid } from '../src/core/grid.js';

const W = 1200;
const H = 800;

function uniformGrid(value) {
  const g = makeFieldGrid({ w: 60, h: 42, worldW: W, worldH: H, fieldCount: 1 });
  g.data.fill(value);
  return g;
}

describe('gradient at domain boundaries', () => {
  test('a uniform field has zero gradient everywhere, including the walls and corners', () => {
    const g = uniformGrid(5);
    const out = { x: 0, y: 0 };
    const probes = [
      [1, H / 2], [W - 1, H / 2], // left and right walls
      [W / 2, 1], [W / 2, H - 1], // top and bottom walls
      [1, 1], [W - 1, 1], [1, H - 1], [W - 1, H - 1], // all four corners
      [W / 2, H / 2], // interior control
    ];
    for (const [x, y] of probes) {
      g.gradient(0, x, y, out);
      const magnitude = Math.hypot(out.x, out.y);
      assert.ok(
        magnitude < 1e-9,
        `uniform field produced a gradient of ${magnitude} at (${x}, ${y}) — the wall is inventing a slope`
      );
    }
  });

  test('a real gradient near a wall still points the right way', () => {
    // A ramp increasing to the right: a cell hugging the left wall must still be pulled right.
    const g = makeFieldGrid({ w: 60, h: 42, worldW: W, worldH: H, fieldCount: 1 });
    for (let cy = 0; cy < 42; cy++) {
      for (let cx = 0; cx < 60; cx++) g.data[cy * 60 + cx] = cx;
    }
    const out = { x: 0, y: 0 };
    g.gradient(0, 2, H / 2, out);
    assert.ok(out.x > 0, `at the left wall the gradient should point right (+x), got ${out.x}`);

    g.gradient(0, W - 2, H / 2, out);
    assert.ok(out.x > 0, `at the right wall the gradient should still point right, got ${out.x}`);
  });

  test('gradient magnitude at a wall is comparable to the interior, not amplified', () => {
    // The old bug produced an enormous edge gradient. Guard against regressions that
    // reintroduce an artificial cliff.
    const g = makeFieldGrid({ w: 60, h: 42, worldW: W, worldH: H, fieldCount: 1 });
    for (let cy = 0; cy < 42; cy++) {
      for (let cx = 0; cx < 60; cx++) g.data[cy * 60 + cx] = cx;
    }
    const out = { x: 0, y: 0 };
    g.gradient(0, W / 2, H / 2, out);
    const interior = Math.abs(out.x);
    g.gradient(0, 2, H / 2, out);
    const wall = Math.abs(out.x);
    assert.ok(
      wall < interior * 3,
      `wall gradient ${wall} is wildly larger than interior ${interior}`
    );
  });

  test('depositing at the extreme edge keeps all of the mass inside the domain', () => {
    const g = makeFieldGrid({ w: 60, h: 42, worldW: W, worldH: H, fieldCount: 1 });
    g.depositRadius(0, 0, 0, 10, 40);
    // Field cells store concentration, so recover substance mass by weighting by cell area.
    const mass = g.total(0) * g.cellW * g.cellH;
    assert.ok(
      Math.abs(mass - 10) < 1e-3,
      `mass deposited in the corner leaked: expected 10, got ${mass}`
    );
  });
});
