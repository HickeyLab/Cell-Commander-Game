/**
 * mhc-independence.test.js — Monte Carlo recognition-coverage check.
 *
 * The project's balance guarantee is that no LevelDef can spawn a tumor cell that nothing
 * in that level's unlocked roster can ever kill. This exact guarantee has been broken twice:
 *
 *   1. A threshold gap between CD8 and NK left cells unkillable regardless of MHC-I. Fixed
 *      by making MHC_RECOGNITION_MIN and NK_MISSING_SELF_MAX exactly complementary, and
 *      covered by recognition.test.js's "CD8 and NK recognition partition the MHC-I range
 *      with no gap" check.
 *   2. Antigen and MHC-I were drawn as two independent Gaussians, so ~37% of antigen-negative
 *      cells in The Escape Artist rolled an MHC-I value above the NK cutoff by chance, with
 *      no CD8 in that level's unlocked roster to catch them either. Fixed by rejection-
 *      sampling MHC-I for antigen-negative cells in engine.js's sampleMhc.
 *
 * Neither the threshold check above, nor recognition.test.js's "no tumor cell survives when
 * both lineages are present" test, catches failure mode 2: the threshold check only compares
 * two constants, and the coverage test always includes CD8 in its killer roster regardless of
 * what any real LevelDef unlocks — so it never reproduces what a player restricted to a
 * specific level's actual palette can build. This file spawns cells with engine.js's real
 * sampleAntigen/sampleMhc against every real LevelDef's real antigenMix and real unlocks, so
 * it fails the way an actual player's build would fail.
 */

import { test, describe, before } from 'node:test';
import assert from 'node:assert/strict';

import { ANTIGEN, KIND } from '../src/core/contracts.js';
import { makeRng } from '../src/core/rng.js';

let LEVELS;
let sampleAntigen;
let sampleMhc;
let MHC_RECOGNITION_MIN;
let NK_MISSING_SELF_MAX;
let available = true;
let loadError = '';

before(async () => {
  try {
    ({ LEVELS } = await import('../src/content/levels.js'));
    ({ sampleAntigen, sampleMhc } = await import('../src/sim/engine.js'));
    ({ MHC_RECOGNITION_MIN, NK_MISSING_SELF_MAX } = await import('../src/sim/params.js'));
  } catch (err) {
    available = false;
    loadError = err.message;
  }
});

const SAMPLES_PER_LEVEL = 50000;
const KILLER_KINDS = [KIND.CART, KIND.CD8, KIND.NK, KIND.MACRO];

/**
 * The color CAR-T is assumed to be built for. Every current LevelDef either has a single
 * non-NONE antigen (the only sane choice, and what every hint text describes) or relies on
 * CD8/NK/MACRO to cover every color regardless of which one CAR-T targets (Sandbox, where
 * all three are unlocked). If a future level adds a genuine multi-color, CAR-T-only puzzle,
 * this heuristic stops being valid, since which color to build CAR-T against becomes a real
 * player decision this test cannot see — that level would need its own targeted case instead
 * of relying on this generic pass.
 */
function assumedCarTarget(antigenMix) {
  let best = null;
  let bestP = -1;
  for (const key of Object.keys(antigenMix)) {
    const v = Number(key);
    if (v === ANTIGEN.NONE) continue;
    if (antigenMix[key] > bestP) {
      best = v;
      bestP = antigenMix[key];
    }
  }
  return best;
}

// Mirrors targetPredicate's recognition rules in engine.js. Kept as a deliberate, narrow
// restatement of just the recognition logic (not imported from engine.js), since
// targetPredicate also does spatial and liveness checks that don't belong in a
// distribution-level balance test.
function isCatchable(killers, antigen, mhc, carTarget) {
  if (killers.has(KIND.MACRO)) return true; // macrophages recognize any tumor cell
  if (killers.has(KIND.CART) && antigen === carTarget) return true;
  if (killers.has(KIND.CD8) && mhc > MHC_RECOGNITION_MIN) return true;
  if (killers.has(KIND.NK) && mhc < NK_MISSING_SELF_MAX) return true;
  return false;
}

describe('every level roster can recognize every tumor cell it can spawn', () => {
  test('the engine is available', () => {
    assert.ok(available, `could not load the simulation: ${loadError}`);
  });

  test('sampleAntigen and sampleMhc are exported from engine.js', (t) => {
    if (!available) return t.skip('engine not built yet');
    assert.equal(typeof sampleAntigen, 'function');
    assert.equal(typeof sampleMhc, 'function');
  });

  test('every level: no uncatchable cells across many samples', (t) => {
    if (!available) return t.skip('engine not built yet');

    const failures = [];
    for (const level of LEVELS) {
      const killers = new Set(level.unlocks.filter((u) => KILLER_KINDS.includes(u)));
      const carTarget = assumedCarTarget(level.tumor.antigenMix);
      const rng = makeRng(1);

      let uncatchable = 0;
      const offendingAntigens = new Set();
      for (let i = 0; i < SAMPLES_PER_LEVEL; i += 1) {
        const antigen = sampleAntigen(level.tumor.antigenMix, rng);
        const mhc = sampleMhc(rng, level.tumor, antigen);
        if (!isCatchable(killers, antigen, mhc, carTarget)) {
          uncatchable += 1;
          offendingAntigens.add(antigen);
        }
      }

      if (uncatchable > 0) {
        failures.push(
          `${level.name}: ${uncatchable}/${SAMPLES_PER_LEVEL} sampled cells uncatchable ` +
            `(offending antigen values: ${[...offendingAntigens].join(', ')})`,
        );
      }
    }

    assert.deepEqual(
      failures,
      [],
      'these levels can spawn a tumor cell nothing in their unlocked roster can kill:\n  ' +
        failures.join('\n  '),
    );
  });
});
