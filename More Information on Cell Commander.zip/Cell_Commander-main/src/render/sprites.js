/**
 * sprites.js owns DOM-safe, DPR-aware pre-baking of fluorescence glow, cell
 * bodies, and state accents so the renderer's agent passes only use drawImage.
 */

import {
  ANTIGEN,
  COLORS,
  KIND,
  KIND_NAME,
  SHAPE,
  STATE,
} from '../core/contracts.js';

// API-NOTE: UX.md asks for more saturated/emissive channel colors than the
// assigned contracts.js COLORS snapshot provides; reconcile saturation in contracts.COLORS.

const SIZE_BUCKETS = new Float32Array([6, 10, 15, 22]);
const VARIANT_SIZE_MASK = 7;
const VARIANT_PHASE_SHIFT = 3;
const VARIANT_DIRECTION_SHIFT = 5;
const VARIANT_DETAIL_SHIFT = 8;
const VARIANT_FLAG_SHIFT = 10;
const VARIANT_MASK = 0xfff;
const TAU = Math.PI * 2;
const HEADLESS_CONTEXT = null;

const KINDS = new Uint8Array([
  KIND.TUMOR,
  KIND.CD8,
  KIND.CART,
  KIND.NK,
  KIND.MACRO,
  KIND.DC,
  KIND.CD4,
  KIND.TREG,
  KIND.VESSEL,
  KIND.HEALTHY,
]);

const STATES_BY_KIND = Object.freeze({
  [KIND.TUMOR]: new Uint8Array([
    STATE.ALIVE,
    STATE.PROLIFERATIVE,
    STATE.QUIESCENT,
    STATE.NECROTIC,
  ]),
  [KIND.CD8]: new Uint8Array([
    STATE.ALIVE,
    STATE.NAIVE,
    STATE.ACTIVE,
    STATE.ENGAGED,
    STATE.EXHAUSTED,
  ]),
  [KIND.CART]: new Uint8Array([
    STATE.ALIVE,
    STATE.NAIVE,
    STATE.ACTIVE,
    STATE.ENGAGED,
    STATE.EXHAUSTED,
  ]),
  [KIND.NK]: new Uint8Array([
    STATE.ALIVE,
    STATE.NAIVE,
    STATE.ACTIVE,
    STATE.ENGAGED,
    STATE.EXHAUSTED,
  ]),
  [KIND.MACRO]: new Uint8Array([STATE.ALIVE, STATE.M0, STATE.M1, STATE.M2]),
  [KIND.DC]: new Uint8Array([
    STATE.ALIVE,
    STATE.IMMATURE,
    STATE.LOADED,
    STATE.MATURE,
  ]),
  [KIND.CD4]: new Uint8Array([STATE.ALIVE, STATE.NAIVE, STATE.ACTIVE]),
  [KIND.TREG]: new Uint8Array([STATE.ALIVE, STATE.ACTIVE]),
  [KIND.VESSEL]: new Uint8Array([STATE.ALIVE, STATE.ACTIVE]),
  [KIND.HEALTHY]: new Uint8Array([STATE.ALIVE, STATE.DEAD]),
});

function clampInt(value, lo, hi) {
  const integer = Number.isFinite(value) ? Math.trunc(value) : 0;
  return Math.max(lo, Math.min(hi, integer));
}

function variantSize(variantKey) {
  return variantKey & VARIANT_SIZE_MASK;
}

function variantPhase(variantKey) {
  return (variantKey >> VARIANT_PHASE_SHIFT) & 3;
}

function variantDirection(variantKey) {
  return (variantKey >> VARIANT_DIRECTION_SHIFT) & 7;
}

function variantDetail(variantKey) {
  return (variantKey >> VARIANT_DETAIL_SHIFT) & 3;
}

function variantFlag(variantKey) {
  return (variantKey >> VARIANT_FLAG_SHIFT) & 1;
}

function normalizedKind(kind) {
  return kind >= KIND.TUMOR && kind <= KIND.HEALTHY ? kind : KIND.HEALTHY;
}

function normalizedSize(variantKey) {
  return Math.min(SIZE_BUCKETS.length - 1, variantSize(variantKey));
}

function bodyState(kind, state) {
  if (kind === KIND.TUMOR) {
    if (state === STATE.QUIESCENT || state === STATE.NECROTIC) {
      return state;
    }
    return STATE.ALIVE;
  }
  if (kind === KIND.MACRO) {
    return state === STATE.M1 || state === STATE.M2 ? state : STATE.M0;
  }
  if (kind === KIND.DC) {
    return state === STATE.MATURE ? STATE.MATURE : STATE.IMMATURE;
  }
  return STATE.ALIVE;
}

function glowState(kind, state) {
  return kind === KIND.TUMOR && state === STATE.QUIESCENT
    ? STATE.QUIESCENT
    : STATE.ALIVE;
}

function accentState(kind, state) {
  if (kind === KIND.CART) {
    return state === STATE.ENGAGED || state === STATE.EXHAUSTED ? state : STATE.ALIVE;
  }
  if (kind === KIND.CD8) {
    return state === STATE.ENGAGED ? STATE.ENGAGED : STATE.ALIVE;
  }
  if (kind === KIND.MACRO) {
    return state === STATE.M1 || state === STATE.M2 ? state : STATE.M0;
  }
  if (kind === KIND.DC) {
    return state === STATE.MATURE ? STATE.MATURE : STATE.IMMATURE;
  }
  return STATE.ALIVE;
}

function bodyVariant(kind, variantKey) {
  const phase = kind === KIND.TUMOR ? variantPhase(variantKey) : 0;
  return spriteVariantKey(normalizedSize(variantKey), phase);
}

function glowVariant(variantKey) {
  return spriteVariantKey(normalizedSize(variantKey));
}

function accentVariant(kind, state, variantKey) {
  const size = normalizedSize(variantKey);
  if (kind === KIND.TUMOR) {
    const flag = state === STATE.QUIESCENT ? 1 : variantFlag(variantKey);
    return spriteVariantKey(size, 0, 0, variantDetail(variantKey), flag);
  }
  if (kind === KIND.CART) {
    const flag = variantFlag(variantKey);
    return spriteVariantKey(size, 0, flag ? variantDirection(variantKey) : 0, 0, flag);
  }
  if (kind === KIND.NK) {
    return spriteVariantKey(size, 0, 0, variantDetail(variantKey));
  }
  if (kind === KIND.HEALTHY) {
    return spriteVariantKey(size, 0, 0, 0, variantFlag(variantKey));
  }
  return spriteVariantKey(size);
}

function colorFor(kind, state) {
  if (kind === KIND.TUMOR && state === STATE.QUIESCENT) {
    return COLORS.tumorQuiescent;
  }
  if (kind === KIND.MACRO) {
    return COLORS.macro;
  }
  if (kind === KIND.DC) {
    return COLORS.dc;
  }
  return COLORS[KIND_NAME[kind]] ?? COLORS.healthy;
}

function withAlpha(color, alpha) {
  return `${color}${alpha}`;
}

function createSurface(cssSize, dpr) {
  const pixelSize = Math.max(1, Math.ceil(cssSize * dpr));
  let canvas;
  if (typeof globalThis.OffscreenCanvas === 'function') {
    canvas = new globalThis.OffscreenCanvas(pixelSize, pixelSize);
  } else if (typeof globalThis.document !== 'undefined'
    && typeof globalThis.document.createElement === 'function') {
    canvas = globalThis.document.createElement('canvas');
    canvas.width = pixelSize;
    canvas.height = pixelSize;
  } else {
    canvas = {
      width: pixelSize,
      height: pixelSize,
      getContext() {
        return HEADLESS_CONTEXT;
      },
    };
  }
  return canvas;
}

function prepareSurface(radius, dpr) {
  const cssSize = Math.ceil(radius * 4.8 + 4);
  const canvas = createSurface(cssSize, dpr);
  const ctx = canvas.getContext('2d');
  if (ctx) {
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    ctx.clearRect(0, 0, cssSize, cssSize);
    ctx.lineCap = 'round';
    ctx.lineJoin = 'round';
  }
  return { canvas, ctx, cssSize, center: cssSize * 0.5 };
}

function tracePolygon(ctx, cx, cy, radius, points, rotation) {
  ctx.beginPath();
  for (let point = 0; point < points; point += 1) {
    const angle = rotation + point * TAU / points;
    const x = cx + Math.cos(angle) * radius;
    const y = cy + Math.sin(angle) * radius;
    if (point === 0) {
      ctx.moveTo(x, y);
    } else {
      ctx.lineTo(x, y);
    }
  }
  ctx.closePath();
}

function traceBlob(ctx, cx, cy, radius, phase) {
  const points = 12;
  const phaseAngle = phase * Math.PI * 0.5;
  ctx.beginPath();
  for (let point = 0; point <= points; point += 1) {
    const index = point % points;
    const angle = index * TAU / points;
    const wobble = 1
      + Math.sin(angle * 3 + phaseAngle) * 0.12
      + Math.cos(angle * 5 - phaseAngle) * 0.07;
    const x = cx + Math.cos(angle) * radius * wobble;
    const y = cy + Math.sin(angle) * radius * wobble;
    if (point === 0) {
      ctx.moveTo(x, y);
    } else {
      ctx.lineTo(x, y);
    }
  }
  ctx.closePath();
}

function traceAmoeba(ctx, cx, cy, radius, state) {
  const points = 16;
  const spiky = state === STATE.M1;
  const rounded = state === STATE.M2;
  ctx.beginPath();
  for (let point = 0; point <= points; point += 1) {
    const index = point % points;
    const angle = index * TAU / points;
    const lobe = index % 4 === 0 ? (spiky ? 1.38 : 1.2) : 0.92;
    const shapeRadius = radius * (rounded ? 0.92 : lobe);
    const x = cx + Math.cos(angle) * shapeRadius;
    const y = cy + Math.sin(angle) * shapeRadius;
    if (point === 0) {
      ctx.moveTo(x, y);
    } else {
      ctx.lineTo(x, y);
    }
  }
  ctx.closePath();
}

function traceStar(ctx, cx, cy, radius, state) {
  const points = 10;
  const outer = state === STATE.MATURE ? radius * 1.34 : radius * 1.12;
  ctx.beginPath();
  for (let point = 0; point <= points * 2; point += 1) {
    const index = point % (points * 2);
    const angle = -Math.PI * 0.5 + index * Math.PI / points;
    const pointRadius = index % 2 === 0 ? outer : radius * 0.45;
    const x = cx + Math.cos(angle) * pointRadius;
    const y = cy + Math.sin(angle) * pointRadius;
    if (point === 0) {
      ctx.moveTo(x, y);
    } else {
      ctx.lineTo(x, y);
    }
  }
  ctx.closePath();
}

function traceRoundedSquare(ctx, cx, cy, radius) {
  const left = cx - radius;
  const top = cy - radius;
  const right = cx + radius;
  const bottom = cy + radius;
  const corner = radius * 0.42;
  ctx.beginPath();
  ctx.moveTo(left + corner, top);
  ctx.lineTo(right - corner, top);
  ctx.quadraticCurveTo(right, top, right, top + corner);
  ctx.lineTo(right, bottom - corner);
  ctx.quadraticCurveTo(right, bottom, right - corner, bottom);
  ctx.lineTo(left + corner, bottom);
  ctx.quadraticCurveTo(left, bottom, left, bottom - corner);
  ctx.lineTo(left, top + corner);
  ctx.quadraticCurveTo(left, top, left + corner, top);
  ctx.closePath();
}

function traceCell(ctx, kind, state, cx, cy, radius, phase) {
  const shape = SHAPE[kind];
  if (kind === KIND.CD8) {
    ctx.beginPath();
    ctx.arc(cx, cy, radius, 0.35, TAU - 0.35);
    ctx.lineTo(cx + radius * 0.48, cy);
    ctx.closePath();
    return;
  }
  if (kind === KIND.CD4) {
    ctx.beginPath();
    ctx.arc(cx, cy, radius * 0.72, 0, TAU);
    return;
  }
  if (kind === KIND.HEALTHY) {
    ctx.beginPath();
    ctx.arc(cx, cy, radius, 0, TAU);
    return;
  }
  if (shape === 'blob') {
    traceBlob(ctx, cx, cy, radius, phase);
  } else if (shape === 'hexagon') {
    tracePolygon(ctx, cx, cy, radius, 6, -Math.PI * 0.5);
  } else if (shape === 'diamond') {
    tracePolygon(ctx, cx, cy, radius, 4, 0);
  } else if (shape === 'amoeba') {
    traceAmoeba(ctx, cx, cy, radius, state);
  } else if (shape === 'star') {
    traceStar(ctx, cx, cy, radius, state);
  } else if (shape === 'square') {
    traceRoundedSquare(ctx, cx, cy, radius);
  } else if (shape === 'ring') {
    ctx.beginPath();
    ctx.arc(cx, cy, radius * 0.8, 0, TAU);
  } else {
    ctx.beginPath();
    ctx.arc(cx, cy, radius, 0, TAU);
  }
}

function bakeGlow(kind, state, variantKey, dpr) {
  const radius = SIZE_BUCKETS[variantSize(variantKey)];
  const surface = prepareSurface(radius, dpr);
  if (!surface.ctx) {
    return surface.canvas;
  }
  const color = colorFor(kind, state);
  const gradient = surface.ctx.createRadialGradient(
    surface.center,
    surface.center,
    radius * 0.35,
    surface.center,
    surface.center,
    radius * 2.2,
  );
  gradient.addColorStop(0, withAlpha(color, '70'));
  gradient.addColorStop(0.38, withAlpha(color, '3A'));
  gradient.addColorStop(1, withAlpha(color, '00'));
  surface.ctx.fillStyle = gradient;
  surface.ctx.fillRect(0, 0, surface.cssSize, surface.cssSize);
  return surface.canvas;
}

function bakeBody(kind, state, variantKey, dpr) {
  const radius = SIZE_BUCKETS[variantSize(variantKey)];
  const surface = prepareSurface(radius, dpr);
  if (!surface.ctx) {
    return surface.canvas;
  }
  const ctx = surface.ctx;
  const color = colorFor(kind, state);
  let alpha = 0.9;
  if (kind === KIND.HEALTHY) {
    alpha = 0.48;
  } else if (kind === KIND.TUMOR && state === STATE.QUIESCENT) {
    alpha = 0.58;
  } else if (kind === KIND.TUMOR && state === STATE.NECROTIC) {
    alpha = 0.3;
  } else if (kind === KIND.MACRO && state === STATE.M2) {
    alpha = 0.58;
  }

  traceCell(
    ctx,
    kind,
    state,
    surface.center,
    surface.center,
    radius,
    variantPhase(variantKey),
  );
  if (kind === KIND.VESSEL) {
    ctx.globalAlpha = alpha;
    ctx.strokeStyle = color;
    ctx.lineWidth = Math.max(2, radius * 0.45);
    ctx.stroke();
  } else {
    ctx.globalAlpha = alpha;
    ctx.fillStyle = color;
    ctx.fill();
    ctx.globalAlpha = Math.min(1, alpha + 0.12);
    ctx.strokeStyle = withAlpha(COLORS.ink, '8C');
    ctx.lineWidth = Math.max(0.75, radius * 0.08);
    ctx.stroke();
  }
  return surface.canvas;
}

function drawRing(ctx, cx, cy, radius, color, alpha, width) {
  ctx.globalAlpha = alpha;
  ctx.strokeStyle = color;
  ctx.lineWidth = width;
  ctx.beginPath();
  ctx.arc(cx, cy, radius, 0, TAU);
  ctx.stroke();
}

function drawTumorAccent(ctx, state, cx, cy, radius, detail, flag) {
  if (flag || state === STATE.QUIESCENT) {
    drawRing(ctx, cx, cy, radius * 1.28, COLORS.ink, 0.78, Math.max(1, radius * 0.12));
  }
  if (detail !== ANTIGEN.NONE) {
    let antigenColor = COLORS.good;
    if (detail === ANTIGEN.BLUE) {
      antigenColor = COLORS.cd8;
    } else if (detail === ANTIGEN.ORANGE) {
      antigenColor = COLORS.nk;
    }
    ctx.globalAlpha = 1;
    ctx.fillStyle = antigenColor;
    ctx.beginPath();
    ctx.arc(cx + radius * 0.5, cy - radius * 0.48, Math.max(1.4, radius * 0.19), 0, TAU);
    ctx.fill();
  }
}

function drawCartAccent(ctx, state, cx, cy, radius, direction, flag) {
  if (state === STATE.ENGAGED) {
    drawRing(ctx, cx, cy, radius * 1.25, COLORS.cart, 0.95, Math.max(1.25, radius * 0.13));
  } else if (state === STATE.EXHAUSTED) {
    ctx.globalAlpha = 0.45;
    ctx.strokeStyle = COLORS.cart;
    ctx.lineWidth = Math.max(1, radius * 0.11);
    ctx.beginPath();
    ctx.arc(cx, cy, radius * 1.2, 0.25, 2.65);
    ctx.stroke();
    ctx.beginPath();
    ctx.arc(cx, cy, radius * 1.2, 3.35, 5.78);
    ctx.stroke();
  }
  if (flag) {
    const angle = direction * TAU / 8;
    const inner = radius * 0.78;
    const outer = radius * 1.48;
    ctx.globalAlpha = state === STATE.EXHAUSTED ? 0.45 : 0.95;
    ctx.strokeStyle = COLORS.cart;
    ctx.lineWidth = Math.max(1.2, radius * 0.13);
    ctx.beginPath();
    ctx.moveTo(cx + Math.cos(angle) * inner, cy + Math.sin(angle) * inner);
    ctx.lineTo(cx + Math.cos(angle) * outer, cy + Math.sin(angle) * outer);
    ctx.stroke();
  }
}

function drawCd8Accent(ctx, state, cx, cy, radius) {
  if (state === STATE.ENGAGED) {
    drawRing(ctx, cx, cy, radius * 1.24, COLORS.cd8, 0.9, Math.max(1.1, radius * 0.12));
  }
}

function drawNkAccent(ctx, cx, cy, radius, detail) {
  const granules = detail;
  ctx.fillStyle = COLORS.ink;
  ctx.globalAlpha = 0.82;
  for (let granule = 0; granule < granules; granule += 1) {
    const angle = granule * 2.4 + 0.4;
    const distance = radius * (0.24 + (granule & 1) * 0.22);
    ctx.beginPath();
    ctx.arc(
      cx + Math.cos(angle) * distance,
      cy + Math.sin(angle) * distance,
      Math.max(0.8, radius * 0.09),
      0,
      TAU,
    );
    ctx.fill();
  }
}

function drawMacroAccent(ctx, state, cx, cy, radius) {
  if (state === STATE.M1) {
    drawRing(ctx, cx, cy, radius * 0.52, COLORS.ink, 0.9, Math.max(1, radius * 0.1));
  } else if (state === STATE.M2) {
    drawRing(ctx, cx, cy, radius * 0.58, COLORS.macro, 0.42, Math.max(1, radius * 0.09));
  }
}

function drawDcAccent(ctx, state, cx, cy, radius) {
  ctx.fillStyle = state === STATE.MATURE ? COLORS.ink : COLORS.dc;
  ctx.globalAlpha = state === STATE.MATURE ? 0.95 : 0.7;
  ctx.beginPath();
  ctx.arc(cx, cy, Math.max(1.2, radius * 0.2), 0, TAU);
  ctx.fill();
}

function drawCd4Accent(ctx, cx, cy, radius) {
  const gradient = ctx.createRadialGradient(cx, cy, radius * 0.52, cx, cy, radius * 1.65);
  gradient.addColorStop(0, withAlpha(COLORS.cd4, '42'));
  gradient.addColorStop(1, withAlpha(COLORS.cd4, '00'));
  ctx.globalAlpha = 0.75;
  ctx.fillStyle = gradient;
  ctx.beginPath();
  ctx.arc(cx, cy, radius * 1.65, 0, TAU);
  ctx.fill();
}

function drawTregAccent(ctx, cx, cy, radius) {
  drawRing(ctx, cx, cy, radius * 1.35, COLORS.bgTissue, 0.72, Math.max(1, radius * 0.13));
}

function drawVesselAccent(ctx, cx, cy, radius) {
  drawRing(ctx, cx, cy, radius * 0.8, COLORS.ink, 0.44, Math.max(1, radius * 0.09));
}

function drawHealthyAccent(ctx, cx, cy, radius, flag) {
  if (!flag) {
    return;
  }
  ctx.strokeStyle = COLORS.bad;
  ctx.globalAlpha = 0.85;
  ctx.lineWidth = Math.max(1, radius * 0.1);
  ctx.beginPath();
  ctx.moveTo(cx - radius * 0.28, cy - radius * 0.6);
  ctx.lineTo(cx + radius * 0.06, cy - radius * 0.1);
  ctx.lineTo(cx - radius * 0.12, cy + radius * 0.48);
  ctx.stroke();
}

function bakeAccent(kind, state, variantKey, dpr) {
  const radius = SIZE_BUCKETS[variantSize(variantKey)];
  const surface = prepareSurface(radius, dpr);
  if (!surface.ctx) {
    return surface.canvas;
  }
  const ctx = surface.ctx;
  const cx = surface.center;
  const cy = surface.center;
  const detail = variantDetail(variantKey);
  const flag = variantFlag(variantKey);
  if (kind === KIND.TUMOR) {
    drawTumorAccent(ctx, state, cx, cy, radius, detail, flag);
  } else if (kind === KIND.CART) {
    drawCartAccent(ctx, state, cx, cy, radius, variantDirection(variantKey), flag);
  } else if (kind === KIND.CD8) {
    drawCd8Accent(ctx, state, cx, cy, radius);
  } else if (kind === KIND.NK) {
    drawNkAccent(ctx, cx, cy, radius, detail);
  } else if (kind === KIND.MACRO) {
    drawMacroAccent(ctx, state, cx, cy, radius);
  } else if (kind === KIND.DC) {
    drawDcAccent(ctx, state, cx, cy, radius);
  } else if (kind === KIND.CD4) {
    drawCd4Accent(ctx, cx, cy, radius);
  } else if (kind === KIND.TREG) {
    drawTregAccent(ctx, cx, cy, radius);
  } else if (kind === KIND.VESSEL) {
    drawVesselAccent(ctx, cx, cy, radius);
  } else if (kind === KIND.HEALTHY) {
    drawHealthyAccent(ctx, cx, cy, radius, flag);
  }
  return surface.canvas;
}

function canvasDestinationSize(variantKey) {
  return Math.ceil(SIZE_BUCKETS[normalizedSize(variantKey)] * 4.8 + 4);
}

/**
 * Returns a stable numeric cache key for one kind, state, and packed variant.
 * @param {number} kind
 * @param {number} state
 * @param {number} variantKey
 * @returns {number}
 */
export function spriteCacheKey(kind, state, variantKey) {
  return ((clampInt(kind, 0, 255) * 256 + clampInt(state, 0, 255)) * 4096)
    + (clampInt(variantKey, 0, VARIANT_MASK) & VARIANT_MASK);
}

/**
 * Maps a screen-space cell radius to the nearest reusable sprite-size bucket.
 * @param {number} radiusPx
 * @returns {number}
 */
export function spriteSizeBucket(radiusPx) {
  const radius = Number.isFinite(radiusPx) ? Math.max(0, radiusPx) : SIZE_BUCKETS[0];
  let best = 0;
  let bestDistance = Math.abs(radius - SIZE_BUCKETS[0]);
  for (let index = 1; index < SIZE_BUCKETS.length; index += 1) {
    const distance = Math.abs(radius - SIZE_BUCKETS[index]);
    if (distance < bestDistance) {
      best = index;
      bestDistance = distance;
    }
  }
  return best;
}

/**
 * Packs the bounded sprite traits used by the pre-baked cache into one integer.
 * @param {number} sizeBucket
 * @param {number} [phase]
 * @param {number} [direction]
 * @param {number} [detail]
 * @param {number} [flag]
 * @returns {number}
 */
export function spriteVariantKey(sizeBucket, phase = 0, direction = 0, detail = 0, flag = 0) {
  return clampInt(sizeBucket, 0, SIZE_BUCKETS.length - 1)
    | (clampInt(phase, 0, 3) << VARIANT_PHASE_SHIFT)
    | (clampInt(direction, 0, 7) << VARIANT_DIRECTION_SHIFT)
    | (clampInt(detail, 0, 3) << VARIANT_DETAIL_SHIFT)
    | (clampInt(flag, 0, 1) << VARIANT_FLAG_SHIFT);
}

/**
 * Builds a DPR-aware sprite cache with eager base combinations and one-time
 * dynamic accent baking.
 * @param {number} dpr
 * @returns {{
 *   get:function(number,number,number):object,
 *   getBody:function(number,number,number):object,
 *   getGlow:function(number,number,number):object,
 *   getAccent:function(number,number,number):object,
 *   destinationSize:function(number):number,
 *   invalidate:function():void
 * }}
 */
export function buildSpriteCache(dpr) {
  const safeDpr = Math.max(1, Math.min(2, Number.isFinite(dpr) ? dpr : 1));
  const bodies = new Map();
  const glows = new Map();
  const accents = new Map();

  function ensureBody(kind, state, variantKey) {
    const safeKind = normalizedKind(kind);
    const safeState = bodyState(safeKind, state);
    const safeVariant = bodyVariant(safeKind, variantKey);
    const key = spriteCacheKey(safeKind, safeState, safeVariant);
    if (!bodies.has(key)) {
      bodies.set(key, bakeBody(safeKind, safeState, safeVariant, safeDpr));
    }
  }

  function ensureGlow(kind, state, variantKey) {
    const safeKind = normalizedKind(kind);
    const safeState = glowState(safeKind, state);
    const safeVariant = glowVariant(variantKey);
    const key = spriteCacheKey(safeKind, safeState, safeVariant);
    if (!glows.has(key)) {
      glows.set(key, bakeGlow(safeKind, safeState, safeVariant, safeDpr));
    }
  }

  function ensureAccent(kind, state, variantKey) {
    const safeKind = normalizedKind(kind);
    const safeState = accentState(safeKind, state);
    const safeVariant = accentVariant(safeKind, state, variantKey);
    const key = spriteCacheKey(safeKind, safeState, safeVariant);
    if (!accents.has(key)) {
      accents.set(key, bakeAccent(safeKind, safeState, safeVariant, safeDpr));
    }
  }

  function getBody(kind, state, variantKey) {
    const safeKind = normalizedKind(kind);
    return bodies.get(spriteCacheKey(
      safeKind,
      bodyState(safeKind, state),
      bodyVariant(safeKind, variantKey),
    ));
  }

  function getGlow(kind, state, variantKey) {
    const safeKind = normalizedKind(kind);
    return glows.get(spriteCacheKey(
      safeKind,
      glowState(safeKind, state),
      glowVariant(variantKey),
    ));
  }

  function getAccent(kind, state, variantKey) {
    const safeKind = normalizedKind(kind);
    return accents.get(spriteCacheKey(
      safeKind,
      accentState(safeKind, state),
      accentVariant(safeKind, state, variantKey),
    ));
  }

  function get(kind, state, variantKey) {
    return getBody(kind, state, variantKey);
  }

  function warmBaseSprites() {
    for (let kindIndex = 0; kindIndex < KINDS.length; kindIndex += 1) {
      const kind = KINDS[kindIndex];
      const states = STATES_BY_KIND[kind];
      for (let stateIndex = 0; stateIndex < states.length; stateIndex += 1) {
        const state = states[stateIndex];
        for (let size = 0; size < SIZE_BUCKETS.length; size += 1) {
          const phaseCount = kind === KIND.TUMOR ? 4 : 1;
          for (let phase = 0; phase < phaseCount; phase += 1) {
            ensureBody(kind, state, spriteVariantKey(size, phase));
          }
          ensureGlow(kind, state, spriteVariantKey(size));
          if (kind === KIND.TUMOR) {
            for (let detail = 0; detail < 4; detail += 1) {
              ensureAccent(kind, state, spriteVariantKey(size, 0, 0, detail, 0));
              ensureAccent(kind, state, spriteVariantKey(size, 0, 0, detail, 1));
            }
          } else if (kind === KIND.CART) {
            ensureAccent(kind, state, spriteVariantKey(size));
            for (let direction = 0; direction < 8; direction += 1) {
              ensureAccent(kind, state, spriteVariantKey(size, 0, direction, 0, 1));
            }
          } else if (kind === KIND.NK) {
            for (let detail = 0; detail < 4; detail += 1) {
              ensureAccent(kind, state, spriteVariantKey(size, 0, 0, detail));
            }
          } else if (kind === KIND.HEALTHY) {
            ensureAccent(kind, state, spriteVariantKey(size));
            ensureAccent(kind, state, spriteVariantKey(size, 0, 0, 0, 1));
          } else {
            ensureAccent(kind, state, spriteVariantKey(size));
          }
        }
      }
    }
  }

  warmBaseSprites();

  return {
    get,
    getBody,
    getGlow,
    getAccent,
    destinationSize: canvasDestinationSize,
    invalidate() {
      bodies.clear();
      glows.clear();
      accents.clear();
      warmBaseSprites();
    },
  };
}
