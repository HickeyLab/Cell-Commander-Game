/**
 * hud.js owns the crisp, accessible DOM instrument readouts, throttled value
 * diffing, roster counts, visibility, and once-per-second live summary.
 */

import {
  COLORS,
  KIND,
  KIND_LABEL,
  PLACEABLE,
} from '../core/contracts.js';

/** The mark each cell type is drawn with, so the roster can be matched to the tissue field. */
const ROSTER_GLYPH = Object.freeze({
  [KIND.CART]: '⬢',
  [KIND.CD8]: '◕',
  [KIND.NK]: '◆',
  [KIND.MACRO]: '✣',
  [KIND.DC]: '✦',
  [KIND.CD4]: '●',
});

const ROSTER_COLOR = Object.freeze({
  [KIND.CART]: COLORS.cart,
  [KIND.CD8]: COLORS.cd8,
  [KIND.NK]: COLORS.nk,
  [KIND.MACRO]: COLORS.macro,
  [KIND.DC]: COLORS.dc,
  [KIND.CD4]: COLORS.cd4,
});

const HUD_INTERVAL_MS = 100;
const LIVE_INTERVAL_MS = 1000;
const INSTRUMENT_FONT = 'ui-monospace, \'SF Mono\', \'Cascadia Mono\', Menlo, Consolas, monospace';

function clockText(seconds) {
  const wholeSeconds = Math.max(0, Math.ceil(Number.isFinite(seconds) ? seconds : 0));
  const minutes = Math.floor(wholeSeconds / 60);
  const remainder = wholeSeconds % 60;
  return `${minutes}:${String(remainder).padStart(2, '0')}`;
}

function currentTimeMs() {
  if (globalThis.performance && typeof globalThis.performance.now === 'function') {
    return globalThis.performance.now();
  }
  return Date.now();
}

function readTumorCount(round) {
  if (Number.isFinite(round?.tumorCount)) {
    return Math.max(0, Math.round(round.tumorCount));
  }
  if (Number.isFinite(round?.stats?.tumorRemaining)) {
    return Math.max(0, Math.round(round.stats.tumorRemaining));
  }
  if (round?.world && typeof round.world.countOf === 'function') {
    return Math.max(0, Math.round(round.world.countOf(KIND.TUMOR)));
  }
  return 0;
}

function readPatientHealth(round) {
  const value = Number.isFinite(round?.patientHealth)
    ? round.patientHealth
    : round?.stats?.patientHealth;
  return Math.max(0, Math.min(100, Math.round(Number(value) || 0)));
}

function readCrsPercent(round) {
  const crs = Math.max(0, Math.min(1, Number(round?.crs) || 0));
  return Math.round(crs * 100);
}

function createMeter(doc, label, className) {
  const row = doc.createElement('div');
  row.className = `cc-hud__meter cc-hud__meter--${className}`;

  const heading = doc.createElement('span');
  heading.className = 'cc-hud__label';
  heading.textContent = label;
  row.appendChild(heading);

  const value = doc.createElement('output');
  value.className = 'cc-hud__value';
  value.setAttribute('aria-label', label);
  value.textContent = '0';
  row.appendChild(value);

  const track = doc.createElement('span');
  track.className = 'cc-hud__track';
  track.setAttribute('aria-hidden', 'true');
  const fill = doc.createElement('span');
  fill.className = 'cc-hud__fill';
  track.appendChild(fill);
  row.appendChild(track);

  return { row, value, fill };
}

function setTextIfChanged(node, displayed, key, nextValue) {
  if (displayed[key] === nextValue) {
    return;
  }
  displayed[key] = nextValue;
  node.textContent = nextValue;
}

function setWidthIfChanged(node, displayed, key, percent) {
  if (displayed[key] === percent) {
    return;
  }
  displayed[key] = percent;
  node.style.width = `${percent}%`;
}

/**
 * Creates a throttled DOM HUD with tumor, health, CRS, clock, roster, and an
 * aria-live plain-language summary.
 * @param {HTMLElement|null} rootEl
 * @returns {{update:function(object,object):void,setVisible:function(boolean):void}}
 */
export function makeHud(rootEl) {
  const doc = rootEl?.ownerDocument ?? null;
  if (!rootEl || !doc || typeof doc.createElement !== 'function') {
    return {
      update() {},
      setVisible() {},
    };
  }

  rootEl.classList.add('cc-hud');
  rootEl.setAttribute('aria-label', 'Treatment instrument panel');
  rootEl.style.fontFamily = INSTRUMENT_FONT;
  rootEl.style.fontVariantNumeric = 'tabular-nums';
  rootEl.style.letterSpacing = '0.08em';
  rootEl.style.textTransform = 'uppercase';

  const tumor = createMeter(doc, 'Tumor', 'tumor');
  const health = createMeter(doc, 'Patient', 'health');
  const crs = createMeter(doc, 'Cytokines', 'crs');
  const clock = createMeter(doc, 'Time', 'clock');
  rootEl.appendChild(tumor.row);
  rootEl.appendChild(health.row);
  rootEl.appendChild(crs.row);
  rootEl.appendChild(clock.row);

  const roster = doc.createElement('section');
  roster.className = 'cc-hud__roster';
  roster.setAttribute('aria-label', 'Your roster');
  const rosterHeading = doc.createElement('h2');
  rosterHeading.className = 'cc-hud__roster-heading';
  rosterHeading.textContent = 'Your roster';
  roster.appendChild(rosterHeading);

  const rosterValues = new Array(PLACEABLE.length);
  for (let index = 0; index < PLACEABLE.length; index += 1) {
    const kind = PLACEABLE[index];
    const item = doc.createElement('div');
    item.className = `cc-hud__roster-item cc-hud__roster-item--${kind}`;
    // Show each cell's own mark in its own colour beside the name. Without it a child has
    // no way to match a name here to a shape on the tissue field — the silhouettes are
    // deliberately distinct, but nothing said which was which.
    const mark = doc.createElement('span');
    mark.className = 'cc-hud__roster-mark';
    mark.setAttribute('aria-hidden', 'true');
    mark.textContent = ROSTER_GLYPH[kind] ?? '•';
    mark.style.color = ROSTER_COLOR[kind] ?? 'currentColor';
    const label = doc.createElement('span');
    label.className = 'cc-hud__roster-label';
    label.textContent = KIND_LABEL[kind];
    const value = doc.createElement('output');
    value.className = 'cc-hud__roster-value';
    value.setAttribute('aria-label', `${KIND_LABEL[kind]} count`);
    value.textContent = '0';
    item.appendChild(mark);
    item.appendChild(label);
    item.appendChild(value);
    roster.appendChild(item);
    rosterValues[index] = value;
  }
  rootEl.appendChild(roster);

  const live = doc.createElement('div');
  live.className = 'cc-hud__live';
  live.setAttribute('aria-live', 'polite');
  live.setAttribute('aria-atomic', 'true');
  live.style.position = 'absolute';
  live.style.width = '1px';
  live.style.height = '1px';
  live.style.padding = '0';
  live.style.margin = '-1px';
  live.style.overflow = 'hidden';
  live.style.clip = 'rect(0, 0, 0, 0)';
  live.style.whiteSpace = 'nowrap';
  live.style.border = '0';
  rootEl.appendChild(live);

  const displayed = Object.create(null);
  let lastUpdateMs = -Infinity;
  let lastLiveMs = -Infinity;
  let visible = !rootEl.hidden;

  function update(round, level) {
    const now = currentTimeMs();
    if (now - lastUpdateMs < HUD_INTERVAL_MS) {
      return;
    }
    lastUpdateMs = now;

    const tumorCount = readTumorCount(round);
    const patientHealth = readPatientHealth(round);
    const crsPercent = readCrsPercent(round);
    const elapsed = Math.max(0, Number(round?.timeSec) || 0);
    const clockSeconds = Number(level?.timeLimitSec) > 0
      ? Math.max(0, Number(level.timeLimitSec) - elapsed)
      : elapsed;

    setTextIfChanged(tumor.value, displayed, 'tumor', String(tumorCount));
    setTextIfChanged(health.value, displayed, 'health', String(patientHealth));
    setTextIfChanged(crs.value, displayed, 'crs', `${crsPercent}%`);
    setTextIfChanged(clock.value, displayed, 'clock', clockText(clockSeconds));
    setWidthIfChanged(
      tumor.fill,
      displayed,
      'tumorWidth',
      Math.max(0, Math.min(100, tumorCount)),
    );
    setWidthIfChanged(health.fill, displayed, 'healthWidth', patientHealth);
    setWidthIfChanged(crs.fill, displayed, 'crsWidth', crsPercent);
    const timeLimitSec = Number(level?.timeLimitSec) || 0;
    const clockPercent = timeLimitSec > 0
      ? Math.max(0, Math.min(100, (clockSeconds / timeLimitSec) * 100))
      : 100; // untimed (Sandbox): no countdown to show, so the bar just stays full
    setWidthIfChanged(clock.fill, displayed, 'clockWidth', clockPercent);

    for (let index = 0; index < PLACEABLE.length; index += 1) {
      const kind = PLACEABLE[index];
      const count = round?.world && typeof round.world.countOf === 'function'
        ? Math.max(0, Math.round(round.world.countOf(kind)))
        : 0;
      setTextIfChanged(rosterValues[index], displayed, `roster${kind}`, String(count));
    }

    if (now - lastLiveMs >= LIVE_INTERVAL_MS) {
      lastLiveMs = now;
      const summary = `${tumorCount} cancer cells left, patient health ${patientHealth}`;
      setTextIfChanged(live, displayed, 'live', summary);
    }
  }

  function setVisible(b) {
    const show = Boolean(b);
    if (visible === show) {
      return;
    }
    visible = show;
    rootEl.hidden = !show;
    rootEl.setAttribute('aria-hidden', show ? 'false' : 'true');
  }

  /**
   * Speak a one-off sentence through the HUD's existing live region.
   *
   * The coach strip is visual only; without this a screen-reader user would see none of it
   * and lose the entire diagnostic layer. Routing through the ONE region hud.js already owns
   * keeps a single announcer — two regions narrating the same round is what made the game
   * unusable with a screen reader before.
   *
   * The announcement briefly replaces the periodic tissue summary; the next update() restores
   * it, which is the desired behaviour: a coach message is more urgent than the running count.
   */
  function announce(message) {
    const text = String(message ?? '').trim();
    if (!text) return;
    setTextIfChanged(live, displayed, 'live', text);
  }

  return {
    update,
    setVisible,
    announce,
  };
}
