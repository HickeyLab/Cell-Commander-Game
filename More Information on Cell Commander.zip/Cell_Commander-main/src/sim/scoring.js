/**
 * scoring.js owns terminal outcome evaluation and the exact ordered score
 * calculation used by the results tally and deterministic leaderboard.
 */

import { OUTCOME } from '../core/contracts.js';
import { SCORE } from './params.js';

function clamp(value, lo, hi) {
  return Math.max(lo, Math.min(hi, value));
}

/**
 * Evaluate the current round against the level's terminal conditions.
 * @param {object} round
 * @param {object} level
 * @returns {number}
 */
export function evaluateOutcome(round, level) {
  if (round.outcome === OUTCOME.ABORTED) {
    return OUTCOME.ABORTED;
  }
  if (round.patientHealth <= 0) {
    return OUTCOME.LOSS_PATIENT_DIED;
  }
  if (round.tumorCount === 0) {
    return OUTCOME.WIN;
  }
  if (round.tumorCount >= level.tumorEscapeCap) {
    return OUTCOME.LOSS_TUMOR_ESCAPED;
  }
  if (level.timeLimitSec > 0 && round.timeSec >= level.timeLimitSec) {
    return OUTCOME.LOSS_TIMEOUT;
  }
  return OUTCOME.RUNNING;
}

/**
 * Compute the design-specified score and ordered animated tally.
 * @param {object} stats
 * @param {object} level
 * @returns {object}
 */
export function computeScore(stats, level) {
  const base = SCORE.base;
  const speedFraction = level.timeLimitSec > 0
    ? clamp(1 - stats.timeSec / level.timeLimitSec, 0, 1)
    : 0;
  const speed = Math.round(SCORE.speedWeight * speedFraction);
  const health = Math.round(SCORE.healthWeight * clamp(stats.patientHealth, 0, 100));
  const efficiency = Math.round(
    SCORE.efficiencyWeight * Math.max(0, stats.budgetUnspent),
  );
  const penalty = Math.round(
    SCORE.crsPenalty * Math.max(0, stats.peakCrs)
      + SCORE.healthyKilledPenalty * Math.max(0, stats.healthyKilled),
  );
  const total = Math.max(0, base + speed + health + efficiency - penalty);

  return {
    total,
    base,
    speed,
    health,
    efficiency,
    penalty,
    breakdown: [
      { label: 'Base score', value: base, good: true },
      { label: 'Fast cure', value: speed, good: true },
      { label: 'Patient health', value: health, good: true },
      { label: 'Budget saved', value: efficiency, good: true },
      { label: 'Treatment harm', value: -penalty, good: false },
    ],
  };
}
