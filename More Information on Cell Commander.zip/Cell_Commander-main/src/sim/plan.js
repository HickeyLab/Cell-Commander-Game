/**
 * plan.js owns treatment-plan construction, cost accounting, validation, and
 * placement edits performed during the setup phase outside the simulation loop.
 */

import {
  ANTIGEN_LIST,
  PLACEABLE,
  PLAN_DEFAULTS,
  WORLD_H,
  WORLD_W,
} from '../core/contracts.js';
import { COST } from './params.js';

function isPlaceable(kind) {
  return PLACEABLE.includes(kind);
}

function syncSpent(plan) {
  plan.spent = planCost(plan);
}

/**
 * Create an independent treatment plan with normalized defaults.
 * @param {object} [overrides]
 * @returns {object}
 */
export function makePlan(overrides = {}) {
  const sourcePlacements = overrides.placements || PLAN_DEFAULTS.placements;
  const placements = new Array(sourcePlacements.length);
  for (let i = 0; i < sourcePlacements.length; i += 1) {
    const source = sourcePlacements[i];
    placements[i] = { kind: source.kind, x: source.x, y: source.y };
  }

  const plan = {
    carTarget: overrides.carTarget ?? PLAN_DEFAULTS.carTarget,
    checkpoint: overrides.checkpoint ?? PLAN_DEFAULTS.checkpoint,
    il2: overrides.il2 ?? PLAN_DEFAULTS.il2,
    lymphodepletion: overrides.lymphodepletion ?? PLAN_DEFAULTS.lymphodepletion,
    placements,
    spent: 0,
    budget: overrides.budget ?? PLAN_DEFAULTS.budget,
  };
  syncSpent(plan);
  return plan;
}

/**
 * Calculate all cell and intervention costs in a plan.
 * @param {object} plan
 * @returns {number}
 */
export function planCost(plan) {
  let total = 0;
  for (let i = 0; i < plan.placements.length; i += 1) {
    total += COST[plan.placements[i].kind] || 0;
  }
  if (plan.checkpoint) total += COST.checkpoint;
  if (plan.il2) total += COST.il2;
  if (plan.lymphodepletion) total += COST.lymphodepletion;
  return total;
}

/**
 * Validate target, affordability, unlocks, and placement geometry for a level.
 * @param {object} plan
 * @param {object} level
 * @returns {{ok:boolean, errors:string[]}}
 */
export function validatePlan(plan, level) {
  const errors = [];
  if (!ANTIGEN_LIST.includes(plan.carTarget)) {
    errors.push('Choose a valid CAR-T target.');
  }
  if (!Number.isFinite(plan.budget) || plan.budget < 0) {
    errors.push('Plan budget must be a non-negative number.');
  }

  for (let i = 0; i < plan.placements.length; i += 1) {
    const placement = plan.placements[i];
    if (!isPlaceable(placement.kind)) {
      errors.push(`Placement ${i + 1} has an invalid cell kind.`);
    } else if (level.unlocks && !level.unlocks.includes(placement.kind)) {
      errors.push(`Placement ${i + 1} uses a locked cell kind.`);
    }
    if (!Number.isFinite(placement.x) || !Number.isFinite(placement.y)
      || placement.x < 0 || placement.x > WORLD_W
      || placement.y < 0 || placement.y > WORLD_H) {
      errors.push(`Placement ${i + 1} is outside the world.`);
    } else if (level.tumor) {
      const dx = placement.x - level.tumor.cx;
      const dy = placement.y - level.tumor.cy;
      if (dx * dx + dy * dy < level.tumor.spreadWu * level.tumor.spreadWu) {
        errors.push(`Placement ${i + 1} is inside the tumor mass.`);
      }
    }
  }

  for (const intervention of ['checkpoint', 'il2', 'lymphodepletion']) {
    if (plan[intervention] && level.unlocks && !level.unlocks.includes(intervention)) {
      errors.push(`${intervention} is locked for this level.`);
    }
  }

  const total = planCost(plan);
  if (total > plan.budget || total > level.budget) {
    errors.push('Treatment plan is over budget.');
  }
  plan.spent = total;
  return { ok: errors.length === 0, errors };
}

/**
 * Add one affordable in-bounds placeable cell to a treatment plan.
 * @param {object} plan
 * @param {number} kind
 * @param {number} x
 * @param {number} y
 * @returns {boolean}
 */
export function addPlacement(plan, kind, x, y) {
  // API-NOTE: This signature has no level argument, so tumor-mass overlap
  // cannot be checked here; validatePlan(plan, level) performs that check.
  if (!isPlaceable(kind) || !Number.isFinite(x) || !Number.isFinite(y)
    || x < 0 || x > WORLD_W || y < 0 || y > WORLD_H) {
    return false;
  }
  const cost = COST[kind] || 0;
  if (planCost(plan) + cost > plan.budget) {
    return false;
  }
  plan.placements.push({ kind, x, y });
  syncSpent(plan);
  return true;
}

/**
 * Remove the nearest placement within a world-space radius.
 * @param {object} plan
 * @param {number} x
 * @param {number} y
 * @param {number} radius
 * @returns {boolean}
 */
export function removePlacementAt(plan, x, y, radius) {
  const radiusSq = radius * radius;
  let nearest = -1;
  let nearestDistanceSq = radiusSq;
  for (let i = 0; i < plan.placements.length; i += 1) {
    const placement = plan.placements[i];
    const dx = placement.x - x;
    const dy = placement.y - y;
    const distanceSq = dx * dx + dy * dy;
    if (distanceSq <= nearestDistanceSq) {
      nearest = i;
      nearestDistanceSq = distanceSq;
    }
  }
  if (nearest < 0) {
    return false;
  }
  plan.placements.splice(nearest, 1);
  syncSpent(plan);
  return true;
}

/**
 * Remove every placed cell while preserving purchased interventions.
 * @param {object} plan
 * @returns {void}
 */
export function clearPlacements(plan) {
  plan.placements.length = 0;
  syncSpent(plan);
}
