/**
 * determinism.test.js proves seeded rounds replay byte-identical live-state hashes
 * and scores across 1200 ticks while a different seed changes the trajectory.
 */

import test from 'node:test';
import assert from 'node:assert/strict';

import {
  ANTIGEN,
  KIND,
  QUALITY,
  TICK_DT,
} from '../src/core/contracts.js';
import { createRound } from '../src/sim/engine.js';
import { makePlan } from '../src/sim/plan.js';
import { computeScore } from '../src/sim/scoring.js';

const level = {
  id: 'determinism-test',
  number: 98,
  name: 'Determinism Test',
  subtitle: 'Test',
  teaches: 'Test',
  budget: 200,
  timeLimitSec: 120,
  tumorEscapeCap: 200,
  tumor: {
    count: 36,
    cx: 650,
    cy: 400,
    spreadWu: 100,
    antigenMix: { [ANTIGEN.GREEN]: 0.7, [ANTIGEN.NONE]: 0.3 },
    mhcMean: 0.55,
    mhcSd: 0.18,
    pdl1Base: 0.08,
    pdl1Inducible: 0.7,
    divideTimeScale: 2,
  },
  healthy: { count: 12, antigen: ANTIGEN.NONE },
  vessels: [{ x: 80, y: 160 }, { x: 80, y: 640 }, { x: 1120, y: 400 }],
  tregs: 4,
  startingSuppress: 0.2,
  startingChemokine: 0.25,
  unlocks: [KIND.CART, KIND.CD8, KIND.NK, KIND.CD4],
  scienceCardId: 'test',
  hint: 'Test',
};

const plan = makePlan({
  budget: level.budget,
  carTarget: ANTIGEN.GREEN,
  checkpoint: true,
  placements: [
    { kind: KIND.CART, x: 430, y: 330 },
    { kind: KIND.CART, x: 430, y: 380 },
    { kind: KIND.CD8, x: 430, y: 430 },
    { kind: KIND.CD8, x: 430, y: 480 },
    { kind: KIND.NK, x: 380, y: 360 },
    { kind: KIND.NK, x: 380, y: 440 },
    { kind: KIND.CD4, x: 350, y: 400 },
  ],
});

function replay(seed) {
  const round = createRound({ level, plan, seed, quality: QUALITY.LOW });
  const hashes = [];
  for (let tick = 1; tick <= 1200; tick += 1) {
    round.tick(TICK_DT);
    if (tick === 1 || tick === 100 || tick === 600 || tick === 1200) {
      hashes.push(round.world.hash());
    }
  }
  return {
    hashes,
    score: computeScore(round.stats, level),
  };
}

test('same seed and plan match at ticks 1, 100, 600, and 1200 and score identically', () => {
  const first = replay(0x1234abcd);
  const second = replay(0x1234abcd);

  assert.deepEqual(first.hashes, second.hashes);
  assert.deepEqual(first.score, second.score);
});

test('a different seed produces a different live-state hash trajectory', () => {
  const first = replay(0x1234abcd);
  const different = replay(0x1234abce);

  assert.notDeepEqual(first.hashes, different.hashes);
});
