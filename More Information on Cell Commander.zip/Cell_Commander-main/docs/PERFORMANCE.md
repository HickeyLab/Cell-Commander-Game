# Performance — measured, not asserted

The claim "this runs on an iPad" is only worth something with numbers behind it. These were
produced by running the code, not by estimating.

Reproduce with:

```bash
npm run bench      # headless simulation cost, no renderer
npm run serve      # then measure real frame times in the browser
```

---

## 1. Simulation cost (headless, Node 24, desktop CPU)

`npm run bench` steps the real engine — fields, spatial hash, behaviors, physics, meters — with
no renderer attached. 600 ticks per row after a 100-tick warmup.

| Agents | Mean ms | p50 | p95 | p99 | Share of a 16.7 ms frame |
|---:|---:|---:|---:|---:|:---|
| 150 | 0.173 | 0.162 | 0.214 | 0.456 | 1.0% |
| 300 | 0.325 | 0.305 | 0.398 | 0.886 | 1.9% |
| 600 | 0.624 | 0.579 | 0.896 | 1.409 | 3.7% |
| 900 | 0.922 | 0.872 | 1.094 | 2.061 | 5.5% |

Cost is essentially linear in agent count, which is the point of the structure-of-arrays design:
no per-agent allocation, no per-agent object graph, no hash-map lookups in the hot loop.

At the maximum quality tier the simulation consumes **about a twentieth of the frame budget**.
Everything else is available to the renderer.

## 2. End-to-end frame rate (real browser, rendering included)

Measured with `requestAnimationFrame` deltas during live play at 1180×820, a full round in
progress with cells engaging, particles firing, and the HUD updating:

| Metric | Value |
|---|---|
| p50 frame time | 16.7 ms |
| p95 frame time | 16.8 ms |
| p99 frame time | 16.8 ms |
| Frame rate | **60 fps, locked** |

p50 and p99 are both pinned at the vsync interval, which means the browser is finishing every
frame with time left over rather than occasionally missing one. There is no long tail.

## 3. What this implies for a tablet

A current iPad is not 18× slower than a desktop, so the headroom above absorbs the difference
comfortably. But rather than rely on that argument, the game measures itself and adapts:

| Tier | Max agents | Field grid | Diffusion | Particles |
|---|---:|---|---|---|
| high | 900 | 60×42 | every frame | full |
| medium | 500 | 48×34 | every 2nd frame | reduced |
| low | 260 | 40×28 | every 3rd frame | off |

It drops a tier when the median frame time exceeds 20 ms for 90 consecutive frames, and raises
one when it stays under 11 ms for 300. The thresholds are deliberately asymmetric so the tier
cannot oscillate. An older iPad therefore gets fewer cells on screen rather than a slideshow,
and the drop is invisible to the player.

## 4. Why the research model cannot do this

| | Research ABM (`tumor-tcell`) | Cell Commander |
|---|---|---|
| Agents | ~1,200 | 150–900, adaptive |
| Per-agent step | full Vivarium process graph: schema resolution, port lookups, update merging | flat numeric update over typed arrays |
| Physics | pymunk rigid-body solver | 2 iterations of circle overlap relaxation |
| Fields | PDE solve | explicit 5-point stencil, 5 fields on a 60×42 grid, sub-stepped for stability |
| Timestep | 60 s of biological time | 1/60 s of wall-clock |
| Runtime | minutes to hours per run | real time |

The decisive difference is **cost per agent-step**, not agent count. A tablet could hold 1,200
agents in memory without difficulty; what it cannot do is evaluate a general-purpose process
graph plus a physics engine plus a PDE solve sixty times a second.

So the honest framing is not "we shrank the model until it fit." It is: the research model and
the game answer different questions. The research model is built to be *extended and audited* —
that generality is exactly what makes it slow. The game is built to run one fixed set of rules
as fast as possible. It reproduces the rules and their qualitative consequences; it does not
reproduce the research model's numerical output, and does not claim to.

## 5. Hot-loop rules that produced these numbers

Enforced by review and, where mechanically checkable, by `tests/architecture.test.js`:

- Agent state lives in parallel typed arrays indexed by slot. Dead slots go on a free list and
  are reused; nothing is ever spliced out of an array.
- No allocation inside per-agent loops — no object literals, no array literals, no closures.
  Scratch vectors are hoisted to module scope.
- The diffusion grid uses pre-allocated ping-pong buffers and allocates nothing per step.
- The spatial hash rebuilds into flat typed arrays each tick and grows only when capacity
  actually increases.
- Sprites are pre-rendered once per (kind, state) into offscreen canvases; the render loop only
  calls `drawImage`. **`ctx.shadowBlur` never appears in a per-frame path** — it is
  catastrophically slow in Safari, so the glow is baked into the sprite bitmap instead.
- Field overlays are drawn as a 60×42 `ImageData` scaled up by the browser, not as 2,520
  individual rectangles.
- The canvas backing store is capped at 2× device pixel ratio; beyond that, fill cost quadruples
  for no visible gain on a Retina display.
- Simulation runs on a fixed 60 Hz logical tick with an accumulator and a 3-tick catch-up cap,
  so it is frame-rate independent, deterministic, and cannot enter a spiral of death.
