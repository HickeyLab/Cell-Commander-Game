/**
 * world.js owns the fixed-capacity structure-of-arrays agent store, stable
 * slot recycling, deterministic snapshots, and order-independent state hashes.
 */

import {
  AGENT_COLUMNS,
  ANTIGEN,
  KIND,
  STATE,
} from '../core/contracts.js';
import { P, radiusFor } from './params.js';

const FNV_OFFSET = 0x811c9dc5;
const FNV_PRIME = 0x01000193;

function stateForKind(kind) {
  switch (kind) {
    case KIND.TUMOR:
      return STATE.PROLIFERATIVE;
    case KIND.CD8:
    case KIND.CART:
    case KIND.NK:
      return STATE.NAIVE;
    case KIND.MACRO:
      return STATE.M0;
    case KIND.DC:
      return STATE.IMMATURE;
    default:
      return STATE.ALIVE;
  }
}

function compareAgentRecords(a, b) {
  const length = a.length;
  for (let i = 0; i < length; i += 1) {
    if (a[i] !== b[i]) {
      return a[i] < b[i] ? -1 : 1;
    }
  }
  return 0;
}

function mix32(value) {
  let mixed = value >>> 0;
  mixed = Math.imul(mixed ^ (mixed >>> 16), 0x21f0aaad);
  mixed = Math.imul(mixed ^ (mixed >>> 15), 0x735a2d97);
  return (mixed ^ (mixed >>> 15)) >>> 0;
}

/**
 * Create a fixed-capacity SoA world whose dead slots are reused without splicing.
 * @param {{capacity:number, worldW:number, worldH:number, rng:object}} opts
 * @returns {object}
 */
export function makeWorld(opts) {
  const capacity = Math.max(0, opts.capacity | 0);
  const kind = new Uint8Array(capacity);
  const state = new Uint8Array(capacity);
  const alive = new Uint8Array(capacity);
  const x = new Float32Array(capacity);
  const y = new Float32Array(capacity);
  const vx = new Float32Array(capacity);
  const vy = new Float32Array(capacity);
  const radius = new Float32Array(capacity);
  const age = new Float32Array(capacity);
  const timer = new Float32Array(capacity);
  const hp = new Float32Array(capacity);
  const a0 = new Float32Array(capacity);
  const a1 = new Float32Array(capacity);
  const a2 = new Float32Array(capacity);
  const a3 = new Float32Array(capacity);
  const free = new Int32Array(capacity);
  const liveBuffer = new Int32Array(capacity);
  const floatScratch = new Float32Array(1);
  const bitsScratch = new Uint32Array(floatScratch.buffer);
  let freeCount = 0;
  let nextSlot = 0;
  let count = 0;

  function hashNumber(hash, value) {
    floatScratch[0] = value;
    const bits = bitsScratch[0];
    hash = Math.imul(hash ^ (bits & 0xff), FNV_PRIME);
    hash = Math.imul(hash ^ ((bits >>> 8) & 0xff), FNV_PRIME);
    hash = Math.imul(hash ^ ((bits >>> 16) & 0xff), FNV_PRIME);
    return Math.imul(hash ^ (bits >>> 24), FNV_PRIME) >>> 0;
  }

  function resetSlot(i, agentKind, worldX, worldY) {
    kind[i] = agentKind;
    state[i] = stateForKind(agentKind);
    alive[i] = 1;
    x[i] = worldX;
    y[i] = worldY;
    vx[i] = 0;
    vy[i] = 0;
    radius[i] = radiusFor(agentKind);
    age[i] = 0;
    timer[i] = agentKind === KIND.TUMOR ? P.tumor.divideTimeSec : 0;
    hp[i] = 1;
    a0[i] = 0;
    a1[i] = 0;
    a2[i] = 0;
    a3[i] = 0;

    if (agentKind === KIND.CD8 || agentKind === KIND.CART || agentKind === KIND.NK) {
      a0[i] = 1;
      a3[i] = -1;
    } else if (agentKind === KIND.MACRO) {
      a3[i] = -1;
    } else if (agentKind === KIND.DC) {
      a2[i] = ANTIGEN.NONE;
    } else if (agentKind === KIND.HEALTHY) {
      a0[i] = ANTIGEN.NONE;
    }
  }

  const world = {
    capacity,
    worldW: opts.worldW,
    worldH: opts.worldH,
    rng: opts.rng,
    kind,
    state,
    alive,
    x,
    y,
    vx,
    vy,
    radius,
    age,
    timer,
    hp,
    a0,
    a1,
    a2,
    a3,

    get count() {
      return count;
    },

    spawn(agentKind, worldX, worldY) {
      let i;
      if (freeCount > 0) {
        freeCount -= 1;
        i = free[freeCount];
      } else if (nextSlot < capacity) {
        i = nextSlot;
        nextSlot += 1;
      } else {
        return -1;
      }

      resetSlot(i, agentKind, worldX, worldY);
      count += 1;
      return i;
    },

    kill(i) {
      if (i < 0 || i >= nextSlot || alive[i] === 0) {
        return;
      }
      alive[i] = 0;
      state[i] = STATE.DEAD;
      hp[i] = 0;
      vx[i] = 0;
      vy[i] = 0;
      free[freeCount] = i;
      freeCount += 1;
      count -= 1;
    },

    compactIfNeeded() {
      while (nextSlot > 0 && alive[nextSlot - 1] === 0) {
        nextSlot -= 1;
      }
      freeCount = 0;
      for (let i = 0; i < nextSlot; i += 1) {
        if (alive[i] === 0) {
          free[freeCount] = i;
          freeCount += 1;
        }
      }
    },

    forEachAlive(fn) {
      for (let i = 0; i < nextSlot; i += 1) {
        if (alive[i] !== 0) {
          fn(i);
        }
      }
    },

    countOf(agentKind) {
      let total = 0;
      for (let i = 0; i < nextSlot; i += 1) {
        if (alive[i] !== 0 && kind[i] === agentKind) {
          total += 1;
        }
      }
      return total;
    },

    aliveIndices() {
      let length = 0;
      for (let i = 0; i < nextSlot; i += 1) {
        if (alive[i] !== 0) {
          liveBuffer[length] = i;
          length += 1;
        }
      }
      return liveBuffer.subarray(0, length);
    },

    snapshot() {
      const agents = [];
      for (let i = 0; i < nextSlot; i += 1) {
        if (alive[i] === 0) {
          continue;
        }
        agents.push([
          kind[i], state[i], x[i], y[i], vx[i], vy[i], radius[i],
          age[i], timer[i], hp[i], a0[i], a1[i], a2[i], a3[i],
        ]);
      }
      agents.sort(compareAgentRecords);
      return {
        capacity,
        worldW: opts.worldW,
        worldH: opts.worldH,
        count,
        rngState: opts.rng.state(),
        agents,
      };
    },

    hash() {
      let sum = 0;
      let xor = 0;
      let weighted = 0;

      for (let i = 0; i < nextSlot; i += 1) {
        if (alive[i] === 0) {
          continue;
        }
        let record = FNV_OFFSET;
        record = Math.imul(record ^ kind[i], FNV_PRIME) >>> 0;
        record = Math.imul(record ^ state[i], FNV_PRIME) >>> 0;
        record = hashNumber(record, x[i]);
        record = hashNumber(record, y[i]);
        record = hashNumber(record, vx[i]);
        record = hashNumber(record, vy[i]);
        record = hashNumber(record, radius[i]);
        record = hashNumber(record, age[i]);
        record = hashNumber(record, timer[i]);
        record = hashNumber(record, hp[i]);
        record = hashNumber(record, a0[i]);
        record = hashNumber(record, a1[i]);
        record = hashNumber(record, a2[i]);
        record = hashNumber(record, a3[i]);

        sum = (sum + record) >>> 0;
        xor = (xor ^ record) >>> 0;
        weighted = (weighted + Math.imul(record, record ^ 0x9e3779b9)) >>> 0;
      }

      return mix32(sum ^ mix32(xor) ^ mix32(weighted) ^ count);
    },
  };

  for (let i = 0; i < AGENT_COLUMNS.length; i += 1) {
    const column = AGENT_COLUMNS[i];
    if (!(world[column.name] instanceof globalThis[column.type])) {
      throw new TypeError(`world.${column.name} must be a ${column.type}`);
    }
  }

  return world;
}
