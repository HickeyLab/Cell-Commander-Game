/**
 * provenance-crosscheck.test.js — checks [MODEL] claims against the actual research model.
 *
 * tests/params.test.js verifies that every [MODEL] tag NAMES a source. That is necessary but
 * not sufficient, and the gap was real: a dendritic-cell radius was tagged [MODEL] with the
 * claim that "dendritic_cell.py uses the same 15 µm class as tumor", when that file actually
 * sets 10.0 µm (Morefield 2005). The tag named a file, so the test passed, and the claim was
 * still false. A reviewer found it in minutes.
 *
 * This file closes that gap for the load-bearing values by reading the research model's own
 * Python source and asserting the game's numbers really do follow from it.
 *
 * The research model is a SEPARATE repository, not vendored here. When it is not present
 * these tests skip rather than fail — a contributor without it should not see red — but on a
 * machine that has it, the claims are checked for real.
 */

import { test, describe } from 'node:test';
import assert from 'node:assert/strict';
import { readFile, access } from 'node:fs/promises';
import { join } from 'node:path';

import * as P from '../src/sim/params.js';
import { KIND, FIELD } from '../src/core/contracts.js';

const CANDIDATE_ROOTS = [
  'C:\\Users\\yn81\\Documents\\GitHub\\tumor-tcell',
  join(process.cwd(), '..', 'tumor-tcell'),
];

async function findResearchModel() {
  for (const root of CANDIDATE_ROOTS) {
    try {
      await access(join(root, 'tumor_tcell', 'processes', 't_cell.py'));
      return root;
    } catch { /* try the next candidate */ }
  }
  return null;
}

const ROOT = await findResearchModel();
const src = ROOT
  ? {
      tcell: await readFile(join(ROOT, 'tumor_tcell/processes/t_cell.py'), 'utf8'),
      tumor: await readFile(join(ROOT, 'tumor_tcell/processes/tumor.py'), 'utf8'),
      dc: await readFile(join(ROOT, 'tumor_tcell/processes/dendritic_cell.py'), 'utf8'),
      fields: await readFile(join(ROOT, 'tumor_tcell/processes/fields.py'), 'utf8'),
    }
  : null;

/**
 * Pull the numeric value of `'name': <expr>` out of a Python defaults dict.
 *
 * Values in the research model come in several shapes:
 *   'diameter': 7.5 * units.um            -> 7.5   (drop the unit factor)
 *   'cytotoxic_packet_threshold': 128 * 100 -> 12800 (keep the arithmetic)
 *   'PD1n_IFNg_production': 1.62e4 / 3600  -> 4.5
 *   'PD1n_migration': 10.0 * units.um / units.min -> 10.0
 * So: take everything up to the end of the entry, cut at the first `units` reference, then
 * evaluate what remains if it is pure arithmetic. Returns null when it cannot be read, and
 * callers assert on the value rather than silently treating null as a pass.
 */
function pyNumber(text, name) {
  const re = new RegExp(`['"]${name}['"]\\s*:\\s*([^,\\n#]+)`);
  const m = text.match(re);
  if (!m) return null;

  let expr = m[1];
  const unitsAt = expr.indexOf('units');
  if (unitsAt !== -1) expr = expr.slice(0, unitsAt);
  // Drop any dangling operator left behind by cutting the unit factor.
  expr = expr.trim().replace(/[*/+\-]\s*$/, '').trim();
  if (!expr || !/^[0-9.eE+\-*/ ()]+$/.test(expr)) return null;

  try {
    // eslint-disable-next-line no-new-func
    const value = Number(Function(`"use strict"; return (${expr});`)());
    return Number.isFinite(value) ? value : null;
  } catch {
    return null;
  }
}

describe('[MODEL] claims match the research model', () => {
  test('the research model is available (otherwise these checks skip)', (t) => {
    if (!ROOT) {
      t.skip('tumor-tcell repository not found on this machine — cross-checks skipped');
      return;
    }
    assert.ok(src.tcell.length > 0);
  });

  test('T cell diameter', (t) => {
    if (!ROOT) return t.skip('research model not present');
    const diameterUm = pyNumber(src.tcell, 'diameter');
    assert.equal(diameterUm, 7.5, 't_cell.py diameter changed upstream');
    // radius(wu) = (diameter/2) µm * WU_PER_UM
    assert.equal(P.radiusFor(KIND.CD8), (diameterUm / 2) * P.WU_PER_UM);
  });

  test('tumor cell diameter', (t) => {
    if (!ROOT) return t.skip('research model not present');
    const diameterUm = pyNumber(src.tumor, 'diameter');
    assert.equal(diameterUm, 15, 'tumor.py diameter changed upstream');
    assert.equal(P.radiusFor(KIND.TUMOR), (diameterUm / 2) * P.WU_PER_UM);
  });

  test('dendritic cell size is NOT claimed to be a research value', async (t) => {
    if (!ROOT) return t.skip('research model not present');
    const diameterUm = pyNumber(src.dc, 'diameter');
    assert.equal(diameterUm, 10, 'dendritic_cell.py diameter changed upstream');

    const modelRadius = (diameterUm / 2) * P.WU_PER_UM; // 10 wu
    const gameRadius = P.radiusFor(KIND.DC);
    if (gameRadius !== modelRadius) {
      // Deviating is allowed — claiming it came from the model is not.
      const params = await readFile(new URL('../src/sim/params.js', import.meta.url), 'utf8');
      const at = params.indexOf('[KIND.DC]');
      // Scope to the DC's OWN comment block: everything between the previous entry and this
      // one. A wider window picks up a neighbouring entry's [MODEL] tag and reports a false
      // failure — the radii are declared one after another, each with its own comment.
      const prevEntry = params.lastIndexOf('[KIND.', at - 1);
      const blockStart = prevEntry === -1 ? 0 : params.indexOf('\n', prevEntry) + 1;
      const block = params.slice(blockStart, at);
      assert.ok(
        !/\[MODEL\]/.test(block),
        `the dendritic-cell radius (${gameRadius} wu) differs from the research model ` +
          `(${modelRadius} wu) but is still tagged [MODEL]. Tag it [SCALED] and record the ` +
          `original value and the reason.`
      );
    }
  });

  test('cytotoxic packet threshold for tumor death', (t) => {
    if (!ROOT) return t.skip('research model not present');
    const threshold = pyNumber(src.tumor, 'cytotoxic_packet_threshold');
    assert.equal(threshold, 12800, 'tumor.py packet threshold changed upstream');
    assert.equal(P.TUMOR_DEATH_PACKETS, threshold);
  });

  test('CD8 kill rate follows from the transfer rate and the time compression', (t) => {
    if (!ROOT) return t.skip('research model not present');
    const perMin = pyNumber(src.tcell, 'cytotoxic_transfer_rate');
    assert.equal(perMin, 400, 't_cell.py transfer rate changed upstream');
    const expected = perMin * P.BIO_MIN_PER_GAME_SEC;
    assert.ok(
      Math.abs(P.killRateFor(KIND.CD8) - expected) < 1e-9,
      `CD8 kill rate ${P.killRateFor(KIND.CD8)} should equal ${perMin} packets/bio-min x ` +
        `${P.BIO_MIN_PER_GAME_SEC} bio-min/game-s = ${expected}`
    );
  });

  test('T cell migration speed', (t) => {
    if (!ROOT) return t.skip('research model not present');
    const umPerMin = pyNumber(src.tcell, 'PD1n_migration');
    assert.equal(umPerMin, 10.0, 't_cell.py PD1n_migration changed upstream');
    assert.ok(
      Math.abs(P.speedFor(KIND.CD8) - P.umPerMinToWuPerGameSec(umPerMin)) < 1e-9,
      'CD8 speed no longer derives from the cited migration value'
    );
  });

  test('exhausted T cells are half speed, per the PD1p/PD1n pair', (t) => {
    if (!ROOT) return t.skip('research model not present');
    const n = pyNumber(src.tcell, 'PD1n_migration');
    const p = pyNumber(src.tcell, 'PD1p_migration');
    assert.equal(p / n, P.EXHAUSTED_SPEED_FRAC);
  });

  test('the IFN-gamma production ratio is the cited tenfold', (t) => {
    if (!ROOT) return t.skip('research model not present');
    const hi = pyNumber(src.tcell, 'PD1n_IFNg_production');
    const lo = pyNumber(src.tcell, 'PD1p_IFNg_production');
    assert.ok(hi && lo, 'could not read IFNg production values');
    assert.ok(
      Math.abs(hi / lo - P.IFNG_PRODUCTION / P.IFNG_PRODUCTION_EXHAUSTED) < 1e-6,
      `research ratio is ${(hi / lo).toFixed(2)}x but the game uses ` +
        `${(P.IFNG_PRODUCTION / P.IFNG_PRODUCTION_EXHAUSTED).toFixed(2)}x`
    );
  });

  test('the PD-1 brake reproduces the cited tenfold cytotoxicity reduction', (t) => {
    if (!ROOT) return t.skip('research model not present');
    const hi = pyNumber(src.tcell, 'PD1n_cytotoxic_packets_max');
    const lo = pyNumber(src.tcell, 'PD1p_cytotoxic_packets_max');
    assert.equal(hi / lo, 10, 't_cell.py cytotoxic maxima changed upstream');
    const brakeAtFull = 1 / (1 + P.PD1_STRENGTH);
    assert.ok(
      Math.abs(1 / brakeAtFull - hi / lo) < 1e-9,
      `PD1_STRENGTH should make full engagement a ${hi / lo}x reduction`
    );
  });

  test('tumor division interval follows from the cited 24-hour division probability', (t) => {
    if (!ROOT) return t.skip('research model not present');
    const p24 = pyNumber(src.tumor, 'PDL1n_growth');
    assert.equal(p24, 0.6, 'tumor.py PDL1n_growth changed upstream');
    // Poisson: lambda = -ln(1 - p) per 24 h; mean interval = 1/lambda.
    const meanHours = 24 / -Math.log(1 - p24);
    const expectedGameSec = (meanHours * 60) / P.BIO_MIN_PER_GAME_SEC;
    assert.ok(
      Math.abs(P.TUMOR_DIVIDE_TIME_SEC - expectedGameSec) / expectedGameSec < 0.02,
      `TUMOR_DIVIDE_TIME_SEC is ${P.TUMOR_DIVIDE_TIME_SEC} but the cited arithmetic gives ` +
        `${expectedGameSec.toFixed(1)} game seconds`
    );
  });

  test('IFN-gamma diffuses faster than the debris field, as in the research rates', (t) => {
    if (!ROOT) return t.skip('research model not present');
    // fields.py gives IFNg 1.25e-3 cm^2/day and tumor_debris 0.0864 cm^2/day, so debris is
    // the FASTER of the two upstream. The game deliberately inverts this (debris is slowed to
    // keep a visible crumb trail) — assert the deviation is declared rather than accidental.
    assert.ok(/1\.25e-3/.test(src.fields), 'fields.py IFNg rate changed upstream');
    assert.ok(P.P.diffusion[FIELD.DEBRIS] < P.P.diffusion[FIELD.IFNG]);
  });
});
